//
//  KSConnect.swift
//  KobelcoService
//
//  Created by Guest L&T on 11/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSConnect: UIViewController {

    @IBOutlet weak var label_Message: UILabel!
    @IBOutlet weak var button_Connect: UIButton!
    @IBOutlet weak var button_WithoutWIFI: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUIComponents()
    }
    func setUpUIComponents() {
        self.label_Message.setLabelFontSize(fontStyle: REGULAR_FONT, fontSize: 14)
        self.button_Connect.setCustomButtonStyle(text: "Connect", image: "wifiIcon")
        self.button_WithoutWIFI.setCustomButtonStyle(text: "Without Connection", image: "")
    }
    @IBAction func connectButtonAction(_ sender: Any) {
        if let connectVC = MAIN_STORYBOARD.instantiateViewController(withIdentifier: "KSWIFISettings") as? KSWIFISettings {
            self.navigationController?.pushViewController(connectVC, animated: true)
        }
    }
    @IBAction func connectWithoutWIFIButtonAction(_ sender: Any) {
    }
    
}
