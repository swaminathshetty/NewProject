//
//  KSLogin.swift
//  KobelcoService
//
//  Created by Guest L&T on 09/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSLogin: UIViewController {

    @IBOutlet weak var label_UserID: UILabel!
    @IBOutlet weak var label_Password: UILabel!
    @IBOutlet weak var textField_UserID: UITextField!
    @IBOutlet weak var textField_Password: UITextField!
    @IBOutlet weak var button_SignIn: UIButton!
    
    private let loginVM: KSLoginVM
    
    init(loginVM: KSLoginVM) {
        self.loginVM = loginVM
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        self.loginVM = KSLoginVM(model: LoginModel())
        super.init(coder: coder)
    }
    override var preferredStatusBarStyle: UIStatusBarStyle {
          return .lightContent
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        setUpUIComponents()
        //Setting default Credentials
        self.textField_UserID.text = "Kobelco"
        self.textField_Password.text = "Password"
    }
    func setUpUIComponents() {
        self.label_UserID.setLabelFontSize(fontStyle: REGULAR_FONT, fontSize: 17)
        self.label_Password.setLabelFontSize(fontStyle: REGULAR_FONT, fontSize: 17)
        self.textField_UserID.setCustomTextFieldStyle()
        self.textField_Password.setCustomTextFieldStyle()
        self.button_SignIn.setCustomButtonStyle(text: "Sign In", image: "")
    }
    @IBAction func signInButtonTap(_ sender: Any) {
        do {
               _ = try loginVM.validateUserName(textField_UserID.text)
               _ = try loginVM.validatePassword(textField_Password.text)
               _ = try loginVM.validateUserNameAndPassword(textField_UserID.text, textField_Password.text)
            if let connectVC = MAIN_STORYBOARD.instantiateViewController(withIdentifier: "KSConnect") as? KSConnect {
                self.navigationController?.pushViewController(connectVC, animated: true)
            }
           } catch {
               SingletonManager.presentAlert(title: "Sign In", message: "\(error.localizedDescription)", viewController: self)
           }
    }
    
}
