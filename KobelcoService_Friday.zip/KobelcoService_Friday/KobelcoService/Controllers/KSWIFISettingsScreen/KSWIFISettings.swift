//
//  KSWIFISettings.swift
//  KobelcoService
//
//  Created by Guest L&T on 11/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSWIFISettings: UIViewController {

    @IBOutlet weak var button_WIFISettings: UIButton!
    @IBOutlet weak var label_SSIDName: UILabel!
    @IBOutlet weak var label_Start: UILabel!
    @IBOutlet weak var button_Start: UIButton!
    @IBOutlet weak var button_WithoutWIFI: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUIComponents()
    }
    func setUpUIComponents() {
        self.label_SSIDName.text = "Your phone is connected to Socket WI-FI"
        self.label_SSIDName.setLabelFontSize(fontStyle: REGULAR_FONT, fontSize: 14)
        self.label_Start.setLabelFontSize(fontStyle: REGULAR_FONT, fontSize: 14)
        self.button_WIFISettings.setCustomButtonStyle(text: "Wi-Fi Settings", image: "")
        self.button_Start.setCustomButtonStyle(text: "Start", image: "")
        self.button_WithoutWIFI.setCustomButtonStyle(text: "Without Connection", image: "")
    }
    @IBAction func wifiSettingsButtonAction(_ sender: Any) {
    }
    @IBAction func startButtonAction(_ sender: Any) {
    }
    @IBAction func withoutWifiButtonAction(_ sender: Any) {
    }
}
