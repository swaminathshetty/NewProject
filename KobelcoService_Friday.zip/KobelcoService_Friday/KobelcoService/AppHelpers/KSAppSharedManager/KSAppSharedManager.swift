//
//  KSAppSharedManager.swift
//  KobelcoService
//
//  Created by Guest L&T on 11/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
import UIKit

class SingletonManager {
    static let shared = SingletonManager()
    private init() { }
    
    class func presentAlert(title: String?, message: String?, viewController: UIViewController?) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        DispatchQueue.main.async(execute: {() -> Void in
            viewController?.present(alertController, animated: true, completion: nil)
            alertController.addAction(UIAlertAction(title: "OK", style: .default))
        })
    }
}
