//
//  KSDiagnosticNormal.swift
//  KobelcoService
//
//  Created by Guest L&T on 06/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSDiagnosticNormal: UIViewController {

    @IBOutlet weak var normalHeaderView: UIView!
    @IBOutlet weak var normalItemName: UIButton!
    @IBOutlet weak var normalHeaderValue: UILabel!
    @IBOutlet weak var normalHeaderUnit: UILabel!
    @IBOutlet weak var normalTableView: UITableView!
    @IBOutlet weak var normalAddButton: UIButton!
    @IBOutlet weak var normalStartButton: UIButton!
    @IBOutlet weak var normalHelpIcon: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        //self.setNavigationBarColorWithButtonTitle(buttonTitle: "Add parameters")// Place diagnostic selected item name
        loadDiagnosticSwitchUIComponents()
    }
    
    // Add custom values to diagnostic normal UI components.
    fileprivate func loadDiagnosticSwitchUIComponents() {
        self.normalHeaderView.layer.cornerRadius = 6
        self.normalItemName.setTitle("Item Name", for: .normal)
        self.normalHeaderValue.text = "Value"
        self.normalHeaderUnit.text = "Unit"
    }
    // Click on this button to add parameters from parameters screen.
    @IBAction func addNormalDiagnosticParameters(_ sender: Any) {
    }
    
    // Its a toggle operation, start and stop websocket value readings.
    @IBAction func normalDiagnosticStartAction(_ sender: Any) {
    }
    
    // Click on this to show help alertview.
    @IBAction func normalDiagnosticHelpAction(_ sender: Any) {
    }
}

// MARK:- Tableview delegates
extension KSDiagnosticNormal: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return rowCountZeroCheckDiagnosticNormal(tableViewName: tableView, rowCount: 4)
    }
    // Condition check for tableview row count and add tableview background with no records label if count == 0.
     fileprivate func rowCountZeroCheckDiagnosticNormal(tableViewName: UITableView, rowCount: Int) -> Int {
         if rowCount == 0 {
             DispatchQueue.main.async {
                 tableViewName.backgroundView =  KSSingletonManager.shared.nullDataFilesLabel()
             }
         } else {
             tableViewName.backgroundView = nil
         }
         return rowCount
     }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let normalCellIdentifier = "KSDiagnosticNormalCell"
        let normalCell = tableView.dequeueReusableCell(withIdentifier: normalCellIdentifier) as! KSDiagnosticNormalCell
        normalCell.configureDiagnosticNormalCell(normalTitle: "Item Name", normalValue: "-", normalUnit: "-")
        return normalCell
    }
}
