//
//  KSDiagnosticUpDown.swift
//  KobelcoService
//
//  Created by Guest L&T on 06/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSDiagnosticUpDown: UIViewController {

    @IBOutlet weak var upDownHeaderView: UIView!
    @IBOutlet weak var upDownHeaderTitle: UIButton!
    @IBOutlet weak var upDownHeaderValue: UILabel!
    @IBOutlet weak var upDownHeaderUnit: UILabel!
    @IBOutlet weak var upDownDiagnosticTableView: UITableView!
    @IBOutlet weak var addParametersUpDown: UIButton!
    @IBOutlet weak var startButtonUpDown: UIButton!
    @IBOutlet weak var upArrowUpDown: UIButton!
    @IBOutlet weak var downArrowUpDown: UIButton!
    @IBOutlet weak var helpButtonUpDown: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        //self.setNavigationBarColorWithButtonTitle(buttonTitle: "Add parameters")// Place diagnostic selected item name
        loadDiagnosticUpDownUIComponents()
    }
    
    // Add custom values to diagnostic updown UI components.
    fileprivate func loadDiagnosticUpDownUIComponents() {
        self.upDownHeaderView.layer.cornerRadius = 6
        self.upDownHeaderTitle.setTitle("Item Name", for: .normal)
        self.upDownHeaderValue.text = "Value"
        self.upDownHeaderUnit.text = "Unit"
    }
    
    // Click on this button to add parameters from parameters screen.
    @IBAction func addParametersForDiagnosticUpDown(_ sender: Any) {
    }
    
    // Its a toggle operation, start and stop websocket value readings.
    @IBAction func startActionForDiagnosticUpdown(_ sender: Any) {
    }
    
    // Click on this to perform up and down websocket request for value field.
    @IBAction func toggleUpAndDownArrowAction(_ sender: Any) {
    }
    
    // Click on this to show help alertview.
    @IBAction func helpButtonActionForDiagnosticUpDown(_ sender: Any) {
    }
}

// MARK:- Tableview delegates
extension KSDiagnosticUpDown: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return rowCountZeroCheckDiagnosticUpDown(tableViewName: tableView, rowCount: 4)
    }
    // Condition check for tableview row count and add tableview background with no records label if count == 0.
     fileprivate func rowCountZeroCheckDiagnosticUpDown(tableViewName: UITableView, rowCount: Int) -> Int {
         if rowCount == 0 {
             DispatchQueue.main.async {
                 tableViewName.backgroundView =  KSSingletonManager.shared.nullDataFilesLabel()
             }
         } else {
             tableViewName.backgroundView = nil
         }
         return rowCount
     }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let upDownCellIdentifier = "KSDiagnosticUpDownCell"
        let upDownCell = tableView.dequeueReusableCell(withIdentifier: upDownCellIdentifier) as! KSDiagnosticUpDownCell
        upDownCell.configureDiagnosticUpDownCell(upDownTitle: "Item Name", upDownValue: "-", upDownUnit: "-")
        return upDownCell
    }
}
