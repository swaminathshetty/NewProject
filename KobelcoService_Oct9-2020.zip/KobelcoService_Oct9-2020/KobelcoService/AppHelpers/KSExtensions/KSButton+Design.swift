//
//  KSButton+Design.swift
//  KobelcoService
//
//  Created by Guest L&T on 14/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
import UIKit

class KSCustomButton: UIButton {
    override init(frame: CGRect) {
        super.init(frame: frame)
        blueColorButton()
    }
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        blueColorButton()
    }
    //Gradient color for blueshade button
    func blueColorButton() {
        applyGradientColorToButton(topColor: #colorLiteral(red: 0.3333333333, green: 0.7803921569, blue: 0.6980392157, alpha: 1), bottomColor: #colorLiteral(red: 0.1843137255, green: 0.5882352941, blue: 0.6901960784, alpha: 1))
    }
}

//MARK:- White Gradient Button
class KSWhiteGradient: UIButton {
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpButton()
    }
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setUpButton()
    }
    func setUpButton() {
        applyGradientColorToButton(topColor: #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), bottomColor: #colorLiteral(red: 0.862745098, green: 0.8666666667, blue: 0.8705882353, alpha: 1))
        self.bringSubviewToFront(self.imageView!)
    }
}

//MARK:- Dashboard Buttons
class KSDashboardButton: UIButton {
    override init(frame: CGRect) {
        super.init(frame: frame)
        addCornorRadius()
    }
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        addCornorRadius()
    }
    // Dashboard squareboxes buttoms.
    fileprivate func addCornorRadius() {
        self.titleLabel?.font = UIFont.medium(ofSize: 15)
        self.titleLabel?.numberOfLines = 0
        self.titleLabel?.lineBreakMode = .byWordWrapping
        self.titleLabel?.textAlignment = .center
        self.titleLabel?.textColor = #colorLiteral(red: 0, green: 0.7005334496, blue: 0.723967135, alpha: 1)
        //layer.borderColor = #colorLiteral(red: 0, green: 0.5366052985, blue: 0.5635471344, alpha: 1)
        layer.cornerRadius = 6
        clipsToBounds = true
    }
}
