//
//  KSNavigationExtension.swift
//  KobelcoService
//
//  Created by Guest L&T on 29/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
import UIKit

//MARK:- NavigationController extension for new extensions
extension UINavigationController {
    //Get Wi-Fi controller index
    func getWiFiSettingsNavigationID() {
        let WiFiSettingsController = self.viewControllers
        KSSingletonManager.shared.WiFiSettingsNavigationID = WiFiSettingsController.count - 1
    }
    //Identify index of dashboard
    func getDashboardNavigationID() {
        let dashboardController = self.viewControllers
        KSSingletonManager.shared.dashboardNavigationID = dashboardController.count - 1
    }
    //Pop to Dashboard
    func popOverToDashboard(index: Int) {
        let dashboardController = self.viewControllers[index]
        self.popToViewController(dashboardController, animated: true)
    }
    //Pop to WIFI Screen
    func popOverToWiFiSettings(index: Int) {
        let WiFiSettingsController = self.viewControllers[index]
        WiFiSettingsController.navigationController?.isNavigationBarHidden = true
        self.popToViewController(WiFiSettingsController, animated: true)
    }
}
