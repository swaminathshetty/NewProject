//
//  KSParameterRegistrationCell.swift
//  KobelcoService
//
//  Created by Swaminath on 9/30/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSParameterRegistrationCell: UITableViewCell {

    @IBOutlet weak var view_SetParameterBG: UIView!
    @IBOutlet weak var button_SetCheckBox: UIButton!
    @IBOutlet weak var label_SetParameterTitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code.
        self.view_SetParameterBG.layer.cornerRadius = 6
        label_SetParameterTitle.font = UIFont.regular(ofSize: 15)
    }
    
    // MARK:- Custom method for binding values to the set parameter cell components
    
    func setParameterCellComponents(itemLists: [String], selecteditems: [String]) {
        self.label_SetParameterTitle.text = itemLists[button_SetCheckBox.tag]
        self.button_SetCheckBox.isSelected = false
        for item in selecteditems {
            let originalString = itemLists[button_SetCheckBox.tag]
            if originalString.contains(item) {
                self.button_SetCheckBox.isSelected = true
            }
        }
    }
}

class KSTheParameterCell: UITableViewCell {

    @IBOutlet weak var view_TheParameterBG: UIView!
    @IBOutlet weak var button_TheParametercheckBox: UIButton!
    @IBOutlet weak var label_TheParameterName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.view_TheParameterBG.layer.cornerRadius = 6
        label_TheParameterName.font = UIFont.regular(ofSize: 15)
    }
    
    // MARK:- Custom method for binding values to the parameter cell components
    
    func setTheParameterCellComponents(itemLists: [String], selecteditems: [String]) {
        self.label_TheParameterName.text = itemLists[button_TheParametercheckBox.tag]
        self.button_TheParametercheckBox.isSelected = false
        for item in selecteditems {
            let originalString = itemLists[button_TheParametercheckBox.tag]
            if originalString.contains(item) {
                self.button_TheParametercheckBox.isSelected = true
            }
        }
    }
}

//MARK:- Edit Parameter Cell
class KSEditParameterCell: UITableViewCell {

    @IBOutlet weak var viewEditParameterNameBG: UIView!
    @IBOutlet weak var checkBoxEditParameter: UIButton!
    @IBOutlet weak var editParameterName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.viewEditParameterNameBG.layer.cornerRadius = 6
        editParameterName.font = UIFont.regular(ofSize: 15)
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    // MARK:- Custom method for binding values to the edit parameter cell components
    func setEditParameterNameCell(theparametersList: [String], selecteditems: [String]) {
        self.editParameterName.text = theparametersList[checkBoxEditParameter.tag]
        self.checkBoxEditParameter.isSelected = false
        for item in selecteditems {
            let originalString = theparametersList[checkBoxEditParameter.tag]
            if originalString.contains(item) {
                self.checkBoxEditParameter.isSelected = true
            }
        }
    }
}

