//
//  KSMachineLearning.swift
//  KobelcoService
//
//  Created by Swaminath on 9/26/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

class KSMachineLearning: UIViewController {

    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var topItemName: UILabel!
    @IBOutlet weak var topValue: UILabel!
    @IBOutlet weak var topUnit: UILabel!
    @IBOutlet weak var unitsLabel: UILabel!
    @IBOutlet weak var learningStatusTableView: UITableView!
    var machineitemsList = [[String: Any]]()
    var machineFrameID = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Machine Learning Status")
        self.topView.layer.cornerRadius = 6
        self.topView.backgroundColor = HEADERVIEWCOLOR
        learningStatusTableView.estimatedRowHeight = 44
        learningStatusTableView.rowHeight = UITableView.automaticDimension
    }
}

// MARK: Tableview delegates
extension KSMachineLearning: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return machineitemsList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "KSMachineLearningCell"
        let MLStatusCell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as! KSMachineLearningCell
        MLStatusCell.configureMachineLearningStatusCellTitle(itemObject: machineitemsList[indexPath.row])
        return MLStatusCell
    }
}
