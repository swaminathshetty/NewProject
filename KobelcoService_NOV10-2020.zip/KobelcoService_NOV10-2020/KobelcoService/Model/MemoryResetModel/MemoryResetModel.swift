//
//  MemoryResetModel.swift
//  KobelcoService
//
//  Created by Guest L&T on 09/11/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation

// websocket request for memory reset switch type
struct ResetSocketRequest: Codable {
    let screenName: String!
    let frameType: String!
    let periodicity: Int!
}

// websocket request for memory reset submenu type read signals
struct ReadSubmenuSocketRequest: Codable {
    let screenName: String!
    let frameType: String!
    let readSignals: [String]!
    let periodicity: Int!
}

// websocket request for memory reset submenu type reset signals
struct ResetSubmenuSocketRequest: Codable {
    let screenName: String!
    let frameType: String!
    let resetSignals: [String]!
    let periodicity: Int!
}
