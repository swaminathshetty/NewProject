//
//  InjectorNumbersModel.swift
//  KobelcoService
//
//  Created by Guest L&T on 11/11/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation

// websocket request for injector part numbers write signals model
struct WriteInjectorsRequest: Codable {
    let screenName: String!
    let frameType: String!
    let writeValues: [String]!
    let periodicity: Int!
}
