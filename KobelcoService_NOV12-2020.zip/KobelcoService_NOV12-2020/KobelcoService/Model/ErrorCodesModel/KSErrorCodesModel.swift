//
//  KSErrorCodesModel.swift
//  KobelcoService
//
//  Created by Guest L&T on 16/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation

struct ErrorcodeResponse: Codable {
    let screenName: String
    let frameType: String
    let ecuErrorCodes: [String]?
    let dcuErrorCodes: [String]?
    var totalErrorCodes: [String]?
}
