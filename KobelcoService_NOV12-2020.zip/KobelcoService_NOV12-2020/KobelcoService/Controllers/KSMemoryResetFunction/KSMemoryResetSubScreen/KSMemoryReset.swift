//
//  KSMemoryReset.swift
//  KobelcoService
//
//  Created by Swaminath on 9/23/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

class KSMemoryReset: UIViewController {

    @IBOutlet weak var tableViewItems: UITableView!
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var buttonItemName: UIButton!
    @IBOutlet weak var labelValue: UILabel!
    @IBOutlet weak var labelUnit: UILabel!
    @IBOutlet weak var resetButton: UIButton!
    var itemsList = [[String: Any]]()
    var readItemIDs = [String]()
    var itemValues = [Int]()
    var selectedFrameID = ""
    fileprivate var selectedItem = String()
    fileprivate var arraySelectedItems = [String]()
    var navigationTitle = ""
    var memoryResetSubMenuCanSwipe = false

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.setNavigationBarColorWithButtonTitle(buttonTitle: navigationTitle)
        // Do any additional setup after loading the view.
        self.loadMemoryResetSubMenuUIComponents()
    }
    // AutoHide iPhoneX/Pro footer line.
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
    // Add customization code to UI Components.
    fileprivate func loadMemoryResetSubMenuUIComponents() {
        self.headerView.layer.cornerRadius = 6
        self.headerView.backgroundColor = HEADERVIEWCOLOR
        self.buttonItemName.isSelected = false
        self.appendEmptyValuesToItemListArray()
        tableViewItems.estimatedRowHeight = 55
        tableViewItems.rowHeight = UITableView.automaticDimension
        KSSingletonManager.shared.delegate = self
    }
    // By default append 0 in item values to display in tableview.
    fileprivate func appendEmptyValuesToItemListArray() {
        itemValues.removeAll(keepingCapacity: false)
        readItemIDs.removeAll(keepingCapacity: false)
        for item in itemsList {
            itemValues.append(0)
            guard let itemID = item["id"] as? String else { return }
            readItemIDs.append(itemID)
        }
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        memoryResetSubMenuCanSwipe = false
        self.appendEmptyValuesToItemListArray()
        self.configureMemoryResetSubViewGestureRecognizers()
        self.showLoader()
        KSSingletonManager.shared.connectWebSocket()
        self.perform(#selector(sendMemoryResetReadWebSocketRequest), with: self, afterDelay: 2)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        self.hideLoader()
    }
    // Action for all items selection.
    @IBAction func itemNameSelectAction(_ sender: UIButton) {
        arraySelectedItems.removeAll(keepingCapacity: false)
        if sender.isSelected {
            sender.isSelected = !sender.isSelected
        } else {
            sender.isSelected = !sender.isSelected
            storeAllSelectedItemID()
        }
        resetButton.isEnabled = arraySelectedItems.count > 0 ? true : false
        self.reloadTableView()
    }
    // called when header item all check mark tapped, to store all item IDs into a single array.
    fileprivate func storeAllSelectedItemID() {
        for item in itemsList {
            guard let itemID = item["id"] as? String else { return }
            arraySelectedItems.append(itemID)
        }
    }
    // Update/refresh tableviewlist with changes.
    func reloadTableView() {
        DispatchQueue.main.async {
            self.tableViewItems.reloadData()
        }
    }
    @IBAction func resetButtonAction(_ sender: Any) {
        if resetButton.isEnabled {
            showResetConfirmationAlert()
        }
    }
    // Confirmation Alert to reset items
    fileprivate func showResetConfirmationAlert() {
        let alert = UIAlertController(title: "Confirmation", message: MEMORYRESETMESSAGE, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: { _ in
        }))
        alert.addAction(UIAlertAction(title: "Reset", style: UIAlertAction.Style.destructive, handler: {(_: UIAlertAction!) in
            DispatchQueue.main.async {
                self.sendMemoryResetWebSocketRequest()
            }
        }))
        self.present(alert, animated: true, completion: nil)
    }
    // Send read websocket request to get item values.
    @objc fileprivate func sendMemoryResetReadWebSocketRequest() {
        self.showLoader()
        let readCommand = ReadSubmenuSocketRequest(screenName: "MemoryResetFunction", frameType: selectedFrameID, readSignals: readItemIDs, periodicity: 0)
        guard let readRequestData = try? JSONEncoder().encode(readCommand) else { return }
        KSSingletonManager.shared.sendCommand(format: readRequestData)
    }
    // Send single/multiple Reset command IDs in websocket request.
    fileprivate func sendMemoryResetWebSocketRequest() {
        self.showLoader()
        let resetCommand = ResetSubmenuSocketRequest(screenName: "MemoryResetFunction", frameType: selectedFrameID, resetSignals: arraySelectedItems, periodicity: 0)
        guard let resetRequestData = try? JSONEncoder().encode(resetCommand) else { return }
        KSSingletonManager.shared.sendCommand(format: resetRequestData)
    }
    // Reset items button selection to default
    fileprivate func resetItems() {
        self.arraySelectedItems.removeAll(keepingCapacity: false)
        self.buttonItemName.isSelected = (self.arraySelectedItems.count == self.itemsList.count) ? true : false
        self.reloadTableView()
        self.hideLoader()
    }
    // Configure gesture recognizer for UIView
    fileprivate func configureMemoryResetSubViewGestureRecognizers() {
        let swipeRightMR = UISwipeGestureRecognizer(target: self, action: #selector(respondToMRSubViewSwipeGesture))
        swipeRightMR.direction = .right
        self.view.addGestureRecognizer(swipeRightMR)
        
        let swipeLeftMR = UISwipeGestureRecognizer(target: self, action: #selector(respondToMRSubViewSwipeGesture))
        swipeLeftMR.direction = .left
        self.view.addGestureRecognizer(swipeLeftMR)
    }
    // Navigate to particular screen based on swipe direction.
    @objc func respondToMRSubViewSwipeGesture(gesture: UIGestureRecognizer) {
        if memoryResetSubMenuCanSwipe {
            if let swipeGesture = gesture as? UISwipeGestureRecognizer {
                 switch swipeGesture.direction {
                 case .right:
                    self.popOverToBackScreen(indexValue: KSSingletonManager.shared.memoryResetMainScreenID)
                 case .left:
                    self.navigation(to: Identifier.setValueWritingFunction)
                 default:
                     break
                 }
             }
        }
    }
}

// MARK: Tableview delegates
extension KSMemoryReset: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemsList.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "KSMemoryResetSubCell"
        let resetCell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as! KSMemoryResetSubCell
        resetCell.buttonItemName.tag = indexPath.row
        resetCell.configureResetCellTitle(itemObject: self.itemsList[indexPath.row], selecteditems: self.arraySelectedItems, itemValue: itemValues[indexPath.row])
        resetCell.buttonItemName.addTarget(self, action: #selector(itemNameButtonSelection(_ :)), for: .touchUpInside)
        return resetCell
    }
    @objc func itemNameButtonSelection(_ sender: UIButton) {
        let subMenuDict = itemsList[sender.tag]
        guard let subMenuID = subMenuDict["id"] as? String else { return }
        self.selectedItem = subMenuID
        if arraySelectedItems.contains(self.selectedItem) {
            if let index = arraySelectedItems.firstIndex(of: self.selectedItem) {
                self.selectedItem = "NOTSELECTED"
                arraySelectedItems.remove(at: index)
            }
        } else {
            self.arraySelectedItems.append(self.selectedItem)
        }
        buttonItemName.isSelected = (arraySelectedItems.count == itemsList.count) ? true : false
        resetButton.isEnabled = arraySelectedItems.count > 0 ? true : false
        self.reloadTableView()
    }
}

// MARK: WebSocket Response Delegate
extension KSMemoryReset: KSWebSocketDelegates {
    func webSocketStringResponse(response: String) {
        print("response: \(response)")
        guard let jsonDictionary = convertToDictionary(text: response) else { return }
        guard let screenTitle = jsonDictionary["screenName"] as? String else { return }
        if screenTitle == "MemoryResetFunction" {
            memoryResetSubMenuCanSwipe = true
            self.hideLoader()
            let resposneKeys = jsonDictionary.keys
            print("resposneKeys: \(resposneKeys)")
            // Condition check for 2 type responses. If response contains status key show success or failure message.
            if resposneKeys.contains("status") {
                guard let status = jsonDictionary["status"] as? Int else { return }
                // Checking success or fail status by 0(Fail) or 1(Success).
                // If status is Success, reset all UI elements and read again the updated values from Websocket response.
                // Show error message for failed status.
                if status == 1 {
                    self.resetItems()
                    DispatchQueue.main.async {
                        //self.sendMemoryResetReadWebSocketRequest()
                    }
                } else {
                    presentAlert(withTitle: "ERROR", message: MEMORYRESETFAILALERT)
                }
            } else {
                memoryResetSubMenuCanSwipe = true
                // Read values from the websocket response and update to tableview items.
                guard let readSignalValues = jsonDictionary["values"] as? [Int] else { return }
                self.itemValues = readSignalValues
            }
            DispatchQueue.main.async {
                self.tableViewItems.reloadData()
            }
        }
    }
    // Called when error connection in websocket communication
    func webSocketErrorConnection(message: String) {
        self.hideLoader()
        presentAlert(withTitle: "ERROR", message: message)
    }
    // Called when internet is disconnected or network not reachable.
    func internetConnectionNotAvailable() {
        self.hideLoader()
        presentAlertOKAction(withTitle: "ERROR", message: WIFIDISCONNECTEDMESSAGE) { (isOkTapped) in
            if isOkTapped {
                self.navigateToWiFiSettings()
            }
        }
    }
}
