//
//  KSDataComparision.swift
//  KobelcoService
//
//  Created by Swaminath on 9/27/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

class KSDataComparision: UIViewController {

    @IBOutlet weak var selectLogDataView: UIView!
    @IBOutlet weak var selectNormalDataView: UIView!
    @IBOutlet weak var logDataTableview: UITableView!
    @IBOutlet weak var normalDataTableview: UITableView!
    @IBOutlet weak var plotChartsButton: KSCustomButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
    }
}

// MARK: Tableview delegate
extension KSDataComparision: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == logDataTableview {
            return rowCountZeroCheckFunctionality(selectedTableView: tableView, rowCount: 4)
        } else {
            return rowCountZeroCheckFunctionality(selectedTableView: tableView, rowCount: 0)
        }
    }
    
    // Condition check for tableview row count and add tableview background with records label if count == 0.
    fileprivate func rowCountZeroCheckFunctionality(selectedTableView: UITableView, rowCount: Int) -> Int {
        if rowCount == 0 {
            DispatchQueue.main.async {
                self.nullDataFilesLabel(tableView: selectedTableView)
            }
        } else {
            selectedTableView.backgroundView = nil
        }
        return rowCount
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == logDataTableview { // Locally saved textfile log-data names
            let setParameterCell = tableView.dequeueReusableCell(withIdentifier: "KSParameterRegistrationCell") as! KSParameterRegistrationCell
            setParameterCell.buttonSetCheckBox.tag = indexPath.row
            setParameterCell.buttonSetCheckBox.addTarget(self, action: #selector(setDataParameterSelection(_ :)), for: .touchUpInside)
            return setParameterCell
        } else { // Webserver textfile normal-data names.
            let theParameterCell = tableView.dequeueReusableCell(withIdentifier: "KSTheParameterCell") as! KSTheParameterCell
            theParameterCell.buttonTheParametercheckBox.tag = indexPath.row
            theParameterCell.buttonTheParametercheckBox.addTarget(self, action: #selector(theDataParameterSelection(_ :)), for: .touchUpInside)
            return theParameterCell
        }
    }
        
    // Click on this button to check / uncheck the logdata files upto max 5 files.
    @objc func setDataParameterSelection(_ sender: UIButton) {
    }
    
    // Restrict to select more than 5 normal data files.
    @objc func theDataParameterSelection(_ sender: UIButton) {
    }
    
    // Called when there are no normal data files available.
    func nullDataFilesLabel(tableView: UITableView) {
        let noDataLabel = UILabel()
        noDataLabel.text = "No Records" // Displays this text when tableview is empty
        noDataLabel.textColor = TABLEVIEWLABELCOLOR
        noDataLabel.font = UIFont.medium(ofSize: 18)
        noDataLabel.textAlignment = .center
        tableView.backgroundView = noDataLabel
    }
}
