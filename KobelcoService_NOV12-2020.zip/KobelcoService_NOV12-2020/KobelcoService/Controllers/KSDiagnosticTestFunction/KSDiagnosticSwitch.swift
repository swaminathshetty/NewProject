//
//  KSDiagnosticSwitch.swift
//  KobelcoService
//
//  Created by Guest L&T on 06/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

class KSDiagnosticSwitch: UIViewController {

    @IBOutlet weak var switchHeaderView: UIView!
    @IBOutlet weak var switchItemName: UIButton!
    @IBOutlet weak var switchValue: UILabel!
    @IBOutlet weak var switchUnit: UILabel!
    @IBOutlet weak var diagnosticSwitchTableView: UITableView!
    @IBOutlet weak var switchAddButton: UIButton!
    @IBOutlet weak var switchTypeStartButton: UIButton!
    @IBOutlet weak var switchTypeHelpButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.setNavigationBarColorWithButtonTitle(buttonTitle: KSSingletonManager.shared.diagnosticNavigationTitle)
        loadDiagnosticSwitchUIComponents()
    }
    
    // Add custom values to diagnostic switch UI components.
    fileprivate func loadDiagnosticSwitchUIComponents() {
        self.switchHeaderView.layer.cornerRadius = 6
        self.switchItemName.setTitle("Item Name", for: .normal)
        self.switchValue.text = "Value"
        self.switchUnit.text = "Unit"
    }
    
    // Click on this button to add parameters from parameters screen.
    @IBAction func appParametersDiagnosticSwitchAction(_ sender: Any) {
        self.navigation(to: Identifier.diagnosticAddParameter)
    }
    
    // Its a toggle operation, start and stop websocket value readings.
    @IBAction func startDiagnosticSwitchAction(_ sender: Any) {
    }
    
    // Click on this to show help alertview.
    @IBAction func helpDiagnosticSwitchAction(_ sender: Any) {
        let switchExplanation = KSSingletonManager.shared.explanationDiagnostic
        let switchAttention = KSSingletonManager.shared.attentionDiagnostic
        DispatchQueue.main.async {
             self.presentAttributedStringAlert(message1: switchExplanation, message2: switchAttention) { (_ ) in
             }
         }
    }
}

// MARK: Tableview delegates
extension KSDiagnosticSwitch: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return rowCountZeroCheckDiagnosticSwicth(tableViewName: tableView, rowCount: 4)
    }
    // Condition check for tableview row count and add tableview background with no records label if count == 0.
     fileprivate func rowCountZeroCheckDiagnosticSwicth(tableViewName: UITableView, rowCount: Int) -> Int {
         if rowCount == 0 {
             DispatchQueue.main.async {
                 tableViewName.backgroundView =  KSSingletonManager.shared.nullDataFilesLabel()
             }
         } else {
             tableViewName.backgroundView = nil
         }
         return rowCount
     }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let switchCellIdentifier = "KSDiagnosticSwitchCell"
        let switchCell = tableView.dequeueReusableCell(withIdentifier: switchCellIdentifier) as! KSDiagnosticSwitchCell
        switchCell.configureDiagnosticSwitchCell(switchTitle: "Item Name", switchValue: "-", switchUnit: "-")
        return switchCell
    }
}
