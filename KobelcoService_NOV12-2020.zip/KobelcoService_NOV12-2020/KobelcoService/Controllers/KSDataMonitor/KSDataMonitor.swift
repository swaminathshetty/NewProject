//
//  KSDataMonitor.swift
//  KobelcoService
//
//  Created by Swaminath on 9/27/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

// Protocals for data monitor listview swipe up and down functionality.
@objc protocol KSMonitorDataDelegate {
    func addDataMonitorListChildController()
    func swipeToInitiateFromChildController()
    func removeMonitorListChildController()
}

class KSDataMonitor: UIViewController {

    @IBOutlet weak var footerViewDataMonitor: UIView!
    @IBOutlet weak var addParameterButton: UIButton!
    @IBOutlet weak var type1Type2Segment: UISegmentedControl!
    @IBOutlet weak var startPlotGraphbutton: UIButton!
    fileprivate var dataMonitorListView: KSDataMonitorList?
    fileprivate var isMonitorViewPresented: Bool = true
    fileprivate var listViewYPosition = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Data Monitor")
        self.navigationItem.hidesBackButton = true
        self.loadDataMonitorUIComponents()
        self.addDataMonitorListChildController()
    }

    // Set customs property values to data monitor UI components.
    fileprivate func loadDataMonitorUIComponents() {
        self.view.backgroundColor = .white
        self.type1Type2Segment.setSegmentTintColors()
        //listViewYPosition = Int(self.view.bounds.height - 240)
    }
    
    // MARK: Identify screen orientation
    // todo: set the updated frame for footer monitor list view.
    // fixme: Again add copyright footer label after screen orientation to avoid constraint problem.
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        if isMonitorViewPresented {
            self.removeMonitorListChildController()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                self.addDataMonitorListChildController()
            }
        }
    }
    
    // Called when user navigate to someother screen
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        isMonitorViewPresented = false
    }

    // Click on this button to add more parameters from paramters screen and plot a line graph.
    @IBAction func addDataParameterButtonTapped(_ sender: Any) {
        self.navigation(to: Identifier.addDataparameters)
    }
    // Display/plot graph based on type1/type2 segment selection.
    @IBAction func segmentControllerForType1AndType2(_ sender: Any) {
    }
    // Used to send websocket request with selected parameters and save records in textfile for every 50 ms interval
    @IBAction func startDataParameterButtonTapped(_ sender: UIButton) {
        if sender.isSelected { // Show alertsheet to select the following options(delete, save, save & send, send & delete).
            startPlotGraphbutton.setTitle("Start", for: .normal)
        } else { // Change button title to stop when user tap on start.
            startPlotGraphbutton.setTitle("Stop", for: .normal)
        }
        sender.isSelected = !sender.isSelected
    }
    
    // get monitor list view y position
    fileprivate func getListViewYPosition() {
        if listViewYPosition <= 68 {
            listViewYPosition = Int(UIDevice.current.orientation.isLandscape ? (self.view.bounds.height - 100) : (self.view.bounds.height - 240))
        } else {
            listViewYPosition = Int(UIDevice.current.orientation.isLandscape ? 40 : 68)
        }
    }
}

// MARK: Data monitor delegates
extension KSDataMonitor: KSMonitorDataDelegate {
    // Add data monitor list child controller as a subview.
    func addDataMonitorListChildController() {
        dataMonitorListView = MAINSTORYBOARD.instantiateViewController(withIdentifier: Identifier.dataMonitorList.rawValue) as? KSDataMonitorList
        self.addChild(dataMonitorListView!)
        dataMonitorListView?.monitorDelegate = self
        print("yposition: \(self.listViewYPosition)")
        listViewYPosition = Int(UIDevice.current.orientation.isLandscape ? (self.view.bounds.height - 100) : (self.view.bounds.height - 240))
        self.dataMonitorListView?.view.frame = CGRect(x: 0, y: CGFloat(self.listViewYPosition), width: self.view.bounds.width, height: self.view.bounds.height - CGFloat(listViewYPosition))
        self.view.addSubview((dataMonitorListView?.view)!)
        self.view.insertSubview((dataMonitorListView?.view)!, belowSubview: self.footerViewDataMonitor)
        dataMonitorListView?.didMove(toParent: self)
    }
        
    // Called when user tap on footer tableview child controller.
    // Used to swipe up and down the footer tableview list.
    func swipeToInitiateFromChildController() {
        self.getListViewYPosition()
        DispatchQueue.main.async {
            UIView.transition(with: (self.dataMonitorListView?.view)!, duration: 0.3, options: [.curveLinear], animations: {
            self.dataMonitorListView?.view.frame = CGRect(x: 0, y: CGFloat(self.listViewYPosition), width: self.view.bounds.width, height: self.view.bounds.height - CGFloat(self.listViewYPosition))
            }, completion: nil)
        }
    }
    
    // Called to remove child controller when user disappears from screen.
    func removeMonitorListChildController() {
        dataMonitorListView?.willMove(toParent: nil)
        dataMonitorListView?.view.removeFromSuperview()
        dataMonitorListView?.removeFromParent()
    }
}
