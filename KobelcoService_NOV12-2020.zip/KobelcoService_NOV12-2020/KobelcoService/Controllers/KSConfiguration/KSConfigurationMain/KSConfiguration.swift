//
//  KSConfiguration.swift
//  KobelcoService
//
//  Created by Swaminath on 9/27/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSConfiguration: UIViewController {

    @IBOutlet weak var tableViewConfiguration: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Configuration")
        self.navigationItem.hidesBackButton = true
        //Adding tableview corner radius and row height
        tableViewConfiguration.layer.cornerRadius = 8
        tableViewConfiguration.rowHeight = 55
    }
}

// MARK: KSConfigurationExtension for tableviewdelegates
extension KSConfiguration: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return CONFIGURATIONLIST.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: "Cell")
        cell.accessoryType = .disclosureIndicator
        cell.textLabel?.text = CONFIGURATIONLIST[indexPath.row]
        cell.textLabel?.font = UIFont.regular(ofSize: 15)
        cell.selectionStyle = .none
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //navigate to particular screens based on index selection
        switch indexPath.row {
        case 0:
            break
        case 1:
            break
        case 2:
            self.navigation(to: Identifier.normalData)
        case 3:
            self.navigation(to: Identifier.logData)
        case 4:
            self.navigation(to: Identifier.parameterRegistration)
        case 5:
            break
        default:
            break
        }
    }
}
