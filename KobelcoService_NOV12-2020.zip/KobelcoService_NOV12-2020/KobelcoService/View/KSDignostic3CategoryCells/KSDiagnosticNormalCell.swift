//
//  KSDiagnosticNormalCell.swift
//  KobelcoService
//
//  Created by Guest L&T on 08/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSDiagnosticNormalCell: UITableViewCell {

    @IBOutlet weak var normalBGView: UIView!
    @IBOutlet weak var normalCellTitle: UIButton!
    @IBOutlet weak var normalCellValue: UILabel!
    @IBOutlet weak var normalCellUnit: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.normalBGView.layer.cornerRadius = 6
    }
    
    // Update diagnostic normal type cell components.
    func configureDiagnosticNormalCell(normalObject: [String: Any]) {
        
    }
}

class KSDiagnosticSwitchCell: UITableViewCell {
    @IBOutlet weak var switchBGView: UIView!
    @IBOutlet weak var switchCellTitle: UIButton!
    @IBOutlet weak var switchToggleButton: UISwitch!
    @IBOutlet weak var switchCellUnit: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.switchBGView.layer.cornerRadius = 6
    }
    
    // Update diagnostic switch type cell components.
    func configureDiagnosticSwitchCell(switchTitle: String, switchValue: String, switchUnit: String) {
        
    }
}

class KSDiagnosticUpDownCell: UITableViewCell {
    @IBOutlet weak var upDownBGView: UIView!
    @IBOutlet weak var upDownCellTitle: UIButton!
    @IBOutlet weak var upDownTextField: UITextField!
    @IBOutlet weak var upDownCellUnit: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.upDownBGView.layer.cornerRadius = 6

    }
    
    // Update diagnostic updown type cell components.
    func configureDiagnosticUpDownCell(upDownTitle: String, upDownValue: String, upDownUnit: String) {
        
    }
}
