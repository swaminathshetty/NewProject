//
//  KSModelTypeCell.swift
//  KobelcoService
//
//  Created by Guest L&T on 21/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSModelTypeCell: UITableViewCell {

    @IBOutlet weak var labelTitle: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
}
