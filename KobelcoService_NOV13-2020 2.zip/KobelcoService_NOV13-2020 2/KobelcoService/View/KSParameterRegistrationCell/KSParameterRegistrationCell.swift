//
//  KSParameterRegistrationCell.swift
//  KobelcoService
//
//  Created by Swaminath on 9/30/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSParameterRegistrationCell: UITableViewCell {

    @IBOutlet weak var viewSetParameterBG: UIView!
    @IBOutlet weak var buttonSetCheckBox: UIButton!
    @IBOutlet weak var labelSetParameterTitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code.
        self.viewSetParameterBG.layer.cornerRadius = 6
        labelSetParameterTitle.font = UIFont.regular(ofSize: 15)
    }
    
    // MARK: Custom method for binding values to the set parameter cell components
    func setParameterCellComponents(itemLists: [String], selecteditems: [String]) {
        self.labelSetParameterTitle.text = itemLists[buttonSetCheckBox.tag]
        self.buttonSetCheckBox.isSelected = false
        for item in selecteditems {
            let originalString = itemLists[buttonSetCheckBox.tag]
            if originalString.contains(item) {
                self.buttonSetCheckBox.isSelected = true
            }
        }
    }
}

class KSTheParameterCell: UITableViewCell {

    @IBOutlet weak var viewTheParameterBG: UIView!
    @IBOutlet weak var buttonTheParametercheckBox: UIButton!
    @IBOutlet weak var labelTheParameterName: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.viewTheParameterBG.layer.cornerRadius = 6
        labelTheParameterName.font = UIFont.regular(ofSize: 15)
    }
    
    // MARK: Custom method for binding values to the parameter cell components
    func setTheParameterCellComponents(itemLists: [String], selecteditems: [String]) {
        self.labelTheParameterName.text = itemLists[buttonTheParametercheckBox.tag]
        self.buttonTheParametercheckBox.isSelected = false
        for item in selecteditems {
            let originalString = itemLists[buttonTheParametercheckBox.tag]
            if originalString.contains(item) {
                self.buttonTheParametercheckBox.isSelected = true
            }
        }
    }
}

// MARK: Edit Parameter Cell
class KSEditParameterCell: UITableViewCell {

    @IBOutlet weak var viewEditParameterNameBG: UIView!
    @IBOutlet weak var checkBoxEditParameter: UIButton!
    @IBOutlet weak var editParameterName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.viewEditParameterNameBG.layer.cornerRadius = 6
        editParameterName.font = UIFont.regular(ofSize: 15)
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    // MARK: Custom method for binding values to the edit parameter cell components
    func setEditParameterNameCell(theparametersList: [String], selecteditems: [String]) {
        self.editParameterName.text = theparametersList[checkBoxEditParameter.tag]
        self.checkBoxEditParameter.isSelected = false
        for item in selecteditems {
            let originalString = theparametersList[checkBoxEditParameter.tag]
            if originalString.contains(item) {
                self.checkBoxEditParameter.isSelected = true
            }
        }
    }
}
