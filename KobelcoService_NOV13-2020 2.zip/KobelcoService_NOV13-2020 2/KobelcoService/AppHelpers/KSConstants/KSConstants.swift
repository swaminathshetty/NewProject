//
//  KSConstants.swift
//  KobelcoService
//
//  Created by Guest L&T on 09/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
import UIKit
import EFAutoScrollLabel
// swiftlint:disable all

//MARK:- APP CONSTANTS
let MAINSCREENBOUNDS   = UIScreen.main.bounds
let SCREEN_WIDTH         = MAINSCREENBOUNDS.width
let SCREEN_HEIGHT        = MAINSCREENBOUNDS.height

let ISIPAD: Bool        = UIDevice.current.userInterfaceIdiom == .pad
let ISIPHONE: Bool      = UIDevice.current.userInterfaceIdiom == .phone

let ISIPHONE4ORLESS  = UIDevice.current.userInterfaceIdiom == .phone && MAINSCREENBOUNDS.height < 568.0
let ISIPHONE5          = UIDevice.current.userInterfaceIdiom == .phone && MAINSCREENBOUNDS.height == 568.0
let ISIPHONE6OR7        = UIDevice.current.userInterfaceIdiom == .phone && MAINSCREENBOUNDS.height == 667.0
let ISIPHONE6P7P      = UIDevice.current.userInterfaceIdiom == .phone && MAINSCREENBOUNDS.height == 736.0
let ISIPHONEX          = ISIPHONEXORXs ? ISIPHONEXORXs : ISIPHONEXrORXmax
let ISIPHONEXORXs    = fabs(Double(UIScreen.main.bounds.size.height) - Double(812)) < Double.ulpOfOne // 3x-2436,x,xs-812
let ISIPHONEXrORXmax = fabs(Double(UIScreen.main.bounds.size.height) - Double(896)) < Double.ulpOfOne //3x-2688-xmax-896,2x-1792-xr-896

let ISIPAD97          = UIDevice.current.userInterfaceIdiom == .pad && MAINSCREENBOUNDS.height == 1024.0
let ISIPADPRO          = UIDevice.current.userInterfaceIdiom == .pad && MAINSCREENBOUNDS.height == 1366.0

//let IS_IPAD_PORTRAIT = UIApplication.shared.statusBarOrientation == .portrait || UIApplication.shared.statusBarOrientation == .portraitUpsideDown

// Websocket IP Address
let WEBSOCKETIP = "10.9.40.186:8080" // Swami Machine IP Address
//let WEBSOCKETIP = "10.9.40.68:8080" // Rahul Machine IP Address
//let WEBSOCKETIP = "192.168.1.117:8080"  //192.168.1.100 //WFH
//let WEBSOCKETIP = "192.168.43.173:8080" // Swami Machine IP Address

let appDelegate = UIApplication.shared.delegate as? AppDelegate

// STORYBOARD
let MAINSTORYBOARD = UIStoryboard.init(name: "Main", bundle: nil)

// USERDEFAULTS
let KSUSERDEFAULTS = UserDefaults.standard

/// CUSTOM UIBUTTON CODE
let KSBUTTONCORNERRADIUS = 6.0

/// COLOR LITERALS
let VIEWBACKGROUNDCOLOR = #colorLiteral(red: 0, green: 0.6470588235, blue: 0.6666666667, alpha: 1)
let NAVIGATIONBARCOLOR = #colorLiteral(red: 0.007843137255, green: 0.4666666667, blue: 0.4901960784, alpha: 1)
let HEADERVIEWCOLOR = #colorLiteral(red: 0.2, green: 0.2470588235, blue: 0.2823529412, alpha: 1)
let TEXTFILEDTEXTCOLOR = #colorLiteral(red: 0.3215686275, green: 0.3215686275, blue: 0.3215686275, alpha: 1)
let TEXTFIELDBORDERCOLOR = #colorLiteral(red: 0.8509803922, green: 0.8509803922, blue: 0.8509803922, alpha: 1).cgColor
let TABLEVIEWLABELCOLOR = #colorLiteral(red: 0.9316138699, green: 0.8908390411, blue: 0.4764822346, alpha: 1)
let SEGMENTNORMALTINTCOLOR = #colorLiteral(red: 0, green: 0.6470588235, blue: 0.6666666667, alpha: 1)

/// NAVIGATIONBAR ITEM IMAGES
let NAVIGATIONLEFTBARLOGO = UIImage.init(named: "kobelcoLogo")
let NAVIGATIONRIGHTBARLOGO = UIImage.init(named: "dashboardIcon")
let NAVIGATIONDASHBOARDRIGHTBAR = UIImage.init(named: "wifiSettingIconDashboard")

/// STATIC JSON FILES
let MODELTYPEFILE = "KSModelTypes"
let ERRORCODESFILES = "KSErrorCodesJSON_V1.0"
let MATRIXDATAFILE = "CategoryWiseData"

// SCROLLABLE NAVIGATION TITLE
//let SCROLLLABEL = EFAutoScrollLabel(frame: CGRect(x: 0, y: 0, width: SCREEN_WIDTH - 100, height: 60))

// ALERT TITLE
let ALERTTITLESTRING = "Message"

/// ALERT MESSAGES
let LOGINSUCCESS = "You are successfully logged in as:"
let MRCONFIRMATIONALERT = "Are you sure you want to clear past records?"
let MEMORYRESETSUCCESSALERT = "Cleared Past records successfully."
let MEMORYRESETMESSAGE = "Are you sure you want to reset values?"
let MEMORYRESETFAILALERT = "Fail to clear past records, please try again after some time."
let COPYRIGHTTEXT = "Copyright© 2021 Kobelco Construction Machinery Co., Ltd."
let NOINTERNETMESSAGE = "Please connect to the proper WIFI network and try gain."
let WIFIDISCONNECTEDMESSAGE = "Your mobile device is disconnected from machine Wi-Fi. Reconnect again to start communication."
let QRCODECONFIRMATION = "Are you sure you want to change value?"
let QRCODEERRORTITLE = "Scanning not supported"
let QRCODEERRORMESSAGE = "Your device does not support scanning a code from an item. Please use a device with a camera."
let QRCODEMESSAGE = "Camera access required for scanning injector QRCode!"
let QRCODESUCESSMESSAGE = "Updated values successfully."
let QRCODEFAILMESSAGE = "Fail to update values, please try gain after some time."
let DIAGNOSTICSTOPSUCCESS = "Successfully stopped the operation."
let DIAGNSOTICSTOPFAIL = "Fail to stop the operation, please try gain once."
/// CONFIGURATION SCREEN MENU ITMES
let CONFIGURATIONLIST = ["Language Settings", "Unit Conversion", "Normal Data Management", "Log Data Management", "Parameter Registration(Favorite)", "Simultion Mode"]

/// NORMAL DATA SCREEN MENU ITEMS
let NORMALDATA_LIST = ["Normal Data Acquisition", "Normal Data Editing"]

/// COREDATA FILES
let SOCKETCOMMANDS_JSON = "KSWebSocketCommands"
let KSFILTYPE = "json"

