//
//  KSFreezeFrameData.swift
//  KobelcoService
//
//  Created by Guest L&T on 21/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSFreezeFrameData: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Freeze Frame Data(U1234)")
    }
}
