//
//  KSErrorCodeCell.swift
//  KobelcoService
//
//  Created by Swaminath on 9/16/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSErrorCodeCell: UITableViewCell {
    @IBOutlet weak var errorCodeBGView: UIView!
    @IBOutlet weak var label_ErrorCode: UILabel!
    @IBOutlet weak var label_Description: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configureCell(errorCode: String, description: String) {
        errorCodeBGView.clipsToBounds = true
        errorCodeBGView.layer.cornerRadius = 6
        label_ErrorCode.backgroundColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 0.8503050086)
        label_ErrorCode.text = errorCode
        label_ErrorCode.textColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        label_Description.textColor = #colorLiteral(red: 0.4549019608, green: 0.4549019608, blue: 0.4549019608, alpha: 1)
        label_Description.text = description
        label_Description.numberOfLines = 3
        label_Description.lineBreakMode = .byWordWrapping
    }
}
