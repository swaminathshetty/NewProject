//
//  KSParameterRegistrationCell.swift
//  KobelcoService
//
//  Created by Swaminath on 9/30/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSParameterRegistrationCell: UITableViewCell {

    @IBOutlet weak var BGView: UIView!
    @IBOutlet weak var button_CheckBox: UIButton!
    @IBOutlet weak var label_Title: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.BGView.layer.cornerRadius = 6
        label_Title.font = KS_LABEL_FONT_R
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func setUpCell(itemLists: [String], selecteditems: [String]) {
        self.label_Title.text = itemLists[button_CheckBox.tag]
        self.button_CheckBox.isSelected = false
        for item in selecteditems {
            let originalString = itemLists[button_CheckBox.tag]
            if originalString.contains(item) {
                self.button_CheckBox.isSelected = true
            }
        }
    }
}

class KSTheParameterCell: UITableViewCell {

    @IBOutlet weak var BGView: UIView!
    @IBOutlet weak var button_CheckBox: UIButton!
    @IBOutlet weak var label_Title: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.BGView.layer.cornerRadius = 6
        label_Title.font = KS_LABEL_FONT_R
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func setUpCell(itemLists: [String], selecteditems: [String]) {
        self.label_Title.text = itemLists[button_CheckBox.tag]
        self.button_CheckBox.isSelected = false
        for item in selecteditems {
            let originalString = itemLists[button_CheckBox.tag]
            if originalString.contains(item) {
                self.button_CheckBox.isSelected = true
            }
        }
    }
}

