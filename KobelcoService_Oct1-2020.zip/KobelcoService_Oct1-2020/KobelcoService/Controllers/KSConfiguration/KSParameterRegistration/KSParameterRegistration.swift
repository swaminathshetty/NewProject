//
//  KSParameterRegistration.swift
//  KobelcoService
//
//  Created by Guest L&T on 30/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSParameterRegistration: UIViewController {

    @IBOutlet weak var view_SetParameter: UIView!
    @IBOutlet weak var view_TheParameter: UIView!
    @IBOutlet weak var label_SetParameter: UILabel!
    @IBOutlet weak var label_TheParameter: UILabel!
    @IBOutlet weak var setParameterTableView: UITableView!
    @IBOutlet weak var theParameterTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view_SetParameter.layer.cornerRadius = 6
        self.view_TheParameter.layer.cornerRadius = 6
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Parameter Registration(Favorite)")
    }
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
}

extension KSParameterRegistration: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == setParameterTableView {
            let cellIdentifier = "KSParameterRegistrationCell"
            let setCell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as! KSParameterRegistrationCell
            setCell.button_CheckBox.tag = indexPath.row
            setCell.button_CheckBox.addTarget(self, action: #selector(setParameterSelection(_ :)), for: .touchUpInside)
            return setCell
        } else {
            let cellIdentifier = "KSTheParameterCell"
            let theCell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as! KSTheParameterCell
            theCell.button_CheckBox.tag = indexPath.row
            theCell.button_CheckBox.addTarget(self, action: #selector(theParameterSelection(_ :)), for: .touchUpInside)
            return theCell
        }
    }
    @objc func setParameterSelection(_ sender: UIButton) {
    }
    @objc func theParameterSelection(_ sender: UIButton) {
    }
    
}
