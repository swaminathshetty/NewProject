//
//  KSLogin.swift
//  KobelcoService
//
//  Created by Guest L&T on 09/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSLogin: UIViewController {

    @IBOutlet weak var label_UserID: UILabel!
    @IBOutlet weak var label_Password: UILabel!
    @IBOutlet weak var textField_UserID: UITextField!
    @IBOutlet weak var textField_Password: UITextField!
    @IBOutlet weak var button_SignIn: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        setUpUIComponents()
    }
    func setUpUIComponents() {
        self.label_UserID.font = KS_LABEL_FONT
        self.label_Password.font = KS_LABEL_FONT
        self.textField_UserID.setCustomTextFieldStyle()
        self.textField_Password.setCustomTextFieldStyle()
        self.button_SignIn.setCustomButtonStyle(text: "Sign In", image: "")
    }
    @IBAction func signInButtonTap(_ sender: Any) {
    }
    
}
