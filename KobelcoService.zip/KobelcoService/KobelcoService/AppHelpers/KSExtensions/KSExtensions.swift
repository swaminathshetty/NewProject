//
//  KSExtensions.swift
//  KobelcoService
//
//  Created by Guest L&T on 09/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
import UIKit

extension UIColor {
    convenience init(red: Int, green: Int, blue: Int) {
        assert(red >= 0 && red <= 255, "Invalid red component")
        assert(green >= 0 && green <= 255, "Invalid green component")
        assert(blue >= 0 && blue <= 255, "Invalid blue component")

        self.init(red: CGFloat(red) / 255.0, green: CGFloat(green) / 255.0, blue: CGFloat(blue) / 255.0, alpha: 1.0)
    }
    convenience init(rgb: Int) {
        self.init(
            red: (rgb >> 16) & 0xFF,
            green: (rgb >> 8) & 0xFF,
            blue: rgb & 0xFF
        )
    }
}
//Hexadecimal conversion
extension Data {
    var hexString: String {
        let hexString = map { String(format: "%02.2hhx", $0) }.joined()
        return hexString
    }
}

// UIFont Setting from hear to allover the Application
extension UIFont {
    class func regular(ofSize size: CGFloat) -> UIFont {
        return UIFont(name: "Lato-Regular", size: size)!
        }
    class func bold(ofSize size: CGFloat) -> UIFont {
        return UIFont(name: "Lato-Bold", size: size)!
    }
}

// UITextField Left & Right Padding
extension UITextField {
    func setCustomTextFieldStyle() {
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 20, height: self.frame.size.height))
        self.leftView = paddingView
        self.leftViewMode = .always
        self.layer.cornerRadius = CGFloat(20)
        self.layer.borderWidth = 1
        self.layer.borderColor = TEXTFIELD_BORDER_COLOR
        self.textColor = TEXTFILED_TEXT_COLOR
        self.font = KS_TEXTFILED_FONT
    }
    func setLeftPaddingPoints(_ amount:CGFloat) {
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.leftView = paddingView
        self.leftViewMode = .always
    }
    func setRightPaddingPoints(_ amount:CGFloat) {
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.rightView = paddingView
        self.rightViewMode = .always
    }
    func setDropdownIconToTextfieldRightView(imageName:String , delegate : Any) {
         let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 50, height: self.frame.size.height))
         paddingView.backgroundColor = .clear
         let imgView = UIImageView(frame: CGRect(x: 25, y: 20, width: 12, height: 8))
         imgView.image = UIImage(named: imageName)
         paddingView.addSubview(imgView)
         self.rightViewMode = .always
         self.rightView = paddingView
     }
}

// Email Validation String

extension String {
    func isValidEmail(email: String) -> Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
         var valid = NSPredicate(format: "SELF MATCHES %@", emailRegex).evaluate(with: email)
         if valid {
             valid = !email.contains("Invalid email id")
         }
         return valid
    }
}

// AlertView Controller
extension UIViewController {

    func presentAlert(withTitle title: String, message : String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default) { _ in
        }
        alertController.addAction(OKAction)
        self.present(alertController, animated: true, completion: nil)
    }
}

// Password Validation With min 8 chracters 1 uppercase 1 lowercase
extension String {
    func isValidPassword() -> Bool {
        //"^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[$@$!%*?&])[A-Za-z\\d$@$!%*?&]{10,}" - with spl char
        let regularExpression = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[a-zA-Z\\d]{8,}$"
        let passwordValidation = NSPredicate.init(format: "SELF MATCHES %@", regularExpression)

        return passwordValidation.evaluate(with: self)
    }
}

extension String {
    var isAlphanumeric: Bool {
        return !isEmpty && range(of: "[^a-zA-Z]", options: .regularExpression) == nil
    }
}

// Adding Shadow to UIVIEW
extension UIView {
    func addShadow() {
        self.layer.shadowColor = UIColor.black.cgColor
        self.layer.shadowOpacity = 0.5
        self.layer.shadowRadius = 4.0
        self.layer.cornerRadius = 10.0
        self.layer.shadowOffset = CGSize(width: 0, height: 0)
    }
    func addShadow1() {
        self.layer.shadowColor = UIColor.black.cgColor
        self.layer.shadowOpacity = 0.5
        self.layer.shadowRadius = 4.0
        self.layer.cornerRadius = 20.0
        self.layer.shadowOffset = CGSize(width: 0, height: 5)
    }
    func addBorderWidthAndCornerRadius(borderWidth:Int, borderColor:
         UIColor, cornerRadius:Int){
        self.layer.shadowColor = UIColor.black.cgColor
        self.layer.shadowOpacity = 0.2
        self.layer.shadowRadius = 2.0
        self.layer.borderWidth = CGFloat(borderWidth)
        self.layer.borderColor = borderColor.cgColor
        self.layer.cornerRadius = CGFloat(cornerRadius)
        self.layer.shadowOffset = CGSize(width: 0, height: 2)
    }
    func addBorderWidthAndCornerRadiusWithoutShadow(borderWidth:Float, borderColor:
    UIColor, cornerRadius:Float){
        self.layer.borderWidth = CGFloat(borderWidth)
        self.layer.borderColor = borderColor.cgColor
        self.layer.cornerRadius = CGFloat(cornerRadius)
    }
    func leftTransition(value:Float){
        let transitionLogo = CATransition()
        transitionLogo.duration = CFTimeInterval(value)
        transitionLogo.type = .moveIn
        transitionLogo.subtype = CATransitionSubtype.fromLeft
        transitionLogo.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)
        self.layer.add(transitionLogo, forKey: nil)
        
    }
    func rightTransition(value:Float){
        let transitionLogo = CATransition()
        transitionLogo.duration = CFTimeInterval(value)
        transitionLogo.type = .moveIn
        transitionLogo.subtype = CATransitionSubtype.fromRight
        transitionLogo.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)
        self.layer.add(transitionLogo, forKey: nil)
        
    }
    func topTransition(value:Float){
        let transitionLogo = CATransition()
        transitionLogo.duration = CFTimeInterval(value)
        transitionLogo.type = .moveIn
        transitionLogo.subtype = CATransitionSubtype.fromTop
        transitionLogo.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)
        self.layer.add(transitionLogo, forKey: nil)
        
    }
    func bottomTransition(value:Float){
        let transitionLogo = CATransition()
        transitionLogo.duration = CFTimeInterval(value)
        transitionLogo.type = .moveIn
        transitionLogo.subtype = CATransitionSubtype.fromBottom
        transitionLogo.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)
        self.layer.add(transitionLogo, forKey: nil)
        
    }
}

// UITextField Bottom layer Only

extension UITextField {
    func addBottomBorder() {
        let bottomLine = CALayer()
        if IS_IPHONE { // width changed 50 to self.frame.width
            bottomLine.frame = CGRect.init(x: 0.0, y: self.frame.height - 1, width: 50 , height: 1.0)

        } else {// width changed 100 to self.frame.width
           bottomLine.frame = CGRect.init(x: 0.0, y: self.frame.height - 1, width: 100, height: 1.0)
        }
        bottomLine.backgroundColor = UIColor.gray.cgColor
        self.borderStyle = UITextField.BorderStyle.none
        self.layer.addSublayer(bottomLine)
        self.font = UIFont.regular(ofSize: 14)
        //self.maxLength = 1
    }
        
    func addCornerRadiusAndBorderColor(cornerRadius:Int){
        self.layer.cornerRadius = CGFloat(cornerRadius)
        self.layer.borderWidth = 1
        self.layer.borderColor = UIColor.darkGray.cgColor
    }
}

//UIButton Corner Radius

extension UIButton{
    func setCustomButtonStyle(text: String, image: String) {
        self.setBackgroundImage(UIImage(named: "buttonEnabled"), for: .normal)
        self.setImage(UIImage(named: "image"), for: .normal)
        self.titleLabel?.font = KS_BUTTON_TITLE_R_FONT
        self.setTitle(text, for: .normal)
    }
    func addCornerRadius(cornerRadius:Float, borderWidth:Float, buttonBorderColor:UIColor){
        self.layer.cornerRadius = CGFloat(cornerRadius)
        self.layer.borderWidth = CGFloat(borderWidth)
        self.layer.borderColor = buttonBorderColor.cgColor
    }
    func setNormalAndSelectedRadioButtonImages(){
        self.setImage(UIImage(named: "Unchecked"), for: .normal)
        self.setImage(UIImage(named: "Checked"), for: .selected)
    }

}
extension UIImageView{
    func addCornerRadius(cornerRadius:Float, borderWidth:Float, buttonBorderColor:UIColor){
        self.layer.cornerRadius = CGFloat(cornerRadius)
        self.layer.borderWidth = CGFloat(borderWidth)
        self.layer.borderColor = buttonBorderColor.cgColor
    }
}

//UILabel Corner Radius

extension UILabel{
    
    func addCornerRadius(label:UILabel, cornerRadius:Float, borderWidth:Float, labelBorderColor:UIColor){
        label.layer.cornerRadius = CGFloat(cornerRadius)
        label.layer.borderWidth = CGFloat(borderWidth)
        label.layer.borderColor = labelBorderColor.cgColor
    }
}

// For calculating the count

extension String {
    var length: Int { return self.count }
}

// Replacing the string
extension String
{
    func replace(target: String, withString: String) -> String
    {
        return self.replacingOccurrences(of: target, with: withString, options: NSString.CompareOptions.literal, range: nil)
    }
}

// Adding Done Button For textfields & textviews

extension UIToolbar {

    func ToolbarPiker(mySelect : Selector) -> UIToolbar {
        let toolBar = UIToolbar()
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor.black
        toolBar.sizeToFit()

        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.plain, target: self, action: mySelect)
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)

        toolBar.setItems([spaceButton, doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true

        return toolBar
    }

}

// Date Picker Formater

extension Date {
    static let formatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "DD/MM/YYYY"
        return formatter
    }()
    var formatted: String {
        return Date.formatter.string(from: self)
    }
}

// UITextField Check empty or not

extension UITextField {
    var isEmpty: Bool {
        return text?.isEmpty ?? true
    }
}

// for checking white spaces

extension String {
    var containsWhitespace : Bool {
        return(self.rangeOfCharacter(from: .whitespacesAndNewlines) != nil)
    }
}

//You can change the .whitespacesAndNewlines with any other CharacterSet like this:

extension String {
    var containsDigits : Bool {
        return(self.rangeOfCharacter(from: CharacterSet.decimalDigits) != nil)
    }
}

// Removes White spaces

extension String {
    func removingWhitespaces() -> String {
        return components(separatedBy: .whitespaces).joined()
    }
}

// Mobile Number Validation

extension String {
    var isValidContact: Bool {
        let phoneNumberRegex = "^[6-9]\\d{9}$"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", phoneNumberRegex)
        let isValidPhone = phoneTest.evaluate(with: self)
        return isValidPhone
    }
}

// Set Text Field Length

private var __maxLengths = [UITextField: Int]()
extension UITextField {
    @IBInspectable var maxLength: Int {
        get {
            guard let l = __maxLengths[self] else {
                return 150 // (global default-limit. or just, Int.max)
            }
            return l
        }
        set {
            __maxLengths[self] = newValue
            addTarget(self, action: #selector(fix), for: .editingChanged)
        }
    }
    @objc func fix(textField: UITextField) {
        let t = textField.text
        textField.text = t?.safelyLimitedTo(length: maxLength)
    }
}

extension String {
    func safelyLimitedTo(length n: Int) -> String {
        if (self.count <= n) {
            return self
        }
        return String( Array(self).prefix(upTo: n) )
    }
}

// Adding image to text field

extension UITextField {

    enum Direction {
        case Left
        case Right
    }

    // add image to textfield
    func withImage(direction: Direction, image: UIImage, colorSeparator: UIColor, colorBorder: UIColor) {
        let mainView = UIView(frame: CGRect(x: 0, y: 0, width: 50, height: 45))
        mainView.layer.cornerRadius = 5

        let view = UIView(frame: CGRect(x: 0, y: 0, width: 50, height: 45))
        view.backgroundColor = .white
        view.clipsToBounds = true
        view.layer.cornerRadius = 5
        view.layer.borderWidth = CGFloat(0.5)
        view.layer.borderColor = colorBorder.cgColor
        mainView.addSubview(view)

        let imageView = UIImageView(image: image)
        imageView.contentMode = .scaleAspectFit
        imageView.frame = CGRect(x: 12.0, y: 10.0, width: 24.0, height: 24.0)
        view.addSubview(imageView)

        let seperatorView = UIView()
        seperatorView.backgroundColor = colorSeparator
        mainView.addSubview(seperatorView)

        if(Direction.Left == direction) { // image left
            seperatorView.frame = CGRect(x: 45, y: 0, width: 5, height: 45)
            self.leftViewMode = .always
            self.leftView = mainView
        } else { // image right
            seperatorView.frame = CGRect(x: 0, y: 0, width: 5, height: 45)
            self.rightViewMode = .always
            self.rightView = mainView
        }

        self.layer.borderColor = colorBorder.cgColor
        self.layer.borderWidth = CGFloat(0.5)
        self.layer.cornerRadius = 5
    }

}

// Remove White spaces

extension String {
    func removingLeadingSpaces() -> String {
        guard let index = firstIndex(where: { !CharacterSet(charactersIn: String($0)).isSubset(of: .whitespaces) }) else {
            return self
        }
        return String(self[index...])
    }
}

// Convert json string to Array

func convertToDictionary(text: String) -> [String: Any]? {
    if let data = text.data(using: .utf8) {
        do {
            return try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
        } catch {
            //print(error.localizedDescription)
        }
    }
    return nil
}
extension UIViewController {
    public func clearAllTexts() {
        for view in self.view.subviews {
            if view is UITextField {
                let field: UITextField = view as! UITextField
                field.text = ""
            }
        }
    }
}

extension CATransition{
    
}
