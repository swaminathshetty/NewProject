//
//  KSErrorCodeDisplay.swift
//  KobelcoService
//
//  Created by Guest L&T on 14/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSErrorCodeDisplay: UIViewController {
    @IBOutlet weak var label_ErrorCodeDisplay: UILabel!
    @IBOutlet weak var segmentController: UISegmentedControl!
    @IBOutlet weak var button_Current: UIButton!
    @IBOutlet weak var button_Past: UIButton!
    @IBOutlet weak var button_Reset: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        setNavigationBarButtonItemAction()
        self.segmentController.layer.cornerRadius = 6
        button_Current.addButtonCornerRadius(cornerRadius: 20, borderWidth: 1, buttonBorderColor: #colorLiteral(red: 0, green: 0.5366052985, blue: 0.5635471344, alpha: 1), backgroundColor: #colorLiteral(red: 0.03890705109, green: 0.7312862873, blue: 0.7512782216, alpha: 1), textColor: #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1))
        self.perform(#selector(disableResetButton), with: button_Reset, afterDelay: 0.2)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarColorAndItems()
    }
    func setNavigationBarButtonItemAction() {
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: NAVIGATION_RIGHTBAR_LOGO, style: .plain, target: self, action: #selector(moveToDashboard))
    }
    @objc func moveToDashboard() {
        self.navigationController?.popViewController(animated: true)
        //self.navigation(to: Identifier.dashboardScreen)
    }
    @IBAction func currentButtonAction(_ sender: Any) {
        button_Current.addButtonCornerRadius(cornerRadius: 20, borderWidth: 1, buttonBorderColor: #colorLiteral(red: 0, green: 0.5366052985, blue: 0.5635471344, alpha: 1), backgroundColor: #colorLiteral(red: 0.03890705109, green: 0.7312862873, blue: 0.7512782216, alpha: 1), textColor: #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1))
        self.perform(#selector(resetPastButton), with: button_Past, afterDelay: 0.2)
        self.perform(#selector(disableResetButton), with: button_Reset, afterDelay: 0.3)
        self.button_Reset.isEnabled = false
    }
    @IBAction func pastButtonAction(_ sender: Any) {
        self.button_Past.addButtonCornerRadius(cornerRadius: 20, borderWidth: 1, buttonBorderColor: #colorLiteral(red: 0, green: 0.5366052985, blue: 0.5635471344, alpha: 1), backgroundColor: #colorLiteral(red: 0.03890705109, green: 0.7312862873, blue: 0.7512782216, alpha: 1), textColor: #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1))
        self.perform(#selector(resetCurrentButton), with: button_Current, afterDelay: 0.2)
        self.perform(#selector(enableResetButton), with: button_Reset, afterDelay: 0.3)
        self.button_Reset.isEnabled = true
    }
    @IBAction func resetButtonTapAction(_ sender: Any) {
        self.button_Reset.addButtonCornerRadius(cornerRadius: 0, borderWidth: 0, buttonBorderColor: .clear, backgroundColor: .clear, textColor: #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1))
    }
    
    //Perform selector button selection
    @objc func resetCurrentButton() {
        self.button_Current.addButtonCornerRadius(cornerRadius: 0, borderWidth: 0, buttonBorderColor: .clear, backgroundColor: .clear, textColor: #colorLiteral(red: 0.03890705109, green: 0.7312862873, blue: 0.7512782216, alpha: 1))
    }
    @objc func resetPastButton() {
        self.button_Past.addButtonCornerRadius(cornerRadius: 0, borderWidth: 0, buttonBorderColor: .clear, backgroundColor: .clear, textColor: #colorLiteral(red: 0.03890705109, green: 0.7312862873, blue: 0.7512782216, alpha: 1))
    }
    @objc func disableResetButton() {
        self.button_Reset.addButtonCornerRadius(cornerRadius: 0, borderWidth: 0, buttonBorderColor: .clear, backgroundColor: .clear, textColor: #colorLiteral(red: 0.5960784314, green: 0.5960784314, blue: 0.5960784314, alpha: 1))
    }
    @objc func enableResetButton() {
        self.button_Reset.addButtonCornerRadius(cornerRadius: 0, borderWidth: 0, buttonBorderColor: .clear, backgroundColor: .clear, textColor: #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1))
    }
    @IBAction func segmentIndexChanged(_ sender: UISegmentedControl) {
        switch segmentController.selectedSegmentIndex {
        case 0:
            break
        case 1:
            break
        default:
            break;
        }
    }
}
