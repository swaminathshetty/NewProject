//
//  KSParameterRegistration.swift
//  KobelcoService
//
//  Created by Guest L&T on 30/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSParameterRegistration: UIViewController {

    @IBOutlet weak var view_SetParameter: UIView!
    @IBOutlet weak var view_TheParameter: UIView!
    @IBOutlet weak var label_SetParameter: UILabel!
    @IBOutlet weak var label_TheParameter: UILabel!
    @IBOutlet weak var setParameterTableView: UITableView!
    @IBOutlet weak var theParameterTableView: UITableView!
    @IBOutlet weak var button_Favorite: UIButton!
    @IBOutlet weak var button_Edit: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Parameter Registration(Favorite)")
        setUpUIParameterRegistrationComponents()
    }
    // Autohide for iPhone Footer Line.
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
    // Configure UI Components.
    func setUpUIParameterRegistrationComponents() {
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        self.view_SetParameter.layer.cornerRadius = 6
        self.view_TheParameter.layer.cornerRadius = 6
        self.button_Edit.setTitle("Edit", for: .normal)
    }
    @IBAction func favoriteButtonTapAction(_ sender: UIButton) {
    }
    @IBAction func editButtonTapAction(_ sender: UIButton) {
        self.navigation(to: Identifier.parameterEditScreen)
    }
}

// MARK:- Tableview delegate
extension KSParameterRegistration: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == setParameterTableView {
            let setParameterCell = tableView.dequeueReusableCell(withIdentifier: "KSParameterRegistrationCell") as! KSParameterRegistrationCell
            setParameterCell.button_SetCheckBox.tag = indexPath.row
            setParameterCell.button_SetCheckBox.addTarget(self, action: #selector(setParameterSelection(_ :)), for: .touchUpInside)
            return setParameterCell
        } else {
            let theParameterCell = tableView.dequeueReusableCell(withIdentifier: "KSTheParameterCell") as! KSTheParameterCell
            theParameterCell.button_TheParametercheckBox.tag = indexPath.row
            theParameterCell.button_TheParametercheckBox.addTarget(self, action: #selector(theParameterSelection(_ :)), for: .touchUpInside)
            return theParameterCell
        }
    }
    @objc func setParameterSelection(_ sender: UIButton) {
    }
    @objc func theParameterSelection(_ sender: UIButton) {
    }
    
}
