//
//  KSNormalDataAcquisition.swift
//  KobelcoService
//
//  Created by Guest L&T on 07/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSNormalDataAcquisition: UIViewController {

    @IBOutlet weak var normalModelType: UILabel!
    @IBOutlet weak var modelSelectionTextField: KSTextFieldDropDown!
    @IBOutlet weak var normalAreaType: UILabel!
    @IBOutlet weak var areaSelectionTextField: KSTextFieldDropDown!
    @IBOutlet weak var acquisitionReadList: KSCustomButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Normal Data Acquisition")
        loadAcquisitionUIComponents()
    }
    
    // Update acquisition components content.
    fileprivate func loadAcquisitionUIComponents() {
        normalModelType.text = "Model Type"
        normalAreaType.text = "Area"
        self.acquisitionReadList.setTitle("Read List", for: .normal)
    }
    
    // Click on this button to download normal data files from webserver.
    @IBAction func readAcquisitionNormalDataFiles(_ sender: Any) {
    }
}
