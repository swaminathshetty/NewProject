//
//  KSNormalDataEditing.swift
//  KobelcoService
//
//  Created by Guest L&T on 07/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSNormalDataEditing: UIViewController {

    @IBOutlet weak var topDataEditingView: UIView!
    @IBOutlet weak var topNormalDataTitle: UILabel!
    @IBOutlet weak var dataEditingTableView: UITableView!
    @IBOutlet weak var deleteDataEditing: UIButton!
    @IBOutlet weak var changeDataEditing: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Normal Data Editing")
        loadNormalDataComponents()
    }
    // Configure Normal data UI components.
    fileprivate func loadNormalDataComponents() {
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        self.topDataEditingView.layer.cornerRadius = 6
        self.topNormalDataTitle.text = "Normal Data List"
        self.deleteDataEditing.setTitle("Delete", for: .normal)
        self.changeDataEditing.setTitle("Change Name", for: .normal)
    }
    
    // User can delete single and multiple normal data files based on selected checkbox from tableview list.
    @IBAction func deleteNormalDataFiles(_ sender: Any) {
    }
    
    // ChangeName button enabled when user want to change any data file name.
    @IBAction func changeNormalDataFileName(_ sender: Any) {
    }
}

//MARK:- Tableview Delegate
extension KSNormalDataEditing: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "KSEditParameterCell"
        let setCell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as! KSEditParameterCell
        setCell.checkBoxEditParameter.tag = indexPath.row
        setCell.checkBoxEditParameter.addTarget(self, action: #selector(editNormalDataFiles), for: .touchUpInside)
        return setCell
        
    }
    // Store locally when user selects data file names from tableview list for data manipulations
    @objc func editNormalDataFiles(_ sender: UIButton) {
    }
}
