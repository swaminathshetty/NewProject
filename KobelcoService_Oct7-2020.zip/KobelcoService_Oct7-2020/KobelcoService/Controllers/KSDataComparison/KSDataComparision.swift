//
//  KSDataComparision.swift
//  KobelcoService
//
//  Created by Swaminath on 9/27/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSDataComparision: UIViewController {

    @IBOutlet weak var logDataTableview: UITableView!
    @IBOutlet weak var normalDataTableview: UITableView!
    @IBOutlet weak var plotChartsButton: KSCustomButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Data Comparison")
        self.navigationItem.hidesBackButton = true // hide navigation bar back button.
    }
    
    // Click on this button after selecting both log and normal data files.
    @IBAction func chartParameterSelectionButtonAction(_ sender: Any) {
        self.navigation(to: Identifier.plotCharts)
    }
}

// MARK:- Tableview delegate
extension KSDataComparision: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == logDataTableview { // Locally saved textfile log-data names
            let setParameterCell = tableView.dequeueReusableCell(withIdentifier: "KSParameterRegistrationCell") as! KSParameterRegistrationCell
            setParameterCell.button_SetCheckBox.tag = indexPath.row
            setParameterCell.button_SetCheckBox.addTarget(self, action: #selector(setDataParameterSelection(_ :)), for: .touchUpInside)
            return setParameterCell
        } else { // Webserver textfile normal-data names.
            let theParameterCell = tableView.dequeueReusableCell(withIdentifier: "KSTheParameterCell") as! KSTheParameterCell
            theParameterCell.button_TheParametercheckBox.tag = indexPath.row
            theParameterCell.button_TheParametercheckBox.addTarget(self, action: #selector(theDataParameterSelection(_ :)), for: .touchUpInside)
            return theParameterCell
        }
    }
    // Click on this button to check / uncheck the logdata files upto max 5 files.
    @objc func setDataParameterSelection(_ sender: UIButton) {
    }
    
    // Restrict to select more than 5 normal data files.
    @objc func theDataParameterSelection(_ sender: UIButton) {
    }
}
