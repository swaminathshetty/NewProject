//
//  KSPlotCharts.swift
//  KobelcoService
//
//  Created by Swaminath on 10/6/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

@objc protocol KSPlotChartsDelegate {
    func sendSelectedParameter(parameterName: String)
}

class KSPlotCharts: UIViewController, KSPlotChartsDelegate {

    @IBOutlet weak var selectParameterTextField: UITextField!
    @IBOutlet weak var shareGraphButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Data Comparison")
        self.shareGraphButton.isEnabled = false
    }    
    @IBAction func openiPhoneShareOptionsButtonAction(_ sender: UIButton) {
    }
    
    // Called when selection of parameter from tableview list and display the selected parameter on textfield.
    func sendSelectedParameter(parameterName: String) {
        selectParameterTextField.text = parameterName
    }
}

//MARK:- Textfield delegate
extension KSPlotCharts: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
            if (textField.text?.count == 0 && string == " ") {
                return false
            }
        return true
    }
    // Tap on texfield to call tableview contoller method.
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if textField == selectParameterTextField {
            presentModelTypeOrAreaController()
        }
        return false
    }
    // load tableview items based on textfield selection.
    func presentModelTypeOrAreaController() {
        let parametersTableView = MAIN_STORYBOARD.instantiateViewController(withIdentifier: Identifier.dataParametersList.rawValue) as! KSDataParameterList
        parametersTableView.delegate = self
        self.present(parametersTableView, animated: true, completion: nil)
    }
}
