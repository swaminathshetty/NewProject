//
//  KSAddParameters.swift
//  KobelcoService
//
//  Created by Swaminath on 10/4/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSAddParameters: UIViewController {

    @IBOutlet weak var headerSetParameterButton: UIButton!
    @IBOutlet weak var tableviewSetDataParameters: UITableView!
    @IBOutlet weak var footerTheParameterButton: UIButton!
    @IBOutlet weak var tableviewTheDataParameters: UITableView!
    @IBOutlet weak var footerConfigureButton: UIButton!
    @IBOutlet weak var footerFavoriteButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Add Parameters")
    }
    
    // Click on this button to plot line graphs for the selected parameters.
    @IBAction func configurePlotButtonTapped(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    // Tap on this button to make/create favorite parameters.
    @IBAction func addFavoriteButtonTapped(_ sender: Any) {
        self.navigation(to: Identifier.createParameter)
    }
}

// MARK:- Tableview delegate
extension KSAddParameters: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == tableviewSetDataParameters {
            let setParameterCell = tableView.dequeueReusableCell(withIdentifier: "KSParameterRegistrationCell") as! KSParameterRegistrationCell
            setParameterCell.button_SetCheckBox.tag = indexPath.row
            setParameterCell.button_SetCheckBox.addTarget(self, action: #selector(setDataParameterSelection(_ :)), for: .touchUpInside)
            return setParameterCell
        } else {
            let theParameterCell = tableView.dequeueReusableCell(withIdentifier: "KSTheParameterCell") as! KSTheParameterCell
            theParameterCell.button_TheParametercheckBox.tag = indexPath.row
            theParameterCell.button_TheParametercheckBox.addTarget(self, action: #selector(theDataParameterSelection(_ :)), for: .touchUpInside)
            return theParameterCell
        }
    }
    @objc func setDataParameterSelection(_ sender: UIButton) {
    }
    @objc func theDataParameterSelection(_ sender: UIButton) {
    }
}

