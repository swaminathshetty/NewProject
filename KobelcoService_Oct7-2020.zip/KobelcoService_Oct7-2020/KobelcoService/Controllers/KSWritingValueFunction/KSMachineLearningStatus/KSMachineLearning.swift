//
//  KSMachineLearning.swift
//  KobelcoService
//
//  Created by Swaminath on 9/26/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSMachineLearning: UIViewController {

    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var button_ItemName: UIButton!
    @IBOutlet weak var label_Value: UILabel!
    @IBOutlet weak var tabelView_LearningStatus: UITableView!
    fileprivate var itemsList = ["Item 1", "Item 2", "Item 3", "Item 4"]

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Machine Learning Status")
        self.headerView.layer.cornerRadius = 6
    }
}

// MARK:- Tableview delegates
extension KSMachineLearning: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemsList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "KSMachineLearningCell"
        let MLStatusCell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as! KSMachineLearningCell
        MLStatusCell.configureMachineLearningStatusCellTitle(itemName: itemsList[indexPath.row])
        return MLStatusCell
    }
}
