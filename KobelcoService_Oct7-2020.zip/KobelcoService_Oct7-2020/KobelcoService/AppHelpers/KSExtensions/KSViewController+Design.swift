//
//  KSViewController+Design.swift
//  KobelcoService
//
//  Created by Guest L&T on 14/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
import UIKit
import EFAutoScrollLabel

// StoryboardIdentifiers
enum Identifier: String {
    case loginScreen = "KSLogin"
    case connectScreen = "KSConnect"
    case wifiSettingsScreen = "KSWIFISettings"
    case modelTypeScreen = "KSModelType"
    case modelTypeList = "KSModelTypeList"
    case dashboardScreen = "KSDashboard"
    case errorCodeScreen = "KSErrorCodeDisplay"
    case freezeFrameScreen = "KSFreezeFrameData"
    case memoryResetScreen = "KSMemoryResetFunction"
    case memoryResetSubScreen = "KSMemoryReset"
    case setValueWritingFunction = "KSwritingValueFunction"
    case injectorPartEntry = "KSInjectorPartEntry"
    case machineLearningStatus = "KSMachineLearning"
    case diagnosticTest = "KSDiagnosticTestFunction"
    case dataMonitor = "KSDataMonitor"
    case addDataparameters = "KSAddParameters"
    case createParameter = "KSCreateParameter"
    case dataComparision = "KSDataComparision"
    case plotCharts = "KSPlotCharts"
    case dataParametersList = "KSDataParameterList"
    case configuration = "KSConfiguration"
    case normalData = "KSNormalDataManagement"
    case logData = "KSLogDataManagement"
    case parameterRegistration = "KSParameterRegistration"
    case parameterEditScreen = "KSParameterEdit"
}
extension UIViewController {
    // ReusableAlert
    func presentAlert(withTitle title: String, message : String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default) { _ in
        }
        alertController.addAction(OKAction)
        self.present(alertController, animated: true, completion: nil)
    }
    // AlertView with 2 titles.
    func presentAttributedStringAlert(message1 : String, message2 : String) {
        let textAttributeForTitle = [NSAttributedString.Key.foregroundColor: UIColor.black, NSAttributedString.Key.font: UIFont.bold(ofSize: 16)]
        let textAttributeForMessage = [NSAttributedString.Key.foregroundColor: UIColor.darkGray, NSAttributedString.Key.font: UIFont.regular(ofSize: 15)]

        let title1 = NSMutableAttributedString(string: "Explanation", attributes: textAttributeForTitle)
        let description1 = NSMutableAttributedString(string: "\n\n\(message1)\n\n", attributes: textAttributeForMessage)
        let title2 = NSMutableAttributedString(string: "Attention", attributes: textAttributeForTitle)
        let description2 = NSMutableAttributedString(string: "\n\n\(message2)", attributes: textAttributeForMessage)

        let attributedText = NSMutableAttributedString()
        attributedText.append(title1)
        attributedText.append(description1)
        attributedText.append(title2)
        attributedText.append(description2)

        let alertController = UIAlertController(title: title, message: "", preferredStyle: .alert)
        alertController.setValue(attributedText, forKey: "attributedMessage")
        let OKAction = UIAlertAction(title: "OK", style: .default) { _ in
        }
        alertController.addAction(OKAction)
        self.present(alertController, animated: true, completion: nil)
    }

    // Navigation based on dynamic identifier name.
    func navigation(to screenIdentifier: Identifier, navigationTitle: String = "") {
        if screenIdentifier.rawValue == "KSMemoryReset" {
            let memoryResetSubScreen = MAIN_STORYBOARD.instantiateViewController(withIdentifier: "KSMemoryReset") as? KSMemoryReset
            memoryResetSubScreen?.navigationTitle = navigationTitle
            self.navigationController?.pushViewController(memoryResetSubScreen!, animated: true)
        } else {
            let viewController = MAIN_STORYBOARD.instantiateViewController(withIdentifier: screenIdentifier.rawValue)
            self.navigationController?.pushViewController(viewController, animated: true)
        }
    }
    
    // MARK: - configure navigationbar
    
    func commonNavigationBarCode() {
        self.navigationController?.setNavigationBarHidden(false, animated: true)
        self.navigationController?.navigationBar.barTintColor = NAVIGATION_BAR_COLOR
    }
    // Dashboard navigationItems.
    func setNavigationBarColorAndItems() {
        commonNavigationBarCode()
        self.navigationController?.navigationBar.backItem?.title = "  "
        self.navigationItem.setHidesBackButton(true, animated: true)
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(image: NAVIGATION_LEFTBAR_LOGO, style: .plain, target: self, action: nil)
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: NAVIGATION_DASHBOARD_RIGHTBAR, style: .plain, target: self, action: #selector(navigateToWiFiSettingsScreen))
    }
    // Subscreen navigation bar.
    func setNavigationBarColorWithButtonTitle(buttonTitle: String) {
        KSSingletonManager.shared.navigationTitle = buttonTitle
        commonNavigationBarCode()
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: NAVIGATION_RIGHTBAR_LOGO, style: .plain, target: self, action: #selector(navigateToDashboard))
        self.navigationItem.setHidesBackButton(false, animated: true)
        self.navigationController?.navigationBar.backItem?.title = "  "
        // Adding scrollable label as navigation title.
        let myLabel = EFAutoScrollLabel(frame: CGRect(x: 0, y: 0, width: self.view.bounds.width - 100, height: 60))
        myLabel.backgroundColor = .clear
        myLabel.textColor = .white
        myLabel.font = UIFont.medium(ofSize: 17)
        myLabel.labelSpacing = 30                       // Distance between start and end labels
        myLabel.pauseInterval = 1.5                     // Seconds of pause before scrolling starts again
        myLabel.scrollSpeed = 50                        // Pixels per second
        myLabel.textAlignment = NSTextAlignment.center    // Centers text when no auto-scrolling is applied
        myLabel.fadeLength = 1                         // Length of the left and right edge fade, 0 to disable
        myLabel.scrollDirection = EFAutoScrollDirection.left
        myLabel.text = buttonTitle
        self.navigationItem.titleView = myLabel
    }
    // ConfirmationAlert for Dashboard RightBarItem.
    @objc func navigateToWiFiSettingsScreen() {
        let alert = UIAlertController(title: "Confirmation", message: "Are you sure you want to disconnect from machine?", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: { _ in
            // Cancel Action
        }))
        alert.addAction(UIAlertAction(title: "Yes", style: UIAlertAction.Style.destructive, handler: {(_: UIAlertAction!) in
            self.navigationController?.popOverToWiFiSettings(index: KSSingletonManager.shared.WiFiSettingsNavigationID)
        }))
        self.present(alert, animated: true, completion: nil)
    }
    // Navigation for Dashboard.
    @objc func navigateToDashboard() {
        self.navigationController?.popOverToDashboard(index: KSSingletonManager.shared.dashboardNavigationID)
    }
    
    // MARK: - SHOW LOADER
    func showLoader(){
        DispatchQueue.main.async {
        self.view.addSubview((appDelegate?.indicatorView)!)
        appDelegate?.indicatorView?.activityIndicator.startAnimating()
        appDelegate?.indicatorView?.setIndicatorFrame()
      }
    }
    
    // MARK: - HIDE LOADER
    func hideLoader(){
        DispatchQueue.main.async {
            appDelegate?.indicatorView?.activityIndicator.stopAnimating()
            appDelegate?.indicatorView?.removeFromSuperview()
            self.view.willRemoveSubview((appDelegate?.indicatorView)!)
        };
    }
    
    // MARK: - Show Copyright Label
    func showCopyrightLabel(){
        DispatchQueue.main.async {
        appDelegate?.copyrightView?.setViewFrame()
        self.view.addSubview((appDelegate?.copyrightView)!)
      }
    }
    
    // MARK: - Hide Copyright Label
    func hideCopyrightLabel(){
        DispatchQueue.main.async {
        appDelegate?.copyrightView?.removeFromSuperview()
        self.view.willRemoveSubview((appDelegate?.copyrightView)!)
      }
    }
}

