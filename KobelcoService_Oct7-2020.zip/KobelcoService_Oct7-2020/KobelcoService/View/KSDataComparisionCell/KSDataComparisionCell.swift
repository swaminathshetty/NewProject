//
//  KSDataComparisionCell.swift
//  KobelcoService
//
//  Created by Guest L&T on 05/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSDataComparisionCell: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}
