//
//  KSErrorCodeDisplay.swift
//  KobelcoService
//
//  Created by Guest L&T on 14/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSErrorCodeDisplay: UIViewController {
    @IBOutlet weak var label_ErrorCodeDisplay: UILabel!
    @IBOutlet weak var segmentController: UISegmentedControl!
    @IBOutlet weak var buttonCurrent: UIButton!
    @IBOutlet weak var buttonPast: UIButton!
    @IBOutlet weak var buttonReset: UIButton!
    @IBOutlet weak var tableView_Codes: UITableView!
    fileprivate let tableViewBackgroundView = UIView()
    fileprivate var codesArray = [String]()
    
    @IBOutlet weak var errocode_HeightCon: NSLayoutConstraint!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        setUpUIComponents()
        codesArray = ["P0018", "P0119", "U1234", "U4321"]
        self.tableView_Codes.rowHeight = 80
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Error Code Display")
    }
    fileprivate func setNavigationBarButtonItemAction() {
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: NAVIGATION_RIGHTBAR_LOGO, style: .plain, target: self, action: #selector(moveToFreezeFrameData))
    }
    fileprivate func setUpUIComponents() {
        setNavigationBarButtonItemAction()
        self.segmentController.layer.cornerRadius = 6
        setCornorRadius(button: buttonCurrent)
        errocode_HeightCon.constant = 0
    }
    @objc func moveToFreezeFrameData() {
        self.navigation(to: Identifier.freezeFrameScreen)
    }
    @IBAction func segmentIndexChanged(_ sender: UISegmentedControl) {
        switch segmentController.selectedSegmentIndex {
        case 0:
            break
        case 1:
            break
        case 2:
            codesArray.removeAll(keepingCapacity: false)
            tableView_Codes.reloadData()
            break
        default:
            break;
        }
    }
    @IBAction func currentButtonTapped(_ sender: UIButton) {
        resetButtonTitleColors()
        setCornorRadius(button: sender)
    }
    @IBAction func pastButtonTapped(_ sender: UIButton) {
        resetButtonTitleColors()
        setCornorRadius(button: sender)
        buttonReset.setTitleColor(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0), for: .normal)
        buttonReset.isEnabled = true
    }
    @IBAction func resetButtonTapped(_ sender: UIButton) {
        print("resetButtonTapped")
    }
    
    fileprivate func resetButtonTitleColors() {
        self.buttonCurrent.setTitleColor(#colorLiteral(red: 0, green: 0.7005334496, blue: 0.723967135, alpha: 1), for: .normal)
        self.buttonCurrent.backgroundColor = .clear
        self.buttonPast.setTitleColor(#colorLiteral(red: 0, green: 0.7005334496, blue: 0.723967135, alpha: 1), for: .normal)
        self.buttonPast.backgroundColor = .clear
        self.buttonReset.setTitleColor(#colorLiteral(red: 0.3333333433, green: 0.3333333433, blue: 0.3333333433, alpha: 1), for: .normal)
    }
    fileprivate func setCornorRadius(button: UIButton) {
        buttonReset.isEnabled = false
        button.addButtonCornerRadius(cornerRadius: 20, borderWidth: 1, buttonBorderColor: #colorLiteral(red: 0, green: 0.5690457821, blue: 0.5746168494, alpha: 1), backgroundColor: #colorLiteral(red: 0, green: 0.7005334496, blue: 0.723967135, alpha: 1), textColor: #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1))
    }
}

extension KSErrorCodeDisplay: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if codesArray.count == 0 {
            DispatchQueue.main.async {
                self.emptyResponseLabel()
            }
            return 0
        } else {
            self.tableView_Codes.backgroundView = nil
            return codesArray.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "KSErrorCodeCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as! KSErrorCodeCell
        cell.configureCell(errorCode: codesArray[indexPath.row], description: codesArray[indexPath.row])
        return cell
    }
    func emptyResponseLabel() {
        let noDataLabel = UILabel()
        noDataLabel.text = "No Records"
        noDataLabel.textColor = TABLEVIEW_LABEL_COLOR
        noDataLabel.font = KS_LABEL_FONT_M18
        noDataLabel.textAlignment = .center
        tableView_Codes.backgroundView = noDataLabel
    }
    
    
}
