//
//  KSFreezeFrameData.swift
//  KobelcoService
//
//  Created by Guest L&T on 21/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit
import SpreadsheetView

class KSFreezeFrameData: UIViewController {

    @IBOutlet weak var spreadSheet: SpreadsheetView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        spreadSheet.dataSource = self
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Freeze Frame Data(U1234)")
        spreadSheet.layer.borderWidth = 1
        spreadSheet.layer.borderColor = #colorLiteral(red: 0, green: 0.5366052985, blue: 0.5635471344, alpha: 1)
        spreadSheet.layer.cornerRadius = 6
        spreadSheet.intercellSpacing = CGSize(width: 1, height: 1)
        //spreadSheet.gridStyle = .solid(width: 0.5, color: .lightGray)
        spreadSheet.alwaysBounceHorizontal = false
        spreadSheet.alwaysBounceVertical = false
        spreadSheet.gridStyle = .solid(width: 5, color: #colorLiteral(red: 0, green: 0.5366052985, blue: 0.5635471344, alpha: 1))

    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        self.navigationController?.navigationBar.backItem?.title = "  "
        setNavigationBarButtonItemAction()
    }
    func setNavigationBarButtonItemAction() {
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: NAVIGATION_RIGHTBAR_LOGO, style: .plain, target: self, action: #selector(moveToFreezeFrameData))
    }
    @objc func moveToFreezeFrameData() {
        self.navigation(to: Identifier.dashboardScreen)
    }
}

extension KSFreezeFrameData: SpreadsheetViewDataSource {
    func numberOfColumns(in spreadsheetView: SpreadsheetView) -> Int {
        return 10
    }

    func numberOfRows(in spreadsheetView: SpreadsheetView) -> Int {
        return 20
    }

    func spreadsheetView(_ spreadsheetView: SpreadsheetView, widthForColumn column: Int) -> CGFloat {
      return 100
    }

    func spreadsheetView(_ spreadsheetView: SpreadsheetView, heightForRow row: Int) -> CGFloat {
      return 35
    }
    func frozenColumns(in spreadsheetView: SpreadsheetView) -> Int {
        return 1
    }

    func frozenRows(in spreadsheetView: SpreadsheetView) -> Int {
        return 1
    }
}
