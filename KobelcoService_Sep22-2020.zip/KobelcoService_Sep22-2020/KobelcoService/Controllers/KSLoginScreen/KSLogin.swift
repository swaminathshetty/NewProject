//
//  KSLogin.swift
//  KobelcoService
//
//  Created by Guest L&T on 09/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSLogin: UIViewController {

    @IBOutlet weak var label_UserID: UILabel!
    @IBOutlet weak var label_Password: UILabel!
    @IBOutlet weak var textField_UserID: UITextField!
    @IBOutlet weak var textField_Password: UITextField!
    @IBOutlet weak var button_SignIn: UIButton!
    
    private let loginVM: KSLoginVM
    
    init(loginVM: KSLoginVM) {
        self.loginVM = loginVM
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        self.loginVM = KSLoginVM(model: LoginModel())
        super.init(coder: coder)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        setUpUIComponents()
        //Setting default Credentials
        self.textField_UserID.text = "kobelcotaro"
        self.textField_Password.text = "kblc4192"
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    func setUpUIComponents() {
        self.label_UserID.font = KS_LABEL_FONT
        self.label_Password.font = KS_LABEL_FONT
        self.textField_UserID.setCustomTextFieldStyle()
        self.textField_Password.setCustomTextFieldStyle()
        self.button_SignIn.setTitle("Sign In", for: .normal)
        self.showCopyrightLabel()
    }
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        self.hideCopyrightLabel()
        if UIDevice.current.orientation.isLandscape {
            print("Landscape")
            self.showCopyrightLabel()
        } else {
            print("Portrait")
            self.showCopyrightLabel()
        }
    }
    @IBAction func signInButtonTap(_ sender: Any) {
        self.view.endEditing(true)
        do {
               _ = try loginVM.validateUserName(textField_UserID.text)
               _ = try loginVM.validatePassword(textField_Password.text)
               _ = try loginVM.validateUserNameAndPassword(textField_UserID.text, textField_Password.text)
            //After successfull authetication navigate to next screen
            self.showLoader()
            self.checkNetworkAvailability()
            
           } catch {
                self.presentAlert(withTitle: "Sign In", message: "\(error.localizedDescription)")
           }
    }
    fileprivate func checkNetworkAvailability() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
            self.hideLoader()
            if appDelegate!.networkAvailability {
                self.navigation(to: Identifier.wifiSettingsScreen)
            } else {
                self.navigation(to: Identifier.connectScreen)
            }
        }
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.hideCopyrightLabel()
    }
}
