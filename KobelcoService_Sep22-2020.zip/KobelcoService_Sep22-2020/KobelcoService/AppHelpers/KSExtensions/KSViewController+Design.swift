//
//  KSViewController+Design.swift
//  KobelcoService
//
//  Created by Guest L&T on 14/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
import UIKit

enum Identifier: String {
    case loginScreen = "KSLogin"
    case connectScreen = "KSConnect"
    case wifiSettingsScreen = "KSWIFISettings"
    case modelTypeScreen = "KSModelType"
    case dashboardScreen = "KSDashboard"
    case errorCodeScreen = "KSErrorCodeDisplay"
    case freezeFrameScreen = "KSFreezeFrameData"
    case modelTypeList = "KSModelTypeList"
    
}
extension UIViewController {

    func presentAlert(withTitle title: String, message : String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default) { _ in
        }
        alertController.addAction(OKAction)
        self.present(alertController, animated: true, completion: nil)
    }
    func navigation(to screenIdentifier: Identifier) {
        let viewController = MAIN_STORYBOARD.instantiateViewController(withIdentifier: screenIdentifier.rawValue)
        self.navigationController?.pushViewController(viewController, animated: true)
    }
    func commonNavigationBarCode() {
        self.navigationController?.setNavigationBarHidden(false, animated: true)
        self.navigationController?.navigationBar.barTintColor = NAVIGATION_BAR_COLOR
    }
    func setNavigationBarColorAndItems() {
        commonNavigationBarCode()
        self.navigationController?.navigationBar.backItem?.title = "  "
        self.navigationItem.setHidesBackButton(true, animated: true)
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(image: NAVIGATION_LEFTBAR_LOGO, style: .plain, target: self, action: nil)
    }
    func setNavigationBarColorWithButtonTitle(buttonTitle: String) {
        KSSingletonManager.shared.navigationTitle = buttonTitle
        commonNavigationBarCode()
        self.navigationItem.setHidesBackButton(false, animated: true)
        self.navigationController?.navigationBar.backItem?.title = "  "
        let button =  UIButton(type: .custom)
        button.frame = CGRect(x: 0, y: 0, width: 100, height: 40)
        button.backgroundColor = .clear
        button.setTitle(buttonTitle, for: .normal)
        button.titleLabel?.textAlignment = .center
        button.titleLabel?.font = KS_LABEL_FONT_M
        button.titleLabel?.lineBreakMode = .byTruncatingTail
        button.titleLabel?.numberOfLines = 2
        button.addTarget(self, action: #selector(showAlert), for: .touchUpInside)
        self.navigationItem.titleView = button
    }
    @objc fileprivate func showAlert() {
        self.presentAlert(withTitle: "", message: KSSingletonManager.shared.navigationTitle)
    }
}
