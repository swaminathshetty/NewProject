//
//  KSMemoryResetSubCell.swift
//  KobelcoService
//
//  Created by Swaminath on 9/26/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSMemoryResetSubCell: UITableViewCell {

    @IBOutlet weak var BGView: UIView!
    @IBOutlet weak var button_ItemName: UIButton!
    @IBOutlet weak var label_Value: UILabel!
    @IBOutlet weak var label_Unit: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.BGView.layer.cornerRadius = 6
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    func configureResetCellTitle(itemLists: [String], selecteditems: [String]) {
        self.button_ItemName.setTitle(itemLists[button_ItemName.tag], for: .normal)
        self.button_ItemName.backgroundColor = .clear
        for item in selecteditems {
            let originalString = itemLists[button_ItemName.tag]
            if originalString.contains(item) {
                self.button_ItemName.backgroundColor = .lightGray
            }
        }
    }
}
