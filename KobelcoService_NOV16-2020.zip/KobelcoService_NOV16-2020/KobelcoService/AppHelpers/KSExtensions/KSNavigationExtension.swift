//
//  KSNavigationExtension.swift
//  KobelcoService
//
//  Created by Guest L&T on 29/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
import UIKit

// MARK: NavigationController extension for new extensions
extension UINavigationController {
    
    open override func viewDidLoad() {
        super.viewDidLoad()
        self.interactivePopGestureRecognizer?.isEnabled = false
    }
    // Get Wi-Fi controller index
    func getWiFiSettingsNavigationID() {
        let wifiSettingsController = self.viewControllers
        KSSingletonManager.shared.wifiSettingsNavigationID = wifiSettingsController.count - 1
    }
    // Identify navigation index of dashboard
    func getDashboardNavigationID() {
        let dashboardController = self.viewControllers
        KSSingletonManager.shared.dashboardNavigationID = dashboardController.count - 1
    }
    // Identify navigation index of dashboard
    func getErrorCodeNavigationID() {
        let errorCodeController = self.viewControllers
        KSSingletonManager.shared.errorCodeNavigationID = errorCodeController.count - 1
    }
    // Identify navigation index of memory reset main
    func getMemoryResetMainNavigationID() {
        let errorCodeController = self.viewControllers
        KSSingletonManager.shared.memoryResetMainScreenID = errorCodeController.count - 1
    }
    // Get navigation index for the current screen
    func getScreenNavigationID() -> Int {
        let currentController = self.viewControllers
        return currentController.count - 1
    }
    // Pop to Dashboard
    func popOverToDefaultController(index: Int) {
        let dashboardController = self.viewControllers[index]
        self.popToViewController(dashboardController, animated: true)
    }
    // Pop to WIFI Screen
    func popOverToWiFiSettings(index: Int) {
        let wifiSettingsController = self.viewControllers[index]
        wifiSettingsController.navigationController?.isNavigationBarHidden = true
        self.popToViewController(wifiSettingsController, animated: true)
    }
}
