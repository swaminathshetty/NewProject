//
//  KSConnect.swift
//  KobelcoService
//
//  Created by Guest L&T on 11/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSConnect: UIViewController {

    @IBOutlet weak var labelMessage: UILabel!
    @IBOutlet weak var buttonConnect: UIButton!
    @IBOutlet weak var buttonWithoutWIFI: UIButton!    
    fileprivate var isConnectViewPresented: Bool = true

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        setUpConnectUIComponents()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        KSSingletonManager.shared.currentScreenName = "KSConnect" // Using this reference to identify navigation viewcontroller index count
        isConnectViewPresented = true
    }
    // Used to hide iPhoneX/XS footer home line.
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.showCopyrightLabel() // It will create footer copyrights text.
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        KSSingletonManager.shared.currentScreenName = "" 
        self.hideCopyrightLabel() // Removing copyright label before navigating to other screen
        isConnectViewPresented = false
    }
    // MARK: Identify screen orientation
    // todo: clear copyright label from footer before orientation changes
    // fixme: Again add copyright footer label after screen orientation to avoid constraint problem.
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        if isConnectViewPresented {
            self.hideCopyrightLabel()
            if UIDevice.current.orientation.isLandscape {
                self.showCopyrightLabel()
            } else {
                self.showCopyrightLabel()
            }
        }
    }
    
    // Assining all custom things here in a single function.
    private func setUpConnectUIComponents() {
        self.labelMessage.font = UIFont.regular(ofSize: 14)
        self.buttonConnect.setTitle("Connect", for: .normal)
        self.buttonWithoutWIFI.setTitle("Next Without Connection", for: .normal)
    }
    
    // MARK: Identify internet connection availability
    // todo: Open iPhone general Wi-Fi settings when network is not reachable
    // fixme: Navigate to next screen if iphone device is connected to any Wi-Fi network.
    private func checkNetworkAvailability() {
        if appDelegate!.networkAvailability == false {
            KSSingletonManager.openWifiSettings() // It will open iPhone general settings screen
        }
        appDelegate?.networkCompletionHandler = { [weak self] (networkStatus, isWiFiMode) in
            if networkStatus == true {
                DispatchQueue.main.async {
                    print("Internet Connected")
                    self?.navigation(to: Identifier.wifiSettingsScreen)
                }
            }
        }
    }
    // Click to check network availability.
    @IBAction func connectButtonAction(_ sender: Any) {
        checkNetworkAvailability()
    }
    // Click on this button when you want to operate this application in offline mode.
    @IBAction func connectWithoutWIFIButtonAction(_ sender: Any) {
        KSSingletonManager.shared.isOfflineConnection = true
        self.navigation(to: Identifier.modelTypeScreen)
    }
}
