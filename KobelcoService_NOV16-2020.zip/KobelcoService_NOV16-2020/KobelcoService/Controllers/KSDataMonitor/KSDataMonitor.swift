//
//  KSDataMonitor.swift
//  KobelcoService
//
//  Created by Swaminath on 9/27/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

// Protocals for data monitor listview swipe up and down functionality.
@objc protocol KSMonitorDataDelegate {
    func addDataMonitorListChildController()
    func swipeUpAndDownTheChildController()
    func removeMonitorListChildController()
}

class KSDataMonitor: UIViewController {

    @IBOutlet weak var footerViewDataMonitor: UIView!
    @IBOutlet weak var addParameterButton: UIButton!
    @IBOutlet weak var type1Type2Segment: UISegmentedControl!
    @IBOutlet weak var startPlotGraphbutton: UIButton!
    fileprivate var dataMonitorListView: KSDataMonitorList?
    fileprivate var isMonitorViewPresented: Bool = true
    fileprivate var listViewYPosition = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        KSSingletonManager.shared.dataMonitorNavigationID = self.navigationController?.getScreenNavigationID() ?? 3
        self.loadDataMonitorUIComponents()
        self.addDataMonitorListChildController()
    }

    // Set customs property values to data monitor UI components.
    fileprivate func loadDataMonitorUIComponents() {
        self.view.backgroundColor = .white
        self.type1Type2Segment.layer.cornerRadius = 8
        self.type1Type2Segment.setSegmentTintColors()
        //listViewYPosition = Int(self.view.bounds.height - 240)
        self.configureDataMonitorGestureRecognizers()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Data Monitor")
        self.navigationItem.hidesBackButton = true
    }
    // MARK: Identify screen orientation
    // todo: set the updated frame for footer monitor list view.
    // fixme: Again add copyright footer label after screen orientation to avoid constraint problem.
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        if isMonitorViewPresented {
            self.removeMonitorListChildController()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                self.addDataMonitorListChildController()
            }
        }
    }
    
    // Called when user navigate to someother screen
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        isMonitorViewPresented = false
    }

    // Configure gesture recognizer for UIView
    fileprivate func configureDataMonitorGestureRecognizers() {
        let swipeRightMR = UISwipeGestureRecognizer(target: self, action: #selector(respondToDataMonitorSwipeGesture))
        swipeRightMR.direction = .right
        self.view.addGestureRecognizer(swipeRightMR)
        
        let swipeLeftMR = UISwipeGestureRecognizer(target: self, action: #selector(respondToDataMonitorSwipeGesture))
        swipeLeftMR.direction = .left
        self.view.addGestureRecognizer(swipeLeftMR)
    }
    
    // Navigate to particular screen based on swipe direction.
    @objc func respondToDataMonitorSwipeGesture(gesture: UIGestureRecognizer) {
        guard KSSingletonManager.shared.isDataMonitorStart == false else { return }
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case .right:
                guard KSSingletonManager.shared.isDiagnsoticStart == false else {
                    self.popOverToBackScreen(indexValue: KSSingletonManager.shared.diagnosticSubScreenID)
                    return
                }
                self.popOverToBackScreen(indexValue: KSSingletonManager.shared.diagnosticMainScreenID)
            case .left:
                self.navigation(to: Identifier.dataComparision)
            default:
                break
            }
        }
    }
    
    // Click on this button to add more parameters from paramters screen and plot a line graph.
    @IBAction func addDataParameterButtonTapped(_ sender: Any) {
        self.navigation(to: Identifier.addDataparameters)
    }
    
    // Display/plot graph based on type1/type2 segment selection.
    @IBAction func segmentControllerForType1AndType2(_ sender: Any) {
    }
    
    // Used to send websocket request with selected parameters and save records in textfile for every 50 ms interval
    @IBAction func startDataParameterButtonTapped(_ sender: UIButton) {
        guard KSSingletonManager.shared.dataMonitorSubMenu.count > 0 else { return }
        if sender.isSelected { // Show alertsheet to select the following options(delete, save, save & send, send & delete).
            disableUIElementActions(title: "Start", isStart: false)
            sendDataMonitorStopWebSocketRequest()
        } else { // Change button title to stop when user tap on start.
            disableUIElementActions(title: "Stop", isStart: true)
        }
        sender.isSelected = !sender.isSelected
    }
    
    // On click of start button disable few UI tap actions.
    fileprivate func disableUIElementActions(title: String, isStart: Bool) {
        startPlotGraphbutton.setTitle(title, for: .normal)
        KSSingletonManager.shared.isDataMonitorStart = isStart
        self.type1Type2Segment.isEnabled = isStart
        self.addParameterButton.isEnabled = !isStart
        navigationController?.navigationBar.isUserInteractionEnabled = !isStart
    }
    
    // Send datamonitor stop websocket request to stop operation.
    @objc fileprivate func sendDataMonitorStopWebSocketRequest() {
        self.showLoader()
        let monitorStopCommand = ResetSocketRequest(screenName: "DataMonitor", frameType: "StopRequest", periodicity: 0)
        guard let monitorStopRequest = try? JSONEncoder().encode(monitorStopCommand) else { return }
        KSSingletonManager.shared.sendCommand(format: monitorStopRequest)
    }
    
    // Show Action sheet options on click of stop button.
    fileprivate func showStopActionSheetOptions() {
        self.showActionSheet { (selectedActionItem) in
            switch selectedActionItem {
            case ActionSheetIdentifiers.delete.rawValue:
                break
            case ActionSheetIdentifiers.save.rawValue:
                break
            case ActionSheetIdentifiers.saveAndSend.rawValue:
                break
            case ActionSheetIdentifiers.sendAndDelete.rawValue:
                break
            default: break
            }
        }
    }
    
    // get monitor list view y position
    fileprivate func getListViewYPosition() {
        if listViewYPosition <= 68 {
            listViewYPosition = Int(UIDevice.current.orientation.isLandscape ? (self.view.bounds.height - 100) : (self.view.bounds.height - 240))
        } else {
            listViewYPosition = Int(UIDevice.current.orientation.isLandscape ? 40 : 68)
        }
    }
}

// MARK: Data monitor delegates
extension KSDataMonitor: KSMonitorDataDelegate {
    // Add data monitor list child controller as a subview.
    func addDataMonitorListChildController() {
        dataMonitorListView = MAINSTORYBOARD.instantiateViewController(withIdentifier: Identifier.dataMonitorList.rawValue) as? KSDataMonitorList
        self.addChild(dataMonitorListView!)
        dataMonitorListView?.monitorDelegate = self
        print("yposition: \(self.listViewYPosition)")
        listViewYPosition = Int(UIDevice.current.orientation.isLandscape ? (self.view.bounds.height - 100) : (self.view.bounds.height - 240))
        self.dataMonitorListView?.view.frame = CGRect(x: 0, y: CGFloat(self.listViewYPosition), width: self.view.bounds.width, height: self.view.bounds.height - CGFloat(listViewYPosition))
        self.view.addSubview((dataMonitorListView?.view)!)
        self.view.insertSubview((dataMonitorListView?.view)!, belowSubview: self.footerViewDataMonitor)
        dataMonitorListView?.didMove(toParent: self)
    }
        
    // Called when user tap on footer tableview child controller.
    // Used to swipe up and down the footer tableview list.
    func swipeUpAndDownTheChildController() {
        self.getListViewYPosition()
        DispatchQueue.main.async {
            UIView.transition(with: (self.dataMonitorListView?.view)!, duration: 0.3, options: [.curveLinear], animations: {
            self.dataMonitorListView?.view.frame = CGRect(x: 0, y: CGFloat(self.listViewYPosition), width: self.view.bounds.width, height: self.view.bounds.height - CGFloat(self.listViewYPosition))
            }, completion: nil)
        }
    }
    
    // Called to remove child controller when user disappears from screen.
    func removeMonitorListChildController() {
        dataMonitorListView?.willMove(toParent: nil)
        dataMonitorListView?.view.removeFromSuperview()
        dataMonitorListView?.removeFromParent()
    }
}

// MARK: MoitorListTableview delegate
extension KSDataMonitorList: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return monitorSubmenu.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let monitorCellIdentifier = "KSMachineLearningCell"
        let monitorCell: KSMachineLearningCell?
        monitorCell = tableView.dequeueReusableCell(withIdentifier: monitorCellIdentifier) as? KSMachineLearningCell
        //monitorCell.button_ItemName.tag = indexPath.row
        //resetCell.configureResetCellTitle(itemLists: itemsList, selecteditems: arraySelectedItems)
        return monitorCell!
    }
}
