//
//  KSDataMonitorList.swift
//  KobelcoService
//
//  Created by Swaminath on 10/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSDataMonitorList: UIViewController {

    @IBOutlet weak var tableViewMonitorList: UITableView!
    @IBOutlet weak var monitorListHeaderView: UIView!
    @IBOutlet weak var monitorListItemName: UIStackView!
    @IBOutlet weak var monitorListHeaderValue: UIStackView!
    @IBOutlet weak var monitorListHeaderUnit: UILabel!
    weak var monitorDelegate: KSMonitorDataDelegate!
    var monitorSubmenu = [[String: Any]]()
    var monitorReadIDs = [String]()
    //var monitorReadValues = [Int]()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.loadMonitorListUIComponents()
    }
    
    // Add custom property values to monitor list UI components.
    fileprivate func loadMonitorListUIComponents() {
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.view.layer.cornerRadius = 10
        self.monitorListHeaderView.layer.cornerRadius = 6
        self.appendEmptyValuesToMonitorItemListArray()
    }
    
    // By default append 0 for item values to display in tableview.
    fileprivate func appendEmptyValuesToMonitorItemListArray() {
        KSSingletonManager.shared.dataMonitorReadValues.removeAll(keepingCapacity: false)
        self.monitorReadIDs.removeAll(keepingCapacity: false)
        self.monitorSubmenu.removeAll(keepingCapacity: false)
        self.monitorSubmenu = KSSingletonManager.shared.dataMonitorSubMenu
        for monitorItemDict in monitorSubmenu {
            KSSingletonManager.shared.dataMonitorReadValues.append(0)
            guard let monitorItemID = monitorItemDict["id"] as? String else { return }
            monitorReadIDs.append(monitorItemID)
        }
        self.mergeDiagnosticAndAddParameterSignals()
    }
    
    // Append 0 to merged datamonitor list items.
    fileprivate func mergeDiagnosticAndAddParameterSignals() {
        for addedSignalsDict in KSSingletonManager.shared.addDataMonitorSubMenu {
            self.monitorSubmenu.append(addedSignalsDict)
            KSSingletonManager.shared.dataMonitorReadValues.append(0)
            guard let addedItemID = addedSignalsDict["id"] as? String else { return }
            self.monitorReadIDs.append(addedItemID)
        }
        self.reloadDataMonitorTableview()
    }
    
    // Reload after merging all signals.
    func reloadDataMonitorTableview() {
        DispatchQueue.main.async {
            self.tableViewMonitorList.reloadData()
        }
    }

    // Tap to swipe up & down the tableview list on the parent Controller.
    @IBAction func swipeUpDownTapAction(_ sender: Any) {
        monitorDelegate.swipeUpAndDownTheChildController()
    }
}
