//
//  ModelTypeJSON.swift
//  KobelcoService
//
//  Created by Guest L&T on 21/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation

struct ModelTypeJSON: Codable {
    let modelTypeList: [MainListDict]
}

struct MainListDict: Codable {
    let name: String
    let area: [AreaDict]
}

struct AreaDict: Codable {
    let name: String
    let type: String
}
