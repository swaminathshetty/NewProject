//
//  KSModelTypeVM.swift
//  KobelcoService
//
//  Created by Guest L&T on 15/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation

class KSModelTypeVM {
    
    // MARK: Called this method to validate modeltype entry.
    func validateModelType(_ modelType: String?) throws -> String {
        guard let modelName = modelType else { throw Validations.selectModelType }
        guard modelName.count != 0  else { throw Validations.selectModelType }
        return modelName
    }
    
    // Called this method to validate area entry.
    func validateArea(_ area: String?) throws -> String {
        guard let areaName = area else { throw Validations.selectArea }
        guard areaName.count != 0 else { throw Validations.selectArea }
        return areaName
    }
}

// MARK: Used to throw custom error messages.
enum Validations: LocalizedError {
    case selectModelType
    case selectArea
        
    var errorDescription: String? {
        switch self {
        case .selectModelType:
            return "Please select Model Type."
        case .selectArea:
            return "Please select any Area"
        }
    }
}
