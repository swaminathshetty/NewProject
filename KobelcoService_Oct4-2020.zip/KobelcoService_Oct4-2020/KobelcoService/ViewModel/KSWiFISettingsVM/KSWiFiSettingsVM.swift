//
//  KSWiFiSettingsVM.swift
//  KobelcoService
//
//  Created by Guest L&T on 15/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
import SystemConfiguration.CaptiveNetwork

class KSWiFiSettingsVM {
    private (set) var ssid: String?
    
   // MARK: - Custom Methods.
   func getSSID() -> String? {
        ssid = fetchSSIDInfo()
        return ssid
   }

   // Used to fetch connected WIFI SSID-Name.
   private func fetchSSIDInfo() -> String? {
       var ssid: String?
       if let interfaces = CNCopySupportedInterfaces() as NSArray? {
           for interface in interfaces {
               if let interfaceInfo = CNCopyCurrentNetworkInfo(interface as! CFString) as NSDictionary? {
                   ssid = interfaceInfo[kCNNetworkInfoKeySSID as String] as? String
                   break
               }
           }
       }
       return ssid
   }
}
