//
//  KSDataMonitor.swift
//  KobelcoService
//
//  Created by Swaminath on 9/27/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSDataMonitor: UIViewController {

    @IBOutlet weak var addParameterButton: UIButton!
    @IBOutlet weak var startPlotGraphbutton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Data Monitor")
        self.navigationItem.hidesBackButton = true
    }
    @IBAction func addDataParameterButtonTapped(_ sender: Any) {
        self.navigation(to: Identifier.addDataparameters)
    }
    @IBAction func startDataParameterButtonTapped(_ sender: UIButton) {
        if sender.isSelected { // Show alertsheet to select the following options(delete, save, save and send, send and delete).
            startPlotGraphbutton.setTitle("Start", for: .normal)
        } else { // Change button title to stop if user tap on start.
            startPlotGraphbutton.setTitle("Stop", for: .normal)
        }
        sender.isSelected = !sender.isSelected
    }
}
