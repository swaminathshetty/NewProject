//
//  KSModelTypeList.swift
//  KobelcoService
//
//  Created by Guest L&T on 21/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSModelTypeList: UIViewController {

    @IBOutlet weak var tableViewData: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    fileprivate var filteredData: [String]!
    weak var delegate:KSModelTypeDelegate!
    
    var selectedInput = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        filteredData =  (selectedInput == "MODELTYPE") ? MODELTYPESARRAY : AREAARRAY
        searchBar.placeholder = (selectedInput == "MODELTYPE") ? "Please select Model Type" : "Please select Area"
        searchBar.becomeFirstResponder()
        self.tableViewData.rowHeight = 44
    }
}

//MARK:- Tableview Delegate

extension KSModelTypeList: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "KSModelTypeCell",for: indexPath) as! KSModelTypeCell
        cell.label_Title.text = filteredData[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedString = filteredData[indexPath.row]
        delegate.sendSelectedModelItem(selectedTF: selectedInput, selectedItem: selectedString)
        self.dismiss(animated: true, completion: nil)
    }
}

//MARK:- SearchBar Delegate

extension KSModelTypeList: UISearchBarDelegate {
    
    //Used to filter the strings based on the user input and showcase on tableview list
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        let mainArray:[String] = (selectedInput == "MODELTYPE") ? MODELTYPESARRAY : AREAARRAY
        filteredData = searchText.isEmpty ? mainArray : mainArray.filter({(dataString: String) -> Bool in
            return dataString.range(of: searchText, options: .caseInsensitive) != nil
        })

        tableViewData.reloadData()
    }
    
    // Dismiss viewcontroller by clicking on search cancel button
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.view.endEditing(true)
        self.dismiss(animated: true, completion: nil)
    }
}
