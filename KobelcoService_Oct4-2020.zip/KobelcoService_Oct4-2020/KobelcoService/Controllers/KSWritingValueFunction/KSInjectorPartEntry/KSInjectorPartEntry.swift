//
//  KSInjectorPartEntry.swift
//  KobelcoService
//
//  Created by Swaminath on 9/26/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSInjectorPartEntry: UIViewController {

    @IBOutlet weak var tableView_InjectorNumbers: UITableView!
    @IBOutlet weak var doneButton: UIButton!
    fileprivate var injectorsList = ["Inj. #1", "Inj. #2", "Inj. #3", "Inj. #4", "Inj. #5", "Inj. #6"]
    fileprivate var injectorNumbers = ["6353E0050171101856421FA0CD30CFBF0E0D1D5E700000000", "6353E0050171001087421F300C9F7F8E4E0EBD2E8000000C1", "6353E0050170902563421D4FCB5E5DCD4D1D3D0E000000063", "6353E00501710010654210306D00AF1E500E7E4FE00000017", "", ""]
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Injector Part Number Entry")
        self.tableView_InjectorNumbers.rowHeight = 94
        self.tableView_InjectorNumbers.estimatedRowHeight = UITableView.automaticDimension
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    // Hide iPhoneX/Pro Footer-Line.
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
    @IBAction func doneButtonAction(_ sender: Any) {
    }
}
// MARK:- TableView Delegate
extension KSInjectorPartEntry: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return injectorsList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "KSInjectorNumberCell"
        let injectorCell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as! KSInjectorNumberCell
        injectorCell.configureCellDetails(injectorName: injectorsList[indexPath.row], injectorNumber: injectorNumbers[indexPath.row])
        return injectorCell
    }
}
