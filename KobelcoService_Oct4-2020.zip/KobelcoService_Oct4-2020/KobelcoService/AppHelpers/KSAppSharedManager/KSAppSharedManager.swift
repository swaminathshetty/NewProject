//
//  KSAppSharedManager.swift
//  KobelcoService
//
//  Created by Guest L&T on 11/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
import UIKit

class KSSingletonManager {
    static let shared = KSSingletonManager()
    private init() { }
    
    var navigationTitle = "" // Set navigation title.
    var currentScreenName = "" // Used to identify screen title.
    var WiFiSettingsNavigationID = 1 // Set Settings Controller Index.
    var dashboardNavigationID = 3 // Set Dashboard Controller Index.

    //MARK:- Goto Wi-Fi Settings
    class func openWifiSettings() {
        let shared = UIApplication.shared
        if let url = URL(string: UIApplication.openSettingsURLString) {
            if #available(iOS 10.0, *) {
                shared.open(url)
            } else {
                shared.openURL(url)
            }
        }
    }    
}
