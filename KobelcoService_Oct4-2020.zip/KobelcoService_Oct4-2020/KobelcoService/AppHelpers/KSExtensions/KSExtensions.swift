//
//  KSExtensions.swift
//  KobelcoService
//
//  Created by Guest L&T on 09/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
import UIKit

// Set RGB Colorcodes.
extension UIColor {
    convenience init(red: Int, green: Int, blue: Int) {
        assert(red >= 0 && red <= 255, "Invalid red component")
        assert(green >= 0 && green <= 255, "Invalid green component")
        assert(blue >= 0 && blue <= 255, "Invalid blue component")

        self.init(red: CGFloat(red) / 255.0, green: CGFloat(green) / 255.0, blue: CGFloat(blue) / 255.0, alpha: 1.0)
    }
    convenience init(rgb: Int) {
        self.init(
            red: (rgb >> 16) & 0xFF,
            green: (rgb >> 8) & 0xFF,
            blue: rgb & 0xFF
        )
    }
}
// Hexadecimal conversion.
extension Data {
    var hexString: String {
        let hexString = map { String(format: "%02.2hhx", $0) }.joined()
        return hexString
    }
}

// UITextField Left & Right Padding.
extension UITextField {
    func setCustomTextFieldStyle(imageName:String = "") {
        self.setLeftPaddingPoints(20)
        self.layer.cornerRadius = CGFloat(22)
        self.layer.borderWidth = 1.5
        self.layer.borderColor = TEXTFIELD_BORDER_COLOR
        self.textColor = TEXTFILED_TEXT_COLOR
        self.font = UIFont.regular(ofSize: 17)
        self.setDropdownIconToTextfieldRightView(imageName: imageName)
    }
    // Used to add leftpadding to the textfield.
    func setLeftPaddingPoints(_ amount:CGFloat) {
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.leftView = paddingView
        self.leftViewMode = .always
    }
    // Used to add rightpadding to the textfield.
    func setRightPaddingPoints(_ amount:CGFloat) {
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.rightView = paddingView
        self.rightViewMode = .always
    }
    // Used to add left Padding with dropdown.
    func setDropdownIconToTextfieldRightView(imageName:String) {
         let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 50, height: self.frame.size.height))
         paddingView.backgroundColor = .clear
         let imgView = UIImageView(frame: CGRect(x: 25, y: 20, width: 12, height: 8))
         imgView.image = UIImage(named: imageName)
         imgView.isUserInteractionEnabled = true
         paddingView.addSubview(imgView)
         self.rightViewMode = .always
         self.rightView = paddingView
     }
}


// MARK:-  UIButton Corner Radius.
extension UIButton{
    // Set title with deafult corner radius.
    func setButtonCornerRadius(text: String, image: String) {
        self.titleLabel?.font = UIFont.regular(ofSize: 17)
        self.setTitle(text, for: .normal)
        commonButtonCodes(radius: 20, width: 1, buttonColor: #colorLiteral(red: 0, green: 0.6470588235, blue: 0.6666666667, alpha: 1))
    }
    // Custom cornor-radius, border-width and botder-color.
    func addButtonCornerRadius(cornerRadius:Float, borderWidth:Float, buttonBorderColor:UIColor, backgroundColor: UIColor, textColor: UIColor){
        self.titleLabel?.font = UIFont.medium(ofSize: 15)
        self.backgroundColor = backgroundColor
        self.setTitleColor(textColor, for: .normal)
        commonButtonCodes(radius: cornerRadius, width: borderWidth, buttonColor: buttonBorderColor)
    }
    // Reusable code for cutsom button.
    func commonButtonCodes(radius: Float, width: Float, buttonColor: UIColor) {
        self.layer.cornerRadius = CGFloat(radius)
        self.layer.borderWidth = CGFloat(width)
        self.layer.borderColor = buttonColor.cgColor
    }
    // Resetting button style and color code to normal for error code display screen.
    func setPlainStyle() {
        self.setTitleColor(#colorLiteral(red: 0, green: 0.7005334496, blue: 0.723967135, alpha: 1), for: .normal)
        self.backgroundColor = .clear
        self.layer.borderWidth = 0
    }
    // Set custom gradientcolor to button background.
    func applyGradientColorToButton(topColor: UIColor, bottomColor: UIColor) {
        let gradientLayer = CAGradientLayer()// Class used to apply gradient color
        gradientLayer.frame = CGRect(x: 0, y: 0, width: 1000, height:  self.frame.height)
        gradientLayer.colors = [topColor.cgColor, bottomColor.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0.5, y: 0.0)
        gradientLayer.endPoint = CGPoint(x: 0.5, y: 1.0)
        gradientLayer.locations = [0.0, 1.0]
        self.layer.addSublayer(gradientLayer)

        self.titleLabel?.font = UIFont.regular(ofSize: 17)
        self.titleLabel?.textColor = .white
        layer.shadowColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 0.2451305651)
        layer.borderWidth = 1.0
        layer.borderColor = #colorLiteral(red: 0, green: 0.5366052985, blue: 0.5635471344, alpha: 1)
        layer.cornerRadius =  20
        layer.shadowRadius = 4.0
        layer.shadowOpacity = 0.6
        clipsToBounds = true
        layer.masksToBounds = true
        self.layer.shadowOffset = CGSize(width: 0, height: 80)
    }
}

// UITextField Check empty or not.
extension UITextField {
    var isEmpty: Bool {
        return text?.isEmpty ?? true
    }
}

// Checking white spaces.
extension String {
    var containsWhitespace : Bool {
        return(self.rangeOfCharacter(from: .whitespacesAndNewlines) != nil)
    }
    // Removes White spaces.
    func removingWhitespaces() -> String {
        return components(separatedBy: .whitespaces).joined()
    }
    // Safety limit for textfield length.
    func safelyLimitedTo(length n: Int) -> String {
        if (self.count <= n) {
            return self
        }
        return String( Array(self).prefix(upTo: n) )
    }
}

// Set Text Field Length.
private var __maxLengths = [UITextField: Int]()
extension UITextField {
    @IBInspectable var maxLength: Int {
        get {
            guard let l = __maxLengths[self] else {
                return 150 // (global default-limit. or just, Int.max)
            }
            return l
        }
        set {
            __maxLengths[self] = newValue
            addTarget(self, action: #selector(fix), for: .editingChanged)
        }
    }
    @objc func fix(textField: UITextField) {
        let t = textField.text
        textField.text = t?.safelyLimitedTo(length: maxLength)
    }
}

// Used to Convert websocket json string response to dictionary format.
func convertToDictionary(text: String) -> [String: Any]? {
    if let data = text.data(using: .utf8) {
        do {
            return try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
        } catch {
            //print(error.localizedDescription)
        }
    }
    return nil
}
