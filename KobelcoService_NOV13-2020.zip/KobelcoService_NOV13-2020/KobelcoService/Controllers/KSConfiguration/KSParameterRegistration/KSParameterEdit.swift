//
//  KSParameterEdit.swift
//  KobelcoService
//
//  Created by Guest L&T on 01/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

class KSParameterEdit: UIViewController {

    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var footerView: UIView!
    @IBOutlet weak var textFieldParameter: UITextField!
    @IBOutlet weak var tableViewParameters: UITableView!
    @IBOutlet weak var buttonDelete: UIButton!
    @IBOutlet weak var buttonSave: UIButton!
    @IBOutlet weak var parameterEngineSegment: UISegmentedControl!
    @IBOutlet weak var paramterECUSegment: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadParameterEditComponents()
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Edit Favorite")
    }
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
    //Configure UI Components
    func loadParameterEditComponents() {
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.headerView.layer.cornerRadius = 6
        self.parameterEngineSegment.layer.cornerRadius = 10
        self.paramterECUSegment.layer.cornerRadius = 6
        self.buttonDelete.setTitle("Delete", for: .normal)
        self.buttonSave.setTitle("Save", for: .normal)
    }
    @IBAction func deleteButtonTapAction(_ sender: Any) {
    }
    @IBAction func saveButtonTapAction(_ sender: Any) {
    }
}

// MARK: Tableview Delegate
extension KSParameterEdit: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "KSEditParameterCell"
        let setCell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as! KSEditParameterCell
        setCell.checkBoxEditParameter.tag = indexPath.row
        setCell.checkBoxEditParameter.addTarget(self, action: #selector(editParameterSelection(_ :)), for: .touchUpInside)
        return setCell
        
    }
    @objc func editParameterSelection(_ sender: UIButton) {
    }
}
