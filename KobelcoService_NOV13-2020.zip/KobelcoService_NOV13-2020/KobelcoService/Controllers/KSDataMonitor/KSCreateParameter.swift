//
//  KSCreateParameter.swift
//  KobelcoService
//
//  Created by Guest L&T on 05/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSCreateParameter: UIViewController {

    @IBOutlet weak var newParameterTextField: UITextField!
    @IBOutlet weak var createParameterButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Add Favorite")
        self.newParameterTextField.setCustomTextFieldStyle()
    }
    @IBAction func createNewParameterTapAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
