//
//  KSDataMonitorList.swift
//  KobelcoService
//
//  Created by Swaminath on 10/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

class KSDataMonitorList: UIViewController {

    @IBOutlet weak var tableViewMonitorList: UITableView!
    @IBOutlet weak var monitorListHeaderView: UIView!
    @IBOutlet weak var monitorListItemName: UIStackView!
    @IBOutlet weak var monitorListHeaderValue: UIStackView!
    @IBOutlet weak var monitorListHeaderUnit: UILabel!
    weak var monitorDelegate: KSMonitorDataDelegate!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.loadMonitorListUIComponents()
    }
    
    // Add custom property values to monitor list UI components.
    fileprivate func loadMonitorListUIComponents() {
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.view.layer.cornerRadius = 10
        self.monitorListHeaderView.layer.cornerRadius = 6
        
    }
    // Tap to swipe up & down the tableview list on the parent Controller.
    @IBAction func swipeUpDownTapAction(_ sender: Any) {
        monitorDelegate.swipeToInitiateFromChildController()
    }
}

// MARK: MoitorListTableview delegate
extension KSDataMonitorList: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 20
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let monitorCellIdentifier = "KSMachineLearningCell"
        let monitorCell = tableView.dequeueReusableCell(withIdentifier: monitorCellIdentifier) as! KSMachineLearningCell
        //monitorCell.button_ItemName.tag = indexPath.row
        //resetCell.configureResetCellTitle(itemLists: itemsList, selecteditems: arraySelectedItems)
        return monitorCell
    }
}
