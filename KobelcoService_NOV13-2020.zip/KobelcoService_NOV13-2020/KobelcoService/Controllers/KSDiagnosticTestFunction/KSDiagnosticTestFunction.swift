//
//  KSDiagnosticTestFunction.swift
//  KobelcoService
//
//  Created by Swaminath on 9/27/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit
@objc protocol KSDiagnosticMainTableViewDelegate {
    func clickOnAttritubedAlertViewOkButton(returnType: Int)
}
class KSDiagnosticTestFunction: UIViewController {
    
    @IBOutlet weak var tableViewDiagnostics: UITableView!
    fileprivate var diagnosticFunctionArray = [[String: Any]]()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Diagnostic Test Function")
        self.navigationItem.hidesBackButton = true
        KSSingletonManager.shared.delegate = self
        self.loadDiagnosticsUIComponets()
    }
    // Assign additional/custom property values to diagnostic UI components.
    fileprivate func loadDiagnosticsUIComponets() {
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.tableViewDiagnostics.layer.cornerRadius = 8
        self.tableViewDiagnostics.estimatedRowHeight = 55
        self.tableViewDiagnostics.rowHeight = UITableView.automaticDimension
        self.configureSetValueGestureRecognizers()
        self.showLoader()
        KSSingletonManager.shared.connectWebSocket()
    }
    // Configure gesture recognizer for UIView
    fileprivate func configureSetValueGestureRecognizers() {
        let swipeRightMR = UISwipeGestureRecognizer(target: self, action: #selector(respondToDiagnosticSwipeGesture))
        swipeRightMR.direction = .right
        self.view.addGestureRecognizer(swipeRightMR)
        
        let swipeLeftMR = UISwipeGestureRecognizer(target: self, action: #selector(respondToDiagnosticSwipeGesture))
        swipeLeftMR.direction = .left
        self.view.addGestureRecognizer(swipeLeftMR)
    }
    // Navigate to particular screen based on swipe direction.
    @objc func respondToDiagnosticSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case .right:
                self.popOverToBackScreen(indexValue: KSSingletonManager.shared.setValueFunctionID)
            case .left:
                self.navigation(to: Identifier.dataMonitor)
            default:
                break
            }
        }
    }

    // Attributed alertview on button action.
    func clickOnAttritubedAlertViewOkButton(returnType: String, subMenuItems: [[String: Any]], frameID: String) {
        KSSingletonManager.shared.diagnosticSubMenuArray.removeAll(keepingCapacity: false)
        KSSingletonManager.shared.diagnosticMainID = frameID
        KSSingletonManager.shared.diagnosticSubMenuArray = subMenuItems

        switch returnType {
        case "ReadOnly":
            // Diagnostic value display screen.
            let diagnosticNormalScreen = MAINSTORYBOARD.instantiateViewController(withIdentifier: "KSDiagnosticNormal") as? KSDiagnosticNormal
            diagnosticNormalScreen?.menuList = subMenuItems
            diagnosticNormalScreen?.mainMenuID = frameID
            self.navigationController?.pushViewController(diagnosticNormalScreen!, animated: true)

        case "Switch":
            // Diagnostic switch display screen.
            self.navigation(to: Identifier.diagnosticSwitch)
        case "UpDown":
            // Diagnostic updown arrow functionality screen.
            self.navigation(to: Identifier.diagnosticUpDown)
        default:
            break
        }
    }
}
// MARK: Tableview delegate
extension KSDiagnosticTestFunction: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        diagnosticFunctionArray.removeAll(keepingCapacity: false)
        guard let diagnosticMenuList = KSSingletonManager.shared.matrixObject["diagnosticFunction"] as? [[String: Any]] else { return 0 }
        diagnosticFunctionArray.append(contentsOf: diagnosticMenuList)
        return diagnosticFunctionArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: "Cell")
        cell.accessoryType = .disclosureIndicator
        cell.textLabel?.text = getDiagnosticFunctionMenuTitle(index: indexPath.row)
        cell.textLabel?.lineBreakMode = .byWordWrapping
        cell.textLabel?.textColor = .darkGray
        cell.textLabel?.font = UIFont.regular(ofSize: 15)
        cell.textLabel?.numberOfLines = 0 // label height increases based on text
        cell.selectionStyle = .none // set clear color on selection
        return cell
    }
    // Used to fetch menu title from dianostic function matrix list.
    func getDiagnosticFunctionMenuTitle(index: Int) -> String {
        guard let diagnosticNameDict = diagnosticFunctionArray[index]["name"] as? [String: Any] else { return "" }
        guard let setValueName = diagnosticNameDict["en"] as? String else { return "" }
        return setValueName
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        KSSingletonManager.shared.diagnosticNavigationTitle = getDiagnosticFunctionMenuTitle(index: indexPath.row)
        guard let explanationDict = diagnosticFunctionArray[indexPath.row]["explanation"] as? [String: Any] else { return }
        guard let explanationMessage = explanationDict["en"] as? String else { return }
        KSSingletonManager.shared.explanationDiagnostic = explanationMessage
        guard let attentionDict = diagnosticFunctionArray[indexPath.row]["attention"] as? [String: Any] else { return }
        guard let attentionMessage = attentionDict["en"] as? String else { return }
        KSSingletonManager.shared.attentionDiagnostic = attentionMessage
        guard let menuType = diagnosticFunctionArray[indexPath.row]["type"] as? String else { return }
        guard let functionID = diagnosticFunctionArray[indexPath.row]["id"] as? String else { return }
        guard let subMenuList = diagnosticFunctionArray[indexPath.row]["submenu"] as? [[String: Any]] else { return }
        showAttributedTextAlert(explanation: explanationMessage, attention: attentionMessage, type: menuType, menuID: functionID, submenuArray: subMenuList)
    }
    // Custom AlertView with 2 titles
    fileprivate func showAttributedTextAlert(explanation: String, attention: String, type: String, menuID: String, submenuArray: [[String: Any]]) {
        DispatchQueue.main.async {
            self.presentAttributedStringAlert(message1: explanation, message2: attention) { [unowned self] (isClickedOnOK) in
                if isClickedOnOK {
                    self.clickOnAttritubedAlertViewOkButton(returnType: type, subMenuItems: submenuArray, frameID: menuID)
                }
            }
        }
    }
}

// MARK: WebSocket Response Delegate
extension KSDiagnosticTestFunction: KSWebSocketDelegates {
    func webSocketStringResponse(response: String) {
        self.hideLoader()
    }
    // Called when error connection in websocket communication
    func webSocketErrorConnection(message: String) {
        self.hideLoader()
        presentAlert(withTitle: "ERROR", message: message)
    }
    // Called when internet is disconnected or network not reachable.
    func internetConnectionNotAvailable() {
        self.hideLoader()
        presentAlertOKAction(withTitle: "ERROR", message: WIFIDISCONNECTEDMESSAGE) { (isOkTapped) in
            if isOkTapped {
                self.navigateToWiFiSettings()
            }
        }
    }
}
