//
//  KSwritingValueFunction.swift
//  KobelcoService
//
//  Created by Swaminath on 9/26/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSwritingValueFunction: UIViewController {
    
    @IBOutlet weak var tableViewWritingFunction: UITableView!
    fileprivate var writingFunctionArray = [[String: Any]]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Set Value Writing Function")
        self.navigationItem.hidesBackButton = true
        // Used to get current screen navigation ID for swipe back functionality.
        KSSingletonManager.shared.setValueFunctionID = self.navigationController?.getScreenNavigationID() ?? 6
        loadWritingValueUIElements()
    }
    // Adding corner radius and row height of tableview.
    fileprivate func loadWritingValueUIElements() {
        tableViewWritingFunction.layer.cornerRadius = 8
        tableViewWritingFunction.rowHeight = 55
        self.configureSetValueGestureRecognizers()
    }
    // Configure gesture recognizer for UIView
    fileprivate func configureSetValueGestureRecognizers() {
        let swipeRightMR = UISwipeGestureRecognizer(target: self, action: #selector(respondToSetValueSwipeGesture))
        swipeRightMR.direction = .right
        self.view.addGestureRecognizer(swipeRightMR)
        
        let swipeLeftMR = UISwipeGestureRecognizer(target: self, action: #selector(respondToSetValueSwipeGesture))
        swipeLeftMR.direction = .left
        self.view.addGestureRecognizer(swipeLeftMR)
    }
    // Navigate to particular screen based on swipe direction.
    @objc func respondToSetValueSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case .right:
                self.popOverToBackScreen(indexValue: KSSingletonManager.shared.memoryResetMainScreenID)
            case .left:
                self.navigation(to: Identifier.diagnosticTest)
            default:
                break
            }
        }
    }
}

// MARK: Tableview delegate
extension KSwritingValueFunction: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let writingFunctionList = KSSingletonManager.shared.matrixObject["setValueFunction"] as? [[String: Any]] else { return 0 }
        writingFunctionArray.append(contentsOf: writingFunctionList)
        return writingFunctionArray.count
    }
    // Used to fetch menu title from setvalue function matrix list.
    func getSetValueMenuTitle(index: Int) -> String {
        guard let setValueDict = writingFunctionArray[index]["name"] as? [String: Any] else { return "" }
        guard let setValueName = setValueDict["en"] as? String else { return "" }
        return setValueName
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: "Cell")
        cell.accessoryType = .disclosureIndicator
        cell.textLabel?.text = getSetValueMenuTitle(index: indexPath.row)
        cell.textLabel?.font = UIFont.regular(ofSize: 15)
        cell.selectionStyle = .none
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let setValueSubMenuArray = writingFunctionArray[indexPath.row]["submenuList"] as? [[String: Any]] else { return }
        guard let machineLearningID = self.writingFunctionArray[indexPath.row]["id"] as? String else { return }
        if setValueSubMenuArray.count > 0 {
            // Navigate to Machine learning screen based on unique id comparision.
            if machineLearningID == "WSV1" {
                let machineLearningScreen = MAINSTORYBOARD.instantiateViewController(withIdentifier: "KSMachineLearning") as? KSMachineLearning
                machineLearningScreen?.machineitemsList = setValueSubMenuArray
                machineLearningScreen?.machineFrameID = machineLearningID
                self.navigationController?.pushViewController(machineLearningScreen!, animated: true)
            } else {
                // Navigate to Injector part number entry screen.
                let qrCodeScreen = MAINSTORYBOARD.instantiateViewController(withIdentifier: "KSInjectorPartEntry") as? KSInjectorPartEntry
                qrCodeScreen?.qrCodeFrameID = machineLearningID
                self.navigationController?.pushViewController(qrCodeScreen!, animated: true)
            }
        }
    }
}
