//
//  KSScanInjectorQRCode.swift
//  KobelcoService
//
//  Created by Guest L&T on 09/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit
import AVFoundation

class KSScanInjectorQRCode: UIViewController, AVCaptureMetadataOutputObjectsDelegate {

    @IBOutlet weak var scanHeaderTitle: UILabel!
    @IBOutlet weak var scanSubTitle: UILabel!
    @IBOutlet weak var scanQRView: UIView!
    fileprivate var isScanViewPresented = true
    // QRScan related properties
    fileprivate var captureSession: AVCaptureSession!
    fileprivate var previewLayer: AVCaptureVideoPreviewLayer!
    private let supportedCodeTypes = [AVMetadataObject.ObjectType.qr]
    
    weak var delegate: KSInjectorPartDelegate!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        DispatchQueue.main.async {
            self.cameraPermissionRequest()
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if captureSession?.isRunning == false {
            captureSession.startRunning()
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.isScanViewPresented = false
        self.removePreviewLayers()
    }
    // MARK: Identify screen orientation
    // todo: clear copyright label from footer before orientation changes
    // fixme: Again add copyright footer label after screen orientation to avoid constraint problem.
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        if isScanViewPresented {
            //if captureSession.isRunning {
                let iPhoneFrame = getWidthAndHeight()
                self.previewLayer.frame =  CGRect(x: 5, y: 5, width: iPhoneFrame.0, height: iPhoneFrame.1)
            //}
        }
    }
    // Get width and height values for all sizes phones in landscape mode.
    fileprivate func getWidthAndHeight() -> (CGFloat, CGFloat) {
        print("Get QRCode Preview Width and Height")
        switch ISIPHONE {
        case ISIPHONE4ORLESS || ISIPHONE5:
            return UIDevice.current.orientation.isLandscape ? (200, 150) : (scanQRView.frame.width - 10, scanQRView.frame.height - 10)
        case ISIPHONE6OR7:
            return UIDevice.current.orientation.isLandscape ? (250, 235) : (324, 333)
        case ISIPHONE6P7P || ISIPHONEX:
            return UIDevice.current.orientation.isLandscape ? (302, 186) : (364, 504)
        default:
            return UIDevice.current.orientation.isLandscape ? (250, 164) : (scanQRView.frame.width - 10, scanQRView.frame.height - 10)
        }
    }
    // Tap to dismiss the current controller
    @IBAction func scanQRCodeBackTap(_ sender: Any) {
        if AVCaptureDevice.authorizationStatus(for: .video) == .authorized {
            self.removePreviewLayers()
        }
        self.dismiss(animated: true, completion: nil)
    }
    // Clear session and preview layers fom mainview.
    func removePreviewLayers() {
        if captureSession?.isRunning == true {
            captureSession.stopRunning()
            previewLayer.removeFromSuperlayer()
            previewLayer.removeAllAnimations()
        }
        captureSession.stopRunning()
    }
    // Requesting for camera access to scan QRCode.
    func cameraPermissionRequest() {
        if AVCaptureDevice.authorizationStatus(for: .video) ==  .authorized {
            // already authorized
            print("already authorized")
            DispatchQueue.main.async {
                self.configureVideoCapture()
            }
        } else {
            AVCaptureDevice.requestAccess(for: .video, completionHandler: { (granted: Bool) in
                if granted {
                    // access allowed
                    print("access allowed")
                    DispatchQueue.main.async {
                        self.configureVideoCapture()
                    }
                } else {
                    // access denied
                    print("access denied")
                    DispatchQueue.main.async {
                        self.presentAlertWithAction(title: "Important", message: QRCODEMESSAGE, action1Title: "Cancel", action2Title: "Allow camera") { (isAllowCamera) in
                            if isAllowCamera {
                                KSSingletonManager.openWifiSettings() // It will open iPhone general settings screen
                            }
                        }
                    }
                }
            })
        }
    }
    
    // configure QRCode session
    func configureVideoCapture() {
        captureSession = AVCaptureSession()
        guard let videoCaptureDevice = AVCaptureDevice.default(for: .video) else {
            self.presentAlertOKAction(withTitle: QRCODEERRORTITLE, message: QRCODEERRORMESSAGE) { (isOkClicked) in
                if isOkClicked {
                    self.removePreviewLayers()
                    self.dismiss(animated: true, completion: nil)
                }
            }
            return
        }
        let videoInput: AVCaptureDeviceInput
        do {
            videoInput = try AVCaptureDeviceInput(device: videoCaptureDevice)
        } catch {
            return
        }
        if captureSession.canAddInput(videoInput) {
            captureSession.addInput(videoInput)
        } else {
            self.presentAlert(withTitle: QRCODEERRORTITLE, message: QRCODEERRORMESSAGE)
            return
        }
        let metadataOutput = AVCaptureMetadataOutput()
        if captureSession.canAddOutput(metadataOutput) {
            captureSession.addOutput(metadataOutput)
            metadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
            metadataOutput.metadataObjectTypes = supportedCodeTypes

        } else {
            self.presentAlert(withTitle: QRCODEERRORTITLE, message: QRCODEERRORMESSAGE)
            return
        }
        self.addVideoPreviewLayer()
    }
    
    // Set video preview layer for scanning.
    func addVideoPreviewLayer() {
        previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        //setFramesForPreviewLayer()
        previewLayer.frame =  CGRect(x: 5, y: 5, width: scanQRView.frame.width - 10, height: scanQRView.frame.height - 10)
        previewLayer.videoGravity = .resizeAspectFill
        scanQRView?.layer.borderColor = UIColor.green.cgColor
        scanQRView?.layer.borderWidth = 5
        scanQRView.layer.addSublayer(previewLayer)
        
        captureSession.startRunning()
    }
    // Callback method to recieve qr scan output.
    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        captureSession.stopRunning()

        if let metadataObject = metadataObjects.first {
            guard let readableObject = metadataObject as? AVMetadataMachineReadableCodeObject else { return }
            guard let stringValue = readableObject.stringValue else { return }
            AudioServicesPlaySystemSound(SystemSoundID(kSystemSoundID_Vibrate))
            found(code: stringValue)
        }
    }
    // Read QRCode string.
    func found(code: String) {
        delegate.removeScanQRChildContoller(QRCode: code)
        self.dismiss(animated: true, completion: nil)
    }
}
