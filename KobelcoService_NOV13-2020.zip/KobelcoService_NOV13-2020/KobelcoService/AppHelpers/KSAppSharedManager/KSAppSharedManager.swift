//
//  KSAppSharedManager.swift
//  KobelcoService
//
//  Created by Guest L&T on 11/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
import Starscream
import UIKit

// Websocket delegates for passing response.
@objc protocol KSWebSocketDelegates: class {
    func webSocketStringResponse(response: String)
    func webSocketErrorConnection(message: String)
    func internetConnectionNotAvailable()
}

class KSSingletonManager {
    static let shared = KSSingletonManager()
    private init() { }
    
    var diagnosticNavigationTitle = "" // Used to pass diagnostic selected tableview index title
    var currentScreenName = "" // Used to identify current screen title.
    var wifiSettingsNavigationID = 1 // Setting default navigation index value to WIFI screen.
    var dashboardNavigationID = 3 // Setting initial default navigation index value to identify dashboard screen
    var errorCodeNavigationID = 4 // Setting initial default navigation index value to identify errorcode screen
    var memoryResetMainScreenID = 5 // Setting initial default navigation index value to identify memory reset main screen
    var setValueFunctionID = 6 // Setting initial default navigation index value to identify set value writing function screen
    var diagnosticFunctionID = 7 // Setting initial default navigation index value to identify diagnostic function screen
    var dataMonitorNavigationID = 8 // Setting initial default navigation index value to identify dataMonitor screen
    var dataComparisionID = 9 // Setting initial default navigation index value to identify dataComparision screen
    // Diagnostic Function Alert messages variables
    var explanationDiagnostic = ""
    var attentionDiagnostic = ""
    // Diagnostic Function Read & Write Signal IDs Array
    var diagnosticSubMenuArray = [[String: Any]]()
    var diagnosticMainID = ""
    var diagnosticReadIDs = [String]()
    var diagnosticWriteIDs = [String]()
    var isDiagnsoticStart = false
    
    var toastController: UIAlertController? // Used to display navigation title on popup.
    var isOfflineConnection: Bool = false // Used to identify the application in offline or online mode
    var modelTypeDefaults = UserDefaults() // Used to set/get model type matrix static json
    var modelTypeSelection = "" // Used to assign machine selection
    var matrixObject = [String: Any]() // Used to set machine selected matrxi object.

    // Websocket references
    weak var delegate: KSWebSocketDelegates?
    fileprivate var socket: WebSocket!
    fileprivate var isWebSocketConnected: Bool = false
    fileprivate var socketConnectionTimer: Timer?

    // Goto Wi-Fi Settings
    class func openWifiSettings() {
        let shared = UIApplication.shared
        if let url = URL(string: UIApplication.openSettingsURLString) {
            if #available(iOS 10.0, *) {
                shared.open(url)
            } else {
                shared.openURL(url)
            }
        }
    }
    
    // Load local static json file
    func loadJson(filename fileName: String, completionHandler: @escaping (Data) -> Void) {
        if let url = Bundle.main.url(forResource: fileName, withExtension: "json") {
            do {
                let dataFormat = try Data(contentsOf: url)
//                let decoder = JSONDecoder()
//                let jsonData = try decoder.decode(ResponseData.self, from: data)
                //return jsonData.person
                completionHandler(dataFormat)
            } catch let error as NSError {
                print(error.localizedDescription)
            }
        }
    }
    
    // Called for null response and place no records text to tableview background.
    func nullDataFilesLabel() -> UILabel {
        let noDataLabel = UILabel()
        noDataLabel.text = "No Records" // Displays this text when tableview list is empty
        noDataLabel.textColor = TABLEVIEWLABELCOLOR
        noDataLabel.font = UIFont.medium(ofSize: 18)
        noDataLabel.textAlignment = .center
        return noDataLabel
    }
    
    /// Network Handler function
    func networkHandler() {
        appDelegate?.networkCompletionHandler = { (networkStatus, isWifiMode) in
            if networkStatus == false || isWifiMode == false {
                print("Not WiFiMode")
                self.delegate?.internetConnectionNotAvailable()
            }
        }
    }
    // MARK: Connect WebSocket
    func connectWebSocket() {
        if appDelegate!.networkAvailability {
            socketConnectionTimer = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(checkWebSocketConnection), userInfo: nil, repeats: false)
            print("connectWebSocket")//ws:localhost:8080/
            let websocketURL = URL(string: "ws://\(WEBSOCKETIP)/")!
            var request = URLRequest(url: websocketURL)
            request.timeoutInterval = 5
            socket = WebSocket(request: request)
            socket.delegate = self
            socket.connect()
        } else {
            delegate?.internetConnectionNotAvailable()
        }
    }
    // Invalidate the socket timer if webscoket communication established successfully.
    @objc func checkWebSocketConnection() {
        print("checkWebSocketConnection")
        socketConnectionTimer?.invalidate()
        socketConnectionTimer = nil
        if !isWebSocketConnected {
            delegate?.internetConnectionNotAvailable()
        }
    }
    // Disconnect WebSocket
    func disconnectWebSocket() {
        print("disconnectWebSocket")
        if isWebSocketConnected {
            socket.disconnect()
            //socket.disconnect(closeCode: CloseCode.normal.rawValue)
        }
    }
    
    // Send WebSocket JSON object Command
    func sendCommand(format requestData: Data) {
        if isWebSocketConnected {
            guard let jsonString =  String(data: requestData, encoding: String.Encoding.utf8) else { return }
            print("jsonString: \(jsonString)")
            socket.write(string: jsonString)
        } else {
            delegate?.webSocketErrorConnection(message: "Please open Websocket connection")
        }
    }
    class func convertJSONStringToDictionary(jsonString: String, completionHandler: @escaping ([String: Any]) -> Void) {
        var dictonary: [String: Any]?
        if let data = jsonString.data(using: String.Encoding.utf8) {
            do {
                dictonary = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
                if let responseDictionary = dictonary {
                    print("responseDictionary: \(responseDictionary)")
                    completionHandler(responseDictionary)
                }
            } catch let error as NSError {
                print(error.localizedDescription)
            }
        }
    }
}

// WebSocket callback delegate
extension KSSingletonManager: WebSocketDelegate {
    func didReceive(event: WebSocketEvent, client: WebSocket) {
        websocketEventCallback(eventCallback: event)
    }
    
    // WebSocket callback event handler.
    func websocketEventCallback(eventCallback: WebSocketEvent) {
        print("event: \(eventCallback)")
        switch eventCallback {
        case .connected(let headers):
            isWebSocketConnected = true
            checkWebSocketConnection()
            print("websocket is connected: \(headers)")
            self.delegate?.webSocketStringResponse(response: "Connection Opened")
        case .disconnected(let reason, let code):
            isWebSocketConnected = false
            print("websocket is disconnected: \(reason) with code: \(code)")
        case .text(let string):
            isWebSocketConnected = true
            print("Received text: \(string)")
            DispatchQueue.main.async {
                self.delegate?.webSocketStringResponse(response: string)
            }
        case .binary(let data):
            print("Received binary: \(data.count)")
        case .ping:
            isWebSocketConnected = false
            socket.write(ping: Data(), completion: nil)
        case .pong:
            isWebSocketConnected = false
            socket.write(pong: Data(), completion: nil)
        case .reconnectSuggested:
            print("websocket reconnectSuggested")
            //delegate?.webSocketErrorConnection(message: "WebSocket Reconnecting")
        case .viabilityChanged:
            print("websocket viabilityChanged")
            isWebSocketConnected = true
            checkWebSocketConnection()
        case .cancelled:
            isWebSocketConnected = false
            print("websocket is cancelled/unable to connect")
            //delegate?.webSocketErrorConnection(message: "WebSocket Connection Closed")
        case .error(let error):
            print("error while connecting: \(error?.localizedDescription ?? "error")")
        }
    }
}
