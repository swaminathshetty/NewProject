//
//  KSViewController+Design.swift
//  KobelcoService
//
//  Created by Guest L&T on 14/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
import UIKit

enum Identifier: String {
    case loginScreen = "KSLogin"
    case connectScreen = "KSConnect"
    case wifiSettingsScreen = "KSWIFISettings"
    case modelTypeScreen = "KSModelType"
    case dashboardScreen = "KSDashboard"
    case errorCodeScreen = "KSErrorCodeDisplay"
}
extension UIViewController {

    func presentAlert(withTitle title: String, message : String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default) { _ in
        }
        alertController.addAction(OKAction)
        self.present(alertController, animated: true, completion: nil)
    }
    func navigation(to screenIdentifier: Identifier) {
        let viewController = MAIN_STORYBOARD.instantiateViewController(withIdentifier: screenIdentifier.rawValue)
        self.navigationController?.pushViewController(viewController, animated: true)
    }
    func setNavigationBarColorAndItems() {
        self.navigationController?.setNavigationBarHidden(false, animated: true)
        self.navigationController?.navigationBar.barTintColor = NAVIGATION_BAR_COLOR
        self.navigationController?.navigationBar.backItem?.title = "  "
        //self.navigationItem.setHidesBackButton(true, animated: true)
        //self.navigationItem.leftBarButtonItem = UIBarButtonItem(image: NAVIGATION_LEFTBAR_LOGO, style: .plain, target: self, action: nil)
    }
}
