//
//  KSDashboard.swift
//  KobelcoService
//
//  Created by Guest L&T on 14/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSDashboard: UIViewController {

    @IBOutlet weak var tableView_Dashboard: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        setNavigationBarButtonItemAction()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarColorAndItems()
    }
    func setNavigationBarButtonItemAction() {
        //self.navigationItem.title = "Error code display for multiple languages(ENGLISH, PORTUGUESE, SPANISH, RUSSIAN)"//31//34
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: NAVIGATION_RIGHTBAR_LOGO, style: .plain, target: self, action: #selector(navigateToErrorCodeDisplay))
    }
    @objc func navigateToErrorCodeDisplay() {
        self.navigation(to: Identifier.errorCodeScreen)
    }
}

extension KSDashboard: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 7
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "KSDashboardCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as! KSDashboardCell
        return cell
    }    
}
