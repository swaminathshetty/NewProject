//
//  KSConnect.swift
//  KobelcoService
//
//  Created by Guest L&T on 11/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSConnect: UIViewController {

    @IBOutlet weak var label_Message: UILabel!
    @IBOutlet weak var button_Connect: UIButton!
    @IBOutlet weak var button_WithoutWIFI: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        setUpUIComponents()
    }
    fileprivate func setUpUIComponents() {
        self.label_Message.setLabelFontSize(fontStyle: REGULAR_FONT, fontSize: 14)
        self.button_Connect.setButtonCornerRadius(text: "Connect", image: "")
        self.button_WithoutWIFI.setTitle("Next Without Connection", for: .normal)
    }
    fileprivate func checkNetworkAvailability() {
        if appDelegate!.networkAvailability == false {
            KSSingletonManager.openWifiSettings()
        }
        appDelegate?.networkCompletionHandler = { networkStatus in
            if networkStatus == true {
                DispatchQueue.main.async {
                    print("Internet Connected")
                    self.navigation(to: Identifier.wifiSettingsScreen)
                }
            }
        }
    }
    @IBAction func connectButtonAction(_ sender: Any) {
        checkNetworkAvailability()
    }
    @IBAction func connectWithoutWIFIButtonAction(_ sender: Any) {
    }
}
