//
//  KSDashboardCell.swift
//  KobelcoService
//
//  Created by Guest L&T on 17/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSDashboardCell: UICollectionViewCell {
    
}
