//
//  KSDataMonitor.swift
//  KobelcoService
//
//  Created by Swaminath on 9/27/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSDataMonitor: UIViewController {

    @IBOutlet weak var addParameterButton: UIButton!
    @IBOutlet weak var startPlotGraphbutton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Data Monitor")
        self.navigationItem.hidesBackButton = true
        startPlotGraphbutton.addButtonCornerRadius(cornerRadius: 20, borderWidth: 1, buttonBorderColor: #colorLiteral(red: 0, green: 0.5690457821, blue: 0.5746168494, alpha: 1), backgroundColor: #colorLiteral(red: 0, green: 0.7005334496, blue: 0.723967135, alpha: 1), textColor: #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1))
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
    }
    // Click on this button to add more parameters in line graph.
    @IBAction func addDataParameterButtonTapped(_ sender: Any) {
        self.navigation(to: Identifier.addDataparameters)
    }
    // Used to send websocket request with selected parameters and save records in textfile for every 50 ms interval
    @IBAction func startDataParameterButtonTapped(_ sender: UIButton) {
        if sender.isSelected { // Show alertsheet to select the following options(delete, save, save and send, send and delete).
            startPlotGraphbutton.setTitle("Start", for: .normal)
        } else { // Change button title to stop if user tap on start.
            startPlotGraphbutton.setTitle("Stop", for: .normal)
        }
        sender.isSelected = !sender.isSelected
    }
}
