//
//  KSModelTypeCell.swift
//  KobelcoService
//
//  Created by Guest L&T on 21/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSModelTypeCell: UITableViewCell {

    @IBOutlet weak var label_Title: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
