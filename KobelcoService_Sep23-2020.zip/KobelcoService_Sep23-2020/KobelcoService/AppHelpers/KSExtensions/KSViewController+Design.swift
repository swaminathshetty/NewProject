//
//  KSViewController+Design.swift
//  KobelcoService
//
//  Created by Guest L&T on 14/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
import UIKit
import EFAutoScrollLabel

enum Identifier: String {
    case loginScreen = "KSLogin"
    case connectScreen = "KSConnect"
    case wifiSettingsScreen = "KSWIFISettings"
    case modelTypeScreen = "KSModelType"
    case modelTypeList = "KSModelTypeList"
    case dashboardScreen = "KSDashboard"
    case errorCodeScreen = "KSErrorCodeDisplay"
    case freezeFrameScreen = "KSFreezeFrameData"
    case memoryResetScreen = "KSMemoryResetFunction"
    
}
extension UIViewController {

    
    func presentAlert(withTitle title: String, message : String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default) { _ in
        }
        alertController.addAction(OKAction)
        self.present(alertController, animated: true, completion: nil)
    }
    func navigation(to screenIdentifier: Identifier) {
        let viewController = MAIN_STORYBOARD.instantiateViewController(withIdentifier: screenIdentifier.rawValue)
        self.navigationController?.pushViewController(viewController, animated: true)
    }
    // MARK : - configure navigationbar
    func commonNavigationBarCode() {
        self.navigationController?.setNavigationBarHidden(false, animated: true)
        self.navigationController?.navigationBar.barTintColor = NAVIGATION_BAR_COLOR
    }
    func setNavigationBarColorAndItems() {
        commonNavigationBarCode()
        self.navigationController?.navigationBar.backItem?.title = "  "
        self.navigationItem.setHidesBackButton(true, animated: true)
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(image: NAVIGATION_LEFTBAR_LOGO, style: .plain, target: self, action: nil)
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: NAVIGATION_RIGHTBAR_LOGO, style: .plain, target: self, action: #selector(navigateToWiFiSettingsScreen))
    }
    func setNavigationBarColorWithButtonTitle(buttonTitle: String) {
        KSSingletonManager.shared.navigationTitle = buttonTitle
        commonNavigationBarCode()
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: NAVIGATION_RIGHTBAR_LOGO, style: .plain, target: self, action: #selector(navigateToDashboard))
        self.navigationItem.setHidesBackButton(false, animated: true)
        self.navigationController?.navigationBar.backItem?.title = "  "
        //Adding scrollable label as navigation title
        let myLabel = EFAutoScrollLabel(frame: CGRect(x: 0, y: 0, width: self.view.bounds.width - 100, height: 60))
        myLabel.backgroundColor = .clear
        myLabel.textColor = .white
        myLabel.font = KS_LABEL_FONT_M
        myLabel.labelSpacing = 30                       // Distance between start and end labels
        myLabel.pauseInterval = 1.5                     // Seconds of pause before scrolling starts again
        myLabel.scrollSpeed = 50                        // Pixels per second
        myLabel.textAlignment = NSTextAlignment.center    // Centers text when no auto-scrolling is applied
        myLabel.fadeLength = 1                         // Length of the left and right edge fade, 0 to disable
        myLabel.scrollDirection = EFAutoScrollDirection.left
        myLabel.text = buttonTitle
        self.navigationItem.titleView = myLabel
    }
    @objc func navigateToWiFiSettingsScreen() {
        let alert = UIAlertController(title: "Confirmation", message: "Are you sure you want to disconnect from machine?", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: { _ in
            //Cancel Action
        }))
        alert.addAction(UIAlertAction(title: "Yes", style: UIAlertAction.Style.destructive, handler: {(_: UIAlertAction!) in
            self.navigation(to: Identifier.wifiSettingsScreen)
        }))
        self.present(alert, animated: true, completion: nil)
    }
    @objc func navigateToDashboard() {
        //self.navigation(to: Identifier.dashboardScreen)
        self.navigationController?.popViewController(animated: true)
    }
    // MARK : - APP SHOW LOADER
    func showLoader(){
        DispatchQueue.main.async {
        self.view.addSubview((appDelegate?.indicatorView)!)
        appDelegate?.indicatorView?.activityIndicator.startAnimating()
        appDelegate?.indicatorView?.setIndicatorFrame()
      }
    }
    // MARK : - APP HIDE LOADER
    func hideLoader(){
        DispatchQueue.main.async {
            appDelegate?.indicatorView?.activityIndicator.stopAnimating()
            appDelegate?.indicatorView?.removeFromSuperview()
            self.view.willRemoveSubview((appDelegate?.indicatorView)!)
        };
    }
    // MARK : - Show Copyright Label
    func showCopyrightLabel(){
        DispatchQueue.main.async {
        appDelegate?.copyrightView?.setViewFrame()
        self.view.addSubview((appDelegate?.copyrightView)!)
      }
    }
    // MARK : - Show Copyright Label
    func hideCopyrightLabel(){
        DispatchQueue.main.async {
        appDelegate?.copyrightView?.removeFromSuperview()
        self.view.willRemoveSubview((appDelegate?.copyrightView)!)
      }
    }
}
