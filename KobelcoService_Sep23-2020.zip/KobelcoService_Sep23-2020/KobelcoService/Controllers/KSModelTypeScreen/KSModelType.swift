//
//  KSModelType.swift
//  KobelcoService
//
//  Created by Guest L&T on 14/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

@objc protocol KSModelTypeDelegate {
    func sendSelectedModelItem(selectedTF: String, selectedItem: String)
}

class KSModelType: UIViewController, KSModelTypeDelegate {

    @IBOutlet weak var label_ModelType: UILabel!
    @IBOutlet weak var label_Area: UILabel!
    @IBOutlet weak var textField_ModelType: UITextField!
    @IBOutlet weak var textField_Area: UITextField!
    @IBOutlet weak var button_Submit: UIButton!
    
    private let modelTypeVM: KSModelTypeVM

    init(modelTypeVM: KSModelTypeVM) {
        self.modelTypeVM = modelTypeVM
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        self.modelTypeVM = KSModelTypeVM()
        super.init(coder: coder)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        setUpUIComponents()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //Setting default ModelType & Area
        self.textField_ModelType.text = "YN15"
        self.textField_Area.text = "India"
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.showCopyrightLabel()
    }
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        self.hideCopyrightLabel()
        if UIDevice.current.orientation.isLandscape {
            print("Landscape")
            //self.showCopyrightLabel()
        } else {
            print("Portrait")
            self.showCopyrightLabel()
        }
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    fileprivate func setUpUIComponents() {
        self.label_ModelType.font = KS_LABEL_FONT
        self.label_Area.font = KS_LABEL_FONT
        self.textField_ModelType.setCustomTextFieldStyle(imageName: "dropdownIcon")
        self.textField_Area.setCustomTextFieldStyle(imageName: "dropdownIcon")
        self.button_Submit.setTitle("Submit", for: .normal)
    }
    @IBAction func submitButtonAction(_ sender: Any) {
        self.view.endEditing(true)
        do {
                _ = try modelTypeVM.validateModelType(textField_ModelType.text)
                _ = try modelTypeVM.validateArea(textField_Area.text)
            self.navigation(to: Identifier.dashboardScreen)
            } catch {
                self.presentAlert(withTitle: "Message", message: "\(error.localizedDescription)")
            }
    }
    func sendSelectedModelItem(selectedTF: String, selectedItem: String) {
        if selectedTF == "MODELTYPE" {
            textField_ModelType.text = selectedItem
        } else {
            textField_Area.text = selectedItem
        }
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.hideCopyrightLabel()
    }
}

//MARK:- Textfield delegate
extension KSModelType: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
            if (textField.text?.count == 0 && string == " ") {
                return false
            }
        return true
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        let textFieldType = (textField == textField_ModelType) ? "MODELTYPE" : "AREA"
        presentModelTypeOrAreaController(selectedInput: textFieldType)
        return false
    }
    func presentModelTypeOrAreaController(selectedInput: String) {
        let tableViewList = MAIN_STORYBOARD.instantiateViewController(withIdentifier: Identifier.modelTypeList.rawValue) as! KSModelTypeList
        tableViewList.delegate = self
        tableViewList.selectedInput = selectedInput
        self.present(tableViewList, animated: true, completion: nil)
    }
}
