//
//  KSDashboard.swift
//  KobelcoService
//
//  Created by Guest L&T on 14/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSDashboard: UIViewController {

    @IBOutlet weak var view_ErrorCodeDisplay: UIView!
    @IBOutlet weak var collectionView_Dashboard: UICollectionView!
    fileprivate let sectionInsets = UIEdgeInsets(top: 1.0, left: 8.0, bottom: 24.0, right: 1.0)

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        self.navigationController?.navigationBar.isHidden = false
        self.showCopyrightLabel()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarColorAndItems()
        self.view_ErrorCodeDisplay.layer.cornerRadius = 6
        configureTapGestureToErrorCodeView()
    }
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        self.hideCopyrightLabel()
        if UIDevice.current.orientation.isLandscape {
            print("Landscape")
            //self.showCopyrightLabel()
        } else {
            print("Portrait")
            self.showCopyrightLabel()
        }
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.navigationController?.navigationBar.isHidden = false
        self.showCopyrightLabel()
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        collectionView_Dashboard.collectionViewLayout.invalidateLayout()
        collectionView_Dashboard.reloadData()
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.hideCopyrightLabel()
    }
    fileprivate func configureTapGestureToErrorCodeView() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:)))
        view_ErrorCodeDisplay.addGestureRecognizer(tap)
    }
    @objc func handleTap(_ sender: UITapGestureRecognizer? = nil) {
        self.navigation(to: Identifier.errorCodeScreen)
    }
}

extension KSDashboard: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return DASHBOARD_ITEMS.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "KSDashboardCell", for: indexPath) as! KSDashboardCell
        cell.updateLabelText(titleString: DASHBOARD_ITEMS[indexPath.row])
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let selectedIndex = indexPath.row
        print("selectedIndex:\(selectedIndex)")
        switch selectedIndex {
        case 0:
            self.navigation(to: Identifier.memoryResetScreen)
            break
        case 1:
            break
        case 2:
            break
        case 3:
            break
        case 4:
            break
        case 5:
            break
        default:
            break
        }
    }
}

// MARK: - Collection View Flow Layout Delegate
extension KSDashboard : UICollectionViewDelegateFlowLayout {
  func collectionView(_ collectionView: UICollectionView,
                      layout collectionViewLayout: UICollectionViewLayout,
                      sizeForItemAt indexPath: IndexPath) -> CGSize {
    var itemsPerRow: CGFloat = 2
    if UIDevice.current.orientation.isLandscape {
        itemsPerRow = 3
        collectionView_Dashboard.reloadData()
    }
    let paddingSpace = sectionInsets.left * (itemsPerRow + 1)
    let availableWidth = collectionView.frame.width - paddingSpace
    var widthPerItem = availableWidth / itemsPerRow
    var heightPerItem = widthPerItem - 28
    if UIDevice.current.orientation.isLandscape {
        widthPerItem = widthPerItem - 6
        heightPerItem = widthPerItem / 1.5
    }
    return CGSize(width: widthPerItem, height: heightPerItem)
  }
}
