//
//  KSMemoryReset.swift
//  KobelcoService
//
//  Created by Swaminath on 9/23/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSMemoryReset: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Memory Reset Function")
    }
}
