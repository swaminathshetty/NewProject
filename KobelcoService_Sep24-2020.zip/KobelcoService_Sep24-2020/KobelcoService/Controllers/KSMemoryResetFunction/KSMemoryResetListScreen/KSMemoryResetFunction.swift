//
//  KSMemoryResetFunction.swift
//  KobelcoService
//
//  Created by Guest L&T on 23/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

@objc protocol KSMemoryResetDelegate {
    func showConfirmationAlert(completionHandler: @escaping(_ isSuccess: Bool) -> Void)
    func showStatusAlert(alertTitle: String, message: String)
}

class KSMemoryResetFunction: UIViewController {

    @IBOutlet weak var tableView_MemoryReset: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView_MemoryReset.layer.cornerRadius = 6
        tableView_MemoryReset.estimatedRowHeight = 50
        tableView_MemoryReset.rowHeight = UITableView.automaticDimension
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Memory Reset Function")
        self.navigationItem.hidesBackButton = true
    }
}

extension KSMemoryResetFunction: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return MEMORYRESET_ITEMS.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row < 3 {
            let cellIdentifier = "KSMemoryResetSwitchCell"
            let switchCell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as! KSMemoryResetSwitchCell
            switchCell.delegate = self
            switchCell.switchOnOff.tag = indexPath.row
            switchCell.configureSwitchCellTitle(titleString: MEMORYRESET_ITEMS[indexPath.row])
            return switchCell
        } else {
            let cellIdentifier = "KSMemoryResetCell"
            let disclouserCell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as! KSMemoryResetCell
            disclouserCell.configureCellTitle(titleString: MEMORYRESET_ITEMS[indexPath.row])
            return disclouserCell
        }
    }
}
