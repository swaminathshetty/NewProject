//
//  KSInjectorNumberCell.swift
//  KobelcoService
//
//  Created by Swaminath on 9/27/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSInjectorNumberCell: UITableViewCell {

    @IBOutlet weak var BGView: UIView!
    @IBOutlet weak var label_InjectorNumber: UILabel!
    @IBOutlet weak var textView_Number: UITextView!
    @IBOutlet weak var button_QRCode: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        BGView.layer.cornerRadius = 8
        textView_Number.layer.borderWidth = 0.5
        textView_Number.layer.borderColor = #colorLiteral(red: 0.6666666865, green: 0.6666666865, blue: 0.6666666865, alpha: 1)
        textView_Number.layer.cornerRadius = 6
        textView_Number.backgroundColor = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
    }
    func configureCellDetails(injectorName: String, injectorNumber: String) {
        self.label_InjectorNumber.text = injectorName
        self.textView_Number.text = injectorNumber
    }

}
