//
//  KSNormalDataManagement.swift
//  KobelcoService
//
//  Created by Swaminath on 9/27/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSNormalDataManagement: UIViewController {

    @IBOutlet weak var tableView_NormalData: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView_NormalData.layer.cornerRadius = 8
        tableView_NormalData.rowHeight = 55
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Normal Data Management")
    }
}
//MARK:- Tableview delegate
extension KSNormalDataManagement: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return NORMALDATA_LIST.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: "Cell")
        cell.accessoryType = .disclosureIndicator
        cell.textLabel?.text = NORMALDATA_LIST[indexPath.row]
        cell.textLabel?.font = KS_LABEL_FONT_R
        cell.selectionStyle = .none
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
}
