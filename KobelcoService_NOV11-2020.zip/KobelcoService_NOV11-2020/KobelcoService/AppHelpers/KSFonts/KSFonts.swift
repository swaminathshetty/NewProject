//
//  KSFonts.swift
//  KobelcoService
//
//  Created by Guest L&T on 10/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
import UIKit

// MARK: - APP FONTS
let REGULAR_FONT: String = "HelveticaNeue"
let MEDIUM_FONT: String = "HelveticaNeue-Medium"
let BOLD_FONT: String = "HelveticaNeue-Bold"

// Setting font sizes from hear for all over application reusability.
extension UIFont {
    // Regular font with dynamic sizes.
    class func regular(ofSize size: CGFloat) -> UIFont {
        return UIFont(name: "HelveticaNeue", size: size)!
        }
    // Medium fontstyle with custom sizes.
    class func medium(ofSize size: CGFloat) -> UIFont {
        return UIFont(name: "HelveticaNeue-Medium", size: size)!
        }
    // Bold style with custom fontsizes.
    class func bold(ofSize size: CGFloat) -> UIFont {
        return UIFont(name: "HelveticaNeue-Bold", size: size)!
    }
}
