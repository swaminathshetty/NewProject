//
//  AppDelegate.swift
//  KobelcoService
//
//  Created by Guest L&T on 09/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit
import CoreData
import Reachability
import IQKeyboardManagerSwift

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    var indicatorView: KSProgressIndicatorView?
    var copyrightView: KSCopyRightView?
    var networkCompletionHandler:((_ networkStatus: Bool?, _ viaWiFi: Bool?) -> Void)?
    let reachability = try? Reachability()
    var networkAvailability = false

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        UINavigationBar.appearance().tintColor = .white
        IQKeyboardManager.shared.enable = true
        IQKeyboardManager.shared.placeholderColor = .clear
        // Creating customized activity indicator loader.
        configureActivityIndicatorView()
        // Creating custom footer copyrights view.
        configureCopyrightView()
        // Using notification for network avilablity identification.
        startReachabilityNotification()
        return true
    }
    
    // MARK: - Customized activity indicator and can used allover the Application
    
    private func configureActivityIndicatorView() {
        guard let PGindicatorView = Bundle.main.loadNibNamed("KSProgressIndicatorView", owner: self, options: nil)?.first as? KSProgressIndicatorView
            else {
            fatalError("")
        }
        appDelegate?.indicatorView = PGindicatorView
        appDelegate?.indicatorView?.prepareIndicator()
    }
    
    // MARK: - Customized copyrights xib file configuration
    
    private func configureCopyrightView() {
        guard let copyrightView = Bundle.main.loadNibNamed("KSCopyRightView", owner: self, options: nil)?.first as? KSCopyRightView
             else {
             fatalError("")
         }
         appDelegate?.copyrightView = copyrightView
         appDelegate?.copyrightView?.configureCopyrightLabel()
    }
    
    // MARK: - Adding notifier to identify the WIFI network switchings
    private func startReachabilityNotification() {
         NotificationCenter.default.addObserver(self, selector: #selector(reachabilityChanged(note:)), name: .reachabilityChanged, object: reachability)
        do {
          try reachability?.startNotifier()
        } catch {
          print("could not start reachability notifier")
        }
    }
    
    // MARK: This function called when there is WIFI network switching and update status to required screens.
    @objc private func reachabilityChanged(note: Notification) {
        guard let reachability = note.object as? Reachability else { return }

      switch reachability.connection {
      case .wifi:
        print("Reachable via WiFi")
        networkAvailability = true
        //if KSSingletonManager.shared.currentScreenName == "KSWIFISettings" || KSSingletonManager.shared.currentScreenName == "KSConnect" {
            networkCompletionHandler?(networkAvailability, networkAvailability)
        //}
      case .cellular:
        print("Reachable via Cellular")
        networkAvailability = true
        //if KSSingletonManager.shared.currentScreenName == "KSWIFISettings" || KSSingletonManager.shared.currentScreenName == "KSConnect" {
            networkCompletionHandler?(networkAvailability, false)
        //}
      case .unavailable:
        print("Network not reachable")
        networkAvailability = false
        //if KSSingletonManager.shared.currentScreenName == "KSWIFISettings" || KSSingletonManager.shared.currentScreenName == "KSConnect" {
            networkCompletionHandler?(networkAvailability, networkAvailability)
        //}
      case .none:
        print("Network not reachable none")
        networkAvailability = false
        //if KSSingletonManager.shared.currentScreenName == "KSWIFISettings" || KSSingletonManager.shared.currentScreenName == "KSConnect" {
            networkCompletionHandler?(networkAvailability, networkAvailability)
        //}
      }
    }

    // Called when application will move from background state to foreground state from scene delegate class.
    func getConnectedSSIDName() {
        networkCompletionHandler?(networkAvailability, networkAvailability)
    }
    
    // MARK: UISceneSession Lifecycle

    @available(iOS 13.0, *)
    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    @available(iOS 13.0, *)
    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
        reachability?.stopNotifier()
        NotificationCenter.default.removeObserver(self, name: .reachabilityChanged, object: nil)
        KSSingletonManager.shared.currentScreenName = ""
    }
    
    // MARK: iOS < 13
    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
        if KSSingletonManager.shared.currentScreenName == "KSWIFISettings" {
        getConnectedSSIDName()
        }
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
        reachability?.stopNotifier() // Stop rechability notifier when application is about to terminate
        NotificationCenter.default.removeObserver(self, name: .reachabilityChanged, object: nil)
        KSSingletonManager.shared.currentScreenName = "" // Clear the screen title before terminating the app
        KSSingletonManager.shared.disconnectWebSocket()
    }

    // MARK: - Core Data stack
    lazy var persistentContainer: NSPersistentContainer = {
        /*
         The persistent container for the application. This implementation
         creates and returns a container, having loaded the store for the application to it. This property is optional since there are legitimate
         error conditions that could cause the creation of the store to fail.
        */
        let container = NSPersistentContainer(name: "KobelcoService")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                 
                /*
                 Typical reasons for an error here include:
                 * The parent directory does not exist, cannot be created, or disallows writing.
                 * The persistent store is not accessible, due to permissions or data protection when the device is locked.
                 * The device is out of space.
                 * The store could not be migrated to the current model version.
                 Check the error message to determine what the actual problem was.
                 */
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()

    // MARK: - Core Data Saving support

    func saveContext () {
        let context = persistentContainer.viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
}
