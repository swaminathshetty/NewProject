//
//  KSErrorCodeCell.swift
//  KobelcoService
//
//  Created by Swaminath on 9/16/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSErrorCodeCell: UITableViewCell {
    @IBOutlet weak var errorCodeBGView: UIView!
    @IBOutlet weak var labelErrorCode: UILabel!
    @IBOutlet weak var labelDescription: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    // Used for binding values and colors to the error code cell components.
    func configureCell(errorCode: String, description: String) {
        errorCodeBGView.clipsToBounds = true
        errorCodeBGView.layer.cornerRadius = 6
        labelErrorCode.backgroundColor = HEADERVIEWCOLOR
        labelErrorCode.text = errorCode
        labelErrorCode.textColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        labelDescription.textColor = #colorLiteral(red: 0.4549019608, green: 0.4549019608, blue: 0.4549019608, alpha: 1)
        labelDescription.text = description
        labelDescription.numberOfLines = 3
        labelDescription.lineBreakMode = .byWordWrapping
    }
}
