//
//  KSFonts.swift
//  KobelcoService
//
//  Created by Guest L&T on 10/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
import UIKit

//MARK: - APP FONTS
let REGULAR_FONT:String = "HelveticaNeue"
let MEDIUM_FONT:String = "HelveticaNeue-Medium"
let BOLD_FONT:String = "HelveticaNeue-Bold"

let KS_NAVIGATION_FONT_M = UIFont(name: MEDIUM_FONT, size: 25)

let KS_LABEL_FONT = UIFont(name: REGULAR_FONT, size: 17)
let KS_LABEL_FONT_M = UIFont(name: MEDIUM_FONT, size: 15)
let KS_LABEL_FONT_M18 = UIFont(name: MEDIUM_FONT, size: 22)


let KS_TEXTFILED_FONT = UIFont(name: REGULAR_FONT, size: 17)

let KS_BUTTON_TITLE_R_FONT = UIFont(name: REGULAR_FONT, size: 17)
let KS_BUTTON_TITLE_M_FONT = UIFont(name: MEDIUM_FONT, size: 20)

