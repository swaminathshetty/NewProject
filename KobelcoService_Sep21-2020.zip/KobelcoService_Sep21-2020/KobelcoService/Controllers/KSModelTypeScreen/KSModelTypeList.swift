//
//  KSModelTypeList.swift
//  KobelcoService
//
//  Created by Guest L&T on 21/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSModelTypeList: UIViewController {

    @IBOutlet weak var tableViewData: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    fileprivate var filteredData: [String]!
    override func viewDidLoad() {
        super.viewDidLoad()
        filteredData = MODELTYPESARRAY
    }
}
//MARK:- Tableview Delegate
extension KSModelTypeList: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "KSModelTypeCell",for: indexPath) as! KSModelTypeCell
        cell.label_Title.text = filteredData[indexPath.row]
        return cell
    }
}
//MARK:- SearchBar Delegate
extension KSModelTypeList: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {

        filteredData = searchText.isEmpty ? MODELTYPESARRAY : MODELTYPESARRAY.filter({(dataString: String) -> Bool in
            // If dataItem matches the searchText, return true to include it
            return dataString.range(of: searchText, options: .caseInsensitive) != nil
        })

        tableViewData.reloadData()
    }
}
