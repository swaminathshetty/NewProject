//
//  KSWIFISettings.swift
//  KobelcoService
//
//  Created by Guest L&T on 11/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit
import NotificationCenter
import UserNotifications

class KSWIFISettings: UIViewController {

    @IBOutlet weak var button_WIFISettings: UIButton!
    @IBOutlet weak var label_SSIDName: UILabel!
    @IBOutlet weak var label_Start: UILabel!
    @IBOutlet weak var button_Start: UIButton!
    @IBOutlet weak var button_WithoutWIFI: UIButton!
    fileprivate var isViewPresented: Bool!

    private let wifiSettingVM: KSWiFiSettingsVM

    init(wifiSettingVM: KSWiFiSettingsVM) {
        self.wifiSettingVM = wifiSettingVM
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) {
        self.wifiSettingVM = KSWiFiSettingsVM()
        super.init(coder: coder)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        self.navigationController?.navigationBar.isHidden = true
        setUpUIComponents()
        updateSSIDName()
        networkMonitor()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        KSSingletonManager.shared.currentScreenName = "KSWIFISettings"
        isViewPresented = true
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.showCopyrightLabel()
    }
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        if isViewPresented {
            self.hideCopyrightLabel()
            if UIDevice.current.orientation.isLandscape {
                print("Landscape")
                //self.showCopyrightLabel()
            } else {
                print("Portrait")
                self.showCopyrightLabel()
            }
        }
     }
    fileprivate func setUpUIComponents() {
        self.label_SSIDName.setLabelFontSize(fontStyle: REGULAR_FONT, fontSize: 14)
        self.label_Start.setLabelFontSize(fontStyle: REGULAR_FONT, fontSize: 14)
        self.button_WIFISettings.setButtonCornerRadius(text: "Wi-Fi Settings", image: "")
        self.button_Start.setButtonCornerRadius(text: "Start", image: "")
        self.button_WithoutWIFI.setTitle("Next Without Connection", for: .normal)
    }
    fileprivate func networkMonitor() {
        appDelegate?.networkCompletionHandler = { (networkStatus, isWifiMode) in
            if networkStatus == true {
                self.updateSSIDName()
                if isWifiMode! {
                    print("WiFiMode")
                } else {
                    print("MobileInternet")
                }
            } else {
                DispatchQueue.main.async {
                    self.navigation(to: Identifier.connectScreen)
                }
            }
        }
    }
    func updateSSIDName() {
        guard let ssidName = self.wifiSettingVM.getSSID() else { return }
        DispatchQueue.main.async {
            self.label_SSIDName.text = "Your phone is connected to \(ssidName)"
        }
    }
    @IBAction func wifiSettingsButtonAction(_ sender: Any) {
        KSSingletonManager.openWifiSettings()
    }
    @IBAction func startButtonAction(_ sender: Any) {
        self.navigation(to: Identifier.modelTypeScreen)
    }
    @IBAction func withoutWifiButtonAction(_ sender: Any) {
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        KSSingletonManager.shared.currentScreenName = ""
        self.hideCopyrightLabel()
        isViewPresented = false
    }
}
