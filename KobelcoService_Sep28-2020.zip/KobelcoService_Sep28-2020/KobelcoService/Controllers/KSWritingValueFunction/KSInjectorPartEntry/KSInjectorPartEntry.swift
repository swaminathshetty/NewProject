//
//  KSInjectorPartEntry.swift
//  KobelcoService
//
//  Created by Swaminath on 9/26/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSInjectorPartEntry: UIViewController {

    @IBOutlet weak var tableView_InjectorNumbers: UITableView!
    @IBOutlet weak var doneButton: UIButton!
    fileprivate var injectorsList = ["Inj. #1", "Inj. #2", "Inj. #3", "Inj. #4", "Inj. #5", "Inj. #6"]
    fileprivate var injectorNumbers = ["", "", "", "", "", ""]
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView_InjectorNumbers.rowHeight = 94
        self.tableView_InjectorNumbers.estimatedRowHeight = UITableView.automaticDimension
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Injector Part Number Entry")
    }
    @IBAction func doneButtonAction(_ sender: Any) {
    }
}
//MARK:- TableView Delegate
extension KSInjectorPartEntry: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return injectorsList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "KSInjectorNumberCell"
        let injectorCell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as! KSInjectorNumberCell
        injectorCell.configureCellDetails(injectorName: injectorsList[indexPath.row], injectorNumber: injectorNumbers[indexPath.row])
        return injectorCell
    }
}
