//
//  KSFonts.swift
//  KobelcoService
//
//  Created by Guest L&T on 10/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
import UIKit

//MARK: - APP FONTS
let REGULAR_FONT:String = "HelveticaNeue"
let MEDIUM_FONT:String = "HelveticaNeue-Medium"
let BOLD_FONT:String = "HelveticaNeue-Bold"

let KS_NAVIGATION_FONT_M = UIFont(name: MEDIUM_FONT, size: 25)

let KS_LABEL_FONT = UIFont(name: REGULAR_FONT, size: 17)
let KS_LABEL_FONT_R = UIFont(name: REGULAR_FONT, size: 15)
let KS_LABEL_FONT_M = UIFont(name: MEDIUM_FONT, size: 15)
let KS_LABEL_FONT_M18 = UIFont(name: MEDIUM_FONT, size: 22)

let KS_LOADER_LABEL_FONT_B = UIFont(name: BOLD_FONT, size: 14)
let KS_COPYRIGHT_FONT_R = UIFont(name: REGULAR_FONT, size: 12)

let ALERT_TITLE_B = UIFont(name: BOLD_FONT, size: 16)
let ALERT_DESCRIPTION_R = UIFont(name: REGULAR_FONT, size: 14)

let KS_TEXTFILED_FONT = UIFont(name: REGULAR_FONT, size: 17)

let KS_BUTTON_TITLE_R_FONT = UIFont(name: REGULAR_FONT, size: 17)
let KS_BUTTON_TITLE_M_FONT = UIFont(name: MEDIUM_FONT, size: 20)

