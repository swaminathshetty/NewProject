//
//  KSDashboardCell.swift
//  KobelcoService
//
//  Created by Guest L&T on 17/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSDashboardCell: UICollectionViewCell {
    @IBOutlet weak var cellBGView: UIView!
    fileprivate let title = UILabel()
    func updateLabelText(titleString: String) {
        title.frame = CGRect(x: 0, y: 0, width: self.bounds.size.width, height: self.bounds.size.height)
        title.text = titleString
        //title.backgroundColor = .blue
        title.lineBreakMode = .byWordWrapping
        title.numberOfLines = 6
        title.font = KS_LABEL_FONT_M
        title.textAlignment = .center
        title.textColor = #colorLiteral(red: 0, green: 0.6470588235, blue: 0.6666666667, alpha: 1)
        self.contentView.addSubview(title)
        self.contentMode = .scaleAspectFit
        self.backgroundColor = .clear
        self.contentView.backgroundColor = .white
        self.contentView.layer.cornerRadius = 6
    }
}
