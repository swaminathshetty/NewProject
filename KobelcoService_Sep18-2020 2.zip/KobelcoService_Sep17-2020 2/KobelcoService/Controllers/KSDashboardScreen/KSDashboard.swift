//
//  KSDashboard.swift
//  KobelcoService
//
//  Created by Guest L&T on 14/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSDashboard: UIViewController {

    @IBOutlet weak var view_ErrorCodeDisplay: UIView!
    @IBOutlet weak var collectionView_Dashboard: UICollectionView!
    fileprivate let sectionInsets = UIEdgeInsets(top: 1.0, left: 8.0, bottom: 24.0, right: 1.0)

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        self.view_ErrorCodeDisplay.layer.cornerRadius = 6
        setNavigationBarButtonItemAction()

    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarColorAndItems()
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        collectionView_Dashboard.collectionViewLayout.invalidateLayout()
    }
    fileprivate func setNavigationBarButtonItemAction() {
        //self.navigationItem.title = "Error code display for multiple languages(ENGLISH, PORTUGUESE, SPANISH, RUSSIAN)"//31//34
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: NAVIGATION_RIGHTBAR_LOGO, style: .plain, target: self, action: #selector(navigateToErrorCodeDisplay))
    }
    @objc func navigateToErrorCodeDisplay() {
        self.navigation(to: Identifier.errorCodeScreen)
    }
}

extension KSDashboard: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return DASHBOARD_ITEMS.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "KSDashboardCell", for: indexPath) as! KSDashboardCell
        cell.updateLabelText(titleString: DASHBOARD_ITEMS[indexPath.row])
        return cell
    }
}

// MARK: - Collection View Flow Layout Delegate
extension KSDashboard : UICollectionViewDelegateFlowLayout {
  func collectionView(_ collectionView: UICollectionView,
                      layout collectionViewLayout: UICollectionViewLayout,
                      sizeForItemAt indexPath: IndexPath) -> CGSize {
    var itemsPerRow: CGFloat = 2
    if UIDevice.current.orientation.isLandscape {
        itemsPerRow = 3
    }
    let paddingSpace = sectionInsets.left * (itemsPerRow + 1)
    let availableWidth = collectionView.frame.width - paddingSpace
    var widthPerItem = availableWidth / itemsPerRow
    var heightPerItem = widthPerItem - 28
    if UIDevice.current.orientation.isLandscape {
        widthPerItem = widthPerItem - 6
        heightPerItem = widthPerItem / 1.5
    }
    return CGSize(width: widthPerItem, height: heightPerItem)
  }
  
  /*func collectionView(_ collectionView: UICollectionView,
                      layout collectionViewLayout: UICollectionViewLayout,
                      minimumLineSpacingForSectionAt section: Int) -> CGFloat {
    return sectionInsets.bottom

  }*/
}
