//
//  KSDataMonitorCell.swift
//  KobelcoService
//
//  Created by Swaminath on 11/16/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSDataMonitorCell: UITableViewCell {

    @IBOutlet weak var monitorCellBGView: UIView!
    @IBOutlet weak var monitorCellItemName: UIButton!
    @IBOutlet weak var monitorCellValue: UILabel!
    @IBOutlet weak var monitorCellUnit: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.monitorCellBGView.layer.cornerRadius = 6
        self.monitorCellItemName.titleLabel?.numberOfLines = 2
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configureDataMonitorCellDetails(itemObject: [String: Any], selecteditems: [String], itemValue: Int) {
        guard let monitorCellDict = itemObject["itemName"] as? [String: Any] else { return }
        guard let monitorCellID = itemObject["id"] as? String else { return }
        guard let monitorCellName = monitorCellDict["en"] as? String else { return }
        self.monitorCellItemName.setTitle(monitorCellName, for: .normal)
        self.monitorCellItemName.isSelected = false
        self.monitorCellValue.text = itemValue == 0 ? "-" : String(itemValue)
        for monitorName in selecteditems {
            if monitorCellID.contains(monitorName) {
                self.monitorCellItemName.isSelected = true
            }
        }
    }

}
