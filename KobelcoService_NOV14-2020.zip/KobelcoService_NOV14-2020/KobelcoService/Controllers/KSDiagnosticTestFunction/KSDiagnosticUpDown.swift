//
//  KSDiagnosticUpDown.swift
//  KobelcoService
//
//  Created by Guest L&T on 06/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

// Protocol for to get updated diagnostic details.
@objc protocol KSDiagnosticDelegate {
    // Used to get textfield entry value from diagnostic tableview cell.
    @objc optional func getTextFieldEntryValue(indexID: Int, textFieldValue: String)
    // Used to get new signals item details from add parameter screen on click of configure.
    @objc optional func updateNewlyAddedConfigureItems()
}
class KSDiagnosticUpDown: UIViewController {

    @IBOutlet weak var upDownHeaderView: UIView!
    @IBOutlet weak var upDownHeaderTitle: UIButton!
    @IBOutlet weak var upDownHeaderValue: UILabel!
    @IBOutlet weak var upDownHeaderUnit: UILabel!
    @IBOutlet weak var upDownDiagnosticTableView: UITableView!
    @IBOutlet weak var addParametersUpDown: UIButton!
    @IBOutlet weak var startButtonUpDown: UIButton!
    @IBOutlet weak var upArrowUpDown: UIButton!
    @IBOutlet weak var downArrowUpDown: UIButton!
    @IBOutlet weak var helpButtonUpDown: UIButton!
    fileprivate var upDownWriteArray = [[String: Any]]()
    fileprivate var upDownReadArray = [[String: Any]]()
    fileprivate var upDownWriteID = [String]()
    fileprivate var upDownWriteValue = [Int]()
    fileprivate var upDownWriteValues = [Int]()
    fileprivate var upDownReadIDs = [String]()
    fileprivate var upDownReadValues = [Int]()
    private var upDownCanViewSwipe = true

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.setNavigationBarColorWithButtonTitle(buttonTitle: KSSingletonManager.shared.diagnosticNavigationTitle)
        KSSingletonManager.shared.diagnosticSubScreenID = self.navigationController?.getScreenNavigationID() ?? 3
        loadDiagnosticUpDownUIComponents()
        KSSingletonManager.shared.delegate = self
    }
    // AutoHide iPhoneX/Pro footer line.
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
    // Add custom values to diagnostic updown UI components.
    fileprivate func loadDiagnosticUpDownUIComponents() {
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.upDownHeaderView.layer.cornerRadius = 6
        self.upDownHeaderTitle.setTitle("Item Name", for: .normal)
        self.upDownHeaderValue.text = "Value"
        self.upDownHeaderUnit.text = "Unit"
        self.configureDiagnosticSubMenuGestureRecognizers()
        self.appendEmptyValuesToSwitchItemListArray()
    }
    // Configure gesture recognizer for UIView
    fileprivate func configureDiagnosticSubMenuGestureRecognizers() {
        let swipeRightMR = UISwipeGestureRecognizer(target: self, action: #selector(respondToDiagnosticSubMenuSwipeGesture))
        swipeRightMR.direction = .right
        self.view.addGestureRecognizer(swipeRightMR)
        
        let swipeLeftMR = UISwipeGestureRecognizer(target: self, action: #selector(respondToDiagnosticSubMenuSwipeGesture))
        swipeLeftMR.direction = .left
        self.view.addGestureRecognizer(swipeLeftMR)
    }
    // Navigate to particular screen based on swipe direction.
    @objc func respondToDiagnosticSubMenuSwipeGesture(gesture: UIGestureRecognizer) {
        guard upDownCanViewSwipe else { return }
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case .right:
                guard KSSingletonManager.shared.isDiagnsoticStart else { return }
                self.popOverToBackScreen(indexValue: KSSingletonManager.shared.setValueFunctionID)
            case .left:
                self.navigation(to: Identifier.dataMonitor)
            default:
                break
            }
        }
    }

    // By default append 0 in item values to display in tableview.
    fileprivate func appendEmptyValuesToSwitchItemListArray() {
        self.upDownReadValues.removeAll(keepingCapacity: false)
        self.upDownWriteArray.removeAll(keepingCapacity: false)
        self.upDownReadIDs.removeAll(keepingCapacity: false)
        self.readAndWriteSignalsSeperation()
        for switchItemDict in upDownReadArray {
            upDownReadValues.append(0)
            guard let switchItemID = switchItemDict["id"] as? String else { return }
            upDownReadIDs.append(switchItemID)
        }
    }
    // Seperate Read and Write Dianostic Sub Menu Details.
    fileprivate func readAndWriteSignalsSeperation() {
        for switchItemObject in KSSingletonManager.shared.diagnosticSubMenuArray {
            guard let switchItemType = switchItemObject["type"] as? String else { return }
            if switchItemType == "ReadOnly" {
                self.upDownReadArray.append(switchItemObject)
            } else {
                self.upDownWriteArray.append(switchItemObject)
            }
        }
        self.appendEmptyValuesToWriteSignals()
    }
    // Append 0 default value to write Signal values.
    fileprivate func appendEmptyValuesToWriteSignals() {
        self.upDownWriteValues.removeAll(keepingCapacity: false)
        for _ in upDownWriteArray {
            self.upDownWriteValues.append(0)
        }
    }
    // Click on this button to add parameters from parameters screen.
    @IBAction func addParametersForDiagnosticUpDown(_ sender: Any) {
        self.navigation(to: Identifier.diagnosticAddParameter)
    }
    
    // Its a toggle operation, start and stop websocket value readings.
    @IBAction func startActionForDiagnosticUpdown(_ sender: Any) {
        if upDownReadArray.count > 0 {
            if KSSingletonManager.shared.isDiagnsoticStart { // Stop
                startAndStopTextBind(isStart: false, title: "Start", canSwipe: true, isEnable: true)
                sendDiagnosticStopWebSocketRequest()
            } else { // Start
                startAndStopTextBind(isStart: true, title: "Stop", canSwipe: false, isEnable: false)
                sendDiagnosticSocketRequest(writeIDs: upDownWriteID, writeValues: upDownWriteValue, interval: 0)
            }
        } else {
            self.presentAlert(withTitle: "Message", message: "To Start Diagnostic Test, please add few read signals from add parameter screen and try again.")
        }
    }
    // Called when user click on start or stop button.
    fileprivate func startAndStopTextBind(isStart: Bool, title: String, canSwipe: Bool, isEnable: Bool) {
        KSSingletonManager.shared.isDiagnsoticStart = isStart
        startButtonUpDown.setTitle(title, for: .normal)
        upDownCanViewSwipe = canSwipe
        addParametersUpDown.isEnabled = isEnable
        helpButtonUpDown.isEnabled = isEnable
        upArrowUpDown.isEnabled = isStart
        downArrowUpDown.isEnabled = isStart
        navigationController?.navigationBar.isUserInteractionEnabled = isEnable
    }
    // Send websocket request With read and write signal IDs
    fileprivate func sendDiagnosticSocketRequest(writeIDs: [String], writeValues: [Int], interval: Int) {
        self.showLoader()
        self.upDownCanViewSwipe = false
        let mainID = KSSingletonManager.shared.diagnosticMainID
        let screenTitle = "DiagnosticTestFunction"
        let switchCommand = DiagnosticStartRequest(screenName: screenTitle, frameType: mainID, writeSignals: writeIDs, writeValue: writeValues, readSignals: upDownReadIDs, periodicity: interval)
        guard let normalRequestData = try? JSONEncoder().encode(switchCommand) else { return }
        KSSingletonManager.shared.sendCommand(format: normalRequestData)
    }
    // Send diagnostic stop websocket request to stop operation.
    @objc fileprivate func sendDiagnosticStopWebSocketRequest() {
        self.showLoader()
        self.upDownCanViewSwipe = false
        let diagnocticStopCommand = ResetSocketRequest(screenName: "DiagnosticTestFunction", frameType: "StopRequest", periodicity: 0)
        guard let diagnosticRequestData = try? JSONEncoder().encode(diagnocticStopCommand) else { return }
        KSSingletonManager.shared.sendCommand(format: diagnosticRequestData)
    }
    // Click on this to perform up and down websocket request for value field.
    @IBAction func toggleUpAndDownArrowAction(_ sender: Any) {
    }
    // Click on this to show help alertview.
    @IBAction func helpButtonActionForDiagnosticUpDown(_ sender: Any) {
        let upDownExplanation = KSSingletonManager.shared.explanationDiagnostic
        let upDownAttention = KSSingletonManager.shared.attentionDiagnostic
        DispatchQueue.main.async {
             self.presentAttributedStringAlert(message1: upDownExplanation, message2: upDownAttention) { (_ ) in
             }
         }
    }

    // Clear all arrays data and set storage capacity to false.
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(true)
        /*upDownWriteArray.removeAll(keepingCapacity: false)
        upDownReadArray.removeAll(keepingCapacity: false)
        upDownWriteValues.removeAll(keepingCapacity: false)
        upDownReadIDs.removeAll(keepingCapacity: false)
        upDownReadValues.removeAll(keepingCapacity: false)
        upDownWriteID.removeAll(keepingCapacity: false)*/
    }
}

// MARK: Extension for add/remove child controllers.
extension KSDiagnosticUpDown: KSDiagnosticDelegate {
    // Get tableview cell textfield value via delegate function.
    func getTextFieldEntryValue(indexID: Int, textFieldValue: String) {
        upDownWriteValues[indexID] = Int(textFieldValue) ?? 0
    }
    
    // Get added new signals from add parameter screen.
    func updateNewlyAddedConfigureItems() {
        
    }
}

// MARK: Tableview delegates
extension KSDiagnosticUpDown: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        //return switchWriteArray.count > 0 ? 2 : 1
        return 2
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return section == 0 ? upDownWriteArray.count : upDownReadArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
             let switchTypeObject = upDownWriteArray[indexPath.row]
             let switchMenuType = switchTypeObject["type"] as? String
            // Load Diagnostic Write Signals.
             if switchMenuType == "Switch" {
                let switchCellIdentifier = "KSDiagnosticSwitchCell"
                let switchCell = tableView.dequeueReusableCell(withIdentifier: switchCellIdentifier) as! KSDiagnosticSwitchCell
                switchCell.switchToggleButton.tag = indexPath.row
                switchCell.configureDiagnosticSwitchCell(switchObject: upDownWriteArray[indexPath.row], switchInput: upDownWriteValues[indexPath.row])
                switchCell.switchToggleButton.addTarget(self, action: #selector(diagnosticSwitchOnAndOffAction(_ :)), for: .touchUpInside)
                return switchCell
             } else {
                self.upArrowUpDown.isHidden = false
                self.downArrowUpDown.isHidden = false
                let upDownCellIdentifier = "KSDiagnosticUpDownCell"
                let upDownCell = tableView.dequeueReusableCell(withIdentifier: upDownCellIdentifier) as! KSDiagnosticUpDownCell
                upDownCell.upDownTextField.tag = indexPath.row
                upDownCell.diagnosticDelegate = self
                upDownCell.configureDiagnosticUpDownCell(upDownObject: upDownWriteArray[indexPath.row], textFieldValue: upDownWriteValues[indexPath.row])
                return upDownCell
             }
         // Load Diagnostic Read Signals.
         } else {
            let switchReadIdentifier = "KSDiagnosticNormalCell"
            let switchReadCell = tableView.dequeueReusableCell(withIdentifier: switchReadIdentifier) as! KSDiagnosticNormalCell
            switchReadCell.configureDiagnosticNormalCell(normalObject: upDownReadArray[indexPath.row], itemValue: upDownReadValues[indexPath.row])
            return switchReadCell
         }
    }
    // Tap to store toggle switch write value for websocket write request.
     @objc func diagnosticSwitchOnAndOffAction(_ sender: UISwitch) {
        if KSSingletonManager.shared.isDiagnsoticStart { // Stop
            DispatchQueue.main.async {
                let switchWriteObject = self.upDownWriteArray[sender.tag]
                guard let switchID = switchWriteObject["id"] as? String else { return }
                self.upDownWriteID[0] = switchID
                let toggleValue = sender.isOn == true ? 1 : 0
                self.upDownWriteValues[sender.tag] = toggleValue
                self.sendDiagnosticSocketRequest(writeIDs: self.upDownWriteID, writeValues: [toggleValue], interval: 5000)
            }
        } else {
            sender.isOn = !sender.isOn
            self.presentAlert(withTitle: "Message", message: "Click on bottom Start button to perform switch operation.")
        }
     }
}
// MARK: WebSocket Response Delegate
extension KSDiagnosticUpDown: KSWebSocketDelegates {
    func webSocketStringResponse(response: String) {
        print("response: \(response)")
        guard let jsonDictionary = convertToDictionary(text: response) else { return }
        guard let screenTitle = jsonDictionary["screenName"] as? String else { return }
        if screenTitle == "DiagnosticTestFunction" {
            self.hideLoader()
            upDownCanViewSwipe = true
            let resposneKeys = jsonDictionary.keys
            // Condition check for 2 type responses. If response contains status key show success or failure message.
            if resposneKeys.contains("status") {
                guard let diagnosticStopStatus = jsonDictionary["status"] as? Int else { return }
                if diagnosticStopStatus != 1 {
                    self.startButtonUpDown.setTitle("Stop", for: .normal)
                    KSSingletonManager.shared.isDiagnsoticStart = true
                }
                let stopStatusMessage = diagnosticStopStatus == 1 ? DIAGNOSTICSTOPSUCCESS : DIAGNSOTICSTOPFAIL
                self.presentAlert(withTitle: ALERTTITLESTRING, message: stopStatusMessage)
            } else {
                // Read values from the websocket response and update to tableview.
                 guard let readSignalValues = jsonDictionary["values"] as? [Int] else { return }
                 DispatchQueue.main.async {
                     if readSignalValues.count == self.upDownReadArray.count {
                         self.upDownReadValues.removeAll(keepingCapacity: false)
                         self.upDownReadValues = readSignalValues
                         self.upDownDiagnosticTableView.reloadData()
                         return
                     } else {
                         self.presentAlert(withTitle: "Error in Response", message: "Request and Response signals are not matching, please try again after some time.")
                         return
                     }
                 }
            }
        }
    }
    // Called when error connection in websocket communication
    func webSocketErrorConnection(message: String) {
        self.hideLoader()
        upDownCanViewSwipe = true
        presentAlert(withTitle: "ERROR", message: message)
    }
    // Called when internet is disconnected or network not reachable.
    func internetConnectionNotAvailable() {
        self.hideLoader()
        presentAlertOKAction(withTitle: "ERROR", message: WIFIDISCONNECTEDMESSAGE) { (isOkTapped) in
            if isOkTapped {
                self.navigateToWiFiSettings()
            }
        }
    }
}
