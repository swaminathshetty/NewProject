//
//  KSErrorCodeDisplay.swift
//  KobelcoService
//
//  Created by Guest L&T on 14/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

class KSErrorCodeDisplay: UIViewController {
    @IBOutlet weak var labelErrorCodeDisplay: UILabel!
    @IBOutlet weak var segmentController: UISegmentedControl!
    @IBOutlet weak var buttonCurrent: UIButton!
    @IBOutlet weak var buttonPast: UIButton!
    @IBOutlet weak var buttonReset: UIButton!
    @IBOutlet weak var tableViewCodes: UITableView!
    fileprivate let tableViewBackgroundView = UIView()
    fileprivate var errorCodesArray = [[String: Any]]()
    fileprivate var filteredErrorCodes = [[String: Any]]()
    fileprivate var responseErrorCodes = [String]()
    fileprivate var errorCodeViewCanSwipe: Bool = false
    fileprivate var deviceType = "ALL"
    fileprivate var frameType = "ActiveErrorCountRequest"
    fileprivate var periodicityValue = 10000
    fileprivate var errorcodeModel: ErrorcodeResponse?
    
    @IBOutlet weak var errocode_HeightCon: NSLayoutConstraint!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Error Code Display")
        self.navigationItem.hidesBackButton = true // hide navigation bar back button
        self.navigationController?.getErrorCodeNavigationID() // To identify the navaigation index for errorcode screen
        loadErrorCodeUIComponents()
        self.tableViewCodes.rowHeight = 80
        KSSingletonManager.shared.delegate = self
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.hideLoader()
        KSSingletonManager.shared.disconnectWebSocket()
    }
    // AutoHide iPhoneX/Pro Footer Line.
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
    // Configure ErrorCode UI-Elements.
    fileprivate func loadErrorCodeUIComponents() {
        self.segmentController.layer.cornerRadius = 10
        setCornorRadius(button: buttonCurrent)
        errocode_HeightCon.constant = 0
        // Configure swipe geture for uiview
        configureGestureRecognizers()
    }
    // Configure gesture recognizer for UIView
    fileprivate func configureGestureRecognizers() {
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(respondToSwipeGesture))
        swipeRight.direction = .right
        self.view.addGestureRecognizer(swipeRight)
        
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(respondToSwipeGesture))
        swipeLeft.direction = .left
        self.view.addGestureRecognizer(swipeLeft)
    }
    // Navigate to particular screen based on swipe direction.
    @objc func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if errorCodeViewCanSwipe {
            if let swipeGesture = gesture as? UISwipeGestureRecognizer {
                 switch swipeGesture.direction {
                 case .right:
                    self.popOverToBackScreen(indexValue: KSSingletonManager.shared.dashboardNavigationID)
                 case .left:
                     self.navigation(to: Identifier.memoryResetScreen)
                 default:
                     break
                 }
             }
        }
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        KSSingletonManager.shared.delegate = self
        self.showLoader()
        errorCodeViewCanSwipe = false
        KSSingletonManager.shared.connectWebSocket()
        self.perform(#selector(sendAllActiveErrorCodeCommand), with: self, afterDelay: 2)
        DispatchQueue.main.async {
            self.errorCodesArray.removeAll(keepingCapacity: false)
            KSSingletonManager.shared.loadJson(filename: ERRORCODESFILES) { (errorCodesData) in
                guard let errorCodesJSON = self.convertDataToDictionary(data: errorCodesData) else { return }
                guard let errorCodesList = errorCodesJSON["KSErrorCodesArray"] as? [[String: Any]] else { return }
                self.errorCodesArray.append(contentsOf: errorCodesList)
            }
        }
    }
    // Start websocket request.
    @objc func sendAllActiveErrorCodeCommand() {
        self.sendCommand(frameName: frameType, deviceName: deviceType, interval: periodicityValue)
    }
    
    // Reusable function for all errorcodes websocket request
    func sendCommand(frameName: String, deviceName: String, interval: Int) {
        self.showLoader()
        errorCodeViewCanSwipe = false
        let errorCodeCommand = SocketRequestDict(screenName: "ErrorCodeDisplay", frameType: frameName, device: deviceName, periodicity: interval)
        guard let errorCodeRequestData = try? JSONEncoder().encode(errorCodeCommand) else { return }
        KSSingletonManager.shared.sendCommand(format: errorCodeRequestData)
    }
    @IBAction func segmentIndexChanged(_ sender: UISegmentedControl) {
        switch segmentController.selectedSegmentIndex {
        case 0:
            deviceType = "ALL"
            sendCommand(frameName: frameType, deviceName: deviceType, interval: periodicityValue)
        case 1:
            deviceType = "ECU"
            sendCommand(frameName: frameType, deviceName: deviceType, interval: periodicityValue)
        case 2:
            deviceType = "DCU"
            sendCommand(frameName: frameType, deviceName: deviceType, interval: periodicityValue)
        default:
            break
        }
    }
    @IBAction func currentButtonTapped(_ sender: UIButton) {
        resetButtonTitleColors()
        setCornorRadius(button: sender)
        frameType = "ActiveErrorCountRequest"
        periodicityValue = 10000
        self.sendCommand(frameName: frameType, deviceName: self.deviceType, interval: periodicityValue)
    }
    @IBAction func pastButtonTapped(_ sender: UIButton) {
        resetButtonTitleColors()
        setCornorRadius(button: sender)
        buttonReset.setTitleColor(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0), for: .normal)
        buttonReset.isEnabled = true
        frameType = "PastErrorCodeRequest"
        periodicityValue = 0
        sendCommand(frameName: frameType, deviceName: deviceType, interval: periodicityValue)
    }
    @IBAction func resetButtonTapped(_ sender: UIButton) {
        if responseErrorCodes.count > 0 {
            let alert = UIAlertController(title: "Confirmation", message: "Are you sure you want to clear past records?", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: { _ in
                //Cancel Action
            }))
            alert.addAction(UIAlertAction(title: "Clear", style: UIAlertAction.Style.destructive, handler: {(_: UIAlertAction!) in
                self.sendCommand(frameName: "ResetPastErrorRequest", deviceName: self.deviceType, interval: self.periodicityValue)
            }))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    // Reset all button selection.
    fileprivate func resetButtonTitleColors() {
        self.buttonCurrent.setPlainStyle()
        self.buttonPast.setPlainStyle()
        self.buttonReset.setTitleColor(#colorLiteral(red: 0.3333333433, green: 0.3333333433, blue: 0.3333333433, alpha: 1), for: .normal)
    }
    // Set button selection style.
    fileprivate func setCornorRadius(button: UIButton) {
        buttonReset.isEnabled = false
        button.addButtonCornerRadius(cornerRadius: 20, borderWidth: 1, buttonBorderColor: #colorLiteral(red: 0, green: 0.5690457821, blue: 0.5746168494, alpha: 1), backgroundColor: #colorLiteral(red: 0, green: 0.7005334496, blue: 0.723967135, alpha: 1), textColor: #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1))
    }
}

// MARK: TableView delegates
extension KSErrorCodeDisplay: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if responseErrorCodes.count == 0 {
            DispatchQueue.main.async {
                self.tableViewCodes.backgroundView =  KSSingletonManager.shared.nullDataFilesLabel()
            }
        } else {
            tableViewCodes.backgroundView = nil
        }
        return responseErrorCodes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "KSErrorCodeCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as! KSErrorCodeCell
        let errorDescription = getErrorCodeDescription(errorCode: responseErrorCodes[indexPath.row])
        cell.configureCell(errorCode: responseErrorCodes[indexPath.row], description: errorDescription)
        return cell
    }
    func getErrorCodeDescription(errorCode: String) -> String {
        let errorCodeObject = errorCodesArray.filter({(dataDict: [String: Any]) -> Bool in
            return (dataDict["errorCode"] as! String).range(of: errorCode, options: .caseInsensitive) != nil
        })
        guard let descriptionObject = errorCodeObject[0]["description"] as? [String: Any] else { return "--" }
        guard let description = descriptionObject["en"] as? String else { return "--"}
        return description
    }
}

// MARK: WebSocket Response Delegate
extension KSErrorCodeDisplay: KSWebSocketDelegates {
    func webSocketStringResponse(response: String) {
        print("response: \(response)")
        guard let jsonDictionary = convertToDictionary(text: response) else { return }
        guard let screenTitle = jsonDictionary["screenName"] as? String else { return }
        guard let frameName = jsonDictionary["frameType"] as? String else { return }
        errorCodeViewCanSwipe = true
        if screenTitle == "ErrorCodeDisplay" {
            self.hideLoader()
            if frameName.contains("Reset") {
                guard let status = jsonDictionary["status"] as? String else { return }
                if status == "Accepted" {
                    responseErrorCodes.removeAll(keepingCapacity: false)
                } else {
                    self.presentAlert(withTitle: ALERTTITLESTRING, message: "Unable to clear past records, please try after sometime.")
                }
            } else {
                if let data = response.data(using: String.Encoding.utf8) {
                     do {
                        responseErrorCodes.removeAll(keepingCapacity: false)
                        self.errorcodeModel = try JSONDecoder().decode(ErrorcodeResponse.self, from: data)
                        if let ecuCodes = self.errorcodeModel?.ecuErrorCodes {
                            responseErrorCodes.append(contentsOf: ecuCodes)
                        }
                        if let dcuCodes = self.errorcodeModel?.dcuErrorCodes {
                            responseErrorCodes.append(contentsOf: dcuCodes)
                        }
                     } catch let error as NSError {
                        print("error.localizedDescription: \(error.localizedDescription)")
                        self.presentAlert(withTitle: "ERROR", message: error.localizedDescription)
                    }
                 }
            }
            DispatchQueue.main.async {
                 print("Reload tableViewCodes")
                 self.tableViewCodes.reloadData()
             }
         }
    }
    // Called when error connection in websocket communication
    func webSocketErrorConnection(message: String) {
        self.hideLoader()
        presentAlert(withTitle: "ERROR", message: message)
    }
    // Called when internet is disconnected or network not reachable.
    func internetConnectionNotAvailable() {
        self.hideLoader()
        presentAlertOKAction(withTitle: "ERROR", message: WIFIDISCONNECTEDMESSAGE) { (isOkTapped) in
            if isOkTapped {
                self.navigateToWiFiSettings()
            }
        }
    }
}
