//
//  ActionSheetIdentifiers.swift
//  KobelcoService
//
//  Created by Swaminath on 11/14/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation

enum ActionSheetIdentifiers: Int {
    case delete = 0
    case save = 1
    case saveAndSend = 2
    case sendAndDelete = 3
}
