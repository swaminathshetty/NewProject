//
//  KSPlistReadAndWriteModel.swift
//  KobelcoService
//
//  Created by Admin on 11/5/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation

class KSPlistReadAndWriteModel {
    func plistFilePath (namePlist: String) -> String {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true) as NSArray
        let documentsDirectory = paths.object(at: 0) as! NSString
        print("plist Path \(documentsDirectory.appendingPathComponent(namePlist+".plist"))")
        return documentsDirectory.appendingPathComponent(namePlist+".plist")
    }

    func readPlistFileAndReturnKey (namePlist: String) -> [String] {
        let path = self.plistFilePath(namePlist: namePlist)
        var plistKeyNames: [String] = []
        if let dict = NSMutableDictionary(contentsOfFile: path) {
            for (key, _) in dict {
                plistKeyNames.append(key as! String)
            }
            return plistKeyNames
        }
        return plistKeyNames
    }

    func readPlistReturnDic(namePlist: String, key: String) -> [String: Any] {
        let path = self.plistFilePath(namePlist: namePlist)
        var output: [String: Any] = [:]
        if let dict = NSMutableDictionary(contentsOfFile: path) {
            output = dict.object(forKey: key) as! [String: Any]
        }
        return output
    }

    func deleteValueFormPlist(namePlist: String, key: String) {
        let path = self.plistFilePath(namePlist: namePlist)
        if let dict = NSMutableDictionary(contentsOfFile: path) {
            dict.removeObject(forKey: key)
            if dict.write(toFile: path, atomically: true) {
                print("plist_write")
            } else {
                print("plist_write_error")
            }
        }
    }

    func readPlist(namePlist: String, key: String) -> AnyObject {
        let path = self.plistFilePath(namePlist: namePlist)
        var output: AnyObject = false as AnyObject
        if let dict = NSMutableDictionary(contentsOfFile: path) {
            output = dict.object(forKey: key)! as AnyObject
        } else {
            if let privPath = Bundle.main.path(forResource: namePlist, ofType: "plist") {
                if let dict = NSMutableDictionary(contentsOfFile: privPath) {
                    output = dict.object(forKey: key)! as AnyObject
                } else {
                    output = false as AnyObject
                    print("error_read")
                }
            } else {
                output = false as AnyObject
                print("error_read")
            }
        }
        print("plist_read \(output)")
        return output
    }

    func writePlist(namePlist: String, key: String, data: AnyObject) {
        let path = self.plistFilePath(namePlist: namePlist)
        if let dict = NSMutableDictionary(contentsOfFile: path) {
            dict.setObject(data, forKey: key as NSCopying)
            if dict.write(toFile: path, atomically: true) {
                print("plist_write")
            } else {
                print("plist_write_error")
            }
        } else {
            do {
            let data = try PropertyListSerialization.data(fromPropertyList: [key: data], format: PropertyListSerialization.PropertyListFormat.binary, options: 0)
                do {
                    try data.write(to: URL(fileURLWithPath: path), options: .atomic)
                    print("Successfully write")
                } catch (let err) {
                    print(err.localizedDescription)
                }
            } catch (let err) {
                print(err.localizedDescription)
            }
        }
    }
}
