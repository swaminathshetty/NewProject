//
//  KSLegendCell.swift
//  ChartLineDemo
//
//  Created by LTTS_iMac_Conti on 25/09/20.
//  Copyright © 2020 LTTS_iMac_Conti. All rights reserved.
//

import UIKit

class KSLegendCell: UITableViewCell {

    @IBOutlet weak var legendNameLabel: UILabel!
    @IBOutlet weak var legendColorImageView: UIImageView!

    func fillCellData(legendDataSet: LegendDataSet) {
        self.legendNameLabel.text = legendDataSet.legendName
        self.legendColorImageView.backgroundColor = legendDataSet.legendColor
    }
}
