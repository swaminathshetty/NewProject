//
//  KSCheckBoxWithLabelCellTableViewCell.swift
//  KobelcoService
//
//  Created by Admin on 11/11/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSCheckBoxWithLabelCellTableViewCell: UITableViewCell {

    @IBOutlet weak var viewParameterBG: UIView!
    @IBOutlet weak var labelParameterName: UILabel!
    @IBOutlet weak var checkBoxImageView: UIImageView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.viewParameterBG.layer.cornerRadius = 6
        self.labelParameterName.font = UIFont.regular(ofSize: 15)
        self.checkBoxImageView.image = UIImage(named: "checkBox")
    }

    // MARK: - Fill cell data based on model
    func fillCellData(lableText: String, isCheckBoxSelected: Bool) {
        self.labelParameterName.text = lableText
        if isCheckBoxSelected {
            self.checkBoxImageView.image = UIImage(named: "checkedBox")
        } else {
            self.checkBoxImageView.image = UIImage(named: "checkBox")
        }
    }
}
