//
//  KSDiagnosticSwitch.swift
//  KobelcoService
//
//  Created by Guest L&T on 06/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

class KSDiagnosticSwitch: UIViewController {

    @IBOutlet weak var switchHeaderView: UIView!
    @IBOutlet weak var switchItemName: UIButton!
    @IBOutlet weak var switchValue: UILabel!
    @IBOutlet weak var switchUnit: UILabel!
    @IBOutlet weak var diagnosticSwitchTableView: UITableView!
    @IBOutlet weak var switchAddButton: UIButton!
    @IBOutlet weak var switchTypeStartButton: UIButton!
    @IBOutlet weak var switchTypeHelpButton: UIButton!
    fileprivate var switchWriteArray = [[String: Any]]()
    fileprivate var switchReadArray = [[String: Any]]()
    fileprivate var switchWriteID = String()
    fileprivate var switchWriteValue = Int()
    fileprivate var switchWriteValues = [Int]()
    fileprivate var switchReadIDs = [String]()
    fileprivate var switchReadValues = [Int]()
    private var switchViewCanSwipe = true

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.setNavigationBarColorWithButtonTitle(buttonTitle: KSSingletonManager.shared.diagnosticNavigationTitle)
        loadDiagnosticSwitchUIComponents()
        KSSingletonManager.shared.delegate = self
    }
    
    // Add custom values to diagnostic switch UI components.
    fileprivate func loadDiagnosticSwitchUIComponents() {
        self.switchHeaderView.layer.cornerRadius = 6
        self.switchItemName.setTitle("Item Name", for: .normal)
        self.switchValue.text = "Value"
        self.switchUnit.text = "Unit"
        self.appendEmptyValuesToSwitchItemListArray()
    }
    // By default append 0 in item values to display in tableview.
    fileprivate func appendEmptyValuesToSwitchItemListArray() {
        self.switchReadArray.removeAll(keepingCapacity: false)
        self.switchReadValues.removeAll(keepingCapacity: false)
        self.switchWriteArray.removeAll(keepingCapacity: false)
        self.switchReadIDs.removeAll(keepingCapacity: false)
        self.readAndWriteSignalsSeperation()
        for switchItemDict in switchReadArray {
            switchReadValues.append(0)
            guard let switchItemID = switchItemDict["id"] as? String else { return }
            switchReadIDs.append(switchItemID)
        }
    }
    // Seperate Read and Write Dianostic Sub Menu Details.
    fileprivate func readAndWriteSignalsSeperation() {
        for switchItemObject in KSSingletonManager.shared.diagnosticSubMenuArray {
            guard let switchItemType = switchItemObject["type"] as? String else { return }
            if switchItemType == "ReadOnly" {
                self.switchReadArray.append(switchItemObject)
            } else {
                self.switchWriteArray.append(switchItemObject)
            }
        }
        self.appendEmptyValuesToWriteSignals()
    }
    // Append 0 default value to write Signal values.
    fileprivate func appendEmptyValuesToWriteSignals() {
        self.switchWriteValues.removeAll(keepingCapacity: false)
        for _ in switchWriteArray {
            self.switchWriteValues.append(0)
        }
    }

    // Click on this button to add parameters from parameters screen.
    @IBAction func appParametersDiagnosticSwitchAction(_ sender: Any) {
        self.navigation(to: Identifier.diagnosticAddParameter)
    }
    
    // Its a toggle operation, start and stop websocket value readings.
    @IBAction func startDiagnosticSwitchAction(_ sender: UIButton) {
        if switchReadArray.count > 0 {
            if KSSingletonManager.shared.isDiagnsoticStart { // Stop
                startAndStopTextBind(isStart: false, title: "Stop", canSwipe: true, isEnable: true)
            } else { // Start
                startAndStopTextBind(isStart: true, title: "Start", canSwipe: false, isEnable: false)
                sendDiagnosticSocketRequest(writeIDs: [switchWriteID], writeValues: [switchWriteValue], interval: 500)
            }
        } else {
            self.presentAlert(withTitle: "Message", message: "To Start Diagnostic Test, please add few read signals from add parameter screen and try again gain.")
        }
    }
    // Called when user click on start or stop button.
    fileprivate func startAndStopTextBind(isStart: Bool, title: String, canSwipe: Bool, isEnable: Bool) {
        KSSingletonManager.shared.isDiagnsoticStart = isStart
        switchTypeStartButton.setTitle(title, for: .normal)
        switchViewCanSwipe = canSwipe
        switchAddButton.isEnabled = isEnable
        switchTypeHelpButton.isEnabled = isEnable
        navigationController?.navigationBar.isUserInteractionEnabled = isEnable
    }
    // Send websocket request With read and write signal IDs
    fileprivate func sendDiagnosticSocketRequest(writeIDs: [String], writeValues: [Int], interval: Int) {
        self.showLoader()
        let switchID = KSSingletonManager.shared.diagnosticMainID
        let screenTitle = "DiagnosticTestFunction"
        let switchCommand = DiagnosticStartRequest(screenName: screenTitle, frameType: switchID, writeSignals: writeIDs, writeValue: writeValues, readSignals: switchReadIDs, periodicity: interval)
        guard let normalRequestData = try? JSONEncoder().encode(switchCommand) else { return }
        KSSingletonManager.shared.sendCommand(format: normalRequestData)
    }

    // Click on this to show help alertview.
    @IBAction func helpDiagnosticSwitchAction(_ sender: Any) {
        let switchExplanation = KSSingletonManager.shared.explanationDiagnostic
        let switchAttention = KSSingletonManager.shared.attentionDiagnostic
        DispatchQueue.main.async {
             self.presentAttributedStringAlert(message1: switchExplanation, message2: switchAttention) { (_ ) in
             }
         }
    }
    // Clear all arrays data and set storage capacity to false.
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(true)
        /*switchWriteArray.removeAll(keepingCapacity: false)
        switchReadArray.removeAll(keepingCapacity: false)
        switchWriteValues.removeAll(keepingCapacity: false)
        switchReadIDs.removeAll(keepingCapacity: false)
        switchReadValues.removeAll(keepingCapacity: false)
        switchWriteID.removeAll(keepingCapacity: false)*/
    }
}

// MARK: Tableview delegates
extension KSDiagnosticSwitch: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        //return switchWriteArray.count > 0 ? 2 : 1
        return 2
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return section == 0 ? switchWriteArray.count : switchReadArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Load Diagnostic Switch Signals.
        if indexPath.section == 0 {
            print("indexPath.section == 0")
            let switchTypeObject = switchWriteArray[indexPath.row]
            let switchMenuType = switchTypeObject["type"] as? String
            if switchMenuType == "Switch" {
                print("Switch MenuType")
                let switchCellIdentifier = "KSDiagnosticSwitchCell"
                let switchCell = tableView.dequeueReusableCell(withIdentifier: switchCellIdentifier) as! KSDiagnosticSwitchCell
                switchCell.switchToggleButton.tag = indexPath.row
                switchCell.configureDiagnosticSwitchCell(switchObject: switchWriteArray[indexPath.row], switchInput: switchWriteValue)
                switchCell.switchToggleButton.addTarget(self, action: #selector(diagnosticSwitchOnAndOffAction(_ :)), for: .touchUpInside)
                return switchCell
            } else {
                print("UpDown MenuType")
                let switchCellIdentifier = "KSDiagnosticSwitchCell"
                let switchCell = tableView.dequeueReusableCell(withIdentifier: switchCellIdentifier) as! KSDiagnosticSwitchCell
                switchCell.switchToggleButton.tag = indexPath.row
                switchCell.configureDiagnosticSwitchCell(switchObject: switchWriteArray[indexPath.row], switchInput: switchWriteValue)
                switchCell.switchToggleButton.addTarget(self, action: #selector(diagnosticSwitchOnAndOffAction(_ :)), for: .touchUpInside)
                return switchCell
            }
        // Load Diagnostic Read Signals.
        } else {
            print("indexPath.section == 1")
            let switchReadIdentifier = "KSDiagnosticNormalCell"
            let switchReadCell = tableView.dequeueReusableCell(withIdentifier: switchReadIdentifier) as! KSDiagnosticNormalCell
            switchReadCell.configureDiagnosticNormalCell(normalObject: switchReadArray[indexPath.row], itemValue: switchReadValues[indexPath.row])
            return switchReadCell
        }
    }
    // Tap to send toggle switch write value in websocket request.
    @objc func diagnosticSwitchOnAndOffAction(_ sender: UISwitch) {
        DispatchQueue.main.async {//switchWriteArray
            let switchWriteObject = self.switchWriteArray[sender.tag]
            guard let switchID = switchWriteObject["id"] as? String else { return }
            self.switchWriteID = switchID
            let toggleValue = sender.isOn == true ? 1 : 0
            self.switchWriteValues[sender.tag] = toggleValue
            self.sendDiagnosticSocketRequest(writeIDs: [self.switchWriteID], writeValues: [toggleValue], interval: 500)
        }
    }
}

// MARK: WebSocket Response Delegate
extension KSDiagnosticSwitch: KSWebSocketDelegates {
    func webSocketStringResponse(response: String) {
        print("response: \(response)")
        guard let jsonDictionary = convertToDictionary(text: response) else { return }
        guard let screenTitle = jsonDictionary["screenName"] as? String else { return }
        if screenTitle == "DiagnosticTestFunction" {
            self.hideLoader()
            //memoryResetSubMenuCanSwipe = true
            // Read values from the websocket response and update to tableview.
            guard let readSignalValues = jsonDictionary["values"] as? [Int] else { return }
            DispatchQueue.main.async {
                if readSignalValues.count == self.switchReadArray.count {
                    self.switchReadValues.removeAll(keepingCapacity: false)
                    self.switchReadValues = readSignalValues
                    self.diagnosticSwitchTableView.reloadData()
                    return
                } else {
                    self.presentAlert(withTitle: "Error in Response", message: "Request and Response signals are not matching, please try again after some time.")
                    return
                }
            }
        }
    }
    // Called when error connection in websocket communication
    func webSocketErrorConnection(message: String) {
        self.hideLoader()
        presentAlert(withTitle: "ERROR", message: message)
    }
    // Called when internet is disconnected or network not reachable.
    func internetConnectionNotAvailable() {
        self.hideLoader()
        presentAlertOKAction(withTitle: "ERROR", message: WIFIDISCONNECTEDMESSAGE) { (isOkTapped) in
            if isOkTapped {
                self.navigateToWiFiSettings()
            }
        }
    }
}
