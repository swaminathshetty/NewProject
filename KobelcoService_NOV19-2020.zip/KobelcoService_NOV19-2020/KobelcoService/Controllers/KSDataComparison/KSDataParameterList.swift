//
//  KSDataParameterList.swift
//  KobelcoService
//
//  Created by Swaminath on 10/6/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

class KSDataParameterList: UIViewController {

    @IBOutlet weak var parametersListTableView: UITableView!
    @IBOutlet weak var serachTextField: UISearchBar!
    var totalParametersList = [String]()
    fileprivate var scannedData: [String]!
    weak var delegate: KSPlotChartsDelegate!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        scannedData = totalParametersList
    }
}

// MARK: Tableview Delegate
extension KSDataParameterList: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return scannedData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "KSModelTypeCell", for: indexPath) as! KSModelTypeCell
        cell.labelTitle.text = scannedData[indexPath.row]
        return cell
    }
    
    // Select the paramter from list and pass as a parameter in delegate method.
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedParameter = scannedData[indexPath.row]
        self.dismiss(animated: true, completion: nil)
        delegate.sendSelectedParameter(parameterName: selectedParameter) // Send selected parameter to plotchart screen.
    }
    
    // Set the default row height for tableview.
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 44
    }
    
}

// MARK: - SearchBar Delegate
extension KSDataParameterList: UISearchBarDelegate {
    
    // Used to filter the strings based on the user input and showcase on tableview list.
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        scannedData = searchText.isEmpty ? totalParametersList : totalParametersList.filter({(dataString: String) -> Bool in
            return dataString.range(of: searchText, options: .caseInsensitive) != nil
        })

        parametersListTableView.reloadData()
    }

    // Dismiss viewcontroller by clicking on search cancel button.
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.view.endEditing(true)
        self.dismiss(animated: true, completion: nil)
    }
}
