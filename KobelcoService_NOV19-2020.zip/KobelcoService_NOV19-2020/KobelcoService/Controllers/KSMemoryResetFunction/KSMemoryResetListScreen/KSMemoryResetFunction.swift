//
//  KSMemoryResetFunction.swift
//  KobelcoService
//
//  Created by Guest L&T on 23/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

class KSMemoryResetFunction: UIViewController {

    @IBOutlet weak var tableView_MemoryReset: UITableView!
    fileprivate var memoryResetItems = [[String: Any]]() // Used to Store only memory reset list items
    fileprivate var menuType = "Switch" // Used to identify menu items display
    fileprivate var selectedCellTitle = ""
    fileprivate var memoryResetMenuCanSwipe = false
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Memory Reset Function")
        self.navigationItem.hidesBackButton = true // Used to hide navigation back button.
        self.navigationController?.getMemoryResetMainNavigationID()
        tableView_MemoryReset.layer.cornerRadius = 6
        tableView_MemoryReset.estimatedRowHeight = 55
        tableView_MemoryReset.rowHeight = UITableView.automaticDimension
        KSSingletonManager.shared.delegate = self
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.memoryResetMenuCanSwipe = false
        self.configureMemoryResetGestureRecognizers()
        KSSingletonManager.shared.delegate = self
        self.showLoader()
        KSSingletonManager.shared.connectWebSocket()
    }
    // Configure gesture recognizer for UIView
    fileprivate func configureMemoryResetGestureRecognizers() {
        let swipeRightMR = UISwipeGestureRecognizer(target: self, action: #selector(respondToMRSwipeGesture))
        swipeRightMR.direction = .right
        self.view.addGestureRecognizer(swipeRightMR)
        
        let swipeLeftMR = UISwipeGestureRecognizer(target: self, action: #selector(respondToMRSwipeGesture))
        swipeLeftMR.direction = .left
        self.view.addGestureRecognizer(swipeLeftMR)
    }
    // Navigate to particular screen based on swipe direction.
    @objc func respondToMRSwipeGesture(gesture: UIGestureRecognizer) {
        if memoryResetMenuCanSwipe {
            if let swipeGesture = gesture as? UISwipeGestureRecognizer {
                 switch swipeGesture.direction {
                 case .right:
                    self.popOverToBackScreen(indexValue: KSSingletonManager.shared.errorCodeNavigationID)
                 case .left:
                    self.navigation(to: Identifier.setValueWritingFunction)
                 default:
                     break
                 }
             }
        }
    }
}

// MARK: - Tableview delegates
extension KSMemoryResetFunction: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let memoryResetList = KSSingletonManager.shared.matrixObject["memoryResetFunction"] as? [[String: Any]] else { return 0 }
        memoryResetItems.append(contentsOf: memoryResetList)
        return memoryResetList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let type = memoryResetItems[indexPath.row]["type"] as? String {
            menuType = type.contains("Submenu") ? "Submenu" : "Switch"
        }
        // Load cell title as disclouser type, if menu type belongs to submenu kind
        if menuType == "Submenu" {
            let cellIdentifier = "KSMemoryResetCell"
            let disclouserCell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as! KSMemoryResetCell
            let subMenuTitle = getMemoryResetMenuTitle(index: indexPath.row)
            disclouserCell.configureCellTitle(titleString: subMenuTitle)
            return disclouserCell
        } else {
            // Load cell title as Switch type, if menu type belongs to switch kind
            let cellIdentifier = "KSMemoryResetSwitchCell"
            let switchCell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as! KSMemoryResetSwitchCell
            switchCell.switchOnOff.tag = indexPath.row
            let switchTitle = getMemoryResetMenuTitle(index: indexPath.row)
            switchCell.configureSwitchCellTitle(titleString: switchTitle)
            switchCell.switchOnOff.addTarget(self, action: #selector(memoryResetSwitchOnAndOffAction(_ :)), for: .touchUpInside)
            return switchCell
        }
     }
    // Tap on to send Memory reset switch type command.
    @objc func memoryResetSwitchOnAndOffAction(_ sender: UISwitch) {
        DispatchQueue.main.async {
            self.presentAlertWithAction(title: "Confirmation", message: MRCONFIRMATIONALERT, action1Title: "Cancel", action2Title: "Clear") { [unowned self] (isSuccess) in
                sender.isOn = false
                if isSuccess {
                    guard let resetFrameID = self.memoryResetItems[sender.tag]["id"] as? String else { return }
                    self.showLoader()
                    self.memoryResetMenuCanSwipe = false
                    let resetSwitchCommand = ResetSocketRequest(screenName: "MemoryResetFunction", frameType: resetFrameID, periodicity: 0)
                    guard let resetRequestData = try? JSONEncoder().encode(resetSwitchCommand) else { return }
                    KSSingletonManager.shared.sendCommand(format: resetRequestData)
                }
            }
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedTitle = getMemoryResetMenuTitle(index: indexPath.row)
        guard let submenuArray = memoryResetItems[indexPath.row]["submenu"] as? [[String: Any]] else { return }
        guard let resetFrameID = self.memoryResetItems[indexPath.row]["id"] as? String else { return }
        if submenuArray.count > 0 {
            let memoryResetSubScreen = MAINSTORYBOARD.instantiateViewController(withIdentifier: "KSMemoryReset") as? KSMemoryReset
            memoryResetSubScreen?.navigationTitle = selectedTitle
            memoryResetSubScreen?.itemsList = submenuArray
            memoryResetSubScreen?.selectedFrameID = resetFrameID
            self.navigationController?.pushViewController(memoryResetSubScreen!, animated: true)
        }
    }
    // Used to fetch menu title from memory reset matrix list.
    func getMemoryResetMenuTitle(index: Int) -> String {
        guard let menuTitleDict = memoryResetItems[index]["name"] as? [String: Any] else { return "" }
        guard let menuName = menuTitleDict["en"] as? String else { return "" }
        return menuName
    }
}

// MARK: WebSocket Response Delegate
extension KSMemoryResetFunction: KSWebSocketDelegates {
    func webSocketStringResponse(response: String) {
        print("response: \(response)")
        if response.contains("Connection Opened") {
            self.hideLoader()
            memoryResetMenuCanSwipe = true
        }
        guard let jsonDictionary = convertToDictionary(text: response) else { return }
        guard let screenTitle = jsonDictionary["screenName"] as? String else { return }
        guard let resetStatus = jsonDictionary["status"] as? Int else { return }
        if screenTitle == "MemoryResetFunction" {
            self.hideLoader()
            memoryResetMenuCanSwipe = true
            let resultMessage = resetStatus == 1 ? MEMORYRESETSUCCESSALERT : MEMORYRESETFAILALERT
            presentAlert(withTitle: ALERTTITLESTRING, message: resultMessage)
        }
    }
    // Called when error connection in websocket communication
    func webSocketErrorConnection(message: String) {
        self.hideLoader()
        presentAlert(withTitle: "Network Error", message: message)
    }
    // Called when internet is disconnected or network not reachable.
    func internetConnectionNotAvailable() {
        self.hideLoader()
        presentAlertOKAction(withTitle: "ERROR", message: WIFIDISCONNECTEDMESSAGE) { (isOkTapped) in
            if isOkTapped {
                self.navigateToWiFiSettings()
            }
        }
    }
}
