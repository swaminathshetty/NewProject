//
//  KSParameterAddfavorite.swift
//  KobelcoService
//
//  Created by Admin on 11/5/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

protocol KSParameterAddfavoriteDelegate: class {
    func parameterAddCaption(txtValue: String)
}

extension KSParameterAddfavoriteDelegate {
    func parameterAddCaption(txtValue: String) {}
}

class KSParameterAddfavorite: UIViewController {
    @IBOutlet weak var newParameterTextField: UITextField!
    @IBOutlet weak var createParameterButton: UIButton!
    weak var ksParameterAddfavoriteDelegate: KSParameterAddfavoriteDelegate?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Add Favorite")
        self.newParameterTextField.setCustomTextFieldStyle()
    }
    @IBAction func createNewParameterTapAction(_ sender: Any) {
        self.ksParameterAddfavoriteDelegate?.parameterAddCaption(txtValue: self.newParameterTextField.text!)
        self.navigationController?.popViewController(animated: true)
    }
}
