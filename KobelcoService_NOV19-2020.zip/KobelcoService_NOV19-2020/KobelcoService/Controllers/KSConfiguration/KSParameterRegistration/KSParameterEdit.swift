//
//  KSParameterEdit.swift
//  KobelcoService
//
//  Created by Guest L&T on 01/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

class KSParameterEdit: UIViewController {

    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var footerView: UIView!
    @IBOutlet weak var textFieldParameter: UITextField!
    @IBOutlet weak var tableViewParameters: UITableView!
    @IBOutlet weak var buttonDelete: UIButton!
    @IBOutlet weak var buttonSave: UIButton!
    @IBOutlet weak var enginePumpSegmentRegistration: UISegmentedControl!
    var selectedFavoriteParameter = ""
    var ecuSignalsArray: [ECUSignalsModel] = []
    var pumpSignalsArray: [ECUSignalsModel] = []
    var plistHelepr = KSPlistReadAndWriteModel()

    override func viewDidLoad() {
        super.viewDidLoad()
        loadParameterEditComponents()
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Edit Favorite")
        let output = plistHelepr.readPlistReturnDic(namePlist: "SetParameters", key: selectedFavoriteParameter)
        self.tableViewParameters.register(UINib(nibName: "KSCheckBoxWithLabelCellTableViewCell", bundle: nil), forCellReuseIdentifier: "KSCheckBoxWithLabelCellTableViewCell")
        self.setECUPumpArrayValues(dicValue: output)
    }
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
    //Configure UI Components
    func loadParameterEditComponents() {
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.headerView.layer.cornerRadius = 6
        self.buttonDelete.setTitle("Delete", for: .normal)
        self.buttonSave.setTitle("Save", for: .normal)
        self.textFieldParameter.text = self.selectedFavoriteParameter
    }
    @IBAction func deleteButtonTapAction(_ sender: Any) {
        self.plistHelepr.deleteValueFormPlist(namePlist: "SetParameters", key: selectedFavoriteParameter)
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func saveButtonTapAction(_ sender: Any) {
        if selectedFavoriteParameter != self.textFieldParameter.text {
            self.plistHelepr.deleteValueFormPlist(namePlist: "SetParameters", key: selectedFavoriteParameter)
        }

        self.parameterAddCaption(txtValue: self.textFieldParameter.text!)
        self.navigationController?.popViewController(animated: true)
    }

    // Toggle segment for engine and pump selection.
    // By default engine and ECU will select and display respective list in the parameter tableview.
    @IBAction func enginePumpRegistrationmainSegmentAction(_ sender: Any) {
        self.tableViewParameters.reloadData()
    }

    func setECUPumpArrayValues(dicValue: [String: Any]) {
        let ecuSignals = dicValue["ECUSignals"] as! [[String: Any]]
        self.ecuSignalsArray = ecuSignals.map {ECUSignalsModel.init(data: $0)}
        let pumpSignals = dicValue["pumpSignals"] as! [[String: Any]]
        self.pumpSignalsArray = pumpSignals.map {ECUSignalsModel.init(data: $0)}
    }

    func parameterAddCaption(txtValue: String) {
        var data: [String: Any]
        let ecuDictionary = self.ecuSignalsArray.map {$0.asDictionary}
        let pumpDictionary = self.pumpSignalsArray.map {$0.asDictionary}
        data = ["ECUSignals": ecuDictionary, "pumpSignals": pumpDictionary]
        plistHelepr.writePlist(namePlist: "SetParameters", key: txtValue, data: data as AnyObject)
    }

}

// MARK: Tableview Delegate
extension KSParameterEdit: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.enginePumpSegmentRegistration.selectedSegmentIndex == 1 {
            return self.pumpSignalsArray.count
        } else {
            return self.ecuSignalsArray.count
        }
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let theParameterCell = tableView.dequeueReusableCell(withIdentifier: "KSCheckBoxWithLabelCellTableViewCell") as! KSCheckBoxWithLabelCellTableViewCell
        self.setUpTheParameterTableView(cellObj: theParameterCell, indexValue: indexPath.row)
        return theParameterCell
    }

    func setUpTheParameterTableView(cellObj: KSCheckBoxWithLabelCellTableViewCell, indexValue: Int) {
        var txtLabel = ""
        var isSelected = false
        if self.enginePumpSegmentRegistration.selectedSegmentIndex == 1 {
            txtLabel = self.pumpSignalsArray[indexValue].name["en"] as! String
            isSelected = self.pumpSignalsArray[indexValue].isSelected
        } else {
            txtLabel = self.ecuSignalsArray[indexValue].name["en"] as! String
            isSelected = self.ecuSignalsArray[indexValue].isSelected
        }

        cellObj.fillCellData(lableText: txtLabel, isCheckBoxSelected: isSelected)
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.parameterCheckBoxButtonPressed(indexValue: indexPath.row)
    }
}

extension KSParameterEdit {
    func parameterCheckBoxButtonPressed(indexValue: Int) {
         if self.enginePumpSegmentRegistration.selectedSegmentIndex == 1 {
            var pump = self.pumpSignalsArray[indexValue]
            pump.isSelected = !pump.isSelected
            self.pumpSignalsArray[indexValue] = pump
         } else {
            var ecu = self.ecuSignalsArray[indexValue]
            ecu.isSelected = !ecu.isSelected
            self.ecuSignalsArray[indexValue] = ecu
         }
        let reloadIndex = IndexPath(row: indexValue, section: 0)
        self.tableViewParameters.reloadRows(at: [reloadIndex], with: .none)
    }
}
