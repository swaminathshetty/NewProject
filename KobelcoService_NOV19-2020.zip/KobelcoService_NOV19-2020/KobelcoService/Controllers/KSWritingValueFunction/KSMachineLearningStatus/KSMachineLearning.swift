//
//  KSMachineLearning.swift
//  KobelcoService
//
//  Created by Swaminath on 9/26/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

class KSMachineLearning: UIViewController {

    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var topItemName: UILabel!
    @IBOutlet weak var topValue: UILabel!
    @IBOutlet weak var topUnit: UILabel!
    @IBOutlet weak var unitsLabel: UILabel!
    @IBOutlet weak var learningStatusTableView: UITableView!
    var machineitemsList = [[String: Any]]()
    var machineReadItemIDs = [String]()
    var machineFrameID = ""
    fileprivate var machineItemValues = [Int]()
    fileprivate var machineLearningViewCanSwipe = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Machine Learning Status")
        self.appendEmptyValuesToMachineLearningItemsArray()
        self.topView.layer.cornerRadius = 6
        self.topView.backgroundColor = HEADERVIEWCOLOR
        self.configureMachineLearningGestureRecognizers()
        learningStatusTableView.estimatedRowHeight = 44
        learningStatusTableView.rowHeight = UITableView.automaticDimension
        self.showLoader()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.machineLearningViewCanSwipe = false
        KSSingletonManager.shared.delegate = self
        KSSingletonManager.shared.connectWebSocket()
        self.perform(#selector(sendMachineLearningReadWebSocketRequest), with: self, afterDelay: 2)
    }
    // Configure gesture recognizer for UIView
    fileprivate func configureMachineLearningGestureRecognizers() {
        let swipeRightMR = UISwipeGestureRecognizer(target: self, action: #selector(respondToMachineLearningSwipeGesture))
        swipeRightMR.direction = .right
        self.view.addGestureRecognizer(swipeRightMR)
        
        let swipeLeftMR = UISwipeGestureRecognizer(target: self, action: #selector(respondToMachineLearningSwipeGesture))
        swipeLeftMR.direction = .left
        self.view.addGestureRecognizer(swipeLeftMR)
    }
    // Navigate to particular screen based on swipe direction.
    @objc func respondToMachineLearningSwipeGesture(gesture: UIGestureRecognizer) {
        if machineLearningViewCanSwipe {
            if let swipeGesture = gesture as? UISwipeGestureRecognizer {
                switch swipeGesture.direction {
                case .right:
                    self.popOverToBackScreen(indexValue: KSSingletonManager.shared.setValueFunctionID)
                case .left:
                    self.navigation(to: Identifier.diagnosticTest)
                default:
                    break
                }
            }
        }
    }
    // By default append 0 in item values to display in tableview.
    fileprivate func appendEmptyValuesToMachineLearningItemsArray() {
        machineItemValues.removeAll(keepingCapacity: false)
        for machineDict in machineitemsList {
            machineItemValues.append(0)
            guard let machineItemID = machineDict["id"] as? String else { return }
            machineReadItemIDs.append(machineItemID)
        }
        print("itemValues.count: \(machineItemValues.count)")
    }
    // Send read websocket request to get item values.
    @objc fileprivate func sendMachineLearningReadWebSocketRequest() {
        let machineReadCommand = ReadSubmenuSocketRequest(screenName: "MachineLearning", frameType: machineFrameID, readSignals: machineReadItemIDs, periodicity: 0)
        guard let machineRequestData = try? JSONEncoder().encode(machineReadCommand) else { return }
        KSSingletonManager.shared.sendCommand(format: machineRequestData)
    }
}

// MARK: Tableview delegates
extension KSMachineLearning: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return machineitemsList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "KSMachineLearningCell"
        let MLStatusCell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as! KSMachineLearningCell
        MLStatusCell.configureMachineLearningStatusCellTitle(itemObject: machineitemsList[indexPath.row], itemValue: machineItemValues[indexPath.row])
        return MLStatusCell
    }
}

// MARK: WebSocket Response Delegate
extension KSMachineLearning: KSWebSocketDelegates {
    func webSocketStringResponse(response: String) {
        guard let jsonDictionary = convertToDictionary(text: response) else { return }
        guard let screenTitle = jsonDictionary["screenName"] as? String else { return }
        if screenTitle == "MachineLearning" {
            self.hideLoader()
            self.setNavigationBarColorWithButtonTitle(buttonTitle: "Machine Learning Status")
            machineLearningViewCanSwipe = true
            // Read values from the websocket response and update values in the tableview.
            guard let readMachineValues = jsonDictionary["values"] as? [Int] else { return }
            self.machineItemValues = readMachineValues
        }
        DispatchQueue.main.async {
            self.learningStatusTableView.reloadData()
        }
    }
    // Called when error connection in websocket communication
    func webSocketErrorConnection(message: String) {
        self.hideLoader()
        presentAlert(withTitle: "Network Error", message: message)
    }
    // Called when internet is disconnected or network not reachable.
    func internetConnectionNotAvailable() {
        self.hideLoader()
        presentAlertOKAction(withTitle: "ERROR", message: WIFIDISCONNECTEDMESSAGE) { (isOkTapped) in
            if isOkTapped {
                self.navigateToWiFiSettings()
            }
        }
    }
}
