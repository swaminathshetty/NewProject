//
//  KSInjectorPartEntry.swift
//  KobelcoService
//
//  Created by Swaminath on 9/26/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

// Protocals for to add scan QR as a child and 
@objc protocol KSInjectorPartDelegate {
    func showConfirmationAlertIfRequired(UIType: String, indexID: Int, injectorHandler: @escaping (Bool) -> Void)
    func addScanQRChildController()
    func removeScanQRChildContoller(QRCode: String)
    func getTextFieldEntryQRValue(indexID: Int, QRCodeValue: String)
}

class KSInjectorPartEntry: UIViewController {

    @IBOutlet weak var tableViewInjectorNumbers: UITableView!
    @IBOutlet weak var doneButton: UIButton!
    var scanQRViewController: KSScanInjectorQRCode?
    var qrCodeFrameID = ""
    var qrCodeValueList = [String]()
    fileprivate var injectorViewCanSwipe = false
    fileprivate var selectedQRIndex = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        super.viewDidAppear(true)
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Injector Part Number Entry")
        self.configureInjectorPartGestureRecognizers()
        self.tableViewInjectorNumbers.rowHeight = 94
        self.tableViewInjectorNumbers.estimatedRowHeight = UITableView.automaticDimension
        initilaizeInjectorPartWebSocketCommunication()
    }
    // Hide iPhoneX/Pro Footer-Line.
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
    // Establish websocket communication and send websocket read request to get qr values.
    fileprivate func initilaizeInjectorPartWebSocketCommunication() {
        self.injectorViewCanSwipe = false
        self.showLoader()
        KSSingletonManager.shared.delegate = self
        KSSingletonManager.shared.connectWebSocket()
        self.perform(#selector(sendInjectorNumbersReadWebSocketRequest), with: self, afterDelay: 2)
    }
    // Click on this to submit updated injector values in websocket request.
    @IBAction func doneButtonAction(_ sender: Any) {
        self.showLoader()
        self.reloadInjectorCodesTableView()
        let injectorWriteCommand = WriteInjectorsRequest(screenName: "InjectorPartNumber", frameType: qrCodeFrameID, writeValues: qrCodeValueList, periodicity: 0)
        guard let injectorWriteData = try? JSONEncoder().encode(injectorWriteCommand) else { return }
        KSSingletonManager.shared.sendCommand(format: injectorWriteData)
        self.doneButton.isEnabled = false
    }
    // Configure gesture recognizer for UIView
    fileprivate func configureInjectorPartGestureRecognizers() {
        let swipeRightMR = UISwipeGestureRecognizer(target: self, action: #selector(respondToInjectorPartSwipeGesture))
        swipeRightMR.direction = .right
        self.view.addGestureRecognizer(swipeRightMR)
        
        let swipeLeftMR = UISwipeGestureRecognizer(target: self, action: #selector(respondToInjectorPartSwipeGesture))
        swipeLeftMR.direction = .left
        self.view.addGestureRecognizer(swipeLeftMR)
    }
    // Navigate to particular screen based on swipe direction.
    @objc func respondToInjectorPartSwipeGesture(gesture: UIGestureRecognizer) {
        if injectorViewCanSwipe {
            if let swipeGesture = gesture as? UISwipeGestureRecognizer {
                switch swipeGesture.direction {
                case .right:
                    self.popOverToBackScreen(indexValue: KSSingletonManager.shared.setValueFunctionID)
                case .left:
                    self.navigation(to: Identifier.diagnosticTest)
                default:
                    break
                }
            }
        }
    }
    // Send read websocket request to get item values.
    @objc fileprivate func sendInjectorNumbersReadWebSocketRequest() {
        let injectorReadCommand = ResetSocketRequest(screenName: "InjectorPartNumber", frameType: qrCodeFrameID, periodicity: 0)
        guard let injectorRequestData = try? JSONEncoder().encode(injectorReadCommand) else { return }
        KSSingletonManager.shared.sendCommand(format: injectorRequestData)
    }
}
// MARK: TableView Delegate
extension KSInjectorPartEntry: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return qrCodeValueList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "KSInjectorNumberCell"
        let injectorCell: KSInjectorNumberCell?
        injectorCell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? KSInjectorNumberCell
        injectorCell?.buttonQRCode.tag = indexPath.row
        injectorCell?.textViewNumber.tag = indexPath.row
        injectorCell?.injectorDelegate = self
        injectorCell?.configureInjectorCellDetails(injectorName: indexPath.row + 1, injectorNumber: qrCodeValueList[indexPath.row])
        injectorCell?.buttonQRCode.addTarget(self, action: #selector(scanInjectorQRCode(_ :)), for: .touchUpInside)
        return injectorCell!
    }
    
    // Click on this to change the default QR value with updated scan value.
    @objc fileprivate func scanInjectorQRCode(_ sender: UIButton) {
        self.selectedQRIndex = sender.tag
        self.showConfirmationAlertIfRequired(UIType: "BUTTON", indexID: sender.tag) { (_ ) in
        }
    }
}

// MARK: Extension for add/remove child controllers.
extension KSInjectorPartEntry: KSInjectorPartDelegate {
    
    // Condition check for to show confirmation alert.
    func showConfirmationAlertIfRequired(UIType: String, indexID: Int, injectorHandler: @escaping (Bool) -> Void) {
        if self.doneButton.isEnabled == false {
            self.presentAlertWithAction(title: "Confirmation", message: QRCODECONFIRMATION, action1Title: "No", action2Title: "Yes") { (isSuccess) in
                if isSuccess {
                    DispatchQueue.main.async {
                        injectorHandler(true)
                        self.selectedQRIndex = indexID
                        self.doneButton.isEnabled = true
                        self.addScanQRChildController()
                    }
                }
            }
        } else {
            if UIType == "BUTTON" { // Navigate to QRScan controller when tap on scan button.
                self.addScanQRChildController()
            } else {
                injectorHandler(true) // Make it true to enable textview keyboard.
            }
        }
    }
    // Used to add QR child controller on top of the current controller
    func addScanQRChildController() {
        scanQRViewController = MAINSTORYBOARD.instantiateViewController(withIdentifier: Identifier.scanInjectorQRCode.rawValue) as? KSScanInjectorQRCode
        scanQRViewController?.delegate = self
        scanQRViewController?.modalPresentationStyle = .fullScreen
        self.present(scanQRViewController!, animated: true, completion: nil)
    }

    // Called from scan QR code screen to remove the child controller
    func removeScanQRChildContoller(QRCode: String) {
        qrCodeValueList[selectedQRIndex] = QRCode
        self.reloadInjectorCodesTableView()
    }
    // get updated QR code value from tableview textfield from tableview cell
    func getTextFieldEntryQRValue(indexID: Int, QRCodeValue: String) {
        qrCodeValueList[indexID] = QRCodeValue
    }
    // Refresh tableview list when new items added.
    fileprivate func reloadInjectorCodesTableView() {
        DispatchQueue.main.async {
            self.tableViewInjectorNumbers.reloadData()
        }
    }
}
// MARK: WebSocket Response Delegate
extension KSInjectorPartEntry: KSWebSocketDelegates {
    func webSocketStringResponse(response: String) {
        print("response: \(response)")
        guard let jsonDictionary = convertToDictionary(text: response) else { return }
        guard let screenTitle = jsonDictionary["screenName"] as? String else { return }
        if screenTitle == "InjectorPartNumber" {
            self.hideLoader()
            self.injectorViewCanSwipe = true
            let resposneKeys = jsonDictionary.keys
            // print("resposneKeys: \(resposneKeys)")
            // Condition check for 2 type responses. If response contains status key show success or failure message.
            if resposneKeys.contains("status") {
                guard let injectorWriteStatus = jsonDictionary["status"] as? Int else { return }
                let resultMessage = injectorWriteStatus == 1 ? QRCODESUCESSMESSAGE : QRCODEFAILMESSAGE
                self.presentAlertOKAction(withTitle: ALERTTITLESTRING, message: resultMessage) { (_ ) in
                    self.sendInjectorNumbersReadWebSocketRequest()
                }
            } else {
                self.qrCodeValueList.removeAll(keepingCapacity: false)
                guard let injectorArray = jsonDictionary["injectorNumbers"] as? [String] else { return }
                self.qrCodeValueList.append(contentsOf: injectorArray)
            }
        }
        self.reloadInjectorCodesTableView()
    }
    // Called when error connection in websocket communication
    func webSocketErrorConnection(message: String) {
        self.hideLoader()
        presentAlert(withTitle: "Network Error", message: message)
    }
    // Called when internet is disconnected or network not reachable.
    func internetConnectionNotAvailable() {
        self.hideLoader()
        presentAlertOKAction(withTitle: "ERROR", message: WIFIDISCONNECTEDMESSAGE) { (isOkTapped) in
            if isOkTapped {
                self.navigateToWiFiSettings()
            }
        }
    }
}
