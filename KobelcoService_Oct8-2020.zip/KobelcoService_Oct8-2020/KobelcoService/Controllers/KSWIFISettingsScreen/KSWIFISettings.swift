//
//  KSWIFISettings.swift
//  KobelcoService
//
//  Created by Guest L&T on 11/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit
import NotificationCenter
import UserNotifications

class KSWIFISettings: UIViewController {

    @IBOutlet weak var button_WIFISettings: UIButton!
    @IBOutlet weak var label_SSIDName: UILabel!
    @IBOutlet weak var label_Start: UILabel!
    @IBOutlet weak var button_Start: UIButton!
    @IBOutlet weak var button_WithoutWIFI: UIButton!
    fileprivate var isWIFIViewPresented: Bool = true

    private let wifiSettingVM: KSWiFiSettingsVM

    init(wifiSettingVM: KSWiFiSettingsVM) {
        self.wifiSettingVM = wifiSettingVM
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) {
        self.wifiSettingVM = KSWiFiSettingsVM()
        super.init(coder: coder)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        self.navigationController?.navigationBar.isHidden = true
        self.navigationController?.getWiFiSettingsNavigationID()
        setUpUIComponents()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        KSSingletonManager.shared.currentScreenName = "KSWIFISettings" // Using this reference to identify navigation viewcontroller index count
        isWIFIViewPresented = true
    }
    
    // Used to hide iPhoneX/XS footer home line.
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.showCopyrightLabel()
    }
    
    // MARK: Identify screen orientation
    // TODO: clear copyright label from footer before orientation changes
    // FIXME: Again add copyright footer label after screen orientation to avoid constraint problem.
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        if isWIFIViewPresented {
            self.hideCopyrightLabel()
            if UIDevice.current.orientation.isLandscape {
                self.showCopyrightLabel()
            } else {
                self.showCopyrightLabel()
            }
        }
     }
    
    // Assining all custom property values here in a single function.
    fileprivate func setUpUIComponents() {
        self.label_SSIDName.font = UIFont.regular(ofSize: 14)
        self.label_Start.font = UIFont.regular(ofSize: 14)
        self.button_WIFISettings.setTitle("Wi-Fi Settings", for: .normal)
        self.button_Start.setTitle("Start", for: .normal)
        self.button_WithoutWIFI.setTitle("Next Without Connection", for: .normal)
        self.perform(#selector(networkMonitor), with: self, afterDelay: 1)
        self.perform(#selector(updateSSIDName), with: self, afterDelay: 1)
    }
    
    // MARK:- Identify internet connection availability
    // TODO: Open iPhone general Wi-Fi settings when network is not reachable
    // FIXME: Navigate to next screen if iphone device is connected to any Wi-Fi network.
    @objc private func networkMonitor() {
        appDelegate?.networkCompletionHandler = { (networkStatus, isWifiMode) in
            if networkStatus == true {
                self.updateSSIDName()
                if isWifiMode! {
                    print("WiFiMode")
                } else {
                    print("MobileInternet")
                }
            } else {
                DispatchQueue.main.async {
                    self.navigation(to: Identifier.connectScreen)
                }
            }
        }
    }
    // Get connected WIFI name and showcase on userinterface label.
    @objc private func updateSSIDName() {
        guard let ssidName = self.wifiSettingVM.getSSID() else { return }
        DispatchQueue.main.async {
            self.label_SSIDName.text = "Your phone is connected to \(ssidName)"
        }
    }
    @IBAction func wifiSettingsButtonAction(_ sender: Any) {
        KSSingletonManager.openWifiSettings() // Used to open iPhone general settings
    }
    // Click on this button to initaite Websocket connection after connected to a proper WIFI network.
    @IBAction func startButtonAction(_ sender: Any) {
        self.navigation(to: Identifier.modelTypeScreen)
    }
    // Click on this button when you want to operate this application in offline mode.
    @IBAction func withoutWifiButtonAction(_ sender: Any) {
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        KSSingletonManager.shared.currentScreenName = "" // Clear screen title text to avoid conflicts
        self.hideCopyrightLabel() // remove footer label before navigating to other screens
        isWIFIViewPresented = false
    }
}
