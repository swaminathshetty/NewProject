//
//  KSAppSharedManager.swift
//  KobelcoService
//
//  Created by Guest L&T on 11/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
import UIKit

class KSSingletonManager {
    static let shared = KSSingletonManager()
    private init() { }
    
    var navigationTitle = "" // Set navigation title.
    var currentScreenName = "" // Used to identify screen title.
    var WiFiSettingsNavigationID = 1 // Set Settings Controller Index.
    var dashboardNavigationID = 3 // Set Dashboard Controller Index.

    //MARK:- Goto Wi-Fi Settings
    class func openWifiSettings() {
        let shared = UIApplication.shared
        if let url = URL(string: UIApplication.openSettingsURLString) {
            if #available(iOS 10.0, *) {
                shared.open(url)
            } else {
                shared.openURL(url)
            }
        }
    }
    
    // Called when there are no data available and add no records text to tableview background.
    func nullDataFilesLabel() -> UILabel {
        let noDataLabel = UILabel()
        noDataLabel.text = "No Records" // Displays this text when tableview is empty
        noDataLabel.textColor = TABLEVIEW_LABEL_COLOR
        noDataLabel.font = UIFont.medium(ofSize: 18)
        noDataLabel.textAlignment = .center
        return noDataLabel
    }
}
