//
//  KSMachineLearningCell.swift
//  KobelcoService
//
//  Created by Swaminath on 9/26/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSMachineLearningCell: UITableViewCell {

    @IBOutlet weak var BGView: UIView!
    @IBOutlet weak var button_ItemName: UIButton!
    @IBOutlet weak var label_Value: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.BGView.layer.cornerRadius = 6
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
    func configureMachineLearningStatusCellTitle(itemName: String) {
        self.button_ItemName.setTitle(itemName, for: .normal)
    }

}
