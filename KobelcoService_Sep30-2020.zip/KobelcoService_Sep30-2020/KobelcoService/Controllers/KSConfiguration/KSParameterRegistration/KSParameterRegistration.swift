//
//  KSParameterRegistration.swift
//  KobelcoService
//
//  Created by Guest L&T on 30/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSParameterRegistration: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Parameter Registration(Favorite)")
    }
}
