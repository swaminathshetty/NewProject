//
//  KSWIFISettings.swift
//  KobelcoService
//
//  Created by Guest L&T on 11/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit
import NotificationCenter
import UserNotifications

class KSWIFISettings: UIViewController {

    @IBOutlet weak var button_WIFISettings: UIButton!
    @IBOutlet weak var label_SSIDName: UILabel!
    @IBOutlet weak var label_Start: UILabel!
    @IBOutlet weak var button_Start: UIButton!
    @IBOutlet weak var button_WithoutWIFI: UIButton!
    
    private let wifiSettingVM: KSWiFiSettingsVM

    init(wifiSettingVM: KSWiFiSettingsVM) {
        self.wifiSettingVM = wifiSettingVM
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) {
        self.wifiSettingVM = KSWiFiSettingsVM()
        super.init(coder: coder)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        setUpUIComponents()
        networkMonitor()
    }
    fileprivate func setUpUIComponents() {
        self.label_SSIDName.setLabelFontSize(fontStyle: REGULAR_FONT, fontSize: 14)
        self.label_Start.setLabelFontSize(fontStyle: REGULAR_FONT, fontSize: 14)
        self.button_WIFISettings.setButtonCornerRadius(text: "Wi-Fi Settings", image: "")
        self.button_Start.setButtonCornerRadius(text: "Start", image: "")
        self.button_WithoutWIFI.setTitle("Next Without Connection", for: .normal)
    }
    fileprivate func networkMonitor() {
        appDelegate?.networkCompletionHandler = { networkStatus in
            if networkStatus == true {
                DispatchQueue.main.async {
                    print("Internet Connected")
                    guard let ssidName = self.wifiSettingVM.getSSID() else { return }
                    self.label_SSIDName.text = "Your phone is connected to \(ssidName)"
                }
            } else {
                DispatchQueue.main.async {
                    print("Internet Not Connected")
                    self.presentAlert(withTitle: "Error", message: "Network not reachable, please check your internet connection")
                }
            }
        }
    }
    @IBAction func wifiSettingsButtonAction(_ sender: Any) {
        KSSingletonManager.openWifiSettings()
    }
    @IBAction func startButtonAction(_ sender: Any) {
        self.navigation(to: Identifier.modelTypeScreen)
    }
    @IBAction func withoutWifiButtonAction(_ sender: Any) {
    }
}
