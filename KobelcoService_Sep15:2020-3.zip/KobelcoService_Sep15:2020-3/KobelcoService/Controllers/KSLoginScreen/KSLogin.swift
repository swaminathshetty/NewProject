//
//  KSLogin.swift
//  KobelcoService
//
//  Created by Guest L&T on 09/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSLogin: UIViewController {

    @IBOutlet weak var label_UserID: UILabel!
    @IBOutlet weak var label_Password: UILabel!
    @IBOutlet weak var textField_UserID: UITextField!
    @IBOutlet weak var textField_Password: UITextField!
    @IBOutlet weak var button_SignIn: UIButton!
    
    private let loginVM: KSLoginVM
    
    init(loginVM: KSLoginVM) {
        self.loginVM = loginVM
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        self.loginVM = KSLoginVM(model: LoginModel())
        super.init(coder: coder)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        setUpUIComponents()
        //Setting default Credentials
        self.textField_UserID.text = "Kobelco"
        self.textField_Password.text = "Password"
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    func setUpUIComponents() {
        self.label_UserID.font = KS_LABEL_FONT
        self.label_Password.font = KS_LABEL_FONT
        self.textField_UserID.setCustomTextFieldStyle()
        self.textField_Password.setCustomTextFieldStyle()
        self.button_SignIn.setTitle("Sign In", for: .normal)
    }
    @IBAction func signInButtonTap(_ sender: Any) {
        self.view.endEditing(true)
        do {
               _ = try loginVM.validateUserName(textField_UserID.text)
               _ = try loginVM.validatePassword(textField_Password.text)
               _ = try loginVM.validateUserNameAndPassword(textField_UserID.text, textField_Password.text)
            //After successfull authetication navigate to next screen
            checkNetworkAvailability()
           } catch {
                self.presentAlert(withTitle: "Sign In", message: "\(error.localizedDescription)")
           }
    }
    fileprivate func checkNetworkAvailability() {
        if appDelegate!.networkAvailability {
            self.navigation(to: Identifier.connectScreen)
        } else {
            self.navigation(to: Identifier.wifiSettingsScreen)
        }
    }
}
