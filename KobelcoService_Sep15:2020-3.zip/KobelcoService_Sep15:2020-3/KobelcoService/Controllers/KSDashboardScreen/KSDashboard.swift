//
//  KSDashboard.swift
//  KobelcoService
//
//  Created by Guest L&T on 14/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSDashboard: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        setNavigationBarButtonItemAction()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarColorAndItems()
    }
    func setNavigationBarButtonItemAction() {
        self.navigationItem.title = "Dashboard"
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: NAVIGATION_RIGHTBAR_LOGO, style: .plain, target: self, action: #selector(navigateToErrorCodeDisplay))
    }
    @objc func navigateToErrorCodeDisplay() {
        self.navigation(to: Identifier.errorCodeScreen)
    }
}
