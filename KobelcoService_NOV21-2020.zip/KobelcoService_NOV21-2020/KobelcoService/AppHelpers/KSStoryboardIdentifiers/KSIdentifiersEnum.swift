//
//  KSIdentifiersEnum.swift
//  KobelcoService
//
//  Created by Swaminath on 10/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation

// StoryboardIdentifiers
enum Identifier: String {
    case loginScreen = "KSLogin"
    case connectScreen = "KSConnect"
    case wifiSettingsScreen = "KSWIFISettings"
    case modelTypeScreen = "KSModelType"
    case modelTypeList = "KSModelTypeList"
    case dashboardScreen = "KSDashboard"
    case errorCodeScreen = "KSErrorCodeDisplay"
    case freezeFrameScreen = "KSFreezeFrameData"
    case memoryResetScreen = "KSMemoryResetFunction"
    case memoryResetSubScreen = "KSMemoryReset"
    case setValueWritingFunction = "KSwritingValueFunction"
    case injectorPartEntry = "KSInjectorPartEntry"
    case scanInjectorQRCode = "KSScanInjectorQRCode"
    case machineLearningStatus = "KSMachineLearning"
    case diagnosticTest = "KSDiagnosticTestFunction"
    case diagnosticNormal = "KSDiagnosticNormal"
    case diagnosticSwitch = "KSDiagnosticSwitch"
    case diagnosticUpDown = "KSDiagnosticUpDown"
    case diagnosticAddParameter = "KSDiagnosticAddParameter"
    case dataMonitor = "KSDataMonitor"
    case dataMonitorList = "KSDataMonitorList"
    case addDataparameters = "KSAddParameters"
    case createParameter = "KSCreateParameter"
    case dataComparision = "KSDataComparision"
    case plotCharts = "KSPlotCharts"
    case dataParametersList = "KSDataParameterList"
    case configuration = "KSConfiguration"
    case normalData = "KSNormalDataManagement"
    case normalDataAcquition = "KSNormalDataAcquisition"
    case normalListDownlaod = "KSNormalDataDownload"
    case normalDataEditing = "KSNormalDataEditing"
    case logData = "KSLogDataManagement"
    case parameterRegistration = "KSParameterRegistration"
    case parameterEditScreen = "KSParameterEdit"
    case parameterAddfavoriteScreen = "KSParameterAddfavorite"
}
