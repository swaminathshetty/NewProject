//
//  KSAddParameters.swift
//  KobelcoService
//
//  Created by Swaminath on 10/4/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

class KSAddParameters: UIViewController {

    @IBOutlet weak var headerViewSetParameter: UIView!
    @IBOutlet weak var headerSetParameterButton: UIButton!
    @IBOutlet weak var tableviewSetDataParameters: UITableView!
    @IBOutlet weak var tableviewTheDataParameters: UITableView!
    @IBOutlet weak var engineSegmentMonitor: UISegmentedControl!
    @IBOutlet weak var segmentECUMonitor: UISegmentedControl!
    @IBOutlet weak var footerConfigureButton: UIButton!
    @IBOutlet weak var footerFavoriteButton: UIButton!
    var ecuSignalsArray: [ECUSignalsModel] = []
    var pumpSignalsArray: [ECUSignalsModel] = []
    var combineECUAndPumpSignalArray: [ECUSignalsModel] = []
    var setParameters: [KSIsCheckBoxSelectedModel] = []
    var plistHelepr = KSPlistReadAndWriteModel()
    var selectedFavoriteParameter = ""
    var previousIndexPathSetParameterTV = IndexPath()
    weak var diagnosticDelegate: KSDiagnosticDelegate?
    weak var dataMonitorDelegate: KSMonitorDataDelegate?
    var mergedFinalSignals = [[String: Any]]()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.loadMonitorAddParametersUIComponents()
        self.tableviewSetDataParameters.register(UINib(nibName: "KSCheckBoxWithLabelCellTableViewCell", bundle: nil), forCellReuseIdentifier: "KSCheckBoxWithLabelCellTableViewCell")
        self.tableviewTheDataParameters.register(UINib(nibName: "KSCheckBoxWithLabelCellTableViewCell", bundle: nil), forCellReuseIdentifier: "KSCheckBoxWithLabelCellTableViewCell")
    }
    // AutoHide iPhoneX/Pro footer line.
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.previousIndexPathSetParameterTV = IndexPath()
        self.selectedFavoriteParameter = ""
        self.engineSegmentMonitor.layer.cornerRadius = 6
        self.segmentECUMonitor.layer.cornerRadius = 6
        self.engineSegmentMonitor.selectedSegmentIndex = 0
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Add Parameters")
        let setParameterData = plistHelepr.readPlistFileAndReturnKey(namePlist: "SetParameters")
        self.setParameters = setParameterData.map {KSIsCheckBoxSelectedModel.init(nameValue: $0, isSelectedValue: false)}
        self.tableviewSetDataParameters.reloadData()
        self.parseCategoryWiseDataJSON()
        self.tableviewTheDataParameters.reloadData()
        self.setConfigureButtonEnable()
    }

    func parseCategoryWiseDataJSON() {
        KSSingletonManager.shared.loadJson(filename: MATRIXDATAFILE) { (categoryWiseData) in
            guard let categoryWiseDataInJSON = self.convertDataToDictionary(data: categoryWiseData)  else { return }
            let aOneDic: [String: Any] = categoryWiseDataInJSON[KSSingletonManager.shared.modelTypeSelection] as! [String: Any]
            self.setECUPumpArrayValues(dicValue: aOneDic)
        }
    }

    func setECUPumpArrayValues(dicValue: [String: Any]) {
        let ecuSignals = dicValue["ECUSignals"] as! [[String: Any]]
        self.ecuSignalsArray = ecuSignals.map {ECUSignalsModel.init(data: $0)}
        let pumpSignals = dicValue["pumpSignals"] as! [[String: Any]]
        self.pumpSignalsArray = pumpSignals.map {ECUSignalsModel.init(data: $0)}
    }

    // Set custom property values to monitor add paramters UI elements.
    fileprivate func loadMonitorAddParametersUIComponents() {
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.headerViewSetParameter.layer.cornerRadius = 6
        self.engineSegmentMonitor.setSegmentTintColors()
        self.segmentECUMonitor.setSegmentTintColors()
        if KSSingletonManager.shared.currentScreenName == "DiagnosticSubMenu" {
            self.footerFavoriteButton.isHidden = true
        }
    }

    func setConfigureButtonEnable() {
        self.combineECUAndPumpSignalArray = [ECUSignalsModel]()
        self.combineECUAndPumpSignalArray = self.ecuSignalsArray.filter {$0.isSelected == true}
        self.combineECUAndPumpSignalArray += self.pumpSignalsArray.filter {$0.isSelected == true}

        if self.combineECUAndPumpSignalArray.isEmpty {
            self.footerConfigureButton.setTitleColor(#colorLiteral(red: 0.3333333433, green: 0.3333333433, blue: 0.3333333433, alpha: 1), for: .normal)
            self.footerConfigureButton.isEnabled = false
        } else {
            self.footerConfigureButton.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
            self.footerConfigureButton.isEnabled = true
        }
    }
    
    // Click on this button to plot line graphs for the selected parameters.
    @IBAction func configurePlotButtonTapped(_ sender: Any) {
        self.mergedFinalSignals.removeAll(keepingCapacity: false)
        let convertedStructArray = self.combineECUAndPumpSignalArray.map {$0.asDictionary}
        for selectedFavoriteSignal in convertedStructArray {
            guard let signalID = selectedFavoriteSignal["id"] as? String else { return }
            let duplicateSignalStatus = checkDuplicateSignalIDs(newSignalID: signalID)
            if duplicateSignalStatus == false {
                KSSingletonManager.shared.dataMonitorSubMenu.append(selectedFavoriteSignal)
                self.mergedFinalSignals.append(selectedFavoriteSignal)
            }
        }
        if KSSingletonManager.shared.currentScreenName == "DiagnosticSubMenu" {
            diagnosticDelegate?.updateNewlyAddedConfigureItems?(selectedParameters: self.mergedFinalSignals)
        } else {
            dataMonitorDelegate?.getAddParametersList(selectedParameters: self.mergedFinalSignals)
        }
        self.navigationController?.popViewController(animated: true)
    }
    // Check duplicate signals before appending add signals dictionary to array.
    fileprivate func checkDuplicateSignalIDs(newSignalID: String) -> Bool {
        var signalStatus = false
        var conditionCheckArray = KSSingletonManager.shared.dataMonitorSubMenu
        if KSSingletonManager.shared.currentScreenName == "DiagnosticSubMenu" {
            conditionCheckArray.removeAll(keepingCapacity: false)
            conditionCheckArray = KSSingletonManager.shared.diagnosticSubMenuArray
        }
        for existingObject in conditionCheckArray {
            guard let existingSignalID = existingObject["id"] as? String else { return false }
            if existingSignalID.contains(newSignalID) {
                signalStatus = true
                break
            } else {
                signalStatus = false
            }
        }
        return signalStatus
    }
    // Tap on this button to make/create favorite parameters.
    @IBAction func addFavoriteButtonTapped(_ sender: Any) {
        let addFavorite = CONFIGURATIONSTORYBOARD.instantiateViewController(withIdentifier: "KSParameterAddfavorite") as! KSParameterAddfavorite
        addFavorite.ksParameterAddfavoriteDelegate = self
        self.navigationController?.pushViewController(addFavorite, animated: true)
    }

    // Toggle action for engine and pump selection.
    @IBAction func engineSegmentMonitorToggleAction(_ sender: Any) {
        self.tableviewTheDataParameters.reloadData()
    }

    // Toggle segment controller for ECU & DCU engine selection.
    @IBAction func segmentECUMonitorToggleAction(_ sender: Any) {
    }
}

// MARK: Tableview delegate
extension KSAddParameters: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == self.tableviewSetDataParameters {
            return self.setParameters.count
        } else {
            if self.engineSegmentMonitor.selectedSegmentIndex == 1 {
                return self.pumpSignalsArray.count
            } else {
                return self.ecuSignalsArray.count
            }
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == self.tableviewSetDataParameters {
            let theParameterCell = tableView.dequeueReusableCell(withIdentifier: "KSCheckBoxWithLabelCellTableViewCell") as! KSCheckBoxWithLabelCellTableViewCell
            self.setUpSetParameterTableView(cellObj: theParameterCell, indexValue: indexPath.row)
            return theParameterCell
        } else {
            let theParameterCell = tableView.dequeueReusableCell(withIdentifier: "KSCheckBoxWithLabelCellTableViewCell") as! KSCheckBoxWithLabelCellTableViewCell
            self.setUpTheParameterTableView(cellObj: theParameterCell, indexValue: indexPath.row)
            return theParameterCell
        }
    }

    func setUpSetParameterTableView(cellObj: KSCheckBoxWithLabelCellTableViewCell?, indexValue: Int) {
        let setParameter = self.setParameters[indexValue]
        if let _ = cellObj {
            cellObj?.fillRadioCellData(lableText: setParameter.name, isCheckBoxSelected: setParameter.isSelected)
        } else {
            let indexPath = IndexPath(row: indexValue, section: 0)
            let getCell = self.tableviewSetDataParameters.cellForRow(at: indexPath) as? KSCheckBoxWithLabelCellTableViewCell
            getCell?.fillRadioCellData(lableText: setParameter.name, isCheckBoxSelected: setParameter.isSelected)
        }
    }

    func tableViewScrollToTop(tableView: UITableView) {
        let topIndex = IndexPath(row: 0, section: 0)
        tableView.reloadRows(at: [topIndex], with: .fade)
        tableView.scrollToRow(at: topIndex, at: .top, animated: true)
    }

    func setUpTheParameterTableView(cellObj: KSCheckBoxWithLabelCellTableViewCell, indexValue: Int) {
        var txtLabel = ""
        var isSelected = false
        if self.engineSegmentMonitor.selectedSegmentIndex == 1 {
            txtLabel = self.pumpSignalsArray[indexValue].name["en"] as! String
            isSelected = self.pumpSignalsArray[indexValue].isSelected
        } else {
            txtLabel = self.ecuSignalsArray[indexValue].name["en"] as! String
            isSelected = self.ecuSignalsArray[indexValue].isSelected
        }

        cellObj.fillCellData(lableText: txtLabel, isCheckBoxSelected: isSelected)
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == self.tableviewSetDataParameters {
            let setParameter = self.setParameters[indexPath.row]
            let output = plistHelepr.readPlistReturnDic(namePlist: "SetParameters", key: setParameter.name)
            self.selectedFavoriteParameter = setParameter.name
            self.setECUPumpArrayValues(dicValue: output)
            self.tableviewTheDataParameters.reloadData()
            _ = self.setPreviousIndexPathValue()
            self.setParameters[indexPath.row] = KSIsCheckBoxSelectedModel.init(nameValue: setParameter.name, isSelectedValue: true)
            self.previousIndexPathSetParameterTV = indexPath
            self.tableviewSetDataParameters.reloadData()
        } else {
            if self.setPreviousIndexPathValue() {
                self.tableviewSetDataParameters.reloadData()
                self.previousIndexPathSetParameterTV = IndexPath()
            }
            self.parameterCheckBoxButtonPressed(indexValue: indexPath.row)
        }
        self.setConfigureButtonEnable()
    }

    func setPreviousIndexPathValue() -> Bool {
        if !self.previousIndexPathSetParameterTV.isEmpty {
            let setParameter1 = self.setParameters[self.previousIndexPathSetParameterTV.row]
            self.setParameters[self.previousIndexPathSetParameterTV.row] = KSIsCheckBoxSelectedModel.init(nameValue: setParameter1.name, isSelectedValue: false)
            return true
        }
        return false
    }
}

extension KSAddParameters {
    func parameterCheckBoxButtonPressed(indexValue: Int) {
         if self.engineSegmentMonitor.selectedSegmentIndex == 1 {
            var pump = self.pumpSignalsArray[indexValue]
            pump.isSelected = !pump.isSelected
            self.pumpSignalsArray[indexValue] = pump
         } else {
            var ecu = self.ecuSignalsArray[indexValue]
            ecu.isSelected = !ecu.isSelected
            self.ecuSignalsArray[indexValue] = ecu
         }
        let reloadIndex = IndexPath(row: indexValue, section: 0)
        self.tableviewTheDataParameters.reloadRows(at: [reloadIndex], with: .none)
    }
}

extension KSAddParameters: KSParameterAddfavoriteDelegate {
    func parameterAddCaption(txtValue: String) {
        var data: [String: Any]
        let ecuDictionary = self.ecuSignalsArray.map {$0.asDictionary}
        let pumpDictionary = self.pumpSignalsArray.map {$0.asDictionary}
        data = ["ECUSignals": ecuDictionary, "pumpSignals": pumpDictionary]
        plistHelepr.writePlist(namePlist: "SetParameters", key: txtValue, data: data as AnyObject)
    }
}
