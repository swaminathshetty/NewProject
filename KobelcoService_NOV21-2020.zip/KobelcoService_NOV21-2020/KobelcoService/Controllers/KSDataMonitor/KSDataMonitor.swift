//
//  KSDataMonitor.swift
//  KobelcoService
//
//  Created by Swaminath on 9/27/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

// Protocals for data monitor listview swipe up and down functionality.
@objc protocol KSMonitorDataDelegate {
    func addDataMonitorListChildController()
    func swipeUpAndDownTheChildController()
    func removeMonitorListChildController()
    func getAddParametersList(selectedParameters: [[String: Any]])
    func delegateStopDataMonitor()
}

class KSDataMonitor: UIViewController {

    @IBOutlet weak var footerViewDataMonitor: UIView!
    @IBOutlet weak var addParameterButton: UIButton!
    @IBOutlet weak var type1Type2Segment: UISegmentedControl!
    @IBOutlet weak var startPlotGraphbutton: UIButton!
    fileprivate var dataMonitorListView: KSDataMonitorList?
    fileprivate var isMonitorViewPresented: Bool = true
    fileprivate var listViewYPosition = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        KSSingletonManager.shared.dataMonitorNavigationID = self.navigationController?.getScreenNavigationID() ?? 3
        KSSingletonManager.shared.currentScreenName = "DataMonitor"
        self.loadDataMonitorUIComponents()
        self.addDataMonitorListChildController()
    }
    // AutoHide iPhoneX/Pro footer line.
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
    // Set customs property values to data monitor UI components.
    fileprivate func loadDataMonitorUIComponents() {
        self.view.backgroundColor = .white
        self.type1Type2Segment.layer.cornerRadius = 8
        self.type1Type2Segment.setSegmentTintColors()
        //listViewYPosition = Int(self.view.bounds.height - 240)
        self.configureDataMonitorGestureRecognizers()
        self.checkDataMinotorReadSignalsCount()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Data Monitor")
        self.navigationItem.hidesBackButton = true
        KSSingletonManager.shared.delegate = self
    }
    // MARK: Identify screen orientation
    // todo: set the updated frame for footer monitor list view.
    // fixme: Again add copyright footer label after screen orientation to avoid constraint problem.
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        if isMonitorViewPresented {
            self.removeMonitorListChildController()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                self.addDataMonitorListChildController()
            }
        }
    }
    
    // Called when user navigate to someother screen
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        isMonitorViewPresented = false
    }

    // Configure gesture recognizer for UIView
    fileprivate func configureDataMonitorGestureRecognizers() {
        let swipeRightMR = UISwipeGestureRecognizer(target: self, action: #selector(respondToDataMonitorSwipeGesture))
        swipeRightMR.direction = .right
        self.view.addGestureRecognizer(swipeRightMR)
        
        let swipeLeftMR = UISwipeGestureRecognizer(target: self, action: #selector(respondToDataMonitorSwipeGesture))
        swipeLeftMR.direction = .left
        self.view.addGestureRecognizer(swipeLeftMR)
    }
    
    // Navigate to particular screen based on swipe direction.
    @objc func respondToDataMonitorSwipeGesture(gesture: UIGestureRecognizer) {
        guard KSSingletonManager.shared.isDataMonitorStart == false else { return }
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case .right:
                guard KSSingletonManager.shared.isDiagnsoticStart == false else {
                    self.popOverToBackScreen(indexValue: KSSingletonManager.shared.diagnosticSubScreenID)
                    return
                }
                KSSingletonManager.shared.clearDataMonitorGlobalArrayReadings()
                self.popOverToBackScreen(indexValue: KSSingletonManager.shared.diagnosticMainScreenID)
            case .left:
                KSSingletonManager.shared.clearDataMonitorGlobalArrayReadings()
                self.navigation(to: Identifier.dataComparision)
            default:
                break
            }
        }
    }
    
    // Condition check for hide and show UI elements.
    fileprivate func checkDataMinotorReadSignalsCount() {
        if KSSingletonManager.shared.dataMonitorSubMenu.count > 0 {
            self.disableFewFooterUIComponents(isEnabled: true)
        } else {
            self.disableFewFooterUIComponents(isEnabled: false)
        }
    }
    
    // Click on this button to add more parameters from paramters screen and plot a line graph.
    @IBAction func addDataParameterButtonTapped(_ sender: Any) {
        let addMonitorParameterScreen = MAINSTORYBOARD.instantiateViewController(withIdentifier: "KSAddParameters") as? KSAddParameters
        addMonitorParameterScreen?.dataMonitorDelegate = self
        self.navigationController?.pushViewController(addMonitorParameterScreen!, animated: true)
    }
    
    // Display/plot graph based on type1/type2 segment selection.
    @IBAction func segmentControllerForType1AndType2(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0 { // Type1
            KSSingletonManager.shared.isDataMonitorType1 = true
        } else { // Type2
            KSSingletonManager.shared.isDataMonitorType1 = false
        }
        dataMonitorListView?.checkType1AndType2SegmentSelection()
    }
    
    // Used to send websocket request with selected parameters and save records in textfile for every 50 ms interval
    @IBAction func startDataParameterButtonTapped(_ sender: UIButton) {
        guard KSSingletonManager.shared.dataMonitorSubMenu.count > 0 else { return }
        guard dataMonitorListView?.arrayMonitorSelectedItems.count ?? 0 > 0 else {
            self.presentAlert(withTitle: "Message", message: "Please select atleast one item name to start data monitor.")
            return }
        if sender.isSelected { // Show alertsheet to select the following options(delete, save, save & send, send & delete).
            disableUIElementActions(title: "Start", isStart: false)
            sendDataMonitorStopWebSocketRequest()
            self.type1Type2Segment.isEnabled = true
        } else { // Change button title to stop when user tap on start.
            disableUIElementActions(title: "Stop", isStart: true)
            sendDataMonitorStartWebSocketRequest()
        }
        sender.isSelected = !sender.isSelected
    }
    
    // On click of start button disable few UI tap actions.
    fileprivate func disableUIElementActions(title: String, isStart: Bool) {
        startPlotGraphbutton.setTitle(title, for: .normal)
        KSSingletonManager.shared.isDataMonitorStart = isStart
        self.type1Type2Segment.isEnabled = isStart
        self.addParameterButton.isEnabled = !isStart
        navigationController?.navigationBar.isUserInteractionEnabled = !isStart
    }
    
    // Default hide some UI Elements before start data monitoring.
    fileprivate func disableFewFooterUIComponents(isEnabled: Bool) {
        self.startPlotGraphbutton.isEnabled = isEnabled
        self.type1Type2Segment.isEnabled = isEnabled
    }
    // Send datamonitor read websocket request to get item values.
    fileprivate func sendDataMonitorStartWebSocketRequest() {
        self.resetGraphJSONArrayValues()
        self.showLoader()
        let monitorStartCommand = ReadSubmenuSocketRequest(screenName: "DataMonitor", frameType: "StartRequest", readSignals: KSSingletonManager.shared.dataMonitorReadIDs, periodicity: 10000)
        guard let monitorRequestData = try? JSONEncoder().encode(monitorStartCommand) else { return }
        KSSingletonManager.shared.sendCommand(format: monitorRequestData)
    }
    // Send datamonitor stop websocket request to stop operation.
    func sendDataMonitorStopWebSocketRequest() {
        self.showLoader()
        let monitorStopCommand = ResetSocketRequest(screenName: "DataMonitor", frameType: "StopRequest", periodicity: 0)
        guard let monitorStopRequest = try? JSONEncoder().encode(monitorStopCommand) else { return }
        KSSingletonManager.shared.sendCommand(format: monitorStopRequest)
    }
    
    // Show Action sheet options on click of stop button.
    fileprivate func showStopActionSheetOptions() {
        self.showActionSheet { (selectedActionItem) in
            switch selectedActionItem {
            case ActionSheetIdentifiers.delete.rawValue:
                break
            case ActionSheetIdentifiers.save.rawValue:
                break
            case ActionSheetIdentifiers.saveAndSend.rawValue:
                break
            case ActionSheetIdentifiers.sendAndDelete.rawValue:
                break
            default: break
            }
        }
    }
    
    // get monitor list view y position
    fileprivate func getListViewYPosition() {
        if listViewYPosition <= 68 {
            listViewYPosition = Int(UIDevice.current.orientation.isLandscape ? (self.view.bounds.height - 100) : (self.view.bounds.height - 240))
        } else {
            listViewYPosition = Int(UIDevice.current.orientation.isLandscape ? 40 : 68)
        }
    }
}

// MARK: Data monitor delegates
extension KSDataMonitor: KSMonitorDataDelegate {
    // Add data monitor list child controller as a subview.
    func addDataMonitorListChildController() {
        dataMonitorListView = MAINSTORYBOARD.instantiateViewController(withIdentifier: Identifier.dataMonitorList.rawValue) as? KSDataMonitorList
        self.addChild(dataMonitorListView!)
        dataMonitorListView?.monitorDelegate = self
        print("yposition: \(self.listViewYPosition)")
        listViewYPosition = Int(UIDevice.current.orientation.isLandscape ? (self.view.bounds.height - 100) : (self.view.bounds.height - 240))
        self.dataMonitorListView?.view.frame = CGRect(x: 0, y: CGFloat(self.listViewYPosition), width: self.view.bounds.width, height: self.view.bounds.height - CGFloat(listViewYPosition))
        self.view.addSubview((dataMonitorListView?.view)!)
        self.view.insertSubview((dataMonitorListView?.view)!, belowSubview: self.footerViewDataMonitor)
        dataMonitorListView?.didMove(toParent: self)
    }
    // Called when user tap on footer tableview child controller lined button.
    // Used to swipe up and down the footer tableview list.
    func swipeUpAndDownTheChildController() {
        self.getListViewYPosition()
        DispatchQueue.main.async {
            UIView.transition(with: (self.dataMonitorListView?.view)!, duration: 0.3, options: [.curveLinear], animations: {
            self.dataMonitorListView?.view.frame = CGRect(x: 0, y: CGFloat(self.listViewYPosition), width: self.view.bounds.width, height: self.view.bounds.height - CGFloat(self.listViewYPosition))
            }, completion: nil)
        }
    }
    // Called to remove child controller when user disappears from screen.
    func removeMonitorListChildController() {
        dataMonitorListView?.willMove(toParent: nil)
        dataMonitorListView?.view.removeFromSuperview()
        dataMonitorListView?.removeFromParent()
    }
    // Get signals from data monitor add paramter screen.
    func getAddParametersList(selectedParameters: [[String: Any]]) {
        if selectedParameters.count > 0 {
            disableFewFooterUIComponents(isEnabled: true)
            dataMonitorListView?.appendEmptyValuesToMonitorItemListArray()
        }
    }
    // Called from tableview cell when selected
    func delegateStopDataMonitor() {
        self.sendDataMonitorStopWebSocketRequest()
    }
    // Append values to plot graph JSON array.
    func appendWebSocketValuesToGraphJSON() {
        commonForLoopToGetGraphDict { (index, setGraphDict) in
            KSSingletonManager.shared.dataMonitorJSONArray[index] = setGraphDict
        }
    }
    // Reset graph JSON array values to empty.
    func resetGraphJSONArrayValues() {
        commonForLoopToGetGraphDict { (index, setGraphDict) in
            var setEmptyArrayValues = setGraphDict
            setEmptyArrayValues["value"] = [Int]()
            KSSingletonManager.shared.dataMonitorJSONArray[index] = setEmptyArrayValues
        }
    }
    // Reusable function to get JSON graph dictionary.
    fileprivate func commonForLoopToGetGraphDict(completionHandler: @escaping (Int, [String: Any]) -> Void) {
        for (index, monitorItemDict) in KSSingletonManager.shared.dataMonitorJSONArray.enumerated() {
            var getMonitorDict = monitorItemDict
            guard var getValuesArray = getMonitorDict["value"] as? [Int] else { return }
            getValuesArray.append(KSSingletonManager.shared.dataMonitorReadValues[index])
            getMonitorDict["value"] = getValuesArray
            completionHandler(index, getMonitorDict)
        }
    }
}
// MARK: WebSocket Response Delegate
extension KSDataMonitor: KSWebSocketDelegates {
    func webSocketStringResponse(response: String) {
        print("response: \(response)")
        guard let jsonDictionary = convertToDictionary(text: response) else { return }
        guard let screenTitle = jsonDictionary["screenName"] as? String else { return }
        if screenTitle == "DataMonitor" {
            self.hideLoader()
            //upDownCanViewSwipe = true
            let resposneKeys = jsonDictionary.keys
            // Condition check for 2 type responses. If response contains status key show success or failure message.
            if resposneKeys.contains("status") {
                guard let diagnosticStopStatus = jsonDictionary["status"] as? Int else { return }
                if diagnosticStopStatus != 1 {
                    self.startPlotGraphbutton.setTitle("Stop", for: .normal)
                    KSSingletonManager.shared.isDataMonitorStart = true
                } else {
                    self.showStopActionSheetOptions()
                }
            } else {
                // Read values from the websocket response and update to tableview.
                 guard let readSignalValues = jsonDictionary["values"] as? [Int] else { return }
                 DispatchQueue.main.async {
                     if readSignalValues.count == KSSingletonManager.shared.dataMonitorReadValues.count {
                        KSSingletonManager.shared.dataMonitorReadValues.removeAll(keepingCapacity: false)
                        KSSingletonManager.shared.dataMonitorReadValues = readSignalValues
                        self.appendWebSocketValuesToGraphJSON()
                        self.dataMonitorListView?.reloadDataMonitorTableview()
                        return
                     } else {
                        self.sendDataMonitorStopWebSocketRequest()
                        self.presentAlert(withTitle: "Error in Response", message: "Request and Response signals are not matching, please try again after some time.")
                        return
                     }
                 }
            }
        }
    }
    // Called when error connection in websocket communication
    func webSocketErrorConnection(message: String) {
        self.hideLoader()
        //self.upDownCanViewSwipe = true
        presentAlertOKAction(withTitle: "ERROR", message: message) { (_ ) in
            KSSingletonManager.shared.connectWebSocket()
        }
    }
    // Called when internet is disconnected or network not reachable.
    func internetConnectionNotAvailable() {
        self.hideLoader()
        presentAlertOKAction(withTitle: "ERROR", message: WIFIDISCONNECTEDMESSAGE) { (isOkTapped) in
            if isOkTapped {
                self.navigateToWiFiSettings()
            }
        }
    }
}
