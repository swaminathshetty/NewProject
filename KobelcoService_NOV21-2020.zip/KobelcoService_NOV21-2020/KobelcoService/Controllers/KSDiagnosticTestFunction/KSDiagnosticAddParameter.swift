//
//  KSDiagnosticAddParameter.swift
//  KobelcoService
//
//  Created by Swaminath on 10/8/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

class KSDiagnosticAddParameter: UIViewController {

    @IBOutlet weak var diagnosticAddHeaderView: UIView!
    @IBOutlet weak var diagnosticAddHeaderTitle: UIButton!
    @IBOutlet weak var diagnosticAddSetTableView: UITableView!
    @IBOutlet weak var diagnosticAddTheTableView: UITableView!
    @IBOutlet weak var diagnosticAddEngineSegment: UISegmentedControl!
    @IBOutlet weak var diagnosticAddECUSegment: UISegmentedControl!
    @IBOutlet weak var diagnosticAddConfigure: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "\(KSSingletonManager.shared.diagnosticNavigationTitle) List")
        self.loadDiagnosticAddParameterUIComponents()
        self.diagnosticAddSetTableView.register(UINib(nibName: "KSCheckBoxWithLabelCellTableViewCell", bundle: nil), forCellReuseIdentifier: "KSCheckBoxWithLabelCellTableViewCell")
        self.diagnosticAddTheTableView.register(UINib(nibName: "KSCheckBoxWithLabelCellTableViewCell", bundle: nil), forCellReuseIdentifier: "KSCheckBoxWithLabelCellTableViewCell")
    }
    
    // Set custom values to UI componets.
    fileprivate func loadDiagnosticAddParameterUIComponents() {
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.diagnosticAddHeaderView.layer.cornerRadius = 6
        self.diagnosticAddEngineSegment.setSegmentTintColors()
        self.diagnosticAddECUSegment.setSegmentTintColors()
    }
    // Click on this button to select all parameters in the set paramter tableview list.
    @IBAction func headerSetParameterDiagnosticAddTapAction(_ sender: Any) {
    }
    
    // Toggle selection for engine & pump selection.
    // Engine and footer ECU will select by default, based on the selection the parameter tableview list items may vary.
    @IBAction func mainEngineSegmentDiagnosticAddAction(_ sender: Any) {
    }
    
    // User can switch either ECU or DCU to display the respective parameter list in the parameter tableview.
    @IBAction func segmentECUDiagnosticAddAction(_ sender: Any) {
    }
    
    // Click on configure to add the selected parameters to the existing list in the previous screen.
    @IBAction func footerConfigureDiagnosticAddAction(_ sender: Any) {
    }
}

// MARK: Tableview delegate
extension KSDiagnosticAddParameter: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let setMonitorCell = tableView.dequeueReusableCell(withIdentifier: "KSCheckBoxWithLabelCellTableViewCell") as! KSCheckBoxWithLabelCellTableViewCell
        return setMonitorCell
    }
}
