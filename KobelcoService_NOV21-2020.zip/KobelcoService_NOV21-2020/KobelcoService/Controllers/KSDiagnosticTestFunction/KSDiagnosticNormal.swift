//
//  KSDiagnosticNormal.swift
//  KobelcoService
//
//  Created by Guest L&T on 06/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

class KSDiagnosticNormal: UIViewController {

    @IBOutlet weak var normalHeaderView: UIView!
    @IBOutlet weak var normalItemName: UIButton!
    @IBOutlet weak var normalHeaderValue: UILabel!
    @IBOutlet weak var normalHeaderUnit: UILabel!
    @IBOutlet weak var normalTableView: UITableView!
    @IBOutlet weak var normalAddButton: UIButton!
    @IBOutlet weak var normalStartButton: UIButton!
    @IBOutlet weak var normalHelpIcon: UIButton!
    var menuList = [[String: Any]]()
    var mainMenuID = ""
    fileprivate var normalReadIDs = [String]()
    fileprivate var normalMenuValues = [Int]()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        // Place diagnostic selected item name
        self.setNavigationBarColorWithButtonTitle(buttonTitle: KSSingletonManager.shared.diagnosticNavigationTitle)
        self.loadDiagnosticSwitchUIComponents()
        KSSingletonManager.shared.delegate = self
    }
    // Add custom values to diagnostic normal UI components.
    fileprivate func loadDiagnosticSwitchUIComponents() {
        self.normalHeaderView.layer.cornerRadius = 6
        self.normalItemName.setTitle("Item Name", for: .normal)
        self.normalHeaderValue.text = "Value"
        self.normalHeaderUnit.text = "Unit"
        self.appendEmptyValuesToNormalItemListArray()
        self.sendDiagnosticSocketRequest(writeIDsArray: [], writeValueArray: [], interval: 0)
    }
    // By default append 0 in item values to display in tableview.
    fileprivate func appendEmptyValuesToNormalItemListArray() {
        normalMenuValues.removeAll(keepingCapacity: false)
        normalReadIDs.removeAll(keepingCapacity: false)
        for normalItemsDict in menuList {
            normalMenuValues.append(0)
            guard let itemID = normalItemsDict["id"] as? String else { return }
            normalReadIDs.append(itemID)
        }
    }

    // Click on this button to add parameters from parameters screen.
    @IBAction func addNormalDiagnosticParameters(_ sender: Any) {
        self.navigation(to: Identifier.diagnosticAddParameter)
    }
    
    // Its a toggle operation, start and stop websocket value readings.
    @IBAction func normalDiagnosticStartAction(_ sender: Any) {
        self.showLoader()
        self.sendDiagnosticSocketRequest(writeIDsArray: [], writeValueArray: [], interval: 0)
    }
    // Send Websocket Request With Default Read Signal IDs
    fileprivate func sendDiagnosticSocketRequest(writeIDsArray: [String], writeValueArray: [Int], interval: Int) {
        let normalReadCommand = DiagnosticStartRequest(screenName: "DiagnosticTestFunction", frameType: mainMenuID, writeSignals: [], writeValue: [], readSignals: normalReadIDs, periodicity: 0)
        guard let normalRequestData = try? JSONEncoder().encode(normalReadCommand) else { return }
        KSSingletonManager.shared.sendCommand(format: normalRequestData)
    }
    // Click on this to show help explanation and attention alertview.
    @IBAction func normalDiagnosticHelpAction(_ sender: Any) {
        let normalExplanation = KSSingletonManager.shared.explanationDiagnostic
        let normalAttention = KSSingletonManager.shared.attentionDiagnostic
        DispatchQueue.main.async {
             self.presentAttributedStringAlert(message1: normalExplanation, message2: normalAttention) { (_ ) in
             }
         }
    }
}

// MARK: Tableview delegates
extension KSDiagnosticNormal: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return rowCountZeroCheckDiagnosticNormal(tableViewName: tableView, rowCount: menuList.count)
    }
    // Condition check for tableview row count and add tableview background with no records label if count == 0.
     fileprivate func rowCountZeroCheckDiagnosticNormal(tableViewName: UITableView, rowCount: Int) -> Int {
         if rowCount == 0 {
             DispatchQueue.main.async {
                 tableViewName.backgroundView =  KSSingletonManager.shared.nullDataFilesLabel(message: "No Records")
             }
         } else {
             tableViewName.backgroundView = nil
         }
         return rowCount
     }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let normalCellIdentifier = "KSDiagnosticNormalCell"
        let normalCell = tableView.dequeueReusableCell(withIdentifier: normalCellIdentifier) as! KSDiagnosticNormalCell
        normalCell.configureDiagnosticNormalCell(normalObject: menuList[indexPath.row], itemValue: normalMenuValues[indexPath.row])
        return normalCell
    }
}

// MARK: WebSocket Response Delegate
extension KSDiagnosticNormal: KSWebSocketDelegates {
    func webSocketStringResponse(response: String) {
        print("response: \(response)")
        guard let jsonDictionary = convertToDictionary(text: response) else { return }
        guard let screenTitle = jsonDictionary["screenName"] as? String else { return }
        if screenTitle == "DiagnosticTestFunction" {
            self.hideLoader()
            //memoryResetSubMenuCanSwipe = true
            // Read values from the websocket response and update to tableview.
            guard let readSignalValues = jsonDictionary["values"] as? [Int] else { return }
            DispatchQueue.main.async {
                if readSignalValues.count == self.menuList.count {
                    self.normalMenuValues = readSignalValues
                    self.normalTableView.reloadData()
                    return
                } else {
                    self.presentAlert(withTitle: "Error in Response", message: "Request and Response signals are not matching, please try again after some time.")
                    return
                }
            }
        }
    }
    // Called when error connection in websocket communication
    func webSocketErrorConnection(message: String) {
        self.hideLoader()
        presentAlertOKAction(withTitle: "ERROR", message: message) { (_ ) in
            KSSingletonManager.shared.connectWebSocket()
        }
    }
    // Called when internet is disconnected or network not reachable.
    func internetConnectionNotAvailable() {
        self.hideLoader()
        presentAlertOKAction(withTitle: "ERROR", message: WIFIDISCONNECTEDMESSAGE) { (isOkTapped) in
            if isOkTapped {
                self.navigateToWiFiSettings()
            }
        }
    }
}
