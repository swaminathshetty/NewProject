//
//  KSPlotCharts.swift
//  KobelcoService
//
//  Created by Swaminath on 10/6/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit
import Charts

class LegendDataSet: NSObject {
    var legendColor: UIColor = .clear
    var legendName: String = ""
}

@objc protocol KSPlotChartsDelegate {
    func sendSelectedParameter(parameterName: String)
}

class KSPlotCharts: UIViewController, KSPlotChartsDelegate {

    @IBOutlet weak var selectParameterTextField: UITextField!
    @IBOutlet weak var shareGraphButton: UIButton!
    @IBOutlet weak var selectGraphTypeSegment: UISegmentedControl!
    @IBOutlet weak var chartView: LineChartView!
    var numberOfChartsSelected = [String]()
    var dictionaryValues = [String: [Double]]()
    var legendDataSetObject: [LegendDataSet] = []
    var lineChartData: [LineChartDataSet] = []
    var selectedGraphArray = [String]()
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var stepperUI: UIStepper!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Data Comparison")
        self.shareGraphButton.isEnabled = false
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.selectParameterTextField.text = self.selectedGraphArray[0]
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.showLoaderWithoutThread()
        self.loadJsonFileAndDrawGraph(jsonFileName: self.selectParameterTextField.text!)
        self.stepperUI.backgroundColor = .lightGray
    }

    func loadJsonFileAndDrawGraph(jsonFileName: String) {
        DispatchQueue.main.async {
            KSSingletonManager.shared.loadJson(filename: jsonFileName) { (data) in
                guard let jsonDictionary = self.convertDataToDictionary(data: data) else { return }
                //print("jsonDictionary \(jsonDictionary)")
                let dataValues = jsonDictionary["data"] as! [[String: Any]]
                for value in dataValues {
                    let signalName = value["signalName"] as! String
                    let signalValues = value["signalValues"] as! [Double]
                    self.dictionaryValues[signalName] = signalValues
                }
            }

            self.drawLineChart()
        }
    }

    func drawLineChart () {
        chartView.chartDescription?.enabled = false
        chartView.dragEnabled = true
        chartView.setScaleEnabled(true)
        chartView.pinchZoomEnabled = true
        chartView.legend.enabled = false
        chartView.backgroundColor = .white

        let xAxis = chartView.xAxis
        xAxis.labelFont = .systemFont(ofSize: 11)
        xAxis.labelTextColor = .blue
        xAxis.labelPosition = .bottom
        xAxis.drawAxisLineEnabled = true
        //        xAxis.axisMaximum = Double(toPointsDisplay)
        //        xAxis.axisMinimum = Double(fromPointsDisplay)
        //  xAxis.valueFormatter = XAxisValueFormatterForLineChart()
        //
        let leftAxis = chartView.leftAxis
        leftAxis.labelTextColor = UIColor(red: 51/255, green: 181/255, blue: 229/255, alpha: 1)
        //        leftAxis.axisMaximum = Double(5000)
        //        leftAxis.axisMinimum = 0
        leftAxis.drawGridLinesEnabled = true
        leftAxis.granularityEnabled = true

        let rightAxis = chartView.rightAxis
        rightAxis.labelTextColor = .red
        //        rightAxis.axisMaximum = Double(500)
        //        rightAxis.axisMinimum = 0
        rightAxis.granularityEnabled = false

        //chartView.animate(xAxisDuration: 2.5)
        //        for (key, value) in dictionaryValues {
        //            print("key --> \(key), value --> \(value)")
        //        }
        self.setDataCount()
    }

    func setDataCount() {
        //self.legendDataSetObject = []
        self.lineChartData = []

        for (key, values) in dictionaryValues {
            //print("key --> \(key) values --> \(values)")
            let yVals1 = (0..<values.count).map { (i) -> ChartDataEntry in
                return ChartDataEntry(x: Double(i), y: values[i])
            }

            let newDataSetName = key
            let setRandomColor = self.randomColor()

            let lds = LegendDataSet()
            lds.legendName = newDataSetName
            lds.legendColor = setRandomColor
            let set1 = LineChartDataSet(entries: yVals1, label: "\(key)")
            set1.axisDependency = .right
            set1.setColor(setRandomColor)
            set1.setCircleColor(setRandomColor)
            set1.lineWidth = 2
            set1.circleRadius = 3
            set1.fillAlpha = 65/255
            set1.fillColor = setRandomColor
            set1.highlightColor = UIColor(red: 244/255, green: 117/255, blue: 117/255, alpha: 1)
            set1.drawCircleHoleEnabled = false
            self.lineChartData.append(set1)
            self.legendDataSetObject.append(lds)
        }

        let data = LineChartData(dataSets: self.lineChartData)
        data.setValueTextColor(.black)
        data.setValueFont(.systemFont(ofSize: 9))

        chartView.data = data
        self.tableView.reloadData()
        self.hideLoader()
    }

    func randomColor() -> UIColor {
        let red = CGFloat(drand48())
        let green = CGFloat(drand48())
        let blue = CGFloat(drand48())
        return UIColor(red: red, green: green, blue: blue, alpha: 1.0)
    }

    @IBAction func openiPhoneShareOptionsButtonAction(_ sender: UIButton) {
    }

    // Called when selection of parameter from tableview list and display the selected parameter on textfield.
    func sendSelectedParameter(parameterName: String) {
        selectParameterTextField.text = parameterName
        DispatchQueue.main.async {
            self.showLoaderWithoutThread()
            self.loadJsonFileAndDrawGraph(jsonFileName: self.selectParameterTextField.text!)
        }
    }
    @IBAction func SelectGraphTypeSegmentAction(_ sender: Any) {
    }
}

// MARK: Textfield delegate
extension KSPlotCharts: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField.text?.count == 0 && string == " " {
            return false
        }
        return true
    }
    // Tap on texfield to call tableview contoller method.
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if textField == selectParameterTextField {
            presentModelTypeOrAreaController()
        }
        return false
    }
    // Load tableview items based on textfield selection.
    func presentModelTypeOrAreaController() {
        let parametersTableView = MAINSTORYBOARD.instantiateViewController(withIdentifier: Identifier.dataParametersList.rawValue) as! KSDataParameterList
        parametersTableView.delegate = self
        parametersTableView.totalParametersList = self.selectedGraphArray
        self.present(parametersTableView, animated: true, completion: nil)
    }
}

extension KSPlotCharts: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.dictionaryValues.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "KSLegendCell", for: indexPath) as! KSLegendCell
        cell.fillCellData(legendDataSet: legendDataSetObject[indexPath.row])
        return cell
    }
}

class ExtendIAxisValueFormatter: NSObject, IAxisValueFormatter {
    public let numFormatter: NumberFormatter

    override init() {
        numFormatter = NumberFormatter()
        numFormatter.numberStyle = .percent
        numFormatter.maximumFractionDigits = 1
        numFormatter.multiplier = 1
        numFormatter.percentSymbol = "%"
    }

    func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        return numFormatter.string(from: NSNumber(floatLiteral: value))!
    }
}

//class XAxisValueFormatterForLineChart: ExtendIAxisValueFormatter {}

class XAxisValueFormatterForLineChart: ExtendIAxisValueFormatter {
    public override func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        return "\(value * 2)"
        //        if value == axis?.axisMaximum {
        //            return "End"//JLGStringConstants.kMostRecent
        //        } else if value == axis?.axisMinimum {
        //            return "Start"
        //        }
        //
        //        return "\(value)"
    }
}
