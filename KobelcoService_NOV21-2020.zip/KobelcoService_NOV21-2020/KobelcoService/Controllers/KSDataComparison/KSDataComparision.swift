//
//  KSDataComparision.swift
//  KobelcoService
//
//  Created by Swaminath on 9/27/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

class KSDataComparision: UIViewController {

    @IBOutlet weak var selectLogDataView: UIView!
    @IBOutlet weak var selectNormalDataView: UIView!
    @IBOutlet weak var logDataTableview: UITableView!
    @IBOutlet weak var normalDataTableview: UITableView!
    @IBOutlet weak var plotChartsButton: KSCustomButton!
    var storeParameters = ["L27_P3", "L27_P500", "L27_P1648", "L27_P3", "L27_P500", "L27_P1648"]
    var setParameters: [KSIsCheckBoxSelectedModel] = []
    var selectedParameter: [Int] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.setUpUIParameterRegistrationComponents()
        self.logDataTableview.register(UINib(nibName: "KSCheckBoxWithLabelCellTableViewCell", bundle: nil), forCellReuseIdentifier: "KSCheckBoxWithLabelCellTableViewCell")
        self.normalDataTableview.register(UINib(nibName: "KSCheckBoxWithLabelCellTableViewCell", bundle: nil), forCellReuseIdentifier: "KSCheckBoxWithLabelCellTableViewCell")
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Data Comparison")
        self.navigationItem.hidesBackButton = true
        self.selectedParameter = []
        self.setParameters = storeParameters.map {KSIsCheckBoxSelectedModel.init(nameValue: $0, isSelectedValue: false)}
        self.logDataTableview.reloadData()
        self.checkPlotChartsButtonEnableOrNot()
    }

    func checkPlotChartsButtonEnableOrNot() {
        if self.selectedParameter.count != 0 {
            self.plotChartsButton.isEnabled = true
        } else {
            self.plotChartsButton.isEnabled = false
        }
    }

    fileprivate func setUpUIParameterRegistrationComponents() {
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.selectLogDataView.layer.cornerRadius = 6
        self.selectNormalDataView.layer.cornerRadius = 6
    }

    @IBAction func plotChartsButtonAction(_ sender: Any) {
        let plotChartVCObj = MAINSTORYBOARD.instantiateViewController(withIdentifier: "KSPlotCharts") as! KSPlotCharts
        plotChartVCObj.selectedGraphArray = self.storeParameters
        self.navigationController?.pushViewController(plotChartVCObj, animated: true)
    }
}

// MARK: Tableview delegate
extension KSDataComparision: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == logDataTableview {
            return storeParameters.count
        } else {
            return rowCountZeroCheckFunctionality(selectedTableView: tableView, rowCount: 0)
        }
    }

    // Condition check for tableview row count and add tableview background with records label if count == 0.
    fileprivate func rowCountZeroCheckFunctionality(selectedTableView: UITableView, rowCount: Int) -> Int {
        if rowCount == 0 {
            DispatchQueue.main.async {
                self.nullDataFilesLabel(tableView: selectedTableView)
            }
        } else {
            selectedTableView.backgroundView = nil
        }
        return rowCount
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == logDataTableview {
            let theParameterCell = tableView.dequeueReusableCell(withIdentifier: "KSCheckBoxWithLabelCellTableViewCell") as! KSCheckBoxWithLabelCellTableViewCell
            self.setupLogDataTableView(cellObj: theParameterCell, indexValue: indexPath.row)
            return theParameterCell
        } else { // Webserver textfile normal-data names.
            let theParameterCell = tableView.dequeueReusableCell(withIdentifier: "KSCheckBoxWithLabelCellTableViewCell") as! KSCheckBoxWithLabelCellTableViewCell
            return theParameterCell
        }
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == logDataTableview {
            let getParameters = self.setParameters[indexPath.row]
            if self.selectedParameter.count < 5 || getParameters.isSelected == true {
                self.setParameters[indexPath.row] = KSIsCheckBoxSelectedModel.init(nameValue: getParameters.name, isSelectedValue: !getParameters.isSelected)

                if !getParameters.isSelected {
                    self.selectedParameter.append(indexPath.row)
                } else {
                    self.selectedParameter = self.selectedParameter.filter {$0 != indexPath.row}
                }
                self.logDataTableview.reloadData()
            }
        }

        self.checkPlotChartsButtonEnableOrNot()
    }

    func setupLogDataTableView(cellObj: KSCheckBoxWithLabelCellTableViewCell, indexValue: Int) {
        let setParameter = self.setParameters[indexValue]
        cellObj.fillCellData(lableText: setParameter.name, isCheckBoxSelected: setParameter.isSelected)
    }

    // Called when there are no normal data files available.
    func nullDataFilesLabel(tableView: UITableView) {
        let noDataLabel = UILabel()
        noDataLabel.text = "No Records" // Displays this text when tableview is empty
        noDataLabel.textColor = TABLEVIEWLABELCOLOR
        noDataLabel.font = UIFont.medium(ofSize: 18)
        noDataLabel.textAlignment = .center
        tableView.backgroundView = noDataLabel
    }
}
