//
//  KSParameterRegistration.swift
//  KobelcoService
//
//  Created by Guest L&T on 30/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

class KSParameterRegistration: UIViewController {

    @IBOutlet weak var viewSetParameter: UIView!
    @IBOutlet weak var viewTheParameter: UIView!
    @IBOutlet weak var labelSetParameter: UILabel!
    @IBOutlet weak var buttonFavorite: UIButton!
    @IBOutlet weak var buttonEdit: UIButton!
    @IBOutlet weak var setParameterTableView: UITableView!
    @IBOutlet weak var theParameterTableView: UITableView!
    @IBOutlet weak var enginePumpSegmentRegistration: UISegmentedControl!
    @IBOutlet weak var registartionECUDCUSegment: UISegmentedControl!
    var ecuSignalsArray: [ECUSignalsModel] = []
    var pumpSignalsArray: [ECUSignalsModel] = []
    var setParameters: [KSIsCheckBoxSelectedModel] = []
    var plistHelepr = KSPlistReadAndWriteModel()
    var selectedFavoriteParameter = ""
    var previousIndexPathSetParameterTV = IndexPath()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.theParameterTableView.register(UINib(nibName: "KSCheckBoxWithLabelCellTableViewCell", bundle: nil), forCellReuseIdentifier: "KSCheckBoxWithLabelCellTableViewCell")
        self.setParameterTableView.register(UINib(nibName: "KSCheckBoxWithLabelCellTableViewCell", bundle: nil), forCellReuseIdentifier: "KSCheckBoxWithLabelCellTableViewCell")
        setUpUIParameterRegistrationComponents()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.previousIndexPathSetParameterTV = IndexPath()
        self.setEditButtonEnable()
        self.selectedFavoriteParameter = ""
        self.enginePumpSegmentRegistration.layer.cornerRadius = 6
        self.registartionECUDCUSegment.layer.cornerRadius = 6
        self.enginePumpSegmentRegistration.selectedSegmentIndex = 0
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Parameter Registration(Favorite)")
        let setParameterData = plistHelepr.readPlistFileAndReturnKey(namePlist: "SetParameters")
        self.setParameters = setParameterData.map {KSIsCheckBoxSelectedModel.init(nameValue: $0, isSelectedValue: false)}
        self.setParameterTableView.reloadData()
        self.parseCategoryWiseDataJSON()
        self.theParameterTableView.reloadData()
    }

    func parseCategoryWiseDataJSON() {
        KSSingletonManager.shared.loadJson(filename: MATRIXDATAFILE) { (categoryWiseData) in
            guard let categoryWiseDataInJSON = self.convertDataToDictionary(data: categoryWiseData)  else { return }
            let aOneDic: [String: Any] = categoryWiseDataInJSON[KSSingletonManager.shared.modelTypeSelection] as! [String: Any]
            self.setECUPumpArrayValues(dicValue: aOneDic)
        }
    }

    func setECUPumpArrayValues(dicValue: [String: Any]) {
        let ecuSignals = dicValue["ECUSignals"] as! [[String: Any]]
        self.ecuSignalsArray = ecuSignals.map {ECUSignalsModel.init(data: $0)}
        let pumpSignals = dicValue["pumpSignals"] as! [[String: Any]]
        self.pumpSignalsArray = pumpSignals.map {ECUSignalsModel.init(data: $0)}
    }

    // Autohide for iPhone Footer Line.
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
    // Configure UI Components.
    fileprivate func setUpUIParameterRegistrationComponents() {
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.viewSetParameter.layer.cornerRadius = 6
        self.viewTheParameter.layer.cornerRadius = 6
        self.buttonEdit.setTitle("Edit", for: .normal)
        self.enginePumpSegmentRegistration.setSegmentTintColors()
        self.registartionECUDCUSegment.setSegmentTintColors()
    }

    // Toggle segment for engine and pump selection.
    // By default engine and ECU will select and display respective list in the parameter tableview.
    @IBAction func enginePumpRegistrationmainSegmentAction(_ sender: Any) {
        self.theParameterTableView.reloadData()
    }

    // Click on this to create temperory favorite parameter name.
    @IBAction func favoriteButtonTapAction(_ sender: UIButton) {
        let addFavorite = CONFIGURATIONSTORYBOARD.instantiateViewController(withIdentifier: "KSParameterAddfavorite") as! KSParameterAddfavorite
        addFavorite.ksParameterAddfavoriteDelegate = self
        self.navigationController?.pushViewController(addFavorite, animated: true)
        //self.navigationToConfigurationStoryboard(to: Identifier.parameterAddfavoriteScreen)
    }
    // Click on this to navigate to edit parameter screen for to edit parameter name and items.
    @IBAction func editButtonTapAction(_ sender: UIButton) {
        let editFavorite = CONFIGURATIONSTORYBOARD.instantiateViewController(withIdentifier: "KSParameterEdit") as! KSParameterEdit
        editFavorite.selectedFavoriteParameter = self.selectedFavoriteParameter
        self.navigationController?.pushViewController(editFavorite, animated: true)
    }

    // Toggle action for the parameters tableview list.
    // If ECU/DCU selected display only ECU/DCU related parameters in the paramter tableview.
    @IBAction func footerRegistrationECUDCUSegmentAction(_ sender: Any) {
    }

    func setEditButtonEnable() {
        if self.previousIndexPathSetParameterTV.isEmpty {
            self.buttonEdit.setTitleColor(#colorLiteral(red: 0.3333333433, green: 0.3333333433, blue: 0.3333333433, alpha: 1), for: .normal)
            self.buttonEdit.isEnabled = false
        } else {
            self.buttonEdit.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
            self.buttonEdit.isEnabled = true
        }

    }
}

extension KSParameterRegistration: KSParameterAddfavoriteDelegate {
    func parameterAddCaption(txtValue: String) {
        var data: [String: Any]
        let ecuDictionary = self.ecuSignalsArray.map {$0.asDictionary}
        let pumpDictionary = self.pumpSignalsArray.map {$0.asDictionary}
        data = ["ECUSignals": ecuDictionary, "pumpSignals": pumpDictionary]
        plistHelepr.writePlist(namePlist: "SetParameters", key: txtValue, data: data as AnyObject)
    }
}

// MARK: Tableview delegate
extension KSParameterRegistration: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == setParameterTableView {
            return self.setParameters.count
        } else {
            if self.enginePumpSegmentRegistration.selectedSegmentIndex == 1 {
                return self.pumpSignalsArray.count
            } else {
                return self.ecuSignalsArray.count
            }
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == setParameterTableView {
            let theParameterCell = tableView.dequeueReusableCell(withIdentifier: "KSCheckBoxWithLabelCellTableViewCell") as! KSCheckBoxWithLabelCellTableViewCell
            self.setUpSetParameterTableView(cellObj: theParameterCell, indexValue: indexPath.row)
            return theParameterCell
        } else {
            let theParameterCell = tableView.dequeueReusableCell(withIdentifier: "KSCheckBoxWithLabelCellTableViewCell") as! KSCheckBoxWithLabelCellTableViewCell
            self.setUpTheParameterTableView(cellObj: theParameterCell, indexValue: indexPath.row)
            return theParameterCell
        }
    }

    func setUpSetParameterTableView(cellObj: KSCheckBoxWithLabelCellTableViewCell?, indexValue: Int) {
        let setParameter = self.setParameters[indexValue]
        if let _ = cellObj {
            cellObj?.fillRadioCellData(lableText: setParameter.name, isCheckBoxSelected: setParameter.isSelected)
        } else {
            let indexPath = IndexPath(row: indexValue, section: 0)
            let getCell = self.setParameterTableView.cellForRow(at: indexPath) as? KSCheckBoxWithLabelCellTableViewCell
            getCell?.fillRadioCellData(lableText: setParameter.name, isCheckBoxSelected: setParameter.isSelected)
        }
    }

    func tableViewScrollToTop(tableView: UITableView) {
        let topIndex = IndexPath(row: 0, section: 0)
        tableView.reloadRows(at: [topIndex], with: .fade)
        tableView.scrollToRow(at: topIndex, at: .top, animated: true)
    }

    func setUpTheParameterTableView(cellObj: KSCheckBoxWithLabelCellTableViewCell, indexValue: Int) {
        var txtLabel = ""
        var isSelected = false
        if self.enginePumpSegmentRegistration.selectedSegmentIndex == 1 {
            txtLabel = self.pumpSignalsArray[indexValue].name["en"] as! String
            isSelected = self.pumpSignalsArray[indexValue].isSelected
        } else {
            txtLabel = self.ecuSignalsArray[indexValue].name["en"] as! String
            isSelected = self.ecuSignalsArray[indexValue].isSelected
        }

        cellObj.fillCellData(lableText: txtLabel, isCheckBoxSelected: isSelected)
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == setParameterTableView {
            let setParameter = self.setParameters[indexPath.row]
            let output = plistHelepr.readPlistReturnDic(namePlist: "SetParameters", key: setParameter.name)
            self.selectedFavoriteParameter = setParameter.name
            self.setECUPumpArrayValues(dicValue: output)
            self.theParameterTableView.reloadData()
            _ = self.setPreviousIndexPathValue()
            self.setParameters[indexPath.row] = KSIsCheckBoxSelectedModel.init(nameValue: setParameter.name, isSelectedValue: true)
            self.previousIndexPathSetParameterTV = indexPath
            self.setParameterTableView.reloadData()
            self.setEditButtonEnable()
        } else {
            if self.setPreviousIndexPathValue() {
                self.setParameterTableView.reloadData()
                self.previousIndexPathSetParameterTV = IndexPath()
            }
            self.parameterCheckBoxButtonPressed(indexValue: indexPath.row)
        }
    }

    func setPreviousIndexPathValue() -> Bool {
        if !self.previousIndexPathSetParameterTV.isEmpty {
            let setParameter1 = self.setParameters[self.previousIndexPathSetParameterTV.row]
            self.setParameters[self.previousIndexPathSetParameterTV.row] = KSIsCheckBoxSelectedModel.init(nameValue: setParameter1.name, isSelectedValue: false)
            return true
        }
        return false
    }
}

extension KSParameterRegistration {
    func parameterCheckBoxButtonPressed(indexValue: Int) {
        self.setEditButtonEnable()
         if self.enginePumpSegmentRegistration.selectedSegmentIndex == 1 {
            var pump = self.pumpSignalsArray[indexValue]
            pump.isSelected = !pump.isSelected
            self.pumpSignalsArray[indexValue] = pump
         } else {
            var ecu = self.ecuSignalsArray[indexValue]
            ecu.isSelected = !ecu.isSelected
            self.ecuSignalsArray[indexValue] = ecu
         }
        let reloadIndex = IndexPath(row: indexValue, section: 0)
        self.theParameterTableView.reloadRows(at: [reloadIndex], with: .none)
    }
}
