//
//  KSWIFISettings.swift
//  KobelcoService
//
//  Created by Guest L&T on 11/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit
import NotificationCenter
import UserNotifications

class KSWIFISettings: UIViewController {

    @IBOutlet weak var buttonWIFISettings: UIButton!
    @IBOutlet weak var labelSSIDName: UILabel!
    @IBOutlet weak var labelStart: UILabel!
    @IBOutlet weak var buttonStart: UIButton!
    @IBOutlet weak var buttonWithoutWIFI: UIButton!
    fileprivate var isWIFIViewPresented: Bool = true
    private let wifiSettingVM: KSWiFiSettingsVM

    init(wifiSettingVM: KSWiFiSettingsVM) {
        self.wifiSettingVM = wifiSettingVM
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) {
        self.wifiSettingVM = KSWiFiSettingsVM()
        super.init(coder: coder)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.navigationController?.navigationBar.isHidden = true
        self.navigationController?.getWiFiSettingsNavigationID()
        setUpUIComponents()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        KSSingletonManager.shared.currentScreenName = "KSWIFISettings" // Using this reference to identify navigation viewcontroller index count
        isWIFIViewPresented = true
    }
    
    // Used to hide iPhoneX/XS footer home line.
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.showCopyrightLabel()
        KSSingletonManager.shared.delegate = self
    }
    
    // MARK: Identify screen orientation
    // todo: clear copyright label from footer before orientation changes
    // fixme: Again add copyright footer label after screen orientation to avoid constraint problem.
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        if isWIFIViewPresented {
            self.hideCopyrightLabel()
            if UIDevice.current.orientation.isLandscape {
                self.showCopyrightLabel()
            } else {
                self.showCopyrightLabel()
            }
        }
     }
    
    // Assining all custom property values here in a single function.
    fileprivate func setUpUIComponents() {
        self.labelSSIDName.font = UIFont.regular(ofSize: 14)
        self.labelStart.font = UIFont.regular(ofSize: 14)
        self.buttonWIFISettings.setTitle("Wi-Fi Settings", for: .normal)
        self.buttonStart.setTitle("Start", for: .normal)
        self.buttonWithoutWIFI.setTitle("Next Without Connection", for: .normal)
        self.perform(#selector(networkMonitor), with: self, afterDelay: 1)
        self.perform(#selector(updateSSIDName), with: self, afterDelay: 1)
        KSSingletonManager.shared.delegate = self
    }
    
    // MARK: Identify internet connection availability
    // todo: Open iPhone general Wi-Fi settings when network is not reachable
    // fixme: Navigate to next screen if iphone device is connected to any Wi-Fi network.
    @objc private func networkMonitor() {
        appDelegate?.networkCompletionHandler = { (networkStatus, isWifiMode) in
            if networkStatus == true {
                self.updateSSIDName()
                if isWifiMode! {
                    print("WIFI Settings WiFiMode")
                } else {
                    print("WIFI Settings  MobileInternet")
                }
            } else {
                DispatchQueue.main.async {
                    self.navigation(to: Identifier.connectScreen)
                }
            }
        }
    }
    // Get connected WIFI name and showcase on userinterface label.
    @objc private func updateSSIDName() {
        guard let ssidName = self.wifiSettingVM.getSSID() else { return }
        DispatchQueue.main.async {
            self.labelSSIDName.text = "Your phone is connected to \(ssidName)"
        }
    }
    @IBAction func wifiSettingsButtonAction(_ sender: Any) {
        KSSingletonManager.openWifiSettings() // Used to open iPhone general settings
    }
    // Click on this button to initaite Websocket connection after connected to a proper WIFI network.
    @IBAction func startButtonAction(_ sender: Any) {
        self.showLoader()
        KSSingletonManager.shared.connectWebSocket()
    }
    // Click on this button when you want to operate this application in offline mode.
    @IBAction func withoutWifiButtonAction(_ sender: Any) {
        KSSingletonManager.shared.isOfflineConnection = true
        self.navigation(to: Identifier.modelTypeScreen)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        KSSingletonManager.shared.currentScreenName = "" // Clear screen title text to avoid conflicts
        self.hideCopyrightLabel() // remove footer label before navigating to other screens
        isWIFIViewPresented = false
        KSSingletonManager.shared.disconnectWebSocket()
    }
}

// MARK: - WebSocket Response Delegate
extension KSWIFISettings: KSWebSocketDelegates {
    func webSocketStringResponse(response: String) {
        self.hideLoader()
        print("String response: \(response)")
        if response == "Connection Opened" {
            KSSingletonManager.shared.isOfflineConnection = false
            self.navigation(to: Identifier.modelTypeScreen)
        }
    }
    func webSocketErrorConnection(message: String) {
        self.hideLoader()
        presentAlertOKAction(withTitle: "ERROR", message: message) { (_ ) in
            KSSingletonManager.shared.connectWebSocket()
        }
    }
    func internetConnectionNotAvailable() {
        self.hideLoader()
        presentAlert(withTitle: "ERROR", message: NOINTERNETMESSAGE)
    }
}
