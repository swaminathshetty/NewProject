//
//  KSMachineLearningCell.swift
//  KobelcoService
//
//  Created by Swaminath on 9/26/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSMachineLearningCell: UITableViewCell {

    @IBOutlet weak var BGLearningView: UIView!
    @IBOutlet weak var learningItemName: UILabel!
    @IBOutlet weak var learningValue: UILabel!
    @IBOutlet weak var learningUnits: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.BGLearningView.layer.cornerRadius = 6
    }

    // Data binding cell function for machine learning itemname, value and unit.
    func configureMachineLearningStatusCellTitle(itemObject: [String: Any], itemValue: Int) {
        guard let learningDict = itemObject["itemName"] as? [String: Any] else { return }
        guard let learningName = learningDict["en"] as? String else { return }
        guard let learningUnit = itemObject["unit"] as? String else { return }
        let value = itemValue == 0 ? "-" : String(itemValue)
        self.learningItemName.text = learningName
        self.learningValue.text = value
        self.learningUnits.text = learningUnit
    }
}
