//
//  DiagnosticTestModel.swift
//  KobelcoService
//
//  Created by Guest L&T on 12/11/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation

// Websocket Request for Diagnostic Read & Write Signals model.
struct DiagnosticStartRequest: Codable {
    let screenName: String!
    let frameType: String!
    let writeSignals: [String]!
    let writeValue: [Int]!
    let readSignals: [String]!
    let periodicity: Int!
}
