//
//  KSConstants.swift
//  KobelcoService
//
//  Created by Guest L&T on 09/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
import UIKit

//MARK:- APP CONSTANTS
let MAIN_SCREEN_BOUNDS   = UIScreen.main.bounds
let SCREEN_WIDTH         = MAIN_SCREEN_BOUNDS.width
let SCREEN_HEIGHT        = MAIN_SCREEN_BOUNDS.height

let IS_IPAD: Bool        = UIDevice.current.userInterfaceIdiom == .pad
let IS_IPHONE: Bool      = UIDevice.current.userInterfaceIdiom == .phone

let IS_IPHONE_4_OR_LESS  = UIDevice.current.userInterfaceIdiom == .phone && MAIN_SCREEN_BOUNDS.height < 568.0
let IS_IPHONE_5          = UIDevice.current.userInterfaceIdiom == .phone && MAIN_SCREEN_BOUNDS.height == 568.0
let IS_IPHONE_6_7        = UIDevice.current.userInterfaceIdiom == .phone && MAIN_SCREEN_BOUNDS.height == 667.0
let IS_IPHONE_6P_7P      = UIDevice.current.userInterfaceIdiom == .phone && MAIN_SCREEN_BOUNDS.height == 736.0
let IS_IPHONE_X          = IS_IPHONE_X_OR_Xs ? IS_IPHONE_X_OR_Xs : IS_IPHONE_Xr_OR_Xmax
let IS_IPHONE_X_OR_Xs    = fabs(Double(UIScreen.main.bounds.size.height) - Double(812)) < Double.ulpOfOne // 3x-2436,x,xs-812
let IS_IPHONE_Xr_OR_Xmax = fabs(Double(UIScreen.main.bounds.size.height) - Double(896)) < Double.ulpOfOne //3x-2688-xmax-896,2x-1792-xr-896

let IS_IPAD_9_7          = UIDevice.current.userInterfaceIdiom == .pad && MAIN_SCREEN_BOUNDS.height == 1024.0
let IS_IPAD_PRO          = UIDevice.current.userInterfaceIdiom == .pad && MAIN_SCREEN_BOUNDS.height == 1366.0

//let IS_IPAD_PORTRAIT = UIApplication.shared.statusBarOrientation == .portrait || UIApplication.shared.statusBarOrientation == .portraitUpsideDown

//STORYBOARD
let MAIN_STORYBOARD = UIStoryboard.init(name: "Main", bundle: nil)
//USERDEFAULTS
let KS_USER_DEFAULTS = UserDefaults.standard

let KS_BUTTON_CORNER_RADIUS = 6.0

let VIEW_BACKGROUND_COLOR = #colorLiteral(red: 0, green: 0.6470588235, blue: 0.6666666667, alpha: 1)
let NAVIGATION_BAR_COLOR = #colorLiteral(red: 0.007843137255, green: 0.4666666667, blue: 0.4901960784, alpha: 1)
let TEXTFILED_TEXT_COLOR = #colorLiteral(red: 0.3215686275, green: 0.3215686275, blue: 0.3215686275, alpha: 1)
let TEXTFIELD_BORDER_COLOR = #colorLiteral(red: 0.8509803922, green: 0.8509803922, blue: 0.8509803922, alpha: 1).cgColor


let NAVIGATION_LEFTBAR_LOGO = UIImage.init(named: "kobelcoLogo")
let NAVIGATION_RIGHTBAR_LOGO = UIImage.init(named: "dashboardIcon")

//Alert Text
let LOGIN_SUCCESS = "You are successfully logged in as:"

