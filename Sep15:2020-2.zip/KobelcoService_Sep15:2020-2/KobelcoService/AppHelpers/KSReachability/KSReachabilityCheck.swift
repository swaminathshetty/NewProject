//
//  KSReachabilityCheck.swift
//  KobelcoService
//
//  Created by Guest L&T on 15/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation

protocol WiFiSettingsDelegate: NSObject {
    func updateWifiStatus(reachabilityStatus: Bool)
}

class KSReachabilityCheck {
    var reachability = Reachability()
    fileprivate var netAvailability: Bool = false
    weak var delegate:WiFiSettingsDelegate?
    
    //MARK:- Reachability Check
    func reachabilityCheck() {
        if reachability!.currentReachabilityStatus != .notReachable {
            netAvailability = true
        }
        // For find out Internet when goes On or Off
        NotificationCenter.default.addObserver(self, selector:#selector(reachabilityChanged), name: ReachabilityChangedNotification, object: nil);
        do{
            try reachability!.startNotifier()
        }catch{
        }
    }
    //MARK: - Network Finder
    @objc func reachabilityChanged(note: NSNotification) {
        let reachability = note.object as! Reachability
            switch reachability.currentReachabilityStatus {
            case .reachableViaWiFi:
                netAvailability = true
                print("netAvailability: \(netAvailability)")
                delegate?.updateWifiStatus(reachabilityStatus: netAvailability)
            case .reachableViaWWAN:
                netAvailability = true
                delegate?.updateWifiStatus(reachabilityStatus: netAvailability)
            case .notReachable:
                netAvailability = false
                delegate?.updateWifiStatus(reachabilityStatus: netAvailability)
          }
    }
}


