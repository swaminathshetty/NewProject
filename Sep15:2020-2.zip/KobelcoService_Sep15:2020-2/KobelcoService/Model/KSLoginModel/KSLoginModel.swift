//
//  KSLoginModel.swift
//  KobelcoService
//
//  Created by Guest L&T on 11/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation

struct LoginModel {
    let username: String = "Kobelco"
    let password: String = "Password"
}
