//
//  KSModelType.swift
//  KobelcoService
//
//  Created by Guest L&T on 14/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSModelType: UIViewController {

    @IBOutlet weak var label_ModelType: UILabel!
    @IBOutlet weak var label_Area: UILabel!
    @IBOutlet weak var textField_ModelType: UITextField!
    @IBOutlet weak var textField_Area: UITextField!
    @IBOutlet weak var button_Submit: UIButton!
    fileprivate var modelTypePicker = UIPickerView()
    fileprivate var areaPicker = UIPickerView()
    fileprivate var modelTypeArray : [String] = ["YN15","YN16"]
    fileprivate var areaArray : [String]! = ["SK300LC","SK400LC"]
    private let modelTypeVM: KSModelTypeVM

    init(modelTypeVM: KSModelTypeVM) {
        self.modelTypeVM = modelTypeVM
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        self.modelTypeVM = KSModelTypeVM()
        super.init(coder: coder)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        setUpUIComponents()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        modelTypePicker.delegate = self
        areaPicker.delegate = self
        //Setting default ModelType & Area
        //self.textField_ModelType.text = ""
        //self.textField_Area.text = ""
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    func setUpUIComponents() {
        self.label_ModelType.font = KS_LABEL_FONT
        self.label_Area.font = KS_LABEL_FONT
        self.textField_ModelType.setCustomTextFieldStyle(imageName: "dropdownIcon")
        self.textField_Area.setCustomTextFieldStyle(imageName: "dropdownIcon")
        self.button_Submit.setTitle("Submit", for: .normal)
        self.textField_ModelType.inputView = modelTypePicker
        self.textField_Area.inputView = areaPicker
    }
    @IBAction func submitButtonAction(_ sender: Any) {
        self.view.endEditing(true)
        do {
                _ = try modelTypeVM.validateModelType(textField_ModelType.text)
                _ = try modelTypeVM.validateArea(textField_Area.text)
            self.navigation(to: Identifier.dashboardScreen)
            } catch {
                self.presentAlert(withTitle: "Message", message: "\(error.localizedDescription)")
            }
    }
}

extension KSModelType: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == self.modelTypePicker {
            return modelTypeArray.count
        } else {
            return areaArray.count
        }
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
           if pickerView == modelTypePicker {
               return modelTypeArray[row]
           } else {
               return areaArray[row]
           }
       }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int){
        if pickerView == modelTypePicker {
           if row < modelTypeArray.count {
                textField_ModelType.text = modelTypeArray[row]
           }
        }else{
           if row < areaArray.count {
                textField_Area.text = areaArray[row]
           }
        }
           self.view.endEditing(true)
    }
    
}
