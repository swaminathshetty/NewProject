//
//  KSWIFISettings.swift
//  KobelcoService
//
//  Created by Guest L&T on 11/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit
import NotificationCenter
import UserNotifications

class KSWIFISettings: UIViewController {

    @IBOutlet weak var button_WIFISettings: UIButton!
    @IBOutlet weak var label_SSIDName: UILabel!
    @IBOutlet weak var label_Start: UILabel!
    @IBOutlet weak var button_Start: UIButton!
    @IBOutlet weak var button_WithoutWIFI: UIButton!
    
    private let wifiSettingVM: KSWiFiSettingsVM
    private let wifiDelegate: KSReachabilityCheck

    init(wifiSettingVM: KSWiFiSettingsVM, wifiDelegate: KSReachabilityCheck) {
          self.wifiSettingVM = wifiSettingVM
          self.wifiDelegate = wifiDelegate
          super.init(nibName: nil, bundle: nil)
      }
      
      required init?(coder: NSCoder) {
          self.wifiSettingVM = KSWiFiSettingsVM()
          self.wifiDelegate = KSReachabilityCheck()
          super.init(coder: coder)
      }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        setUpUIComponents()
        wifiDelegate.delegate = self
        wifiDelegate.reachabilityCheck()
    }
    func setUpUIComponents() {
        self.label_SSIDName.setLabelFontSize(fontStyle: REGULAR_FONT, fontSize: 14)
        self.label_Start.setLabelFontSize(fontStyle: REGULAR_FONT, fontSize: 14)
        self.button_WIFISettings.setButtonCornerRadius(text: "Wi-Fi Settings", image: "")
        self.button_Start.setButtonCornerRadius(text: "Start", image: "")
        self.button_WithoutWIFI.setTitle("Next Without Connection", for: .normal)
    }
    @IBAction func wifiSettingsButtonAction(_ sender: Any) {
        wifiDelegate.delegate = self
        wifiDelegate.reachabilityCheck()
        KSSingletonManager.openWifiSettings()
    }
    @IBAction func startButtonAction(_ sender: Any) {
        self.navigation(to: Identifier.modelTypeScreen)
    }
    @IBAction func withoutWifiButtonAction(_ sender: Any) {
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        removeReachabilityObserver()
    }
    func removeReachabilityObserver() {
        self.wifiDelegate.reachability?.stopNotifier()
         NotificationCenter.default.removeObserver(self, name: ReachabilityChangedNotification, object: self.wifiDelegate.reachability)
         self.wifiDelegate.delegate = nil
    }
}

extension KSWIFISettings: WiFiSettingsDelegate {
    func updateWifiStatus(reachabilityStatus: Bool) {
        if reachabilityStatus {
            guard let ssidName = wifiSettingVM.getSSID() else { return }
            DispatchQueue.main.async {
                self.label_SSIDName.text = "Your phone is connected to \(ssidName) WI-FI"
            }
        } else {
            removeReachabilityObserver()
            self.navigation(to: Identifier.connectScreen)
        }
    }
}
