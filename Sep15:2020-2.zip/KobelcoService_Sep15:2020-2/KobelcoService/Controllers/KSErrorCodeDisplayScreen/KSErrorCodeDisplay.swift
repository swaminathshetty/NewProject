//
//  KSErrorCodeDisplay.swift
//  KobelcoService
//
//  Created by Guest L&T on 14/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSErrorCodeDisplay: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        setNavigationBarButtonItemAction()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarColorAndItems()
    }
    func setNavigationBarButtonItemAction() {
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: NAVIGATION_RIGHTBAR_LOGO, style: .plain, target: self, action: #selector(moveToDashboard))
    }
    @objc func moveToDashboard() {
        self.navigationController?.popViewController(animated: true)
        //self.navigation(to: Identifier.dashboardScreen)
    }
}
