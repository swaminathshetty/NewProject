//
//  KSConnect.swift
//  KobelcoService
//
//  Created by Guest L&T on 11/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSConnect: UIViewController {

    @IBOutlet weak var label_Message: UILabel!
    @IBOutlet weak var button_Connect: UIButton!
    @IBOutlet weak var button_WithoutWIFI: UIButton!
    private let wifiDelegate: KSReachabilityCheck

    init(wifiDelegate: KSReachabilityCheck) {
        self.wifiDelegate = wifiDelegate
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) {
        self.wifiDelegate = KSReachabilityCheck()
        super.init(coder: coder)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        setUpUIComponents()
    }
    func checkNetworkAvailability() {
        if KSSingletonManager.shared.IS_REACHABILITY() {
            self.navigation(to: Identifier.wifiSettingsScreen)
        } else {
            KSSingletonManager.openWifiSettings()
        }
    }
    func setUpUIComponents() {
        self.label_Message.setLabelFontSize(fontStyle: REGULAR_FONT, fontSize: 14)
        self.button_Connect.setButtonCornerRadius(text: "Connect", image: "")
        self.button_WithoutWIFI.setTitle("Next Without Connection", for: .normal)
    }
    @IBAction func connectButtonAction(_ sender: Any) {
        checkNetworkAvailability()
    }
    @IBAction func connectWithoutWIFIButtonAction(_ sender: Any) {
    }
}

/*extension KSConnect: WiFiSettingsDelegate {
    func updateWifiStatus(reachabilityStatus: Bool) {
        if reachabilityStatus {
            DispatchQueue.main.async {
                self.wifiDelegate.reachability?.stopNotifier()
                NotificationCenter.default.removeObserver(self, name: ReachabilityChangedNotification, object: self.wifiDelegate.reachability)
                self.wifiDelegate.delegate = nil
                self.navigation(to: Identifier.wifiSettingsScreen)
            }
        } else {
        }
    }    
}*/
