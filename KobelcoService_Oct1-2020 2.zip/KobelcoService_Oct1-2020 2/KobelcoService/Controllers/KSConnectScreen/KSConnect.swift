//
//  KSConnect.swift
//  KobelcoService
//
//  Created by Guest L&T on 11/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSConnect: UIViewController {

    @IBOutlet weak var label_Message: UILabel!
    @IBOutlet weak var button_Connect: UIButton!
    @IBOutlet weak var button_WithoutWIFI: UIButton!
    fileprivate var isViewPresented: Bool = true

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        setUpUIComponents()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        KSSingletonManager.shared.currentScreenName = "KSConnect"
        isViewPresented = true
    }
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.showCopyrightLabel()
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        KSSingletonManager.shared.currentScreenName = ""
        self.hideCopyrightLabel()
        isViewPresented = false
    }
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        if isViewPresented {
            self.hideCopyrightLabel()
            if UIDevice.current.orientation.isLandscape {
                self.showCopyrightLabel()
            } else {
                self.showCopyrightLabel()
            }
        }
    }
    fileprivate func setUpUIComponents() {
        self.label_Message.setLabelFontSize(fontStyle: REGULAR_FONT, fontSize: 14)
        self.button_Connect.setTitle("Connect", for: .normal)
        self.button_WithoutWIFI.setTitle("Next Without Connection", for: .normal)
    }
    fileprivate func checkNetworkAvailability() {
        if appDelegate!.networkAvailability == false {
            KSSingletonManager.openWifiSettings()
        }
        appDelegate?.networkCompletionHandler = { (networkStatus, isWiFiMode) in
            if networkStatus == true {
                DispatchQueue.main.async {
                    print("Internet Connected")
                    self.navigation(to: Identifier.wifiSettingsScreen)
                }
            }
        }
    }
    @IBAction func connectButtonAction(_ sender: Any) {
        checkNetworkAvailability()
    }
    @IBAction func connectWithoutWIFIButtonAction(_ sender: Any) {
    }
}
