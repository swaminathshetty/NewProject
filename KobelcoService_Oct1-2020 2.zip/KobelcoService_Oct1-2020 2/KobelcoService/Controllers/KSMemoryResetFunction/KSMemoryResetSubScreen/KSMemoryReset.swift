//
//  KSMemoryReset.swift
//  KobelcoService
//
//  Created by Swaminath on 9/23/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSMemoryReset: UIViewController {

    @IBOutlet weak var tableView_Items: UITableView!
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var button_ItemName: UIButton!
    @IBOutlet weak var label_Value: UILabel!
    @IBOutlet weak var label_Unit: UILabel!
    @IBOutlet weak var resetButton: UIButton!
    fileprivate var itemsList = ["Item 1", "Item 2", "Item 3", "Item 4"]
    fileprivate var selectedItem = String()
    fileprivate var arraySelectedItems = [String]()
    var navigationTitle = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        self.headerView.layer.cornerRadius = 6
        self.button_ItemName.isSelected = false
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarColorWithButtonTitle(buttonTitle: navigationTitle)
    }
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
    @IBAction func itemNameSelectAction(_ sender: UIButton) {
        arraySelectedItems.removeAll(keepingCapacity: false)
        if sender.isSelected {
            sender.isSelected = !sender.isSelected
        } else {
            sender.isSelected = !sender.isSelected
            arraySelectedItems = itemsList
        }
        resetButton.isEnabled = arraySelectedItems.count > 0 ? true : false
        self.reloadTableView()
    }
    func reloadTableView() {
        DispatchQueue.main.async {
            self.tableView_Items.reloadData()
        }
    }
    @IBAction func resetButtonAction(_ sender: Any) {
        if resetButton.isEnabled {
            showResetConfirmationAlert()
        }
    }
    fileprivate func showResetConfirmationAlert() {
        let alert = UIAlertController(title: "Confirmation", message: "Are you sure you want to reset values?", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: { _ in
        }))
        alert.addAction(UIAlertAction(title: "Reset", style: UIAlertAction.Style.destructive, handler: {(_: UIAlertAction!) in
            self.showLoader()
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                self.resetItems()
            }
        }))
        self.present(alert, animated: true, completion: nil)
    }
    //Reset items button selection to default
    fileprivate func resetItems() {
        self.arraySelectedItems.removeAll(keepingCapacity: false)
        self.button_ItemName.isSelected = (self.arraySelectedItems.count == self.itemsList.count) ? true : false
        self.reloadTableView()
        self.hideLoader()
    }

}

extension KSMemoryReset: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemsList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "KSMemoryResetSubCell"
        let resetCell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as! KSMemoryResetSubCell
        resetCell.button_ItemName.tag = indexPath.row
        resetCell.configureResetCellTitle(itemLists: itemsList, selecteditems: arraySelectedItems)
        resetCell.button_ItemName.addTarget(self, action: #selector(itemNameButtonSelection(_ :)), for: .touchUpInside)
        return resetCell
    }
    @objc func itemNameButtonSelection(_ sender: UIButton) {
        self.selectedItem = itemsList[sender.tag]
        if arraySelectedItems.contains(self.selectedItem) {
            if let index = arraySelectedItems.firstIndex(of: self.selectedItem) {
                self.selectedItem = "NOTSELECTED"
                arraySelectedItems.remove(at: index)
            }
        }
        else{
            self.arraySelectedItems.append(self.selectedItem)
        }
        button_ItemName.isSelected = (arraySelectedItems.count == itemsList.count) ? true : false
        resetButton.isEnabled = arraySelectedItems.count > 0 ? true : false
        self.reloadTableView()
    }

}
