//
//  KSParameterEdit.swift
//  KobelcoService
//
//  Created by Guest L&T on 01/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSParameterEdit: UIViewController {

    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var footerView: UIView!
    @IBOutlet weak var textField_Parameter: UITextField!
    @IBOutlet weak var tableView_Parameters: UITableView!
    @IBOutlet weak var button_Delete: UIButton!
    @IBOutlet weak var button_Save: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUIComponents()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Edit Favorite")
    }
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
    func setUpUIComponents() {
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        self.headerView.layer.cornerRadius = 6
        self.button_Delete.setTitle("Delete", for: .normal)
        self.button_Save.setTitle("Save", for: .normal)
    }
    @IBAction func deleteButtonTapAction(_ sender: Any) {
    }
    @IBAction func saveButtonTapAction(_ sender: Any) {
    }
}

//MARK:- Tableview Delegate
extension KSParameterEdit: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "KSEditParameterCell"
        let setCell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as! KSEditParameterCell
        setCell.button_CheckBox.tag = indexPath.row
        setCell.button_CheckBox.addTarget(self, action: #selector(editParameterSelection(_ :)), for: .touchUpInside)
        return setCell
        
    }
    @objc func editParameterSelection(_ sender: UIButton) {
    }
}
