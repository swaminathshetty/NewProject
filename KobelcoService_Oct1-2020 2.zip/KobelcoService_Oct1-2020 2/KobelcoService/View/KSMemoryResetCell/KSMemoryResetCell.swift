//
//  KSMemoryResetCell.swift
//  KobelcoService
//
//  Created by Guest L&T on 23/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

//MARK:- Disclosure type cell
class KSMemoryResetCell: UITableViewCell {

    @IBOutlet weak var label_Title: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        label_Title.font = KS_LABEL_FONT_R
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }

    func configureCellTitle(titleString: String) {
        label_Title.text = titleString
    }
}
//MARK:- Switch type cell
class KSMemoryResetSwitchCell: UITableViewCell {
    @IBOutlet weak var label_Title: UILabel!
    @IBOutlet weak var switchOnOff: UISwitch!
    weak var delegate:KSMemoryResetDelegate?
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        label_Title.font = KS_LABEL_FONT_R
        switchOnOff.isOn = false
        self.tintColor = #colorLiteral(red: 0, green: 0.7005334496, blue: 0.723967135, alpha: 1)
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    func configureSwitchCellTitle(titleString: String) {
        label_Title.text = titleString
     }
    @IBAction func switchOnAndOffAction(_ sender: UISwitch) {
        DispatchQueue.main.async {
            self.delegate?.showConfirmationAlert(completionHandler: { [unowned self] (isSuccess) in
            sender.isOn = false
            if isSuccess {
                self.delegate?.showStatusAlert(alertTitle: ALERT_TITLE_STRING, message: MEMORYRESET_SUCCESS_ALERT)
            }
        })
        }
    }
}

extension KSMemoryResetFunction: KSMemoryResetDelegate {

    func showConfirmationAlert(completionHandler: @escaping (Bool) -> Void) {
        let alert = UIAlertController(title: "Confirmation", message: "Are you sure you want to clear past records?", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: { _ in
            //Cancel Action
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.0) {
                completionHandler(false)
            }
        }))
        alert.addAction(UIAlertAction(title: "Clear", style: UIAlertAction.Style.destructive, handler: {(_: UIAlertAction!) in
            self.showLoader()
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                completionHandler(true)
                self.hideLoader()
            }
        }))
        self.present(alert, animated: true, completion: nil)
    }

    func showStatusAlert(alertTitle: String, message: String) {
        self.presentAlert(withTitle: alertTitle, message: message)
    }
}
