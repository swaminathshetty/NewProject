//
//  KSCopyRightView.swift
//  KobelcoService
//
//  Created by Guest L&T on 22/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSCopyRightView: UIView {
    @IBOutlet weak var BGView: UIView!
    @IBOutlet weak var label_Copyright: UILabel!
    
    public func configureCopyrightLabel() {
        BGView.backgroundColor = #colorLiteral(red: 0.2, green: 0.2470588235, blue: 0.2823529412, alpha: 0.9020761987)
        label_Copyright?.backgroundColor = UIColor.clear
        label_Copyright?.textColor = .white
        label_Copyright?.adjustsFontSizeToFitWidth = true
        label_Copyright?.font = KS_COPYRIGHT_FONT_R
        label_Copyright?.textAlignment = .center
        label_Copyright?.text = COPYRIGHT_TEXT
        self.setViewFrame()
    }
    
    public func setViewFrame() {
        self.frame = CGRect(x: 0, y: UIScreen.main.bounds.size.height - 22, width: UIScreen.main.bounds.size.width, height: 22)
        BGView.translatesAutoresizingMaskIntoConstraints = false
    }
}
