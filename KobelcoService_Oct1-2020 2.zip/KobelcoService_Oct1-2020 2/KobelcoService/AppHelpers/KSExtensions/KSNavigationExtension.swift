//
//  KSNavigationExtension.swift
//  KobelcoService
//
//  Created by Guest L&T on 29/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
import UIKit

//MARK:- NavigationController extension for new extensions
extension UINavigationController {
    //get
    func getWiFiSettingsNavigationID() {
        let WiFiSettingsController = self.viewControllers
        KSSingletonManager.shared.WiFiSettingsNavigationID = WiFiSettingsController.count - 1
    }
    
    func getDashboardNavigationID() {
        let dashboardController = self.viewControllers
        KSSingletonManager.shared.dashboardNavigationID = dashboardController.count - 1
    }
    
    func popOverToDashboard(index: Int) {
        let dashboardController = self.viewControllers[index]
        self.popToViewController(dashboardController, animated: true)
    }
    func popOverToWiFiSettings(index: Int) {
        let WiFiSettingsController = self.viewControllers[index]
        WiFiSettingsController.navigationController?.isNavigationBarHidden = true
        self.popToViewController(WiFiSettingsController, animated: true)
    }
}
