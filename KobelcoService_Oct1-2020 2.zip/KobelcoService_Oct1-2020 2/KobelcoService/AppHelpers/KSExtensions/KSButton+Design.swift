//
//  KSButton+Design.swift
//  KobelcoService
//
//  Created by Guest L&T on 14/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
import UIKit

class KSCustomButton: UIButton {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpButton()
    }
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setUpButton()
    }
    func setUpButton() {
        testGradientButton()
        self.titleLabel?.font = KS_BUTTON_TITLE_R_FONT
        layer.shadowColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 0.2451305651)
        layer.borderWidth = 1.0
        layer.borderColor = #colorLiteral(red: 0, green: 0.5366052985, blue: 0.5635471344, alpha: 1)
        layer.cornerRadius =  20
        layer.shadowRadius = 4.0
        layer.shadowOpacity = 0.6
        clipsToBounds = true
        layer.masksToBounds = true
        self.layer.shadowOffset = CGSize(width: 0, height: 80)

    }
    @objc func testGradientButton() {
        let gradientLayer = CAGradientLayer()
        //gradientLayer.frame = self.bounds
        gradientLayer.frame = CGRect(x: 0, y: 0, width: 1000, height:  self.frame.height)
        let color1 = #colorLiteral(red: 0.3333333333, green: 0.7803921569, blue: 0.6980392157, alpha: 1)
        let color2 = #colorLiteral(red: 0.1843137255, green: 0.5882352941, blue: 0.6901960784, alpha: 1)
        gradientLayer.colors = [color1.cgColor, color2.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0.5, y: 0.0)
        gradientLayer.endPoint = CGPoint(x: 0.5, y: 1.0)
        gradientLayer.locations = [0.0, 1.0]
        self.layer.addSublayer(gradientLayer)
    }

}

//MARK:- White Gradient Button
class KSWhiteGradient: UIButton {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpButton()
    }
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setUpButton()
    }
    func setUpButton() {
        testGradientButton()
        self.titleLabel?.font = KS_BUTTON_TITLE_R_FONT
        layer.shadowColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 0.2451305651)
        layer.borderWidth = 1.0
        layer.borderColor = #colorLiteral(red: 0, green: 0.5366052985, blue: 0.5635471344, alpha: 1)
        layer.cornerRadius =  20
        layer.shadowRadius = 4.0
        layer.shadowOpacity = 0.6
        clipsToBounds = true
        layer.masksToBounds = true
        self.layer.shadowOffset = CGSize(width: 0, height: 80)
        self.bringSubviewToFront(self.imageView!)

    }
    func testGradientButton() {
        let gradientLayer = CAGradientLayer()
        //gradientLayer.frame = self.bounds
        gradientLayer.frame = CGRect(x: 0, y: 0, width: 1000, height:  self.frame.height)
        let color1 = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        let color2 = #colorLiteral(red: 0.862745098, green: 0.8666666667, blue: 0.8705882353, alpha: 1)
        gradientLayer.colors = [color1.cgColor, color2.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0.5, y: 0.0)
        gradientLayer.endPoint = CGPoint(x: 0.5, y: 1.0)
        gradientLayer.locations = [0.0, 1.0]
        self.layer.addSublayer(gradientLayer)
    }

}

//MARK:- Dashboard Buttons
class KSDashboardButton: UIButton {
    override init(frame: CGRect) {
        super.init(frame: frame)
        addCornorRadius()
    }
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        addCornorRadius()
    }
    fileprivate func addCornorRadius() {
        self.titleLabel?.font = KS_LABEL_FONT_M
        self.titleLabel?.numberOfLines = 0
        self.titleLabel?.lineBreakMode = .byWordWrapping
        self.titleLabel?.textAlignment = .center
        self.titleLabel?.textColor = #colorLiteral(red: 0, green: 0.7005334496, blue: 0.723967135, alpha: 1)
        layer.borderColor = #colorLiteral(red: 0, green: 0.5366052985, blue: 0.5635471344, alpha: 1)
        layer.cornerRadius = 6
        clipsToBounds = true
    }

}

extension UIButton {
    func addWhiteGradientColor() {
        addGradientButton()
        self.titleLabel?.font = KS_BUTTON_TITLE_R_FONT
        layer.shadowColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 0.2451305651)
        layer.borderWidth = 1.0
        layer.borderColor = #colorLiteral(red: 0, green: 0.5366052985, blue: 0.5635471344, alpha: 1)
        layer.cornerRadius =  20
        layer.shadowRadius = 4.0
        layer.shadowOpacity = 0.6
        clipsToBounds = true
        layer.masksToBounds = true
        self.layer.shadowOffset = CGSize(width: 0, height: 80)
        self.bringSubviewToFront(self.imageView!)

    }
    func addGradientButton() {
        let gradientLayer = CAGradientLayer()
        //gradientLayer.frame = self.bounds
        gradientLayer.frame = CGRect(x: 0, y: 0, width: self.frame.width, height:  self.frame.height)
        let color1 = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        let color2 = #colorLiteral(red: 0.862745098, green: 0.8666666667, blue: 0.8705882353, alpha: 1)
        gradientLayer.colors = [color1.cgColor, color2.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0.5, y: 0.0)
        gradientLayer.endPoint = CGPoint(x: 0.5, y: 1.0)
        gradientLayer.locations = [0.0, 1.0]
        self.layer.addSublayer(gradientLayer)
    }

}
