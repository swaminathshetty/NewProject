//
//  KSSocketCommands.swift
//  KobelcoService
//
//  Created by Guest L&T on 14/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation

/// Common websocket request for dashboard and error codes display screen.
struct SocketRequestDict: Codable {
    let screenName: String!
    let frameType: String!
    let device: String!
    let periodicity: Int!
}

/// Use this websocket model for status type response.
struct SocketStatusResponse: Codable {
    let screenName: String!
    let frameType: String!
    let status: String!
}
