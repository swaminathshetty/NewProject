//
//  KSIsCheckBoxSelectedModel.swift
//  KobelcoService
//
//  Created by Admin on 11/12/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation

struct KSIsCheckBoxSelectedModel: Codable {
    var name: String = ""
    var isSelected: Bool = false
    
    init(nameValue: String, isSelectedValue: Bool) {
        self.name = nameValue
        self.isSelected = isSelectedValue
    }
}
