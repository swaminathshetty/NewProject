//
//  KSConstants.swift
//  KobelcoService
//
//  Created by Guest L&T on 09/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
import UIKit
import EFAutoScrollLabel
// swiftlint:disable all

//MARK:- APP CONSTANTS
let MAINSCREENBOUNDS   = UIScreen.main.bounds
let SCREEN_WIDTH         = MAINSCREENBOUNDS.width
let SCREEN_HEIGHT        = MAINSCREENBOUNDS.height

let ISIPAD: Bool        = UIDevice.current.userInterfaceIdiom == .pad
let ISIPHONE: Bool      = UIDevice.current.userInterfaceIdiom == .phone

let ISIPHONE4ORLESS  = UIDevice.current.userInterfaceIdiom == .phone && MAINSCREENBOUNDS.height < 568.0
let ISIPHONE5          = UIDevice.current.userInterfaceIdiom == .phone && MAINSCREENBOUNDS.height == 568.0
let ISIPHONE6OR7        = UIDevice.current.userInterfaceIdiom == .phone && MAINSCREENBOUNDS.height == 667.0
let ISIPHONE6P7P      = UIDevice.current.userInterfaceIdiom == .phone && MAINSCREENBOUNDS.height == 736.0
let ISIPHONEX          = ISIPHONEXORXs ? ISIPHONEXORXs : ISIPHONEXrORXmax
let ISIPHONEXORXs    = fabs(Double(UIScreen.main.bounds.size.height) - Double(812)) < Double.ulpOfOne // 3x-2436,x,xs-812
let ISIPHONEXrORXmax = fabs(Double(UIScreen.main.bounds.size.height) - Double(896)) < Double.ulpOfOne //3x-2688-xmax-896,2x-1792-xr-896

let ISIPAD97          = UIDevice.current.userInterfaceIdiom == .pad && MAINSCREENBOUNDS.height == 1024.0
let ISIPADPRO          = UIDevice.current.userInterfaceIdiom == .pad && MAINSCREENBOUNDS.height == 1366.0

//let IS_IPAD_PORTRAIT = UIApplication.shared.statusBarOrientation == .portrait || UIApplication.shared.statusBarOrientation == .portraitUpsideDown

// Websocket IP Address
let WEBSOCKETIP = "10.9.40.186:8080" // Swami Machine IP Address
//let WEBSOCKETIP = "10.9.40.68:8080" // Rahul Machine IP Address
//let WEBSOCKETIP = "192.168.1.117:8080"  //192.168.1.100 //WFH

let appDelegate = UIApplication.shared.delegate as? AppDelegate

// STORYBOARD
let MAINSTORYBOARD = UIStoryboard.init(name: "Main", bundle: nil)
let CONFIGURATIONSTORYBOARD = UIStoryboard.init(name: "KSConfiguration", bundle: nil)

// USERDEFAULTS
let KSUSERDEFAULTS = UserDefaults.standard

/// CUSTOM UIBUTTON CODE
let KSBUTTONCORNERRADIUS = 6.0

/// COLOR LITERALS
let NAVIGATIONBARCOLOR = #colorLiteral(red: 0.007843137255, green: 0.4666666667, blue: 0.4901960784, alpha: 1)
let VIEWBACKGROUNDCOLOR = #colorLiteral(red: 0, green: 0.6470588235, blue: 0.6666666667, alpha: 1)
let COPYRIGHTBGCOLOR = #colorLiteral(red: 0.2, green: 0.2470588235, blue: 0.2823529412, alpha: 1)
let HEADERVIEWCOLOR = #colorLiteral(red: 0.2, green: 0.2470588235, blue: 0.2823529412, alpha: 1)
let TEXTFILEDTEXTCOLOR = #colorLiteral(red: 0.3215686275, green: 0.3215686275, blue: 0.3215686275, alpha: 1)
let TEXTFIELDBORDERCOLOR = #colorLiteral(red: 0.8509803922, green: 0.8509803922, blue: 0.8509803922, alpha: 1).cgColor
let TABLEVIEWLABELCOLOR = #colorLiteral(red: 0.9316138699, green: 0.8908390411, blue: 0.4764822346, alpha: 1)
let SEGMENTNORMALTINTCOLOR = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
let DISBALECOLOR = #colorLiteral(red: 0.3058823529, green: 0.6274509804, blue: 0.6431372549, alpha: 1)
let SEGMENTBGCOLOR = #colorLiteral(red: 0, green: 0.7019607843, blue: 0.7254901961, alpha: 1)

/// NAVIGATIONBAR ITEM IMAGES
let NAVIGATIONLEFTBARLOGO = UIImage.init(named: "kobelcoLogo")
let NAVIGATIONRIGHTBARLOGO = UIImage.init(named: "dashboardIcon")
let NAVIGATIONBACKICON = UIImage.init(named: "backIcon")
let NAVIGATIONDASHBOARDRIGHTBAR = UIImage.init(named: "wifiSettingIconDashboard")

/// STATIC JSON FILES
let MODELTYPEFILE = "KSModelTypes"
let ERRORCODESFILES = "KSErrorCodesJSON_V1.0"
let MATRIXDATAFILE = "CategoryWiseData"

// SCROLLABLE NAVIGATION TITLE
//let SCROLLLABEL = EFAutoScrollLabel(frame: CGRect(x: 0, y: 0, width: SCREEN_WIDTH - 100, height: 60))

/// LOGIN LOCALIZATION ALERT MESSAGES
let INVALIDUSER = NSLocalizedString("InValidUser", comment: "")
let INVALIDCREDENTIALS = NSLocalizedString("InValidCredentails", comment: "")
let INVALIDUSERNAME = NSLocalizedString("InValidUserName", comment: "")
let INVALIDPASSWORD = NSLocalizedString("InValidPassword", comment: "")

/// LOCATION ACCESS ALERT
let LOCATIONTITLE = NSLocalizedString("LocationAccessTitle", comment: "")
let LOCATIONACCESSMESSAGE = NSLocalizedString("LocationAccessAlert", comment: "")

/// MODELTYPE LOCALIZATION ALERT MESSAGE
let SELECTMODELTYPE = NSLocalizedString("ModelTypeValidation", comment: "")
let SELECTAREA = NSLocalizedString("AreaValidation", comment: "")

/// QRCODE SCREEN LOCALIZATION
let QRHEADERTITLE = NSLocalizedString("QRTitle", comment: "")
let QRBODYTEXT = NSLocalizedString("QRMessage", comment: "")

/// DATAMONITOR  LOCALIZATION
let NODATAAVAILABLE = NSLocalizedString("NoDataAvailableText", comment: "")

// ALERT TITLE//
let ALERTTITLESTRING = NSLocalizedString("MessageText", comment: "")
let ERRORINRESPONSETITLE = NSLocalizedString("ErrorInResponseText", comment: "")
let ERRORTITLE = NSLocalizedString("ErrorText", comment: "")
let CONFIRMATIONTITLE = NSLocalizedString("ConfirmationText", comment: "")
let INFORMATIONTITLE = NSLocalizedString("InformationText", comment: "")
let CANCELTITLE = NSLocalizedString("CancelText", comment: "")
let SAVETITLE = NSLocalizedString("SaveText", comment: "")
let YESTITLE = NSLocalizedString("YesText", comment: "")
let NOTITLE = NSLocalizedString("NoText", comment: "")
let CLEARTITLE = NSLocalizedString("ClearText", comment: "")
let OKTITLE = NSLocalizedString("OkText", comment: "")
let LOADINGTITLE = NSLocalizedString("LoadingText", comment: "")
let CHOOSEANYOPTIONTITLE = NSLocalizedString("ChooseOptionTitle", comment: "")

/// ALERT MESSAGES
let LOGINSUCCESS = "You are successfully logged in as:"
let DASHBOARDWIFIDISCONNECT = NSLocalizedString("DashboardDisconnect", comment: "")
let MRCONFIRMATIONALERT = NSLocalizedString("MRConfirmationAlert", comment: "")
let MEMORYRESETSUCCESSALERT = NSLocalizedString("MRSuccessAlert", comment: "")
let MEMORYRESETMESSAGE = NSLocalizedString("MRSubResetAlert", comment: "")
let MEMORYRESETFAILALERT = NSLocalizedString("MRFailAlert", comment: "")
let COPYRIGHTTEXT = "Copyright© 2021 Kobelco Construction Machinery Co., Ltd."
let NOINTERNETMESSAGE = NSLocalizedString("NoInternetAlert", comment: "")
let WIFIDISCONNECTEDMESSAGE = NSLocalizedString("WiFiDisconnectedAlert", comment: "")
let QRCODECONFIRMATION = NSLocalizedString("QRCodeConfirmationAlert", comment: "")
let QRCODEERRORTITLE = NSLocalizedString("QRCodeErrorTitle", comment: "")
let QRCODEERRORMESSAGE = NSLocalizedString("QRCodeErrorAlert", comment: "")
let QRCODEMESSAGE = NSLocalizedString("QRCodeAccessAlert", comment: "")
let QRCODESUCESSMESSAGE = NSLocalizedString("QRCodeSuccessAlert", comment: "")
let QRCODEFAILMESSAGE = NSLocalizedString("QRCodeFailAlert", comment: "")
let ERRORINRESPONSE = NSLocalizedString("ErrorInResponseMessage", comment: "")
let DELETEALERT = NSLocalizedString("DeleteAlertText", comment: "")
let DATAMONITORSTOPVALIDATION = NSLocalizedString("DualOperationAlert", comment: "")
let NAMEEXISTMESSAGE = NSLocalizedString("AlreadyNameExists", comment: "")
//
let SCANVALIDQRCODE = NSLocalizedString("ScanValidQRCodeAlert", comment: "")
let ENTERVALIDQRCODE = NSLocalizedString("EnterValidQRCodeAlert", comment: "")
let DONEVALIDQRCODE = NSLocalizedString("DoneQRCodeFailAlert", comment: "")
let DIAGNOSTIC0STATUSALERT = NSLocalizedString("DiagnosticStatu0Alert", comment: "")
let DIAGNOSTIC2STATUSALERT = NSLocalizedString("DiagnosticStatus2Alert", comment: "")
let DOAGNOSTICERRORFORWRITE = NSLocalizedString("DiagnosticWriteErrorAlert", comment: "")
let TEXTFIELDINVALIDENTRY = NSLocalizedString("DiagnosticTextFieldInValidAlert", comment: "")
let DATAMONITORSTARTERROR = NSLocalizedString("DataMonitorStartErrorAlert", comment: "")
let DIAGNOSTICWRITEALERT = NSLocalizedString("DiagnosticWriteBeforeStart", comment: "")

/// WEBSOCKET ALERT MESSAGES
let SOCKETRECONNECT = NSLocalizedString("SocketReconnectAlert", comment: "")
let SOCKETRESPONSETIMEOUT = NSLocalizedString("SocketResponseTimeOutAlert", comment: "")

/// DATAMONITOR SCREEN ACTIONSHEET ITEMS
let ACTIONSHEETITEMS = [NSLocalizedString("SaveText", comment: ""),
                        NSLocalizedString("DeleteText", comment: ""),
                        NSLocalizedString("SendAndSave", comment: ""),
                        NSLocalizedString("SendAndDelete", comment: "")]

/// CONFIGURATION SCREEN MENU ITMES
let CONFIGURATIONLIST = [NSLocalizedString("LanguageSettings", comment: ""),
                         NSLocalizedString("UnitConversion", comment: ""),
                         NSLocalizedString("NormalDataManagement", comment: ""),
                         NSLocalizedString("LogDataManagement", comment: ""),
                         NSLocalizedString("ParameterRegistration", comment: ""),
                         NSLocalizedString("SimulationMode", comment: "")]

/// NORMAL DATA SCREEN MENU ITEMS
let NORMALDATA_LIST = ["Normal Data Acquisition", "Normal Data Editing"]

/// COREDATA FILES
let SOCKETCOMMANDS_JSON = "KSWebSocketCommands"
let KSFILTYPE = "json"

/// Library Folder Name
let DataMonitorLogDataFolder = "KSDataMonitorLogDataFolder"
let ParameterRegistrationFolder = "KSParameterRegistrationFolder"
let ParameterRegistrationFile = "KSParameterRegistrationFile"
