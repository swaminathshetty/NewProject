//
//  KSTextFileString.swift
//  KobelcoService
//
//  Created by Guest L&T on 25/11/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
import UIKit

class KSTextFileString {
    // Merge all required parameters and creat final datamonitor graph json object.
    static func createDataMonitorGraphJSON(timeStamp: String) -> [String: Any] {
        var logDataDict = [String: Any]()
        logDataDict["Application_Unit"] = KSSingletonManager.shared.applicationUnit
        logDataDict["PartsNo"] = KSSingletonManager.shared.partNumber
        logDataDict["Date"] = timeStamp
        logDataDict["Sample_Period"] = "50"
        logDataDict["TriggerA"] = ""
        logDataDict["TriggerB"] = ""
        logDataDict["TriggerCombine"] = ""
        logDataDict["data"] = KSSingletonManager.shared.dataMonitorJSONArray
        return logDataDict
    }
    // Convert json to textfile format.
    static func getTextFileString(readValues: [[Int]], timeInterval: Int) -> String {
        let currentTimeStamp = KSSingletonManager.shared.getCurrentTimeStamp(format: "yyyy-MM-dd HH:mm:ss")
        // Append double quotes to each string in an array and join comma seperated.
        let textFilesignals = KSSingletonManager.shared.dataMonitorJSONArray.map({ "\("\"")\($0["signalName"] ?? "")\("\"")" }).joined(separator: ",")
        let textFileIds = (KSSingletonManager.shared.dataMonitorJSONArray.map { "\($0["signalId"] ?? "")" }).joined(separator: ",")
        var textFileValues = ""
        for (index, valuesArray) in readValues.enumerated() {
            let textValues = (valuesArray.map {String($0)}).joined(separator: ",")
            textFileValues = "\(textFileValues) \n \(index)=\(textValues)"
        }
        let logDataText = """
        [INF] \n Application_Unit=\(KSSingletonManager.shared.applicationUnit) \n PartsNo=\(KSSingletonManager.shared.partNumber) \n Date=\(currentTimeStamp) \n Sample_Period=\(timeInterval) \n TriggerA=\("") \n TriggerB=\("") \n TriggerCombine= \n\n [Data] \n Signal=\(textFilesignals) \n Pid_id=\(textFileIds) \(textFileValues)
        """
        return logDataText
    }
    
    // Used to save json object into local library using filemanager.
    static func saveJSONDataToLibrary(viewController: UIViewController, fileName: String, jsonDict: [String: Any]) {
        if let folderURl = self.getLogDataFilesLibraryDirectoryPath(path: DataMonitorLogDataFolder) {
            let fileURL = folderURl.appendingPathComponent(fileName + ".json")
            do {
                if let theJSONData = try? JSONSerialization.data(withJSONObject: jsonDict, options: []) {
                    try theJSONData.write(to: fileURL)
                }
            } catch {
                print("Failed to create json file")
            }

            viewController.hideLoader()
        }
    }
    
    // Used to write text into textfile and save it into local directory for textfile upload.
    static func writeJSONDataToTextfile(viewController: UIViewController, valuesArray: [[Int]], fileName: String, interval: Int) {
        // Create text file format data and store into a string.
        let writeText = KSTextFileString.getTextFileString(readValues: valuesArray, timeInterval: interval)
        // Convert string to data format.
        let textData = writeText.data(using: .utf8)
        // Get local document directory path and append filename.
        let filename = "\(KSTextFileString.getDocumentsDirectory())/\(fileName).txt"
        // Create url for saving textfile.
        let fileURL = URL(fileURLWithPath: filename)
        print("Write fileURL: \(fileURL)")
        do {
            // Write converted textdata to local document directory.
            try textData?.write(to: fileURL)
            // Make the activityViewController which shows the share-view
            let activityViewController = UIActivityViewController(activityItems: [fileURL], applicationActivities: nil)
            // Exclude other application types
            activityViewController.excludedActivityTypes = [.airDrop,
                                                            .addToReadingList,
                                                            .assignToContact,
                                                            .copyToPasteboard,
                                                            .markupAsPDF,
                                                            .message,
                                                            .openInIBooks,
                                                            .postToFacebook,
                                                            .postToFlickr,
                                                            .postToTwitter,
                                                            .postToVimeo,
                                                            .postToWeibo,
                                                            .saveToCameraRoll,
                                                            .print,
                                                            .init(rawValue: "com.apple.reminders.RemindersEditorExtension"),
                                                            .init(rawValue: "com.apple.reminders.sharingextension"),
                                                            .init(rawValue: "com.apple.mobilenotes.SharingExtension"),
                                                            .init(rawValue: "com.apple.reminders.reminderseditorextension"),
                                                            .init(rawValue: "com.apple.mobilenotes.sharingextension"),
                                                            .init(rawValue: "com.google.Drive.ShareExtension"),
                                                            .init(rawValue: "com.apple.iCloudDrive.ShareExtension"),
                                                            .init(rawValue: "com.apple.CloudDocsUI.AddToiCloudDrive")]
            // So that iPads won't crash
            activityViewController.popoverPresentationController?.sourceView = viewController.view
            // Show the share-view
            viewController.present(activityViewController, animated: true, completion: nil)
            viewController.hideLoader()
        } catch { print("Failed to share textfile")
            viewController.hideLoader()
        }
    }
    // Used to get local document directory path.
    static func getDocumentsDirectory() -> String {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentsDirectory = paths[0]
        return documentsDirectory
    }
    // Clear all document directory log textfiles.
    static func clearDiskCache() {
        let fileManager = FileManager.default
        let myDocuments = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!
        guard let filePaths = try? fileManager.contentsOfDirectory(at: myDocuments, includingPropertiesForKeys: nil, options: []) else { return }
        for filePath in filePaths {
            try? fileManager.removeItem(at: filePath)
            print("remove files from filepath")
        }
    }
    // Create folder in Library Folder pass folder name
    static func getLogDataFilesLibraryDirectoryPath(path: String) -> URL? {
        let fileManager = FileManager.default
        guard let documentsFolder = try? fileManager.url(for: .libraryDirectory, in: .userDomainMask, appropriateFor: nil, create: false) else { return nil}
        let folderURl = documentsFolder.appendingPathComponent(path)
        let folderExists = (try? folderURl.checkResourceIsReachable()) ?? false
        do {
            if !folderExists {
                try fileManager.createDirectory(at: folderURl, withIntermediateDirectories: false)
            }
        } catch {
            print("Failed to create directory")
            return nil
        }
        
        return folderURl
    }
}
