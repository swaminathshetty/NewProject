//
//  KSExtensions.swift
//  KobelcoService
//
//  Created by Guest L&T on 09/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
import UIKit

// Set RGB Colorcodes.
extension UIColor {
    convenience init(red: Int, green: Int, blue: Int) {
        assert(red >= 0 && red <= 255, "Invalid red component")
        assert(green >= 0 && green <= 255, "Invalid green component")
        assert(blue >= 0 && blue <= 255, "Invalid blue component")

        self.init(red: CGFloat(red) / 255.0, green: CGFloat(green) / 255.0, blue: CGFloat(blue) / 255.0, alpha: 1.0)
    }
    convenience init(rgb: Int) {
        self.init(
            red: (rgb >> 16) & 0xFF,
            green: (rgb >> 8) & 0xFF,
            blue: rgb & 0xFF
        )
    }
    
    static func random() -> UIColor {
       return UIColor.rgb(CGFloat.random(in: 0..<256), green: CGFloat.random(in: 0..<256), blue: CGFloat.random(in: 0..<256))
    }

    static func rgb(_ red: CGFloat, green: CGFloat, blue: CGFloat) -> UIColor {
     return UIColor(red: red/255, green: green/255, blue: blue/255, alpha: 1)
    }
    
    static func colorFromHexString(_ hexCode: String!) -> UIColor {
        let scanner = Scanner(string: hexCode)
        scanner.charactersToBeSkipped = CharacterSet(charactersIn: "$+#")
        var hex: CUnsignedLongLong = 0
        if !scanner.scanHexInt64(&hex) {
            return UIColor()
        }
        let r = (hex >> 16) & 0xFF
        let g = (hex >> 8) & 0xFF
        let b = (hex) & 0xFF
        return UIColor.init(red: CGFloat(r) / 255.0, green: CGFloat(g) / 255.0, blue: CGFloat(b) / 255.0, alpha: 1)
    }
    
    var htmlRGBaColor: String {
        return String(format: "#%02x%02x%02x%02x", Int(rgbComponents.red * 255), Int(rgbComponents.green * 255), Int(rgbComponents.blue * 255), Int(rgbComponents.alpha * 255) )
    }
    
    var rgbComponents:(red: CGFloat, green: CGFloat, blue: CGFloat, alpha: CGFloat) {
        var r: CGFloat = 0
        var g: CGFloat = 0
        var b: CGFloat = 0
        var a: CGFloat = 0
        if getRed(&r, green: &g, blue: &b, alpha: &a) {
            return (r, g, b, a)
        }
        return (0, 0, 0, 0)
    }
}
// Hexadecimal conversion.
extension Data {
    var hexString: String {
        let hexString = map { String(format: "%02.2hhx", $0) }.joined()
        return hexString
    }
}

// UITextField Left & Right Padding.
extension UITextField {
    func setCustomTextFieldStyle(imageNameString: String = "") {
        self.setLeftPaddingPoints(20)
        self.layer.cornerRadius = CGFloat(22)
        self.layer.borderWidth = 1.5
        self.layer.borderColor = TEXTFIELDBORDERCOLOR
        self.textColor = TEXTFILEDTEXTCOLOR
        self.font = UIFont.regular(ofSize: 17)
        self.clipsToBounds = true
        self.setDropdownIconToTextfieldRightView(imageName: imageNameString)
    }
    // Used to add leftpadding to the textfield.
    func setLeftPaddingPoints(_ amount: CGFloat) {
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.leftView = paddingView
        self.leftViewMode = .always
    }
    // Used to add rightpadding to the textfield.
    func setRightPaddingPoints(_ amount: CGFloat) {
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.rightView = paddingView
        self.rightViewMode = .always
    }
    // Used to add left Padding with dropdown.
    func setDropdownIconToTextfieldRightView(imageName: String) {
         let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 50, height: self.frame.size.height))
         paddingView.backgroundColor = .clear
         let imgView = UIImageView(frame: CGRect(x: 25, y: 20, width: 12, height: 8))
         imgView.image = UIImage(named: imageName)
         imgView.isUserInteractionEnabled = true
         paddingView.addSubview(imgView)
         self.rightViewMode = .always
         self.rightView = paddingView
     }
}

// MARK: UIButton Corner Radius.
extension UIButton {
    // Set title with deafult corner radius.
    func setButtonCornerRadius(text: String, image: String) {
        self.titleLabel?.font = UIFont.regular(ofSize: 17)
        self.setTitle(text, for: .normal)
        commonButtonCodes(radius: 20, width: 1, buttonColor: #colorLiteral(red: 0, green: 0.6470588235, blue: 0.6666666667, alpha: 1))
    }
    // Custom cornor-radius, border-width and botder-color.
    func addButtonCornerRadius(cornerRadius: Float, borderWidth: Float, buttonBorderColor: UIColor, backgroundColor: UIColor, textColor: UIColor) {
        self.titleLabel?.font = UIFont.medium(ofSize: 15)
        self.backgroundColor = backgroundColor
        self.setTitleColor(textColor, for: .normal)
        commonButtonCodes(radius: cornerRadius, width: borderWidth, buttonColor: buttonBorderColor)
    }
    // Reusable code for cutsom button.
    func commonButtonCodes(radius: Float, width: Float, buttonColor: UIColor) {
        self.layer.cornerRadius = CGFloat(radius)
        self.layer.borderWidth = CGFloat(width)
        self.layer.borderColor = buttonColor.cgColor
    }
    // Resetting button style and color code to normal for error code display screen.
    func setPlainStyle() {
        self.setTitleColor(#colorLiteral(red: 0, green: 0.7005334496, blue: 0.723967135, alpha: 1), for: .normal)
        self.backgroundColor = .clear
        self.layer.borderWidth = 0
    }
    // Set custom gradientcolor to button background.
    func applyGradientColorToButton(topColor: UIColor, bottomColor: UIColor) {
        let gradientLayer = CAGradientLayer()// Class used to apply gradient color
        gradientLayer.frame = CGRect(x: 0, y: 0, width: 1000, height: self.frame.height)
        gradientLayer.colors = [topColor.cgColor, bottomColor.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0.5, y: 0.0)
        gradientLayer.endPoint = CGPoint(x: 0.5, y: 1.0)
        gradientLayer.locations = [0.0, 1.0]
        self.layer.addSublayer(gradientLayer)

        self.titleLabel?.font = UIFont.regular(ofSize: 17)
        self.titleLabel?.textColor = .white
        layer.shadowColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 0.2451305651)
        layer.borderWidth = 1.0
        layer.borderColor = #colorLiteral(red: 0, green: 0.5366052985, blue: 0.5635471344, alpha: 1)
        layer.cornerRadius =  20
        layer.shadowRadius = 4.0
        layer.shadowOpacity = 0.6
        clipsToBounds = true
        layer.masksToBounds = true
        self.layer.shadowOffset = CGSize(width: 0, height: 80)
        self.bringSubviewToFront(self.titleLabel!)
    }
}

// UITextField Check empty or not.
extension UITextField {
    var isEmpty: Bool {
        return text?.isEmpty ?? true
    }
}

// Checking white spaces.
extension String {
    var containsWhitespace: Bool {
        return(self.rangeOfCharacter(from: .whitespacesAndNewlines) != nil)
    }
    // Removes White spaces.
    func removingWhitespaces() -> String {
        return components(separatedBy: .whitespaces).joined()
    }
    // Safety limit for textfield length.
    func safelyLimitedTo(totalNumber: Int) -> String {
        if self.count <= totalNumber {
            return self
        }
        return String( Array(self).prefix(upTo: totalNumber) )
    }
}

// Custom segment control tint colors.
extension UISegmentedControl {
    // Set selected and normal tint colors.
    func setSegmentTintColors() {
        self.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: SEGMENTNORMALTINTCOLOR], for: .selected)
        self.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: SEGMENTNORMALTINTCOLOR], for: .normal)
        self.tintColor = SEGMENTBGCOLOR
        //self.layer.borderWidth = 0.6
        //self.layer.borderColor = #colorLiteral(red: 0, green: 0.5366052985, blue: 0.5635471344, alpha: 1).cgColor
    }
}
// Set Text Field Length.
private var maxLengths = [UITextField: Int]()
extension UITextField {
    @IBInspectable var maxLength: Int {
        get {
            guard let value = maxLengths[self] else {
                return 150 // (global default-limit. or just, Int.max)
            }
            return value
        }
        set {
            maxLengths[self] = newValue
            addTarget(self, action: #selector(fix), for: .editingChanged)
        }
    }
    @objc func fix(textField: UITextField) {
        let textFieldLength = textField.text
        textField.text = textFieldLength?.safelyLimitedTo(totalNumber: maxLength)
    }
}

// Used to Convert websocket json string response to dictionary format.
func convertToDictionary(text: String) -> [String: Any]? {
    if let data = text.data(using: .utf8) {
        do {
            return try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
        } catch {
            //print(error.localizedDescription)
        }
    }
    return nil
}
extension UIApplication {
   var statusBarView: UIView? {
      return value(forKey: "statusBarWindow.statusBar") as? UIView
    }
}

extension UIView {
    func addShadowToView() {
        let viewShadowPath = UIBezierPath.init(rect: self.bounds)
        self.layer.masksToBounds = false
        self.layer.shadowColor = UIColor.darkGray.cgColor
        self.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
        self.layer.shadowOpacity = 0.3
        self.layer.shadowPath = viewShadowPath.cgPath
    }
}
// Used to milliseconds to seconds conversion
extension Int {
    var msToSeconds: Double { Double(self) / 1000 }
}

// Used to rotate the label
extension UILabel {
    func rotate(degrees: Int, clockwise: Bool) {
        let x  = 180 / degrees
        if clockwise {
            self.transform = CGAffineTransform(rotationAngle: CGFloat.pi / CGFloat(x))
        } else {
            self.transform = CGAffineTransform(rotationAngle: -CGFloat.pi / CGFloat(x))
        }
    }
}
