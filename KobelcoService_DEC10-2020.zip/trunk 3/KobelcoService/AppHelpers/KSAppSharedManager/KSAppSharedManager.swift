//
//  KSAppSharedManager.swift
//  KobelcoService
//
//  Created by Guest L&T on 11/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
import Starscream
import UIKit

// Websocket delegates for passing response.
@objc protocol KSWebSocketDelegates: class {
    @objc optional func webSocketStringResponse(response: String)
    @objc optional func stopActivityIndicator()
    @objc optional func showDataMonitorActionSheet()
    @objc optional func reloadMonitorSubTableView()
    @objc optional func sendMonitorStopSocketRequest()
    @objc optional func createDictionaryForGraphDataDelegate()

    func webSocketErrorConnection(message: String)
    func internetConnectionNotAvailable()
    func noWebSocketResponse(message: String)
}

class KSSingletonManager {
    static let shared = KSSingletonManager()
    private init() { }
    
    var diagnosticNavigationTitle = "" // Used to pass diagnostic selected tableview index title
    var currentScreenName = "" // Used to identify current screen title.
    var connectNavigationID = 0 // setting deafult navigation index value to connect screen
    var wifiSettingsNavigationID = 1 // Setting default navigation index value to WIFI screen
    var dashboardNavigationID = 3 // Setting initial default navigation index value to identify dashboard screen
    var errorCodeNavigationID = 3 // Setting initial default navigation index value to identify errorcode screen
    var memoryResetMainScreenID = 3 // Setting initial default navigation index value to identify memory reset main screen
    var setValueFunctionID = 3 // Setting initial default navigation index value to identify set value writing function screen
    var diagnosticMainScreenID = 3 // Setting initial default navigation index value to identify diagnostic function screen
    var diagnosticSubScreenID = 3 // Setting initial default navigation index value to identify diagnostic function screen
    var dataMonitorNavigationID = 3 // Setting initial default navigation index value to identify dataMonitor screen
    var configurationNavigationID = 3 // Setting initial default navigation index value to identify configuration screen
    var dataComparisionID = 3 // Setting initial default navigation index value to identify dataComparision screen
    
    // Application unit & part number
    var applicationUnit = ""
    var partNumber = ""
        
    // Diagnostic Function global variables.
    var isDiagnsoticStart = false
    var diagnosticMainID = ""
    var explanationDiagnostic = ""
    var attentionDiagnostic = ""
    var diagnosticSubMenuArray = [[String: Any]]()
    var diagnosticMenuType = "ReadOnly"
    
    // Data Monitor global variables.
    var isDataMonitorStart = false
    var dataMonitorSubMenu = [[String: Any]]()
    var addDataMonitorSubMenu = [[String: Any]]()
    var dataMonitorReadValues = [Int]()
    var dataMonitorReadIDs = [String]()
    var dataMonitorJSONArray = [[String: Any]]()
    var textFileReadValues = [[Int]]()
    var isDataMonitorType1 = true

    var toastController: UIAlertController? // Used to display navigation title on popup.
    var isOfflineConnection: Bool = false // Used to identify the application in offline or online mode
    var modelTypeDefaults = UserDefaults() // Used to set/get model type matrix static json
    var modelTypeSelection = "" // Used to assign machine selection
    var modelTypeName = "" // Used to assign unique machine/modeltype name
    var matrixObject = [String: Any]() // Used to set machine selected matrxi object.

    // Websocket references
    weak var delegate: KSWebSocketDelegates?
    fileprivate var socket: WebSocket!
    var isWebSocketConnected: Bool = false
    fileprivate var socketConnectionTimer: Timer?
    fileprivate var socketRequestTimer: Timer?
    var languageCode = "en"
    var tempIPAddress = ""

    // Goto iPhone wifi settings.
    class func openWifiSettings() {
        let shared = UIApplication.shared
        if let url = URL(string: UIApplication.openSettingsURLString) {
            if #available(iOS 10.0, *) {
                shared.open(url)
            } else {
                shared.openURL(url)
            }
        }
    }
    
    // Load local static json file
    func loadJson(filename fileName: String, completionHandler: @escaping (Data) -> Void) {
        if let url = Bundle.main.url(forResource: fileName, withExtension: "json") {
            do {
                let dataFormat = try Data(contentsOf: url)
                completionHandler(dataFormat)
            } catch let error as NSError {
                print(error.localizedDescription)
            }
        }
    }
    // Load json file form URL
    func loadJsonFileFromURL(filename fileURL: NSURL, completionHandler: @escaping (Data) -> Void) {
        do {
            let dataFormat = try Data(contentsOf: fileURL as URL)
            completionHandler(dataFormat)
        } catch let error as NSError {
            print(error.localizedDescription)
        }
    }
    // Called for null response and place no records text to tableview background.
    func nullDataFilesLabel(message: String) -> UILabel {
        let noDataLabel = UILabel()
        noDataLabel.text = message // Displays this text when tableview list is empty
        noDataLabel.textColor = TABLEVIEWLABELCOLOR
        noDataLabel.font = UIFont.medium(ofSize: 18)
        noDataLabel.textAlignment = .center
        noDataLabel.lineBreakMode = .byWordWrapping
        noDataLabel.numberOfLines = 0
        return noDataLabel
    }
    
    /// Network Handler function
    func networkHandler() {
        appDelegate?.networkCompletionHandler = { (networkStatus, isWifiMode) in
            if networkStatus == false || isWifiMode == false {
                print("Not WiFiMode")
                self.delegate?.internetConnectionNotAvailable()
            }
        }
    }
    // MARK: Connect WebSocket
    func connectWebSocket() {
        if appDelegate!.networkAvailability {
            socketConnectionTimer = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(checkWebSocketConnection), userInfo: nil, repeats: false)
            print("connectWebSocket")//ws:localhost:8080/
            //Swami
            //let websocketURL = URL(string: "ws://\(WEBSOCKETIP)/")!
            let websocketURL = URL(string: "ws://\(KSSingletonManager.shared.tempIPAddress):8080/")!
            var request = URLRequest(url: websocketURL)
            request.timeoutInterval = 5
            socket = WebSocket(request: request)
            socket.delegate = self
            socket.connect()
        } else {
            delegate?.internetConnectionNotAvailable()
        }
    }
    // Invalidate the socket timer if webscoket communication established successfully.
    @objc func checkWebSocketConnection() {
        print("checkWebSocketConnection")
        self.invalidateAllTimers()
        if !isWebSocketConnected {
            delegate?.internetConnectionNotAvailable()
        }
    }
    // Invalidate all the assigned timers.
    func invalidateAllTimers() {
        socketConnectionTimer?.invalidate()
        socketConnectionTimer = nil
        socketRequestTimer?.invalidate()
        socketRequestTimer = nil
    }
    // Invalidate socket request timer when there is no reponse from websocket after 5 seconds.
    // Invalidate the socket timer if webscoket communication established successfully.
    @objc func checkWebSocketResponseTimeOut() {
        self.isWebSocketConnected = false
        self.invalidateAllTimers()
        self.delegate?.noWebSocketResponse(message: SOCKETRESPONSETIMEOUT)
    }
    // Disconnect WebSocket
    func disconnectWebSocket() {
        print("disconnectWebSocket")
        if isWebSocketConnected {
            socket.disconnect()
            //socket.disconnect(closeCode: CloseCode.normal.rawValue)
        }
    }
    
    // Send WebSocket JSON object Command
    func sendCommand(format requestData: Data) {
        if isWebSocketConnected {
            socketRequestTimer = Timer.scheduledTimer(timeInterval: 6.0, target: self, selector: #selector(checkWebSocketResponseTimeOut), userInfo: nil, repeats: false)
            guard let jsonString =  String(data: requestData, encoding: String.Encoding.utf8) else { return }
            print("Request jsonString: \(jsonString)")
            socket.write(string: jsonString)
        } else {
            print("Calling webSocketErrorConnection")
            delegate?.webSocketErrorConnection(message: SOCKETRECONNECT)
        }
    }
    class func convertJSONStringToDictionary(jsonString: String, completionHandler: @escaping ([String: Any]) -> Void) {
        var dictonary: [String: Any]?
        if let data = jsonString.data(using: String.Encoding.utf8) {
            do {
                dictonary = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
                if let responseDictionary = dictonary {
                    completionHandler(responseDictionary)
                }
            } catch let error as NSError {
                print(error.localizedDescription)
            }
        }
    }
    // Condition check for websocket response.
    func getWebSocketResponse(responseString: String) {
        print("getWebSocketResponse: \(responseString)")
        guard let jsonDictionary = convertToDictionary(text: responseString) else { return }
        guard let screenTitle = jsonDictionary["screenName"] as? String else { return }
        if screenTitle == "DataMonitor" {
            self.dataMonitorWebSocketResponse(response: responseString, responseDictionary: jsonDictionary)
        } else {
            self.delegate?.webSocketStringResponse?(response: responseString)
        }
    }
    // Handle datamonitor websocket response and do manipulations.
    private func dataMonitorWebSocketResponse(response: String, responseDictionary: [String: Any]) {
        let resposneKeys = responseDictionary.keys
        // Condition check for 2 type responses. If response contains status key show success or failure message.
        if resposneKeys.contains("status") {
            guard let diagnosticStopStatus = responseDictionary["status"] as? Int else { return }
            if diagnosticStopStatus != 1 {
                //self.startPlotGraphbutton.setTitle("Stop", for: .normal)// NC
                KSSingletonManager.shared.isDataMonitorStart = true
            } else {
                KSSingletonManager.shared.isDataMonitorStart = false
                delegate?.showDataMonitorActionSheet?()
            }
        } else {
            // Read values from the websocket response and update to tableview.
            guard let readSignalValues = responseDictionary["values"] as? [Int] else { return }
            guard let readSignalIDs = responseDictionary["itemNames"] as? [String] else { return }
            DispatchQueue.main.async {
                if readSignalValues.count == KSSingletonManager.shared.dataMonitorReadValues.count && readSignalIDs.count == KSSingletonManager.shared.dataMonitorReadValues.count {
                    for (index, item) in readSignalIDs.enumerated() {
                        print("item: \(item)")
                        print("value: \(readSignalValues[index])")
                        if KSSingletonManager.shared.dataMonitorReadIDs.contains(item) {
                            KSSingletonManager.shared.dataMonitorReadValues[index] = readSignalValues[index]
                        }
                    }
                    KSSingletonManager.shared.textFileReadValues.append(KSSingletonManager.shared.dataMonitorReadValues)
                    self.appendWebSocketValuesToGraphJSON()
                    self.delegate?.reloadMonitorSubTableView?()
                    return
                } else {
                    self.delegate?.sendMonitorStopSocketRequest?()
                    return
                }
            }
        }
    }
    // Append values to plot graph JSON array.
    func appendWebSocketValuesToGraphJSON() {
        self.commonForLoopToGetGraphDict { (index, setGraphDict) in
            KSSingletonManager.shared.dataMonitorJSONArray[index] = setGraphDict
            self.delegate?.createDictionaryForGraphDataDelegate?()
        }
    }
    // Reusable function to get JSON graph dictionary.
    func commonForLoopToGetGraphDict(completionHandler: @escaping (Int, [String: Any]) -> Void) {
        for (index, monitorItemDict) in KSSingletonManager.shared.dataMonitorJSONArray.enumerated() {
            var getMonitorDict = monitorItemDict
            guard var getValuesArray = getMonitorDict["signalValues"] as? [Int] else { return }
            getValuesArray.append(KSSingletonManager.shared.dataMonitorReadValues[index])
            getMonitorDict["signalValues"] = getValuesArray
            completionHandler(index, getMonitorDict)
        }
    }
    // Convert date to string format.
    func getCurrentTimeStamp(format: String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        let timeStamp = dateFormatter.string(from: Date())
        return timeStamp
    }
    // Clear all datamonitor arrays data before navigating to other screens.
    func clearDataMonitorGlobalArrayReadings() {
        KSSingletonManager.shared.dataMonitorSubMenu.removeAll(keepingCapacity: false)
        KSSingletonManager.shared.dataMonitorReadIDs.removeAll(keepingCapacity: false)
        KSSingletonManager.shared.dataMonitorReadValues.removeAll(keepingCapacity: false)
    }
}

// WebSocket callback delegate
extension KSSingletonManager: WebSocketDelegate {
    func didReceive(event: WebSocketEvent, client: WebSocket) {
        websocketEventCallback(eventCallback: event)
    }
    
    // WebSocket callback event handler.
    func websocketEventCallback(eventCallback: WebSocketEvent) {
        isWebSocketConnected = false
        switch eventCallback {
        case .connected(let headers):
            print("connected:")
            _ =  headers
            //print("headers: \(headers)")
            isWebSocketConnected = true
            checkWebSocketConnection()
            //self.getWebSocketResponse(responseString: "Connection Opened")
            self.delegate?.webSocketStringResponse!(response: "Connection Opened")
        case .disconnected(let reason, let code):
            _ = (reason, code)
        case .text(let string):
            isWebSocketConnected = true
            DispatchQueue.main.async {
                self.invalidateAllTimers()
                self.getWebSocketResponse(responseString: string)
            }
        case .binary(let data):
            _ = data
        case .ping:
            socket.write(ping: Data(), completion: nil)
        case .pong:
            socket.write(pong: Data(), completion: nil)
        case .reconnectSuggested:
            print("websocket reconnectSuggested")
            //delegate?.webSocketErrorConnection(message: "WebSocket Reconnecting")
        case .viabilityChanged:
            print("viabilityChanged:")
            isWebSocketConnected = true
            checkWebSocketConnection()
        case .cancelled:
            print("websocket is cancelled/unable to connect")
            //delegate?.webSocketErrorConnection(message: "WebSocket Connection Closed")
        case .error(let error):
            print("error while connecting: \(error?.localizedDescription ?? "error")")
        }
    }
}
