//
//  KSReachabilityCheck.swift
//  KobelcoService
//
//  Created by Guest L&T on 15/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation

class KSReachabilityCheck {
    fileprivate var netAvailability: Bool = false
}
