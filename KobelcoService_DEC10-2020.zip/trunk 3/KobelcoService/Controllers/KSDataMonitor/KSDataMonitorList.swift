//
//  KSDataMonitorList.swift
//  KobelcoService
//
//  Created by Swaminath on 10/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSDataMonitorList: UIViewController {

    @IBOutlet weak var tableViewMonitorList: UITableView!
    @IBOutlet weak var monitorListHeaderView: UIView!
    @IBOutlet weak var monitorListItemName: UIButton!
    @IBOutlet weak var monitorListHeaderValue: UILabel!
    @IBOutlet weak var monitorListHeaderUnit: UILabel!
    weak var monitorDelegate: KSMonitorDataDelegate?
    var monitorSubmenu = [[String: Any]]()
    var monitorReadIDs = [String]()
    fileprivate var monitorSelectedItem = String()
    var arrayMonitorSelectedItems = [String]()
    //var monitorReadValues = [Int]()
    var plistHelepr = KSPlistReadAndWriteModel()
    var ecuSignalsArray: [ECUSignalsModel] = []
    var pumpSignalsArray: [ECUSignalsModel] = []
    var combineECUAndPumpSignalArray: [ECUSignalsModel] = []
    var setParameters: [KSIsCheckBoxSelectedModel] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.loadMonitorListUIComponents()
    }
    // Add custom property values to monitor list UI components.
    fileprivate func loadMonitorListUIComponents() {
        self.view.backgroundColor = NAVIGATIONBARCOLOR
        self.view.layer.cornerRadius = 10
        self.monitorListHeaderView.layer.cornerRadius = 6
        self.monitorListItemName.setTitle(localizedKey("ItemNameText"), for: .normal)
        self.monitorListHeaderValue.text = localizedKey("ValueText")
        self.monitorListHeaderUnit.text = localizedKey("UnitText")
        guard KSSingletonManager.shared.dataMonitorSubMenu.count > 0 else { return }
        self.appendEmptyValuesToMonitorItemListArray()
    }

    // By default append 0 for item values to display in tableview.
    func appendEmptyValuesToMonitorItemListArray() {
        if KSSingletonManager.shared.dataMonitorSubMenu.count > 0 {
            self.monitorListHeaderView.isHidden = false
        }
        KSSingletonManager.shared.dataMonitorReadValues.removeAll(keepingCapacity: false)
        KSSingletonManager.shared.dataMonitorReadIDs.removeAll(keepingCapacity: false)
        if !KSSingletonManager.shared.isDataMonitorStart {
            KSSingletonManager.shared.dataMonitorJSONArray.removeAll(keepingCapacity: false)
        }
        arrayMonitorSelectedItems.removeAll(keepingCapacity: false)
        self.monitorSubmenu.removeAll(keepingCapacity: false)
        self.monitorSubmenu = KSSingletonManager.shared.dataMonitorSubMenu
        for monitorItemDict in monitorSubmenu {
            print("monitorItemDict: \(monitorItemDict)")
            KSSingletonManager.shared.dataMonitorReadValues.append(0)
            guard let monitorItemNameDict = monitorItemDict["name"] as? [String: Any] else { return }
            guard let monitorItemName = monitorItemNameDict[KSSingletonManager.shared.languageCode] as? String else { return }
            guard let monitorItemID = monitorItemDict["id"] as? String else { return }
            KSSingletonManager.shared.dataMonitorReadIDs.append(monitorItemID)
            arrayMonitorSelectedItems.append(monitorItemID)
            if !KSSingletonManager.shared.isDataMonitorStart {
                storeGraphParameterDetails(itemName: monitorItemName, itemID: monitorItemID)
            }
        }
        print("monitorSubmenu.count: \(monitorSubmenu.count)")
        monitorListItemName.isSelected = (arrayMonitorSelectedItems.count == monitorSubmenu.count) ? true : false
        self.reloadDataMonitorTableview()
    }
    // Store itemname, id and value for to plot graph.
    func storeGraphParameterDetails(itemName: String, itemID: String) {
        var monitorItemDict = [String: Any]()
        monitorItemDict["signalId"] = itemID
        monitorItemDict["signalName"] = itemName
        monitorItemDict["signalValues"] = [Int]()
        monitorItemDict["signalColor"] = UIColor.random().htmlRGBaColor
        KSSingletonManager.shared.dataMonitorJSONArray.append(monitorItemDict)
    }
    // Reload after merging all signals.
    func reloadDataMonitorTableview() {
        DispatchQueue.main.async {
            self.tableViewMonitorList.reloadData()
            self.monitorListItemName.setImage(UIImage(named: "diabledCheckBox"), for: .disabled)
        }
    }
    // Tap to swipe up & down the tableview list on the parent Controller.
    @IBAction func swipeUpDownTapAction(_ sender: Any) {
        monitorDelegate?.swipeUpAndDownTheChildController()
    }
    @IBAction func monitorSelectAllItemNames(_ sender: UIButton) {
        self.arrayMonitorSelectedItems.removeAll(keepingCapacity: false)
        if monitorListItemName.isSelected == false {
            for monitorItemDict in monitorSubmenu {
                guard let monitorItemID = monitorItemDict["id"] as? String else { return }
                arrayMonitorSelectedItems.append(monitorItemID)
            }
        }
        self.monitorListItemName.isSelected = (arrayMonitorSelectedItems.count == monitorSubmenu.count) ? true : false
        self.reloadDataMonitorTableview()
        self.monitorDelegate?.getSelectedMonitorItems(monitorItems: self.arrayMonitorSelectedItems)
    }
    
    // Condition check for type1 & type 2 segment selection.
    func checkType1AndType2SegmentSelection() {
        let isType1Graph = KSSingletonManager.shared.isDataMonitorType1
        self.arrayMonitorSelectedItems.removeAll(keepingCapacity: false)
        if isType1Graph {
            for type1ItemDict in monitorSubmenu {
                guard let type1ItemID = type1ItemDict["id"] as? String else { return }
                self.arrayMonitorSelectedItems.append(type1ItemID)
            }
        self.monitorListItemName.isSelected = (arrayMonitorSelectedItems.count == monitorSubmenu.count) ? true : false
        } else {
            let type2ItemDict = monitorSubmenu[0]
            guard let type2ItemID = type2ItemDict["id"] as? String else { return }
            self.arrayMonitorSelectedItems.append(type2ItemID)
            self.monitorListItemName.isSelected = false
            self.monitorListItemName.isEnabled = false
        }
        self.monitorListItemName.isEnabled = isType1Graph ? true : false
        self.reloadDataMonitorTableview()
        self.monitorDelegate?.getSelectedMonitorItems(monitorItems: self.arrayMonitorSelectedItems)
    }
    
    func getSelectedMonitorListItem() {
        self.monitorDelegate?.getSelectedMonitorItems(monitorItems: self.arrayMonitorSelectedItems)
    }
}
 // MARK: MoitorListTableview delegate
 extension KSDataMonitorList: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if monitorSubmenu.count == 0 {
            DispatchQueue.main.async {
                self.tableViewMonitorList.backgroundView =  KSSingletonManager.shared.nullDataFilesLabel(message: self.localizedKey("PlusSignMessage"))
            }
        } else {
            self.tableViewMonitorList.backgroundView = nil
        }
        return monitorSubmenu.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let monitorCellIdentifier = "KSDataMonitorCell"
        let monitorCell: KSDataMonitorCell?
        monitorCell = tableView.dequeueReusableCell(withIdentifier: monitorCellIdentifier) as? KSDataMonitorCell
        monitorCell?.configureDataMonitorCellDetails(itemObject: monitorSubmenu[indexPath.row], selecteditems: arrayMonitorSelectedItems, itemValue: KSSingletonManager.shared.dataMonitorReadValues[indexPath.row])
        return monitorCell!
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let monitorSelectedDict = monitorSubmenu[indexPath.row]
        guard let selectedMenuID = monitorSelectedDict["id"] as? String else { return }
        self.monitorSelectedItem = selectedMenuID
        let isType1Graph = KSSingletonManager.shared.isDataMonitorType1
        if isType1Graph {
            if arrayMonitorSelectedItems.contains(self.monitorSelectedItem) {
                if let index = arrayMonitorSelectedItems.firstIndex(of: self.monitorSelectedItem) {
                    self.monitorSelectedItem = "NOTSELECTED"
                    //guard arrayMonitorSelectedItems.count != 1 else { return }
                    self.arrayMonitorSelectedItems.remove(at: index)
                }
            } else {
                self.arrayMonitorSelectedItems.append(self.monitorSelectedItem)
            }
        } else {
            guard arrayMonitorSelectedItems.contains(self.monitorSelectedItem) == false else { return }
            arrayMonitorSelectedItems.removeAll(keepingCapacity: false)
            arrayMonitorSelectedItems.append(self.monitorSelectedItem)
        }
        self.monitorListItemName.isSelected = (arrayMonitorSelectedItems.count == monitorSubmenu.count) ? true : false
        self.reloadDataMonitorTableview()
        self.monitorDelegate?.getSelectedMonitorItems(monitorItems: self.arrayMonitorSelectedItems)
    }
 }
