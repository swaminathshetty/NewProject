//
//  KSAddParameters.swift
//  KobelcoService
//
//  Created by Swaminath on 10/4/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

class KSAddParameters: UIViewController {

    @IBOutlet weak var addParameterBGView: UIView!
    @IBOutlet weak var headerViewSetParameter: UIView!
    @IBOutlet weak var headerSetParameterButton: UIButton!
    @IBOutlet weak var tableviewSetDataParameters: UITableView!
    @IBOutlet weak var tableviewTheDataParameters: UITableView!
    @IBOutlet weak var engineSegmentMonitor: UISegmentedControl!
    @IBOutlet weak var segmentECUMonitor: UISegmentedControl!
    @IBOutlet weak var footerConfigureButton: UIButton!
    @IBOutlet weak var footerFavoriteButton: UIButton!
    var ecuSignalsArray: [ECUSignalsModel] = []
    var pumpSignalsArray: [ECUSignalsModel] = []
    var combineECUAndPumpSignalArray: [ECUSignalsModel] = []
    var setParameters: [KSIsCheckBoxSelectedModel] = []
    var plistHelper = KSPlistReadAndWriteModel()
    var selectedFavoriteParameter = ""
    var previousIndexPathSetParameterTV = IndexPath()
    weak var diagnosticDelegate: KSDiagnosticDelegate?
    weak var dataMonitorDelegate: KSMonitorDataDelegate?
    var mergedFinalSignals = [[String: Any]]()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.loadMonitorAddParametersUIComponents()
        self.tableviewSetDataParameters.register(UINib(nibName: "KSCheckBoxWithLabelCellTableViewCell", bundle: nil), forCellReuseIdentifier: "KSCheckBoxWithLabelCellTableViewCell")
        self.tableviewTheDataParameters.register(UINib(nibName: "KSCheckBoxWithLabelCellTableViewCell", bundle: nil), forCellReuseIdentifier: "KSCheckBoxWithLabelCellTableViewCell")
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.previousIndexPathSetParameterTV = IndexPath()
        self.selectedFavoriteParameter = ""
        self.engineSegmentMonitor.layer.cornerRadius = 6
        self.segmentECUMonitor.layer.cornerRadius = 6
        self.engineSegmentMonitor.selectedSegmentIndex = 0
        self.setNavigationBarColorWithButtonTitle(buttonTitle: localizedKey("AddParameters"))
        self.headerSetParameterButton.setTitle(localizedKey("SetParameter"), for: .normal)
        self.engineSegmentMonitor.setTitle(localizedKey("Engine"), forSegmentAt: 0)
        self.engineSegmentMonitor.setTitle(localizedKey("Pump"), forSegmentAt: 1)
        self.footerConfigureButton.setTitle(localizedKey("Configure"), for: .normal)
        let setParameterData = plistHelper.readPlistFileAndReturnKey(namePlist: ParameterRegistrationFile)
        self.setParameters = setParameterData.map {KSIsCheckBoxSelectedModel.init(nameValue: $0, isSelectedValue: false)}
        self.tableviewSetDataParameters.reloadData()
        self.parseCategoryWiseDataJSON()
        self.setParameterForDataMonitorSubMenu()
        self.tableviewTheDataParameters.reloadData()
        self.setConfigureButtonEnable()
        self.setAddFavoriteEnableOrNot()
    }

    func setParameterForDataMonitorSubMenu() {
        for monitorData in KSSingletonManager.shared.dataMonitorSubMenu {
            guard let signalID = monitorData["id"] as? String else { return }
            self.ecuSignalsArray = self.ecuSignalsArray.map { self.returnECUSignalsModel(signalVal: $0, signalID: signalID)}
            self.pumpSignalsArray = self.pumpSignalsArray.map { self.returnECUSignalsModel(signalVal: $0, signalID: signalID)}
        }
    }
    
    func returnECUSignalsModel(signalVal: ECUSignalsModel, signalID: String) -> ECUSignalsModel {
        if signalVal.id == signalID {
            var signal = signalVal
            signal.isSelected = true
            return signal
        }
        return signalVal
    }

    func parseCategoryWiseDataJSON() {
        KSSingletonManager.shared.loadJson(filename: MATRIXDATAFILE) { (categoryWiseData) in
            guard let categoryWiseDataInJSON = self.convertDataToDictionary(data: categoryWiseData)  else { return }
            let aOneDic: [String: Any] = categoryWiseDataInJSON[KSSingletonManager.shared.modelTypeSelection] as! [String: Any]
            self.setECUPumpArrayValues(dicValue: aOneDic)
        }
    }

    func setECUPumpArrayValues(dicValue: [String: Any]) {
        let ecuSignals = dicValue["ECUSignals"] as! [[String: Any]]
        self.ecuSignalsArray = ecuSignals.map {ECUSignalsModel.init(data: $0)}
        let pumpSignals = dicValue["pumpSignals"] as! [[String: Any]]
        self.pumpSignalsArray = pumpSignals.map {ECUSignalsModel.init(data: $0)}
    }

    // Set custom property values to monitor add paramters UI elements.
    fileprivate func loadMonitorAddParametersUIComponents() {
        self.view.backgroundColor = NAVIGATIONBARCOLOR
        self.addParameterBGView.backgroundColor = VIEWBACKGROUNDCOLOR
        self.headerViewSetParameter.layer.cornerRadius = 6
        self.engineSegmentMonitor.setSegmentTintColors()
        self.segmentECUMonitor.setSegmentTintColors()
        if KSSingletonManager.shared.currentScreenName == "DiagnosticSubMenu" {
            self.footerFavoriteButton.isHidden = true
        }
    }

    func setConfigureButtonEnable() {
        self.combineECUAndPumpSignalArray = [ECUSignalsModel]()
        self.combineECUAndPumpSignalArray = self.ecuSignalsArray.filter {$0.isSelected == true}
        self.combineECUAndPumpSignalArray += self.pumpSignalsArray.filter {$0.isSelected == true}

        if self.combineECUAndPumpSignalArray.isEmpty {
            self.footerConfigureButton.setTitleColor(DISBALECOLOR, for: .normal)
            self.footerConfigureButton.isEnabled = false
        } else {
            self.footerConfigureButton.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
            self.footerConfigureButton.isEnabled = true
        }
    }

    func setAddFavoriteEnableOrNot() {
        var checkECUAndPumpValues = [ECUSignalsModel]()
        checkECUAndPumpValues = self.ecuSignalsArray.filter {$0.isSelected == true}
        checkECUAndPumpValues += self.pumpSignalsArray.filter {$0.isSelected == true}

        if checkECUAndPumpValues.count != 0 {
            self.footerFavoriteButton.isEnabled = true
        } else {
            self.footerFavoriteButton.isEnabled = false
        }
    }

    // Click on this button to plot line graphs for the selected parameters.
    @IBAction func configurePlotButtonTapped(_ sender: Any) {
        self.mergedFinalSignals.removeAll(keepingCapacity: false)
        let convertedStructArray = self.combineECUAndPumpSignalArray.map {$0.asDictionary}
        for selectedFavoriteSignal in convertedStructArray {
            guard let signalID = selectedFavoriteSignal["id"] as? String else { return }
            let duplicateSignalStatus = checkDuplicateSignalIDs(newSignalID: signalID)
            if duplicateSignalStatus == false {
                self.mergedFinalSignals.append(selectedFavoriteSignal)
            }
        }
        if KSSingletonManager.shared.currentScreenName == "DiagnosticSubMenu" {
            diagnosticDelegate?.updateNewlyAddedConfigureItems(selectedParameters: self.mergedFinalSignals)
        } else {
            KSSingletonManager.shared.isDataMonitorType1 = true
            dataMonitorDelegate?.getAddParametersList(selectedParameters: convertedStructArray)
        }
        self.navigationController?.popViewController(animated: true)
    }
    // Check duplicate signals before appending add signals dictionary to array.
    fileprivate func checkDuplicateSignalIDs(newSignalID: String) -> Bool {
        var signalStatus = false
        let conditionCheckArray = KSSingletonManager.shared.currentScreenName == "DiagnosticSubMenu" ? KSSingletonManager.shared.diagnosticSubMenuArray : KSSingletonManager.shared.dataMonitorSubMenu
        for existingObject in conditionCheckArray {
            guard let existingSignalID = existingObject["id"] as? String else { return false }
            if existingSignalID.contains(newSignalID) {
                signalStatus = true
                break
            } else {
                signalStatus = false
            }
        }
        return signalStatus
    }
    // Tap on this button to make/create favorite parameters.
    @IBAction func addFavoriteButtonTapped(_ sender: Any) {
        let addFavorite = CONFIGURATIONSTORYBOARD.instantiateViewController(withIdentifier: "KSParameterAddfavorite") as! KSParameterAddfavorite
        addFavorite.ksParameterAddfavoriteDelegate = self
        addFavorite.setParameters = self.setParameters
        self.navigationController?.pushViewController(addFavorite, animated: true)
    }

    // Toggle action for engine and pump selection.
    @IBAction func engineSegmentMonitorToggleAction(_ sender: Any) {
        self.tableviewTheDataParameters.reloadData()
    }

    // Toggle segment controller for ECU & DCU engine selection.
    @IBAction func segmentECUMonitorToggleAction(_ sender: Any) {
    }
}

// MARK: Tableview delegate
extension KSAddParameters: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == self.tableviewSetDataParameters {
            if setParameters.count == 0 {
                DispatchQueue.main.async {
                    self.tableviewSetDataParameters.backgroundView = KSSingletonManager.shared.nullDataFilesLabel(message: self.localizedKey("NoRecordsText"))
                }
            } else {
                self.tableviewSetDataParameters.backgroundView = nil
            }
            return self.setParameters.count
        } else {
            if self.engineSegmentMonitor.selectedSegmentIndex == 1 {
                return self.pumpSignalsArray.count
            } else {
                return self.ecuSignalsArray.count
            }
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == self.tableviewSetDataParameters {
            let theParameterCell = tableView.dequeueReusableCell(withIdentifier: "KSCheckBoxWithLabelCellTableViewCell") as! KSCheckBoxWithLabelCellTableViewCell
            self.setUpSetParameterTableView(cellObj: theParameterCell, indexValue: indexPath.row)
            return theParameterCell
        } else {
            let theParameterCell = tableView.dequeueReusableCell(withIdentifier: "KSCheckBoxWithLabelCellTableViewCell") as! KSCheckBoxWithLabelCellTableViewCell
            self.setUpTheParameterTableView(cellObj: theParameterCell, indexValue: indexPath.row)
            return theParameterCell
        }
    }

    func setUpSetParameterTableView(cellObj: KSCheckBoxWithLabelCellTableViewCell?, indexValue: Int) {
        let setParameter = self.setParameters[indexValue]
        if let _ = cellObj {
            cellObj?.fillRadioCellData(lableText: setParameter.name, isCheckBoxSelected: setParameter.isSelected)
        } else {
            let indexPath = IndexPath(row: indexValue, section: 0)
            let getCell = self.tableviewSetDataParameters.cellForRow(at: indexPath) as? KSCheckBoxWithLabelCellTableViewCell
            getCell?.fillRadioCellData(lableText: setParameter.name, isCheckBoxSelected: setParameter.isSelected)
        }
    }

    func tableViewScrollToTop(tableView: UITableView) {
        let topIndex = IndexPath(row: 0, section: 0)
        tableView.reloadRows(at: [topIndex], with: .fade)
        tableView.scrollToRow(at: topIndex, at: .top, animated: true)
    }

    func setUpTheParameterTableView(cellObj: KSCheckBoxWithLabelCellTableViewCell, indexValue: Int) {
        var txtLabel = ""
        var isSelected = false
        if self.engineSegmentMonitor.selectedSegmentIndex == 1 {
            txtLabel = self.pumpSignalsArray[indexValue].name[KSSingletonManager.shared.languageCode] as! String
            isSelected = self.pumpSignalsArray[indexValue].isSelected
        } else {
            txtLabel = self.ecuSignalsArray[indexValue].name[KSSingletonManager.shared.languageCode] as! String
            isSelected = self.ecuSignalsArray[indexValue].isSelected
        }

        cellObj.fillCellData(lableText: txtLabel, isCheckBoxSelected: isSelected)
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == tableviewSetDataParameters && self.previousIndexPathSetParameterTV == indexPath {
            self.resetSetParameterTableViewRow()
            self.parseCategoryWiseDataJSON()
            self.tableviewTheDataParameters.reloadData()
        } else if tableView == self.tableviewSetDataParameters {
            let setParameter = self.setParameters[indexPath.row]
            let output = plistHelper.readPlistReturnDic(namePlist: ParameterRegistrationFile, key: setParameter.name)
            self.selectedFavoriteParameter = setParameter.name
            self.setECUPumpArrayValues(dicValue: output)
            self.tableviewTheDataParameters.reloadData()
            _ = self.setPreviousIndexPathValue()
            self.setParameters[indexPath.row] = KSIsCheckBoxSelectedModel.init(nameValue: setParameter.name, isSelectedValue: true)
            self.previousIndexPathSetParameterTV = indexPath
            self.tableviewSetDataParameters.reloadData()
        } else {
            self.resetSetParameterTableViewRow()
            self.parameterCheckBoxButtonPressed(indexValue: indexPath.row)
        }
        self.setConfigureButtonEnable()
        self.setAddFavoriteEnableOrNot()
    }
    
    func resetSetParameterTableViewRow() {
        if self.setPreviousIndexPathValue() {
            self.tableviewSetDataParameters.reloadData()
            self.previousIndexPathSetParameterTV = IndexPath()
        }
    }

    /*
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == self.tableviewSetDataParameters {
            let setParameter = self.setParameters[indexPath.row]
            let output = plistHelper.readPlistReturnDic(namePlist: ParameterRegistrationFile, key: setParameter.name)
            self.selectedFavoriteParameter = setParameter.name
            self.setECUPumpArrayValues(dicValue: output)
            self.tableviewTheDataParameters.reloadData()
            _ = self.setPreviousIndexPathValue()
            self.setParameters[indexPath.row] = KSIsCheckBoxSelectedModel.init(nameValue: setParameter.name, isSelectedValue: true)
            self.previousIndexPathSetParameterTV = indexPath
            self.tableviewSetDataParameters.reloadData()
        } else {
            if self.setPreviousIndexPathValue() {
                self.tableviewSetDataParameters.reloadData()
                self.previousIndexPathSetParameterTV = IndexPath()
            }
            self.parameterCheckBoxButtonPressed(indexValue: indexPath.row)
        }
        self.setConfigureButtonEnable()
        self.setAddFavoriteEnableOrNot()
    }
*/
    func setPreviousIndexPathValue() -> Bool {
        if !self.previousIndexPathSetParameterTV.isEmpty {
            let setParameter1 = self.setParameters[self.previousIndexPathSetParameterTV.row]
            self.setParameters[self.previousIndexPathSetParameterTV.row] = KSIsCheckBoxSelectedModel.init(nameValue: setParameter1.name, isSelectedValue: false)
            return true
        }
        return false
    }
}

extension KSAddParameters {
    func parameterCheckBoxButtonPressed(indexValue: Int) {
         if self.engineSegmentMonitor.selectedSegmentIndex == 1 {
            var pump = self.pumpSignalsArray[indexValue]
            pump.isSelected = !pump.isSelected
            self.pumpSignalsArray[indexValue] = pump
         } else {
            var ecu = self.ecuSignalsArray[indexValue]
            ecu.isSelected = !ecu.isSelected
            self.ecuSignalsArray[indexValue] = ecu
         }
        let reloadIndex = IndexPath(row: indexValue, section: 0)
        self.tableviewTheDataParameters.reloadRows(at: [reloadIndex], with: .none)
    }
}

extension KSAddParameters: KSParameterAddfavoriteDelegate {
    func parameterAddCaption(txtValue: String) {
        var data: [String: Any]
        let ecuDictionary = self.ecuSignalsArray.map {$0.asDictionary}
        let pumpDictionary = self.pumpSignalsArray.map {$0.asDictionary}
        data = ["ECUSignals": ecuDictionary, "pumpSignals": pumpDictionary]
        plistHelper.writePlist(namePlist: ParameterRegistrationFile, key: txtValue, data: data as AnyObject)
    }
}
