//
//  KSModelType.swift
//  KobelcoService
//
//  Created by Guest L&T on 14/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

@objc protocol KSModelTypeDelegate {
    func sendSelectedModelItem(selectedTF: String, selectedItem: String)
}

class KSModelType: UIViewController, KSModelTypeDelegate {

    @IBOutlet weak var labelModelType: UILabel!
    @IBOutlet weak var labelArea: UILabel!
    @IBOutlet weak var textFieldModelType: UITextField!
    @IBOutlet weak var textFieldArea: UITextField!
    @IBOutlet weak var buttonSubmit: UIButton!
    fileprivate var isModelTypeViewPresented: Bool = true
    private let modelTypeVM: KSModelTypeVM

    init(modelTypeVM: KSModelTypeVM) {
        self.modelTypeVM = modelTypeVM
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        self.modelTypeVM = KSModelTypeVM()
        super.init(coder: coder)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = COPYRIGHTBGCOLOR
        setUpModelTypeUIComponents()
        KSSingletonManager.shared.delegate = self
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        isModelTypeViewPresented = true
    }
    override var prefersHomeIndicatorAutoHidden: Bool {
        return false
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.showCopyrightLabel()
        if KSSingletonManager.shared.isOfflineConnection == false {
            //Swami
            //KSSingletonManager.shared.connectWebSocket()
        }
    }
    // Do condition check for offline & online connectivity and then send websocket command.
    func sendModeltypeCommand(frameName: String) {
        getMachineSelectedMatrixObject(machineType: frameName)
        if KSSingletonManager.shared.isOfflineConnection == true {
            self.navigation(to: Identifier.dashboardScreen)
        } else {
            let dashboardCommand = SocketRequestDict(screenName: "ModelTypeSelection", frameType: frameName, device: "All", periodicity: 0)
            guard let dashboardRequestData = try? JSONEncoder().encode(dashboardCommand) else { return }
            KSSingletonManager.shared.sendCommand(format: dashboardRequestData)
        }
    }
    // Fetch only particular matrix object(A1, A2, A3, A4, B1, B2, B3) based on modeltype & area selection.
    fileprivate func getMachineSelectedMatrixObject(machineType: String) {
        KSSingletonManager.shared.loadJson(filename: MATRIXDATAFILE) { (errorCodesData) in
            guard let matrixJSON = self.convertDataToDictionary(data: errorCodesData) else { return }
            guard let appConfigurationObject = matrixJSON[machineType] as? [String: Any] else { return }
            KSSingletonManager.shared.matrixObject = appConfigurationObject
        }
    }
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        if isModelTypeViewPresented {
            self.hideCopyrightLabel()
            if UIDevice.current.orientation.isLandscape {
                self.showCopyrightLabel()
            } else {
                self.showCopyrightLabel()
            }
        }
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    // MARK: Add all custom property values here
    fileprivate func setUpModelTypeUIComponents() {
        self.labelModelType.font = UIFont.regular(ofSize: 17)
        self.labelArea.font = UIFont.regular(ofSize: 17)
        self.labelModelType.text = localizedKey("ModelTypeText")
        self.labelArea.text = localizedKey("AreaText")
        self.textFieldModelType.placeholder = localizedKey("MachinePlaceHolder")
        self.textFieldArea.placeholder = localizedKey("MachinePlaceHolder")
        self.buttonSubmit.setTitle(localizedKey("SubmitText"), for: .normal)
    }
    // Click on this button after proper selection of modeltype and area.
    @IBAction func submitButtonAction(_ sender: Any) {
        self.view.endEditing(true)
        do {
                _ = try modelTypeVM.validateModelType(textFieldModelType.text)
                _ = try modelTypeVM.validateArea(textFieldArea.text)
            self.showLoader()
            self.sendModeltypeCommand(frameName: KSSingletonManager.shared.modelTypeSelection)
            } catch {
                self.presentAlert(withTitle: ALERTTITLESTRING, message: "\(error.localizedDescription)")
            }
    }
    // Called this after selection of modeltype and area from tableview list.
    func sendSelectedModelItem(selectedTF: String, selectedItem: String) {
        if selectedTF == "MODELTYPE" {
            textFieldModelType.text = selectedItem
            textFieldArea.text = ""
        } else {
            textFieldArea.text = selectedItem
        }
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.hideCopyrightLabel()
        isModelTypeViewPresented = false
        //Swami
        //KSSingletonManager.shared.disconnectWebSocket()
    }
}

// MARK: Textfield delegate
extension KSModelType: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
            if textField.text?.count == 0 && string == " " {
                return false
            }
        return true
    }
    // Tap on texfield to call tableview contoller method.
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        let textFieldType = (textField == textFieldModelType) ? "MODELTYPE" : "AREA"
        if textField == textFieldArea {
            do {
                _ = try modelTypeVM.validateModelType(textFieldModelType.text)
                self.presentModelTypeOrAreaController(selectedInput: textFieldType)
            } catch {
                self.presentAlert(withTitle: ALERTTITLESTRING, message: "\(error.localizedDescription)")
            }
        } else {
            presentModelTypeOrAreaController(selectedInput: textFieldType)
        }
        return false
    }
    // load tableview items based on textfield selection.
    func presentModelTypeOrAreaController(selectedInput: String) {
        let tableViewList = MAINSTORYBOARD.instantiateViewController(withIdentifier: Identifier.modelTypeList.rawValue) as! KSModelTypeList
        tableViewList.delegate = self
        tableViewList.selectedInput = selectedInput
        tableViewList.modelTypeName = self.textFieldModelType.text ?? ""
        self.present(tableViewList, animated: true, completion: nil)
    }
}

// MARK: - WebSocket Response Delegate
extension KSModelType: KSWebSocketDelegates {
    func webSocketStringResponse(response: String) {
        self.hideLoader()
        print("String response: \(response)")
        guard let jsonDictionary = convertToDictionary(text: response) else { return }
        guard let screenTitle = jsonDictionary["screenName"] as? String else { return }
        if screenTitle == "ModelTypeSelection" {
            guard let modelTypeData = response.data(using: String.Encoding.utf8) else { return }
            do {
                let modelTypeResponse = try JSONDecoder().decode(ModelSelectionResponse.self, from: modelTypeData)
                if modelTypeResponse.status.contains("Accepted") {
                    DispatchQueue.main.async {
                        KSSingletonManager.shared.isOfflineConnection = false
                        KSSingletonManager.shared.applicationUnit = modelTypeResponse.applicationUnit
                        KSSingletonManager.shared.partNumber = modelTypeResponse.partsNo
                        self.navigation(to: Identifier.dashboardScreen)
                    }
                }
            } catch let error as NSError {
                self.presentAlert(withTitle: ERRORTITLE, message: error.localizedDescription)
            }
        }
    }
    func webSocketErrorConnection(message: String) {
        self.hideLoader()
        presentAlertOKAction(withTitle: ERRORTITLE, message: message) { (_ ) in
            KSSingletonManager.shared.connectWebSocket()
        }
    }
    // Called whenever there is no internet connection.
    func internetConnectionNotAvailable() {
        self.hideLoader()
        presentAlert(withTitle: ERRORTITLE, message: NOINTERNETMESSAGE)
    }
    // Websocket response timeout alert.
    func noWebSocketResponse(message: String) {
        self.hideLoader()
        presentAlert(withTitle: ERRORTITLE, message: message)
    }
}
