//
//  KSWIFISettings.swift
//  KobelcoService
//
//  Created by Guest L&T on 11/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit
import NotificationCenter
import UserNotifications
import CoreLocation

class KSWIFISettings: UIViewController {

    @IBOutlet weak var buttonWIFISettings: UIButton!
    @IBOutlet weak var labelSSIDName: UILabel!
    @IBOutlet weak var labelStart: UILabel!
    @IBOutlet weak var buttonStart: UIButton!
    @IBOutlet weak var buttonWithoutWIFI: UIButton!
    fileprivate var isWIFIViewPresented: Bool = true
    private let wifiSettingVM: KSWiFiSettingsVM
    private let locationManager = CLLocationManager()

    init(wifiSettingVM: KSWiFiSettingsVM) {
        self.wifiSettingVM = wifiSettingVM
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) {
        self.wifiSettingVM = KSWiFiSettingsVM()
        super.init(coder: coder)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = COPYRIGHTBGCOLOR
        self.navigationController?.navigationBar.isHidden = true
        self.navigationController?.getWiFiSettingsNavigationID()
        setUpUIComponents()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        KSSingletonManager.shared.currentScreenName = "KSWIFISettings" // Using this reference to identify navigation viewcontroller index count
        isWIFIViewPresented = true
    }
    
    // Used to hide iPhoneX/XS footer home line.
    override var prefersHomeIndicatorAutoHidden: Bool {
        return false
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.showCopyrightLabel()
        KSSingletonManager.shared.delegate = self
        // Start activity indicator loader.
        self.showLoader()
        // Check network availability
        self.perform(#selector(networkMonitor), with: self, afterDelay: 1)
        // Get connected ssid name.
        self.perform(#selector(updateSSIDName), with: self, afterDelay: 1)
        // Clear document directory files.
        KSTextFileString.clearDiskCache()
    }
    
    // MARK: Identify screen orientation
    // todo: clear copyright label from footer before orientation changes
    // fixme: Again add copyright footer label after screen orientation to avoid constraint problem.
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        if isWIFIViewPresented {
            self.hideCopyrightLabel()
            if UIDevice.current.orientation.isLandscape {
                self.showCopyrightLabel()
            } else {
                self.showCopyrightLabel()
            }
        }
     }
    
    // Assining all custom property values here in a single function.
    fileprivate func setUpUIComponents() {
        self.labelSSIDName.font = UIFont.regular(ofSize: 14)
        self.labelStart.font = UIFont.regular(ofSize: 14)
        self.labelStart.text = localizedKey("WiFiStartMessage")
        self.buttonWIFISettings.setTitle(localizedKey("WiFiSettingsText"), for: .normal)
        self.buttonStart.setTitle(localizedKey("StartText"), for: .normal)
        self.buttonWithoutWIFI.setTitle(localizedKey("NextWithOutConnection"), for: .normal)
        KSSingletonManager.shared.delegate = self
    }
    
    // MARK: Identify internet connection availability
    // todo: Open iPhone general Wi-Fi settings when network is not reachable
    // fixme: Navigate to next screen if iphone device is connected to any Wi-Fi network.
    @objc private func networkMonitor() {
        appDelegate?.networkCompletionHandler = { (networkStatus, isWifiMode) in
            if networkStatus == true {
                if isWifiMode {
                    print("WIFI Settings WiFiMode")
                    self.updateSSIDName()
                } else {
                    // Navigate back to connect screen when mobile internet is on.
                    self.hideLoader()
                    self.presentAlertOKAction(withTitle: ALERTTITLESTRING, message: NOINTERNETMESSAGE) { (isOkPressed) in
                        if isOkPressed {
                            self.checkInitiallyLoadedConnectScreenNavigationIndex()
                        }
                    }
                }
            } else {
                DispatchQueue.main.async {
                    self.checkInitiallyLoadedConnectScreenNavigationIndex()
                }
            }
        }
    }
    // Condition check for connect screen initial loading.
    fileprivate func checkInitiallyLoadedConnectScreenNavigationIndex() {
        if KSSingletonManager.shared.connectNavigationID == 0 {
            self.navigation(to: Identifier.connectScreen)
        } else {
            self.popOverToBackScreen(indexValue: KSSingletonManager.shared.connectNavigationID)
        }
    }
    // Get connected WIFI name and showcase on userinterface label.
    @objc private func updateSSIDName() {
        if CLLocationManager.locationServicesEnabled() {
            // continue to implement here
            self.checkLocationAuthorization()
            locationManager.startUpdatingLocation()
        }
        /*else {
            self.getSSIDInformation()
        }*/
    }
    // Get SSID information after location check.
    fileprivate func getSSIDInformation() {
        self.hideLoader()
        guard let ssidName = self.wifiSettingVM.getSSID(viewController: self) else {
            //checkInitiallyLoadedConnectScreenNavigationIndex()
            return }
         DispatchQueue.main.async {
            let wifiLocalizedString = self.localizedKey("SSIDMessage")
            self.labelSSIDName.text = wifiLocalizedString.replacingOccurrences(of: "SSID", with: "\(ssidName)")
         }
    }
    @IBAction func wifiSettingsButtonAction(_ sender: Any) {
        KSSingletonManager.openWifiSettings() // Used to open iPhone general settings
    }
    // Click on this button to initaite Websocket connection after connected to a proper WIFI network.
    @IBAction func startButtonAction(_ sender: Any) {
        self.showLoader()
        KSSingletonManager.shared.connectWebSocket()
    }
    // Click on this button when you want to operate this application in offline mode.
    @IBAction func withoutWifiButtonAction(_ sender: Any) {
        KSSingletonManager.shared.isOfflineConnection = true
        self.navigation(to: Identifier.modelTypeScreen)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        KSSingletonManager.shared.currentScreenName = "" // Clear screen title text to avoid conflicts
        self.hideCopyrightLabel() // remove footer label before navigating to other screens
        self.hideLoader()
        isWIFIViewPresented = false
        //Swami
        //KSSingletonManager.shared.disconnectWebSocket()
    }
}

// MARK: - WebSocket Response Delegate
extension KSWIFISettings: KSWebSocketDelegates {
    func webSocketStringResponse(response: String) {
        self.hideLoader()
        print("String response: \(response)")
        if response == "Connection Opened" {
            KSSingletonManager.shared.isOfflineConnection = false
            self.navigation(to: Identifier.modelTypeScreen)
        }
    }
    func webSocketErrorConnection(message: String) {
        self.hideLoader()
        presentAlertOKAction(withTitle: ERRORTITLE, message: message) { (_ ) in
        }
    }
    // Called whenever there is no internet connection.
    func internetConnectionNotAvailable() {
        self.hideLoader()
        presentAlertOKAction(withTitle: ERRORTITLE, message: NOINTERNETMESSAGE) { (_ ) in
            KSSingletonManager.shared.connectWebSocket()
        }
    }
    // Websocket response timeout alert.
    func noWebSocketResponse(message: String) {
        self.hideLoader()
        presentAlert(withTitle: ERRORTITLE, message: message)
    }
}

// location access extension to get wifi ssid name.
extension KSWIFISettings {
    func checkLocationAuthorization() {
        switch CLLocationManager.authorizationStatus() {
        case .authorizedWhenInUse:
            self.getSSIDInformation()
        case .denied: // Show alert telling users how to turn on permissions
            alertLocationAccessNeeded()
        case .notDetermined:
            locationManager.requestWhenInUseAuthorization()
        case .restricted: // Show an alert letting them know what’s up
            alertLocationAccessNeeded()
        case .authorizedAlways:
            self.getSSIDInformation()
        default:
            break
        }
    }
    // Show alert for location permission.
    func alertLocationAccessNeeded() {// Gather location updates to get SSID information
        self.presentAlertOKAction(withTitle: LOCATIONTITLE, message: LOCATIONACCESSMESSAGE) { (goToSettings) in
            if goToSettings {
                // Used to open iPhone general settings
                KSSingletonManager.openWifiSettings()
            }
        }
    }
    // Stop updating location once location permission accepted by user.
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        locationManager.stopUpdatingLocation()
        self.getSSIDInformation()
    }
}
