//
//  KSNormalDataEditing.swift
//  KobelcoService
//
//  Created by Guest L&T on 07/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

class KSNormalDataEditing: UIViewController {

    @IBOutlet weak var topDataEditingView: UIView!
    @IBOutlet weak var topNormalDataTitle: UILabel!
    @IBOutlet weak var dataEditingTableView: UITableView!
    @IBOutlet weak var deleteDataEditing: UIButton!
    @IBOutlet weak var changeDataEditing: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Normal Data Editing")
        loadNormalDataComponents()
        self.dataEditingTableView.register(UINib(nibName: "KSCheckBoxWithLabelCellTableViewCell", bundle: nil), forCellReuseIdentifier: "KSCheckBoxWithLabelCellTableViewCell")

    }
    // Configure Normal data UI components.
    fileprivate func loadNormalDataComponents() {
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.topDataEditingView.layer.cornerRadius = 6
        self.topNormalDataTitle.text = "Normal Data List"
        self.deleteDataEditing.setTitle("Delete", for: .normal)
        self.changeDataEditing.setTitle("Change Name", for: .normal)
    }
    
    // User can delete single and multiple normal data files based on selected checkbox from tableview list.
    @IBAction func deleteNormalDataFiles(_ sender: Any) {
    }
    
    // ChangeName button enabled when user want to change any data file name.
    @IBAction func changeNormalDataFileName(_ sender: Any) {
    }
}

// MARK: Tableview Delegate
extension KSNormalDataEditing: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return rowCountZeroCheckDataEditing(tableViewName: tableView, rowCount: 0)
    }
    // Condition check for tableview row count and add tableview background with records label if count == 0.
     fileprivate func rowCountZeroCheckDataEditing(tableViewName: UITableView, rowCount: Int) -> Int {
         if rowCount == 0 {
             DispatchQueue.main.async {
                 tableViewName.backgroundView =  KSSingletonManager.shared.nullDataFilesLabel(message: self.localizedKey("NoRecordsText"))
             }
         } else {
             tableViewName.backgroundView = nil
         }
         return rowCount
     }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let theParameterCell = tableView.dequeueReusableCell(withIdentifier: "KSCheckBoxWithLabelCellTableViewCell") as! KSCheckBoxWithLabelCellTableViewCell
        return theParameterCell
    }
}
