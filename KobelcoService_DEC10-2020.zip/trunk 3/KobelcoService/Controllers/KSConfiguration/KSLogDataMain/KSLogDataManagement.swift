//
//  KSLogDataManagement.swift
//  KobelcoService
//
//  Created by Swaminath on 9/27/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

class KSLogDataManagement: UIViewController {

    @IBOutlet weak var logTopView: UIView!
    @IBOutlet weak var topViewLogTitle: UILabel!
    @IBOutlet weak var logDataTableView: UITableView!
    @IBOutlet weak var logDeleteButton: UIButton!
    @IBOutlet weak var logChangeNameButton: UIButton!
    @IBOutlet weak var logShareButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Log Data Management")
        loadLogDataComponents()
        self.logDataTableView.register(UINib(nibName: "KSCheckBoxWithLabelCellTableViewCell", bundle: nil), forCellReuseIdentifier: "KSCheckBoxWithLabelCellTableViewCell")
    }

    // Configure log data UI components.
    fileprivate func loadLogDataComponents() {
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.logTopView.layer.cornerRadius = 6
        self.topViewLogTitle.text = "Log Data(s)"
        self.logDeleteButton.setTitle("Delete", for: .normal)
        self.logChangeNameButton.setTitle("Change Name", for: .normal)
    }
    // User can delete single as well as multiple data files.
    @IBAction func deleteLogDataFiles(_ sender: Any) {
    }

    // At a time user can edit only single datafile name from the list.
    @IBAction func changeLogFileName(_ sender: Any) {
    }

    // Click on this button to share single and mutiple data files based on user selection.
    @IBAction func shareLogFiles(_ sender: Any) {
    }
}

// MARK: Tableview Delegate
extension KSLogDataManagement: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let theParameterCell = tableView.dequeueReusableCell(withIdentifier: "KSCheckBoxWithLabelCellTableViewCell") as! KSCheckBoxWithLabelCellTableViewCell
        return theParameterCell
    }
}
