//
//  KSConfiguration.swift
//  KobelcoService
//
//  Created by Swaminath on 9/27/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSConfiguration: UIViewController {

    @IBOutlet weak var tableViewConfiguration: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.setNavigationBarColorWithButtonTitle(buttonTitle: localizedKey("Configuration"))
        self.navigationItem.hidesBackButton = true
        KSSingletonManager.shared.currentScreenName = "KSConfiguration"
        //Adding tableview corner radius and row height
        tableViewConfiguration.layer.cornerRadius = 8
        tableViewConfiguration.rowHeight = 55
        self.configureConfiguarationGestureRecognizers()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        KSSingletonManager.shared.configurationNavigationID = self.navigationController?.getScreenNavigationID() ?? 3
    }
    // Configure gesture recognizer for UIView
    fileprivate func configureConfiguarationGestureRecognizers() {
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(respondToConfigSwipeGesture))
        swipeRight.direction = .right
        self.view.addGestureRecognizer(swipeRight)
        
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(respondToConfigSwipeGesture))
        swipeLeft.direction = .left
        self.view.addGestureRecognizer(swipeLeft)
    }
    // Navigate to particular screen based on swipe direction.
    @objc func respondToConfigSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case .right:
                //self.popOverToBackScreen(indexValue: KSSingletonManager.shared.dataComparisionID)
                self.navigation(to: Identifier.dataComparision, isSwiped: true, rightSwipe: SwipeIdentifiers.left.rawValue)
            case .left:
                self.navigation(to: Identifier.dashboardScreen)
            default:
                break
            }
        }
    }
}

// MARK: KSConfigurationExtension for tableviewdelegates
extension KSConfiguration: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return CONFIGURATIONLIST.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: "Cell")
        cell.accessoryType = .disclosureIndicator
        cell.textLabel?.text = CONFIGURATIONLIST[indexPath.row]
        cell.textLabel?.font = UIFont.regular(ofSize: 15)
        cell.selectionStyle = .none
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // Navigate to particular screen based on index selection.
        switch indexPath.row {
        case 0:
            break
        case 1:
            break
        case 2:
            // self.navigation(to: Identifier.normalData)
            break
        case 3:
            // self.navigation(to: Identifier.logData)
            break
        case 4:
            // self.navigation(to: Identifier.parameterRegistration)
            // CONFIGURATIONSTORYBOARD -> Parameter Registration
            self.navigationToConfigurationStoryboard(to: Identifier.parameterRegistration)
        case 5:
            break
        default:
            break
        }
    }
}
