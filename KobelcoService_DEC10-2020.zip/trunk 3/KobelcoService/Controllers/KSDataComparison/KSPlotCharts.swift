//
//  KSPlotCharts.swift
//  KobelcoService
//
//  Created by Swaminath on 10/6/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit
import Charts

class LegendDataSet: NSObject {
    var legendColor: UIColor = .clear
    var legendName: String = ""
}

@objc protocol KSPlotChartsDelegate {
    func sendSelectedParameter(selectedIndex: Int)
}

class KSPlotCharts: UIViewController, KSPlotChartsDelegate {

    @IBOutlet weak var selectParameterTextField: UITextField!
    @IBOutlet weak var shareGraphButton: UIButton!
    @IBOutlet weak var selectGraphTypeSegment: UISegmentedControl!
    @IBOutlet weak var chartView: LineChartView!
    @IBOutlet weak var plusButton: UIButton!
    @IBOutlet weak var minusButton: UIButton!
    @IBOutlet weak var centerLabel: UILabel!
    @IBOutlet weak var bottomLabel: UILabel!
    
    var graphDictionaryValues = [String: GraphData]()
    var legendDataSetObject: [LegendDataSet] = []
    var lineChartData: [LineChartDataSet] = []
    var selectedGraphArray = [NSURL]()
    @IBOutlet weak var tableView: UITableView!
    // Type 2 Graph
    var uniqueSignalNames = [String]()
    var fileNameAndPoints = [String: Any]()
    // Points plot limit
    var pointsLimit = 500
    var fromPointsDisplay = 0
    var toPointsDisplay = 0
    var pointNo = 0
    var typeOneGraphLastIndex = 0
    var typeTwoGraphLastIndex = 0

    // MARK: - View life cycle events
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        chartView.backgroundColor = .white
        self.setNavigationBarColorWithButtonTitle(buttonTitle: localizedKey("DataComparision"))
        self.selectGraphTypeSegment.setTitle(localizedKey("Type1text"), forSegmentAt: 0)
        self.selectGraphTypeSegment.setTitle(localizedKey("Type2text"), forSegmentAt: 1)
        self.selectGraphTypeSegment.layer.cornerRadius = 6
        self.selectGraphTypeSegment.setSegmentTintColors()
        self.shareGraphButton.isEnabled = false
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.selectParameterTextField.text = self.getStringFormURLDeletingPathExtension(url: self.selectedGraphArray[0])
        self.centerLabel.text = ""
        self.bottomLabel.text = ""
        self.configurePlotchartsGestureRecognizers()
        self.setupInitialGraphData()
        self.loadJsonFileAndDrawGraph(selectedIndex: self.typeOneGraphLastIndex)
        self.getUniqueSignalNames()
    }

    func getStringFormURLDeletingPathExtension(url: NSURL) -> String {
        return (url.lastPathComponent! as NSString).deletingPathExtension
    }

    // Configure gesture recognizer for UIView
    fileprivate func configurePlotchartsGestureRecognizers() {
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(respondToPlotChartsSwipeGesture))
        swipeRight.direction = .right
        self.view.addGestureRecognizer(swipeRight)
        
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(respondToPlotChartsSwipeGesture))
        swipeLeft.direction = .left
        self.view.addGestureRecognizer(swipeLeft)
    }
    // Navigate to particular screen based on swipe direction.
    @objc func respondToPlotChartsSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case .right:
                self.navigation(to: Identifier.dataComparision, isSwiped: true)
            case .left:
                self.navigationToConfigurationStoryboard(to: Identifier.configuration)
            default:
                break
            }
        }
    }
    // MARK: - Buttons action
    @IBAction func pluse500Action(_ sender: Any) {
        self.showLoaderWithoutThread()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.fromPointsDisplay += self.pointsLimit
            self.drawLineChart()
        }
    }

    @IBAction func minus500Action(_ sender: Any) {
        showLoaderWithoutThread()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.fromPointsDisplay -= self.pointsLimit
            self.drawLineChart()
        }
    }

    @IBAction func SelectGraphTypeSegmentAction(_ sender: Any) {
        if selectGraphTypeSegment.selectedSegmentIndex == 1 {
            self.drawTypeTwoGraph(selectedIndex: self.typeTwoGraphLastIndex)
        } else {
            self.loadJsonFileAndDrawGraph(selectedIndex: self.typeOneGraphLastIndex)
        }
    }
    
    @IBAction func openiPhoneShareOptionsButtonAction(_ sender: UIButton) {
    }

    func getUniqueSignalNames() {
        var arrayOfAllLegends = [[String: Any]]()
        for file in self.selectedGraphArray {
            KSSingletonManager.shared.loadJsonFileFromURL(filename: file) { (data) in
                guard let jsonDictionary = self.convertDataToDictionary(data: data) else { return }
                let dataValues = jsonDictionary["data"] as! [[String: Any]]
                _ = dataValues.map {arrayOfAllLegends.append($0)}
                print("arrayOfAllLegends \(arrayOfAllLegends)")
                self.fileNameAndPoints[self.getStringFormURLDeletingPathExtension(url: file)] = dataValues
            }
        }

        let signalNames: [String] = arrayOfAllLegends.map { $0["signalName"] as! String }
        self.uniqueSignalNames = Array(Set(signalNames))
        self.uniqueSignalNames = self.uniqueSignalNames.sorted(by: <)
    }

    func loadJsonFileAndDrawGraph(selectedIndex: Int) {
        self.showLoaderWithoutThread()
        self.selectParameterTextField.text = self.getStringFormURLDeletingPathExtension(url: self.selectedGraphArray[selectedIndex])
        DispatchQueue.main.async {
            KSSingletonManager.shared.loadJsonFileFromURL(filename: self.selectedGraphArray[selectedIndex]) { (data) in
                guard let jsonDictionary = self.convertDataToDictionary(data: data) else { return }
                //print("jsonDictionary \(jsonDictionary)")
                let dataValues = jsonDictionary["data"] as! [[String: Any]]
                self.graphDictionaryValues.removeAll()
                for value in dataValues {
                    guard let getValuesArray = value["signalValues"] as? [Int] else { return }
                    guard let getSignalName = value["signalName"] as? String else { return }
                    guard let getSignalColorInHex = value["signalColor"] as? String else { return }
                    let graphData = GraphData(legendColor: UIColor.colorFromHexString(getSignalColorInHex), legendPoints: getValuesArray)
                    self.graphDictionaryValues[getSignalName] = graphData
                    self.pointNo = getValuesArray.count
                }
            }
            self.fromPointsDisplay = 0
            self.drawLineChart()
        }
    }

    func setupInitialGraphData() {
        self.centerLabel.rotate(degrees: 90, clockwise: false)
        chartView.chartDescription?.enabled = false
        chartView.dragEnabled = true
        chartView.setScaleEnabled(true)
        chartView.pinchZoomEnabled = true
        chartView.legend.enabled = false
        chartView.rightAxis.enabled = false
        chartView.drawBordersEnabled = true
        chartView.borderColor = NSUIColor.gray
        chartView.drawGridBackgroundEnabled = true
        let leftAxis = chartView.leftAxis
        leftAxis.drawGridLinesEnabled = true
        leftAxis.granularityEnabled = true
    }
    
    func drawLineChart () {
        self.centerLabel.text = self.selectParameterTextField.text!
        self.bottomLabel.text = "Time (Seconds)"
        let xAxis = chartView.xAxis
        xAxis.labelPosition = .bottom
        xAxis.drawAxisLineEnabled = true
        if self.fromPointsDisplay + self.pointsLimit < self.pointNo {
            self.toPointsDisplay = self.fromPointsDisplay + self.pointsLimit
            self.plusButton.isEnabled = true
            self.plusButton.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
        } else {
            self.toPointsDisplay = self.pointNo
            self.plusButton.isEnabled = false
            self.plusButton.setTitleColor(DISBALECOLOR, for: .normal)
        }
        
        xAxis.axisMinimum = Double(self.fromPointsDisplay)
        xAxis.axisMaximum = Double(self.toPointsDisplay)
        xAxis.valueFormatter = XAxisValueFormatterForLineChart()

        self.setDataCount()
    }

    func setDataCount() {
        self.legendDataSetObject = []
        self.lineChartData = []

        for (key, values) in self.graphDictionaryValues {
            print("key --> \(key) values --> \(values)")
            var yVals1 = [ChartDataEntry.init()]
            if self.selectGraphTypeSegment.selectedSegmentIndex == 0 {
                yVals1 = (self.fromPointsDisplay..<self.toPointsDisplay).map { (i) -> ChartDataEntry in
                    return ChartDataEntry(x: Double(i), y: Double(values.legendPoints[i]))
                }
            } else {
                yVals1 = (0..<values.legendPoints.count).map { (i) -> ChartDataEntry in
                    return ChartDataEntry(x: Double(i), y: Double(values.legendPoints[i]))
                }
            }

            let lds = LegendDataSet()
            lds.legendName = key
            lds.legendColor = values.legendColor

            let set1 = LineChartDataSet(entries: yVals1, label: "\(key)")
            set1.axisDependency = .right
            set1.setColor(values.legendColor)
            set1.lineWidth = 1
            set1.highlightEnabled = false
            set1.drawValuesEnabled = false
            set1.drawCirclesEnabled = false
            set1.drawCircleHoleEnabled = false
            self.lineChartData.append(set1)
            self.legendDataSetObject.append(lds)
        }

        let data = LineChartData(dataSets: self.lineChartData)
        //data.setValueTextColor(.black)
        //data.setValueFont(.systemFont(ofSize: 9))

        chartView.data = data
        self.legendDataSetObject = self.legendDataSetObject.sorted { $0.legendName < $1.legendName }

        self.tableView.reloadData()
        if fromPointsDisplay == 0 {
            self.minusButton.isEnabled = false
            self.minusButton.setTitleColor(DISBALECOLOR, for: .normal)
        } else {
            self.minusButton.isEnabled = true
            self.minusButton.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
        }
        self.hideLoader()
    }

    // Called when selection of parameter from tableview list and display the selected parameter on textfield.
    func sendSelectedParameter(selectedIndex: Int) {
        DispatchQueue.main.async {
            self.showLoaderWithoutThread()
            if self.selectGraphTypeSegment.selectedSegmentIndex == 0 {
                self.typeOneGraphLastIndex = selectedIndex
                self.loadJsonFileAndDrawGraph(selectedIndex: self.typeOneGraphLastIndex)
            } else {
                self.typeTwoGraphLastIndex = selectedIndex
                self.drawTypeTwoGraph(selectedIndex: self.typeTwoGraphLastIndex)
            }
        }
    }

    func drawTypeTwoGraph(selectedIndex: Int) {
        showLoaderWithoutThread()
        self.selectParameterTextField.text = self.uniqueSignalNames[self.typeTwoGraphLastIndex]

        DispatchQueue.main.async {
            var finalGraphData = [String: GraphData]()
            self.fromPointsDisplay = 0
            self.pointNo = 0
            for (key, value) in self.fileNameAndPoints {
                print("key \(key), value \(value)")
                let val = value as! [[String: Any]]
                let item = val.filter {($0["signalName"] as! String) == self.selectParameterTextField.text}
                if item.count != 0 {
                    guard let getValuesArray = item[0]["signalValues"] as? [Int] else { return }
                    guard let getSignalColorInHex = item[0]["signalColor"] as? String else { return }
                    finalGraphData[key] = GraphData(legendColor: UIColor.colorFromHexString(getSignalColorInHex), legendPoints: getValuesArray)
                    print("finalGraphData \(finalGraphData)")
                }
            }
            self.graphDictionaryValues.removeAll()
            for (key, value) in finalGraphData {
                if self.pointNo < value.legendPoints.count {
                    self.pointNo = value.legendPoints.count
                }
                self.graphDictionaryValues[key] = value
            }

            self.drawLineChart()
        }
    }
}

// MARK: Textfield delegate
extension KSPlotCharts: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField.text?.count == 0 && string == " " {
            return false
        }
        return true
    }
    // Tap on textfield to call tableview controller method.
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if textField == selectParameterTextField {
            presentModelTypeOrAreaController()
        }
        return false
    }
    // Load tableview items based on textfield selection.
    func presentModelTypeOrAreaController() {
        let parametersTableView = MAINSTORYBOARD.instantiateViewController(withIdentifier: Identifier.dataParametersList.rawValue) as! KSDataParameterList
        parametersTableView.delegate = self
        if self.selectGraphTypeSegment.selectedSegmentIndex == 0 {
            parametersTableView.totalParametersList = self.selectedGraphArray.map { self.getStringFormURLDeletingPathExtension(url: $0) }
        } else {
            parametersTableView.totalParametersList = self.uniqueSignalNames
        }
        self.present(parametersTableView, animated: true, completion: nil)
    }
}

extension KSPlotCharts: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.graphDictionaryValues.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "KSLegendCell", for: indexPath) as! KSLegendCell
        cell.fillCellData(legendDataSet: legendDataSetObject[indexPath.row])
        return cell
    }
}
//
class ExtendIAxisValueFormatter: NSObject, IAxisValueFormatter {
    func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        return "\(value)"
    }
}
class XAxisValueFormatterForLineChart: ExtendIAxisValueFormatter {
    public override func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        var msToSeconds = Int(value * 50.0)
        msToSeconds = Int(msToSeconds.msToSeconds)
        print("value --> \(value)")
        print("msToSeconds --> \(msToSeconds)")
        print("msToSeconds.msToSeconds --> \(msToSeconds.msToSeconds)")
//        print("msToSeconds \(msToSeconds.msToSeconds)")
        if msToSeconds < 1 {
            if value == axis?.axisMinimum {
                return "0"
            } else if value == axis?.axisMaximum {
                return "1"
            }
//            if msToSeconds.msToSeconds < 0.0 {
//                return ""
//            } else if msToSeconds.msToSeconds == 0.0 {
//                return "0"
//            }
//
//            return "\(msToSeconds.msToSeconds)"
        }
        return "\(msToSeconds)"
    }
}
