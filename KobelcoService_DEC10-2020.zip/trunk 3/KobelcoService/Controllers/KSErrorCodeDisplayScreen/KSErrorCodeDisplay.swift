//
//  KSErrorCodeDisplay.swift
//  KobelcoService
//
//  Created by Guest L&T on 14/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

class KSErrorCodeDisplay: UIViewController {
    
    @IBOutlet var errorCodeBGView: UIView!
    @IBOutlet weak var labelErrorCodeDisplay: UILabel!
    @IBOutlet weak var segmentController: UISegmentedControl!
    @IBOutlet weak var buttonCurrent: UIButton!
    @IBOutlet weak var buttonPast: UIButton!
    @IBOutlet weak var buttonReset: UIButton!
    @IBOutlet weak var tableViewCodes: UITableView!
    fileprivate let tableViewBackgroundView = UIView()
    fileprivate var errorCodesArray = [[String: Any]]()
    fileprivate var filteredErrorCodes = [[String: Any]]()
    fileprivate var responseErrorCodes = [String]()
    fileprivate var errorCodeViewCanSwipe: Bool = false
    fileprivate var deviceType = "ALL"
    fileprivate var frameType = "ActiveErrorCountRequest"
    fileprivate var periodicityValue = 100
    fileprivate var errorcodeModel: ErrorcodeResponse?
    fileprivate var errorCodeResponseTimer: Timer?
    fileprivate var isErrorCodePeriodicty: Bool = false

    @IBOutlet weak var errocode_HeightCon: NSLayoutConstraint!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.errorCodeBGView.backgroundColor = VIEWBACKGROUNDCOLOR
        self.setNavigationBarColorWithButtonTitle(buttonTitle: localizedKey("ErrorCodeDisplayText"))
        self.navigationItem.hidesBackButton = true // hide navigation bar back button
        self.navigationController?.getErrorCodeNavigationID() // To identify the navaigation index for errorcode screen
        loadErrorCodeUIComponents()
        self.tableViewCodes.rowHeight = 80
        KSSingletonManager.shared.delegate = self
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        isErrorCodePeriodicty = false
        self.hideLoader()
    }
    // AutoHide iPhoneX/Pro Footer Line.
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
    // Configure ErrorCode UI-Elements.
    fileprivate func loadErrorCodeUIComponents() {
        self.segmentController.layer.cornerRadius = 6
        self.segmentController.setSegmentTintColors()
        setCornorRadius(button: buttonCurrent)
        errocode_HeightCon.constant = 0
        self.segmentController.setTitle(localizedKey("All"), forSegmentAt: 0)
        self.buttonCurrent.setTitle(localizedKey("CurrentText"), for: .normal)
        self.buttonPast.setTitle(localizedKey("PastText"), for: .normal)
        self.buttonReset.setTitle(localizedKey("AllResetText"), for: .normal)
        self.buttonReset.titleLabel?.lineBreakMode = .byWordWrapping
        self.buttonReset.titleLabel?.numberOfLines = 0
        self.buttonReset.titleLabel?.adjustsFontSizeToFitWidth = true
        // Configure swipe geture for uiview
        configureGestureRecognizers()
    }
    // Configure gesture recognizer for UIView
    fileprivate func configureGestureRecognizers() {
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(respondToSwipeGesture))
        swipeRight.direction = .right
        self.view.addGestureRecognizer(swipeRight)
        
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(respondToSwipeGesture))
        swipeLeft.direction = .left
        self.view.addGestureRecognizer(swipeLeft)
    }
    // Navigate to particular screen based on swipe direction.
    @objc func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if errorCodeViewCanSwipe {
            if let swipeGesture = gesture as? UISwipeGestureRecognizer {
                 switch swipeGesture.direction {
                 case .right:
                    self.popOverToBackScreen(indexValue: KSSingletonManager.shared.dashboardNavigationID)
                 case .left:
                     self.navigation(to: Identifier.memoryResetScreen)
                 default:
                     break
                 }
             }
        }
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        KSSingletonManager.shared.delegate = self
        self.navigationController?.getErrorCodeNavigationID() // To identify the navaigation index for errorcode screen
        errorCodeViewCanSwipe = false
        //Swami
        self.showLoader()
        //KSSingletonManager.shared.connectWebSocket()
        //self.perform(#selector(sendAllActiveErrorCodeCommand), with: self, afterDelay: 0.1)
        self.sendAllActiveErrorCodeCommand()
        DispatchQueue.main.async {
            self.errorCodesArray.removeAll(keepingCapacity: false)
            KSSingletonManager.shared.loadJson(filename: ERRORCODESFILES) { (errorCodesData) in
                guard let errorCodesJSON = self.convertDataToDictionary(data: errorCodesData) else { return }
                guard let errorCodesList = errorCodesJSON["KSErrorCodesArray"] as? [[String: Any]] else { return }
                self.errorCodesArray.append(contentsOf: errorCodesList)
            }
        }
    }
    // Start websocket request.
    @objc func sendAllActiveErrorCodeCommand() {
        startPeriodictyErrorCodeResponseTimer()
        self.sendCommand(frameName: frameType, deviceName: deviceType, interval: periodicityValue)
    }
    
    // Reusable function for all errorcodes websocket request
    func sendCommand(frameName: String, deviceName: String, interval: Int) {
        self.showLoader()
        errorCodeViewCanSwipe = false
        let errorCodeCommand = SocketRequestDict(screenName: "ErrorCodeDisplay", frameType: frameName, device: deviceName, periodicity: interval)
        guard let errorCodeRequestData = try? JSONEncoder().encode(errorCodeCommand) else { return }
        KSSingletonManager.shared.sendCommand(format: errorCodeRequestData)
    }
    @IBAction func segmentIndexChanged(_ sender: UISegmentedControl) {
        //responseErrorCodes.removeAll(keepingCapacity: false)
        self.segmentController.isEnabled = false
        switch segmentController.selectedSegmentIndex {
        case 0:
            deviceType = "ALL"
            sendCommand(frameName: frameType, deviceName: deviceType, interval: periodicityValue)
        case 1:
            deviceType = "ECU"
            sendCommand(frameName: frameType, deviceName: deviceType, interval: periodicityValue)
        case 2:
            deviceType = "DCU"
            sendCommand(frameName: frameType, deviceName: deviceType, interval: periodicityValue)
        default:
            break
        }
    }
    // Start repeated periodicty responser timer for every 1 second.
    func startPeriodictyErrorCodeResponseTimer() {
        errorCodeResponseTimer = Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: #selector(checkErrorCodePeriodicResponseTimeOut), userInfo: nil, repeats: true)
    }
    // Invalidate periodicity response timer when there is no reponse from websocket after 1 second.
    @objc func checkErrorCodePeriodicResponseTimeOut() {
        if !isErrorCodePeriodicty {
            self.invalidateErrorCodePeriodicResponseTimer()
            presentAlertOKAction(withTitle: ERRORTITLE, message: SOCKETRESPONSETIMEOUT) { (_ ) in
                KSSingletonManager.shared.connectWebSocket()
            }
        }
        self.isErrorCodePeriodicty = false
    }
    @IBAction func currentButtonTapped(_ sender: UIButton) {
        startPeriodictyErrorCodeResponseTimer()
        resetButtonTitleColors()
        setCornorRadius(button: sender)
        frameType = "ActiveErrorCountRequest"
        periodicityValue = 200
        self.sendCommand(frameName: frameType, deviceName: self.deviceType, interval: periodicityValue)
    }
    @IBAction func pastButtonTapped(_ sender: UIButton) {
        invalidateErrorCodePeriodicResponseTimer()
        resetButtonTitleColors()
        setCornorRadius(button: sender)
        buttonReset.setTitleColor(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0), for: .normal)
        buttonReset.isEnabled = true
        frameType = "PastErrorCodeRequest"
        periodicityValue = 200
        self.sendCommand(frameName: frameType, deviceName: deviceType, interval: periodicityValue)
    }
    @IBAction func resetButtonTapped(_ sender: UIButton) {
        invalidateErrorCodePeriodicResponseTimer()
        if responseErrorCodes.count > 0 {
            let alert = UIAlertController(title: CONFIRMATIONTITLE, message: MRCONFIRMATIONALERT, preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: CANCELTITLE, style: UIAlertAction.Style.default, handler: { _ in
                //Cancel Action
            }))
            alert.addAction(UIAlertAction(title: CLEARTITLE, style: UIAlertAction.Style.destructive, handler: {(_: UIAlertAction!) in
                self.sendCommand(frameName: "ResetPastErrorRequest", deviceName: self.deviceType, interval: self.periodicityValue)
            }))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    // Reset all button selection.//9A9A9A
    fileprivate func resetButtonTitleColors() {
        self.enableFooterButtons(isEnabled: false)
        self.buttonCurrent.setPlainStyle()
        self.buttonPast.setPlainStyle()
        self.buttonReset.setTitleColor(#colorLiteral(red: 0.6039215686, green: 0.6039215686, blue: 0.6039215686, alpha: 1), for: .normal)
    }
    // Set button selection style.
    fileprivate func setCornorRadius(button: UIButton) {
        buttonReset.isEnabled = false
        button.addButtonCornerRadius(cornerRadius: 20, borderWidth: 1, buttonBorderColor: #colorLiteral(red: 0, green: 0.5690457821, blue: 0.5746168494, alpha: 1), backgroundColor: #colorLiteral(red: 0, green: 0.7005334496, blue: 0.723967135, alpha: 1), textColor: #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1))
    }
    // Enable/disable the current and past footer buttons
    fileprivate func enableFooterButtons(isEnabled: Bool) {
        buttonCurrent.isEnabled = isEnabled
        buttonPast.isEnabled = isEnabled
    }
}

// MARK: TableView delegates
extension KSErrorCodeDisplay: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if responseErrorCodes.count == 0 {
            DispatchQueue.main.async {
                self.tableViewCodes.backgroundView =  KSSingletonManager.shared.nullDataFilesLabel(message: self.localizedKey("NoRecordsText"))
            }
        } else {
            tableViewCodes.backgroundView = nil
        }
        return responseErrorCodes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "KSErrorCodeCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as! KSErrorCodeCell
        if responseErrorCodes.count > 0 {
            print("responseErrorCodes: \(responseErrorCodes)")
            let errorDescription = getErrorCodeDescription(errorCode: responseErrorCodes[indexPath.row])
            print("errorDescription: \(errorDescription)")
            cell.configureCell(errorCode: responseErrorCodes[indexPath.row], description: errorDescription)
        }
        return cell
    }
    func getErrorCodeDescription(errorCode: String) -> String {
        let errorCodeObject = errorCodesArray.filter({(dataDict: [String: Any]) -> Bool in
            return (dataDict["errorCode"] as! String).range(of: errorCode, options: .caseInsensitive) != nil
        })
        if errorCodeObject.count > 0 {
            guard let descriptionObject = errorCodeObject[0]["description"] as? [String: Any] else { return "--" }
            guard let description = descriptionObject[KSSingletonManager.shared.languageCode] as? String else { return "--"}
            return description
        } else {
            return "--"
        }
    }
    // Invalidate the assigned current error codes timer.
    func invalidateErrorCodePeriodicResponseTimer() {
        errorCodeResponseTimer?.invalidate()
        errorCodeResponseTimer = nil
    }
}

// MARK: WebSocket Response Delegate
extension KSErrorCodeDisplay: KSWebSocketDelegates {
    func webSocketStringResponse(response: String) {
        print("response: \(response)")
        if response == "Connection Opened" {
            self.hideLoader()
        }
        guard let jsonDictionary = convertToDictionary(text: response) else { return }
        guard let screenTitle = jsonDictionary["screenName"] as? String else { return }
        guard let frameName = jsonDictionary["frameType"] as? String else { return }
        errorCodeViewCanSwipe = true
        if screenTitle == "ErrorCodeDisplay" {
            if frameName.contains("Reset") {
                guard let status = jsonDictionary["status"] as? String else { return }
                if status == "Accepted" {
                    responseErrorCodes.removeAll(keepingCapacity: false)
                } else {
                    self.presentAlert(withTitle: ALERTTITLESTRING, message: "Unable to clear past records, please try after sometime.")
                }
            } else {
                if let data = response.data(using: String.Encoding.utf8) {
                     do {
                        responseErrorCodes.removeAll(keepingCapacity: false)
                        self.errorcodeModel = try JSONDecoder().decode(ErrorcodeResponse.self, from: data)
                        if let ecuCodes = self.errorcodeModel?.ecuErrorCodes {
                            responseErrorCodes.append(contentsOf: ecuCodes)
                        }
                        if let dcuCodes = self.errorcodeModel?.dcuErrorCodes {
                            responseErrorCodes.append(contentsOf: dcuCodes)
                        }
                     } catch let error as NSError {
                        print("error.localizedDescription: \(error.localizedDescription)")
                        self.presentAlert(withTitle: ERRORTITLE, message: error.localizedDescription)
                    }
                 }
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                self.hideLoader()
                print("Reload tableViewCodes")
                self.tableViewCodes.reloadData()
                self.tableViewCodes.isHidden = false
                self.segmentController.isEnabled = true
                self.enableFooterButtons(isEnabled: true)
                self.isErrorCodePeriodicty = true
            }
         }
    }
    // Called when error connection in websocket communication
    func webSocketErrorConnection(message: String) {
        self.hideLoader()
        self.enableFooterButtons(isEnabled: true)
        presentAlertOKAction(withTitle: ERRORTITLE, message: message) { (_ ) in
            self.showLoader()
            KSSingletonManager.shared.connectWebSocket()
        }
    }
    // Called when internet is disconnected or network not reachable.
    func internetConnectionNotAvailable() {
        self.hideLoader()
        self.enableFooterButtons(isEnabled: true)
        presentAlertOKAction(withTitle: ERRORTITLE, message: WIFIDISCONNECTEDMESSAGE) { (isOkTapped) in
            if isOkTapped {
                self.navigateToWiFiSettings()
            }
        }
    }
    // Websocket response timeout alert.
     func noWebSocketResponse(message: String) {
         self.hideLoader()
        self.enableFooterButtons(isEnabled: true)
         presentAlert(withTitle: ERRORTITLE, message: message)
     }
}
