//
//  KSProgressIndicatorView.swift
//  KobelcoService
//
//  Created by Guest L&T on 22/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSProgressIndicatorView: UIView {

    @IBOutlet weak var indicatorBGView: UIView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var labelLoading: UILabel!

    public func prepareIndicator() {
        // Set transparent view background color.
        self.backgroundColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 0.04518942637)
        
        // Adding corner radius to activity indicator view.
        indicatorBGView.layer.borderWidth = 0.5
        indicatorBGView.layer.borderColor = UIColor.lightGray.cgColor
        indicatorBGView.backgroundColor = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
        indicatorBGView?.clipsToBounds = true
        indicatorBGView?.layer.cornerRadius = 8.0
        
        // Adding loading label text as a subview on bottom of the indicator view.
        labelLoading?.backgroundColor = UIColor.clear
        labelLoading?.textColor = .black
        labelLoading?.adjustsFontSizeToFitWidth = true
        labelLoading?.font = UIFont.bold(ofSize: 14)
        labelLoading?.textAlignment = .center
        labelLoading?.text = LOADINGTITLE
        self.setIndicatorFrame()
       }
       
       // Setting the main view frame 
       public func setIndicatorFrame() {
           self.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
       }
}
