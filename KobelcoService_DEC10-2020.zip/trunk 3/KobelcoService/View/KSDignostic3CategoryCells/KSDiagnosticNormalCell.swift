//
//  KSDiagnosticNormalCell.swift
//  KobelcoService
//
//  Created by Guest L&T on 08/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSDiagnosticNormalCell: UITableViewCell {

    @IBOutlet weak var normalBGView: UIView!
    @IBOutlet weak var normalCellTitle: UIButton!
    @IBOutlet weak var normalCellValue: UILabel!
    @IBOutlet weak var normalCellUnit: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.normalBGView.layer.cornerRadius = 6
    }
    
    // Update diagnostic normal type cell components.
    func configureDiagnosticNormalCell(normalObject: [String: Any], itemValue: Int) {
        guard let normalDict = normalObject["name"] as? [String: Any] else { return }
        guard let normalName = normalDict[KSSingletonManager.shared.languageCode] as? String else { return }
        guard let normalUnit = normalObject["unit"] as? String else { return }
        let value = itemValue == 0 ? "-" : String(itemValue)
        self.normalCellTitle.setTitle(normalName, for: .normal)
        self.normalCellValue.text = value
        self.normalCellUnit.text = normalUnit
    }
}

class KSDiagnosticSwitchCell: UITableViewCell {
    @IBOutlet weak var switchBGView: UIView!
    @IBOutlet weak var switchCellTitle: UIButton!
    @IBOutlet weak var switchToggleButton: UISwitch!
    @IBOutlet weak var switchCellUnit: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.switchBGView.layer.cornerRadius = 6
        self.switchCellUnit.text = "-"
    }
    
    // Update diagnostic switch type cell components.
    func configureDiagnosticSwitchCell(switchObject: [String: Any], switchInput: Int) {
        guard let switchDict = switchObject["name"] as? [String: Any] else { return }
        guard let switchName = switchDict[KSSingletonManager.shared.languageCode] as? String else { return }
        let switchValue = switchInput == 0 ? false : true
        self.switchCellTitle.setTitle(switchName, for: .normal)
        self.switchToggleButton.isOn = switchValue
    }
}
