//
//  KSMemoryResetCell.swift
//  KobelcoService
//
//  Created by Guest L&T on 23/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

// MARK: Disclosure type cell
class KSMemoryResetCell: UITableViewCell {

    @IBOutlet weak var labelTitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        labelTitle.font = UIFont.regular(ofSize: 15)
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }

    func configureCellTitle(titleString: String) {
        labelTitle.text = titleString
        labelTitle.textColor = .black
    }
}

// MARK: Switch type cell
class KSMemoryResetSwitchCell: UITableViewCell {
    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var switchOnOff: UISwitch!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        labelTitle.font = UIFont.regular(ofSize: 15)
        labelTitle.lineBreakMode = .byWordWrapping
        labelTitle.numberOfLines = 0
        switchOnOff.isOn = false
        self.tintColor = #colorLiteral(red: 0, green: 0.7005334496, blue: 0.723967135, alpha: 1)
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    func configureSwitchCellTitle(titleString: String) {
        labelTitle.text = titleString
        labelTitle.textColor = .black
     }
}
