//
//  KSViewController+Design.swift
//  KobelcoService
//
//  Created by Guest L&T on 14/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
import UIKit
import EFAutoScrollLabel

extension UIViewController {
        
    // ReusableAlert without button action
    func presentAlert(withTitle title: String, message: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default) { _ in
        }
        alertController.addAction(OKAction)
        self.present(alertController, animated: true, completion: nil)
    }
    // ReusableAlert without button action
    func presentAlertOKAction(withTitle title: String, message: String, completionHandler: @escaping (Bool) -> Void) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default) { _ in
            completionHandler(true)
        }
        alertController.addAction(OKAction)
        self.present(alertController, animated: true, completion: nil)
    }

    // Reuable 2 titles alert with return action
    func presentAlertWithAction(title: String, message: String, action1Title: String, action2Title: String, completionHandler: @escaping (Bool) -> Void) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: action1Title, style: .default) { _ in
            completionHandler(false)
        }
        let OKAction = UIAlertAction(title: action2Title, style: .destructive) { _ in
            completionHandler(true)
        }
        alertController.addAction(cancelAction)
        alertController.addAction(OKAction)
        self.present(alertController, animated: true, completion: nil)
    }
    // AlertView with 2 titles.
    func presentAttributedStringAlert(message1: String, message2: String, completionHandler: @escaping (Bool) -> Void) {
        let textAttributeForTitle = [NSAttributedString.Key.foregroundColor: UIColor.black, NSAttributedString.Key.font: UIFont.bold(ofSize: 16)]
        let textAttributeForMessage = [NSAttributedString.Key.foregroundColor: UIColor.darkGray, NSAttributedString.Key.font: UIFont.regular(ofSize: 15)]

        let title1 = NSMutableAttributedString(string: localizedKey("ExplanationTitle"), attributes: textAttributeForTitle)
        let description1 = NSMutableAttributedString(string: "\n\n\(message1)\n\n", attributes: textAttributeForMessage)
        let title2 = NSMutableAttributedString(string: localizedKey("AttentionText"), attributes: textAttributeForTitle)
        let description2 = NSMutableAttributedString(string: "\n\n\(message2)", attributes: textAttributeForMessage)

        let attributedText = NSMutableAttributedString()
        attributedText.append(title1)
        attributedText.append(description1)
        attributedText.append(title2)
        attributedText.append(description2)

        let alertController = UIAlertController(title: title, message: "", preferredStyle: .alert)
        alertController.setValue(attributedText, forKey: "attributedMessage")
        let OKAction = UIAlertAction(title: "OK", style: .default) { _ in
            completionHandler(true)
        }
        alertController.addAction(OKAction)
        self.present(alertController, animated: true, completion: nil)
    }

    // ActionSheet for datamonitor stop action.
    func showActionSheet(actionItemIndex: @escaping(Int) -> Void) {
        let actionSheet = UIAlertController(title: nil, message: CHOOSEANYOPTIONTITLE, preferredStyle: .actionSheet)
        for (index, title) in ACTIONSHEETITEMS.enumerated() {
            let itemAction = UIAlertAction(title: title, style: .default) { (_) in
                actionItemIndex(index)
            }
            actionSheet.addAction(itemAction)
        }
        // To avoid iPad crash.
        if let presenter = actionSheet.popoverPresentationController {
            presenter.sourceView = self.view
            presenter.sourceRect = self.view.bounds
        }
        self.present(actionSheet, animated: true, completion: nil)
    }
    
    // Alert view with textfield
    func alertWithTextField(title: String? = nil, message: String? = nil, placeholder: String? = nil, completion: @escaping ((String) -> Void) = { _ in }) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addTextField() { newTextField in
            newTextField.placeholder = placeholder
            newTextField.keyboardType = .default
        }
        alert.addAction(UIAlertAction(title: CANCELTITLE, style: .cancel))

        alert.addAction(UIAlertAction(title: SAVETITLE, style: .default) { _ in
            if let textFields = alert.textFields, let tf = textFields.first, let result = tf.text {
                completion(result)
            } else {
                completion("")
            }
        })
        navigationController?.present(alert, animated: true)
    }

    // Navigation based on dynamic identifier name.
    func navigation(to screenIdentifier: Identifier, navigationTitle: String = "", isSwiped: Bool = false, rightSwipe: String = SwipeIdentifiers.right.rawValue) {
        if screenIdentifier.rawValue == "KSMemoryReset" {
            let memoryResetSubScreen = MAINSTORYBOARD.instantiateViewController(withIdentifier: "KSMemoryReset") as? KSMemoryReset
            memoryResetSubScreen?.navigationTitle = navigationTitle
            self.navigationController?.modalTransitionStyle = isSwiped ? .partialCurl: .coverVertical
            self.navigationController?.pushViewController(memoryResetSubScreen!, animated: true)
        } else {
            let viewController = MAINSTORYBOARD.instantiateViewController(withIdentifier: screenIdentifier.rawValue)
            if isSwiped {
                print("isSwiped: \(isSwiped)")
                let transition = CATransition()
                transition.duration = 0.35
                transition.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.default)
                transition.type = CATransitionType.moveIn
                transition.subtype = ("RightSwipe" == rightSwipe) ? CATransitionSubtype.fromRight : CATransitionSubtype.fromLeft
                self.navigationController?.view.layer.add(transition, forKey: kCATransition)
            }
            self.navigationController?.pushViewController(viewController, animated: isSwiped ? false: true)
        }
    }
    // Navigation for Configuration Storyborad.
    func navigationToConfigurationStoryboard(to screenIdentifier: Identifier) {
        let viewController = CONFIGURATIONSTORYBOARD.instantiateViewController(withIdentifier: screenIdentifier.rawValue)
        self.navigationController?.pushViewController(viewController, animated: true)
    }
    // MARK: - configure navigationbar
    func commonNavigationBarCode() {
        self.navigationController?.setNavigationBarHidden(false, animated: true)
        self.navigationController?.navigationBar.barTintColor = NAVIGATIONBARCOLOR
    }
    // Dashboard navigationItems.
    func setNavigationBarColorAndItems() {
        commonNavigationBarCode()
        self.navigationController?.navigationBar.backItem?.title = "  "
        self.navigationItem.setHidesBackButton(true, animated: true)
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(image: NAVIGATIONLEFTBARLOGO, style: .plain, target: self, action: nil)
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: NAVIGATIONDASHBOARDRIGHTBAR, style: .plain, target: self, action: #selector(navigateToWiFiSettingsScreen))
    }
    // Subscreen navigation bar.
    func setNavigationBarColorWithButtonTitle(buttonTitle: String) {
        commonNavigationBarCode()
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: NAVIGATIONRIGHTBARLOGO, style: .plain, target: self, action: #selector(navigateToDashboard))
        self.navigationItem.setHidesBackButton(false, animated: true)
        self.navigationController?.navigationBar.backItem?.title = "  "
        // Adding scrollable label as navigation title.
        let SCROLLLABEL = EFAutoScrollLabel(frame: CGRect(x: 0, y: 0, width: SCREEN_WIDTH - 100, height: 60))
        SCROLLLABEL.backgroundColor = .clear
        SCROLLLABEL.textColor = .white
        SCROLLLABEL.font = UIFont.medium(ofSize: 16)
        SCROLLLABEL.labelSpacing = 30                       // Distance between start and end labels
        SCROLLLABEL.pauseInterval = 1.5                     // Seconds of pause before scrolling starts again
        SCROLLLABEL.scrollSpeed = 0                        // Pixels per second
        SCROLLLABEL.textAlignment = NSTextAlignment.center    // Centers text when no auto-scrolling is applied
        SCROLLLABEL.fadeLength = 1                         // Length of the left and right edge fade, 0 to disable
        SCROLLLABEL.scrollDirection = EFAutoScrollDirection.left
        SCROLLLABEL.text = buttonTitle
        SCROLLLABEL.isUserInteractionEnabled = true
        self.navigationItem.titleView = SCROLLLABEL
        /*let tap = UITapGestureRecognizer(target: self, action: #selector(self.tapToScrollNavigationTitle(_:)))
        SCROLLLABEL.addGestureRecognizer(tap)*/
    }
    // Tap geture action for errorcodedisplay view.
    /*@objc func tapToScrollNavigationTitle(_ : UITapGestureRecognizer?) {
        KSSingletonManager.shared.toastController = UIAlertController(title: "Title", message: "\(SCROLLLABEL.text ?? "")", preferredStyle: .alert)
        KSSingletonManager.shared.toastController?.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { _ in
            // OK Action
        }))
        self.present(KSSingletonManager.shared.toastController!, animated: true, completion: {
            KSSingletonManager.shared.toastController?.view.superview?.isUserInteractionEnabled = true
            KSSingletonManager.shared.toastController?.view.superview?.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(self.alertClose(_:))))
        })
    }*/
    // Touch outside on view anywhere to hide alertview.
     @objc func alertClose(_ : UITapGestureRecognizer) {
        KSSingletonManager.shared.toastController?.dismiss(animated: true, completion: nil)
    }
    // ConfirmationAlert for Dashboard RightBarItem.
    @objc func navigateToWiFiSettingsScreen() {
        if KSSingletonManager.shared.isOfflineConnection == true {
            self.navigateToWiFiSettings()
        } else {
            let alert = UIAlertController(title: CONFIRMATIONTITLE, message: DASHBOARDWIFIDISCONNECT, preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: CANCELTITLE, style: UIAlertAction.Style.default, handler: { _ in
                // Cancel Action
            }))
            alert.addAction(UIAlertAction(title: YESTITLE, style: UIAlertAction.Style.destructive, handler: {(_: UIAlertAction!) in
                KSSingletonManager.shared.disconnectWebSocket()
                self.navigateToWiFiSettings()
            }))
            self.present(alert, animated: true, completion: nil)
        }
    }
    // Popover Navigation for Dashboard.
    @objc func navigateToDashboard() {
        self.clearAndResetAllDataAndNavigateToDashboard()
    }
    // Reset the dual functionality and clear all global array data.
    func clearAndResetAllDataAndNavigateToDashboard() {
        KSSingletonManager.shared.clearDataMonitorGlobalArrayReadings()
        KSSingletonManager.shared.diagnosticSubMenuArray.removeAll(keepingCapacity: false)
        KSSingletonManager.shared.isDiagnsoticStart = false
        KSSingletonManager.shared.isDataMonitorStart = false
        KSSingletonManager.shared.isDataMonitorType1 = true
        self.navigationController?.popOverToDefaultController(index: KSSingletonManager.shared.dashboardNavigationID)
    }
    // Popover Navigation for WiFiSettings Screen.
    func navigateToWiFiSettings() {
        self.navigationController?.popOverToWiFiSettings(index: KSSingletonManager.shared.wifiSettingsNavigationID)
    }
    // Popover Navigation for ErrorCodes.
    @objc func navigateToErrorCodes() {
        self.navigationController?.popOverToDefaultController(index: KSSingletonManager.shared.errorCodeNavigationID)
    }
    // Popover Navigation for Dashboard.
    @objc func popOverToBackScreen(indexValue: Int) {
        self.navigationController?.popOverToDefaultController(index: indexValue)
    }
    // Reset all screens navigation index value.
    func resetNavigationIndexes() {
        KSSingletonManager.shared.errorCodeNavigationID = KSSingletonManager.shared.dashboardNavigationID
        KSSingletonManager.shared.memoryResetMainScreenID = KSSingletonManager.shared.dashboardNavigationID
        KSSingletonManager.shared.setValueFunctionID = KSSingletonManager.shared.dashboardNavigationID
        KSSingletonManager.shared.diagnosticMainScreenID = KSSingletonManager.shared.dashboardNavigationID
        KSSingletonManager.shared.diagnosticSubScreenID = KSSingletonManager.shared.dashboardNavigationID
        KSSingletonManager.shared.dataMonitorNavigationID = KSSingletonManager.shared.dashboardNavigationID
        KSSingletonManager.shared.dataComparisionID = KSSingletonManager.shared.dashboardNavigationID
        KSSingletonManager.shared.configurationNavigationID = KSSingletonManager.shared.dashboardNavigationID
    }
    // Convert data format to JSON dictionary format
    func convertDataToDictionary(data: Data) -> [String: Any]? {
        do {
            return try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
        } catch {
            print(error.localizedDescription)
        }
        return nil
    }
    // Send diagnostic stop websocket request to stop operation.
    func sendDiagnosticStopWebSocketRequest() {
        guard KSSingletonManager.shared.isDiagnsoticStart == false else {
            print("sendDiagnosticStopWebSocketRequest")
            KSSingletonManager.shared.isDiagnsoticStart = false
            let diagnosticStopCommand = ResetSocketRequest(screenName: "DiagnosticTestFunction", frameType: "StopRequest", periodicity: 0)
            guard let diagnosticRequestData = try? JSONEncoder().encode(diagnosticStopCommand) else { return }
            KSSingletonManager.shared.sendCommand(format: diagnosticRequestData)
            return }
    }
    // Set localization text to all UI components based on language selection.
    func localizedKey(_ key: String) -> String {
        return NSLocalizedString(key, comment: "")
    }
    // MARK: - SHOW LOADER
    func showLoader() {
        DispatchQueue.main.async {
        self.view.addSubview((appDelegate?.indicatorView)!)
        appDelegate?.indicatorView?.activityIndicator.startAnimating()
        appDelegate?.indicatorView?.setIndicatorFrame()
      }
    }
    func showLoaderWithoutThread() {
        self.view.addSubview((appDelegate?.indicatorView)!)
        appDelegate?.indicatorView?.activityIndicator.startAnimating()
        appDelegate?.indicatorView?.setIndicatorFrame()
    }
    // MARK: - HIDE LOADER
    func hideLoader() {
        DispatchQueue.main.async {
            appDelegate?.indicatorView?.activityIndicator.stopAnimating()
            appDelegate?.indicatorView?.removeFromSuperview()
            self.view.willRemoveSubview((appDelegate?.indicatorView)!)
        }
    }
    
    // MARK: - Show Copyright Label
    func showCopyrightLabel() {
        DispatchQueue.main.async {
        appDelegate?.copyrightView?.setViewFrame()
        self.view.addSubview((appDelegate?.copyrightView)!)
      }
    }
    
    // MARK: - Hide Copyright Label
    func hideCopyrightLabel() {
        DispatchQueue.main.async {
        appDelegate?.copyrightView?.removeFromSuperview()
        self.view.willRemoveSubview((appDelegate?.copyrightView)!)
      }
    }
    
    // MARK: - Connect websocket reuable function
    func initiateWebSocketConnection() {
        self.showLoader()
        KSSingletonManager.shared.connectWebSocket()
    }

    // Get file name form url
    func getStringFormURLDeletingPathExtension(url: NSURL) -> String {
        return (url.lastPathComponent! as NSString).deletingPathExtension
    }
}
