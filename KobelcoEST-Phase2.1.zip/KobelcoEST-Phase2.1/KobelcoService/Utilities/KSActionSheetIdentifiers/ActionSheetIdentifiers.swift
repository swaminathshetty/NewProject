//
//  ActionSheetIdentifiers.swift
//  KobelcoService
//
//  Created by Swaminath on 11/14/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation

enum ActionSheetIdentifiers: Int {
    case save = 0
    case delete = 1
    case saveAndSend = 2
    case sendAndDelete = 3
}
