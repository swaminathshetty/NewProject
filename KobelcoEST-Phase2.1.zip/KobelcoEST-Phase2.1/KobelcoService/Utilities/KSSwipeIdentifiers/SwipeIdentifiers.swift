//
//  SwipeIdentifiers.swift
//  KobelcoService
//
//  Created by Guest L&T on 12/12/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation

enum SwipeIdentifiers: String {
    case left = "LeftSwipe"
    case right = "RightSwipe"
}
