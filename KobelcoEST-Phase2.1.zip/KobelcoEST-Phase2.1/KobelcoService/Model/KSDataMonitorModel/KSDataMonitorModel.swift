//
//  KSDataMonitorModel.swift
//  KobelcoService
//
//  Created by Guest L&T on 21/11/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation

struct KSDataMonitorModel: Codable {
    var id: String = ""
    var name: String = ""
    var value: [String]?
    
    init(itemName: String, itemID: String) {
        self.name = itemName
        self.id = itemID
    }
}
