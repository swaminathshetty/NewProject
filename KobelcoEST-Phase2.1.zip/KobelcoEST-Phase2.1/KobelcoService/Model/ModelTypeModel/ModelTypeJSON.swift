//
//  ModelTypeJSON.swift
//  KobelcoService
//
//  Created by Guest L&T on 21/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation

// Modeltype selection matrix struct.
struct ModelTypeJSON: Codable {
    let modelTypeList: [MainListDict]
}

struct MainListDict: Codable {
    let name: String
    let area: [AreaDict]
}

struct AreaDict: Codable {
    let name: String
    let type: String
}

/// Modeltype selection struct websocket repsonse.
struct ModelSelectionResponse: Codable {
    let screenName: String!
    let frameType: String!
    let status: String!
    let applicationUnit: String!
    let partsNo: String!
}
