//
//  KSParameterRegistrationModel.swift
//  KobelcoService
//
//  Created by Admin on 11/3/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
struct ECUSignalsModel {
    var id: String
    var name: [String: Any]
    var pidID: Int
    var device: String
    var value: String
    var unit: String
    var type: String
    var isSelected: Bool

    init(data: [String: Any]) {
        id = data["id"] as? String ?? ""
        var nameModelObj = NameModel.init(data: [:])
        if let nameData = data["name"] as? [String: Any] {
            nameModelObj = NameModel.init(data: nameData)
        }
        name = nameModelObj.asDictionary
        pidID = data["pidID"] as? Int ?? 0
        device = data["device"] as? String ?? ""
        type = data["type"] as? String ?? ""
        value = data["value"] as? String ?? ""
        unit = data["unit"] as? String ?? ""
        isSelected = data["isSelected"] as? Bool ?? false
    }

    var asDictionary: [String: Any] {
      let mirror = Mirror(reflecting: self)
      let dict = Dictionary(uniqueKeysWithValues: mirror.children.lazy.map({ (label: String?, value: Any) -> (String, Any)? in
        guard let label = label else { return nil }
        return (label, value)
      }).compactMap { $0 })
      return dict
    }
}

struct NameModel {
    var en: String
    var ja: String

    init(data: [String: Any]) {
        en = data["en"] as? String ?? ""
        ja = data["ja"] as? String ?? ""
    }

    var asDictionary: [String: Any] {
      let mirror = Mirror(reflecting: self)
      let dict = Dictionary(uniqueKeysWithValues: mirror.children.lazy.map({ (label: String?, value: Any) -> (String, Any)? in
        guard let label = label else { return nil }
        return (label, value)
      }).compactMap { $0 })
      return dict
    }
}
/*
struct PumpSignalsModel {
    //var name: NameModel
    var pidID: Int
    var device: String
    var value: String
    var unit: String

    init(data: [String: Any]) {
//        if let nameData = data["name"] as? [String: Any] {
//            name = NameModel.init(data: nameData)
//        } else {
//            name = NameModel.init(data: [:])
//        }
        pidID = data["pidID"] as? Int ?? 0
        device = data["device"] as? String ?? ""
        value = data["value"] as? String ?? ""
        unit = data["unit"] as? String ?? ""
    }
}


struct NameModel {
    var enStr: String
    var jaStr: String

    init(data: [String: Any]) {
        enStr = data["en"] as? String ?? ""
        jaStr = data["ja"] as? String ?? ""
    }
}
*/
