//
//  KSServiceConnectorDelegate.swift
//  KobelcoService
//
//  Created by Swaminath on 1/19/21.
//  Copyright © 2021 L&T. All rights reserved.
//

import Foundation

@objc protocol KSServiceConnectorClassDelegate: class {
    func webServiceResponse(responseObject: NSMutableDictionary)
    func webServiceResponse(data: Data)
}
