//
//  KSServiceConnector.swift
//  KobelcoService
//
//  Created by Guest L&T on 06/01/21.
//  Copyright © 2021 L&T. All rights reserved.
//

import Foundation
import UIKit

let GET = "GET"
let TIMEOUT:Double = 30.0
let POST = "POST"
let PATCH = "PATCH"
let DELETE = "DELETE"

class KSServiceConnector: NSObject {
    static let sharedConnector = KSServiceConnector()
    static var serviceUrlformat:String = ""
    var delegate:Any?
    weak var serviceConnectorDelegate: KSServiceConnectorClassDelegate?

    // Global method for webserver restful communication.
    static func initiateServiceCall(controller: UIViewController, serviceUrl: String, methodType: String, params: String, completionHandler: @escaping(_ data: Data?, _ response: AnyObject, _ error: Error?) -> Void) {
        // Allow webserver communication only for mobile networks.
        if !appDelegate!.isMobileInternet {
            return
        }
        // Need to place loader
        // Show Loader
        controller.showLoader()
        // Check request type and assign base url
        if methodType == GET || methodType == DELETE {
            if(params.isEmpty){
                serviceUrlformat = BASEURL + String(format:"%@",serviceUrl)
                print("BASE_URL_GET =================>",serviceUrlformat)
            }
            else {
                serviceUrlformat = BASEURL + String(format:"%@/%@",serviceUrl,params)
                print("BASE_URL_REQUEST =================>",serviceUrlformat)
            }
            print("\(serviceUrlformat)")
        } else {
            serviceUrlformat = BASEURL + String(format:"%@",serviceUrl)
            print("BASE_URL_POST =================>",serviceUrlformat)
        }

        let requestWithData = self.requestHeaders(methodType, withURLString:serviceUrlformat,parameter: params,contentType:true)
        guard let request = requestWithData else { return }
        let session = URLSession.shared
        let task = session.dataTask(with: request) { (data, response, error) in
            // Check if any error on api call
            guard error == nil else {
                print("Error on GET call")
                print("\(error.debugDescription)")
                // Hide loader
                controller.hideLoader()
                DispatchQueue.main.async(execute: {() -> Void in
                    completionHandler(nil, "" as AnyObject, error)
                })
                return
            }
            // Check if unable to read data from api
            guard let responseData = data else {
                print("Error: did not receive data")
                // Hide loader
                controller.hideLoader()
                DispatchQueue.main.async(execute: {() -> Void in
                    completionHandler(nil, "" as AnyObject, error)
                })
                return
            }
            do {
                guard let responseObject = try JSONSerialization.jsonObject(with: responseData, options: []) as? [String: AnyObject] else {
                    // Hide loader
                    controller.hideLoader()
                    print("Error trying to convert data to JSON")
                    return
                }
                // Hide loader
                controller.hideLoader()
                // Send data to requested screens for binding.
                DispatchQueue.main.async(execute: {() -> Void in
                    completionHandler(responseData, responseObject as AnyObject, error)
                })
            } catch {
                print("Catch block")
                // Hide loader
                controller.hideLoader()
                DispatchQueue.main.async(execute: {() -> Void in
                    completionHandler(nil, "" as AnyObject, error)
                })
            }
        }
        task.resume()
    }
    //MARK : - Prepare request body
    static private func requestHeaders(_ methodType: String?, withURLString serviceUrl: String?, parameter params: String?, contentType isCheck: Bool) -> URLRequest? {
        let set = CharacterSet.urlQueryAllowed
        let encodedUrlAsString = serviceUrl?.addingPercentEncoding(withAllowedCharacters: set)
        let urlPoint=URL(string:encodedUrlAsString!)
        guard let url = urlPoint
            else
        {
            DispatchQueue.main.async(execute: {() -> Void in
                //self.hideLoader()
            })
            return nil
        }
        var request = URLRequest(url:url)
        request.timeoutInterval = TimeInterval(TIMEOUT)
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        //request.setValue("Bearer "+GlobalSharedInstanceClass.shared().yajamanToken, forHTTPHeaderField: "authorization")
        request.httpMethod = methodType
        if (methodType == POST || methodType == PATCH) {
            let requestData: Data? = params?.data(using: String.Encoding(rawValue: String.Encoding.utf8.rawValue), allowLossyConversion: true)
            request.httpBody = requestData
        }
        return request
    }
    func hideSceneLoader(loadController: UIViewController) {
        DispatchQueue.main.async {
            if #available(iOS 13.0, *) {
                let scene = UIApplication.shared.connectedScenes.first
                if let delegate = scene?.delegate as? SceneDelegate  {
                    delegate.hideSceneDelegateLoader()
                }
            } else {
                loadController.showLoader()
            }
        }
    }
}
