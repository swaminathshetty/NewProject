//
//  KSDiagnosticUpDownCell.swift
//  KobelcoService
//
//  Created by Guest L&T on 13/11/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSDiagnosticUpDownCell: UITableViewCell {

    @IBOutlet weak var upDownBGView: UIView!
    @IBOutlet weak var upDownCellTitle: UIButton!
    @IBOutlet weak var upDownTextField: UITextField!
    @IBOutlet weak var upDownCellUnit: UILabel!
    weak var diagnosticDelegate: KSDiagnosticDelegate?
    fileprivate var upDownMinValue = 0
    fileprivate var upDownMaxValue = 10

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.upDownBGView.layer.cornerRadius = 6
        self.upDownTextField.delegate = self
    }
    
    // Update diagnostic updown type cell components.
    func configureDiagnosticUpDownCell(upDownObject: [String: Any], textFieldValue: Int) {
        guard let upDownDict = upDownObject["name"] as? [String: Any] else { return }
        guard let upDownName = upDownDict[KSSingletonManager.shared.languageCode] as? String else { return }
        self.upDownCellTitle.setTitle(upDownName, for: .normal)//defaultValue
        guard let minValue = upDownObject["minValue"] as? Int else { return }
        guard let maxValue = upDownObject["maxValue"] as? Int else { return }
        upDownMinValue = minValue
        upDownMaxValue = maxValue
        self.upDownTextField.text = textFieldValue == 0 ? "0" : String(textFieldValue)
        self.upDownCellUnit.text = "-"
    }
}

// MARK: Textfield delegate
extension KSDiagnosticUpDownCell: UITextFieldDelegate {
    // Called when user changing something on textfield.
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField.text?.count == 0 && string == " " {
            return false
        }
        guard CharacterSet(charactersIn: "0123456789").isSuperset(of: CharacterSet(charactersIn: string)) else {
            return false
        }
        return true
     }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        guard KSSingletonManager.shared.isDiagnsoticStart else {
            textField.resignFirstResponder()
            return false
        }
        self.diagnosticDelegate?.sendStopRequest()
        return true
    }
    // Called on click of keyboard done button.
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField.isEmpty {
            self.diagnosticDelegate?.sendStartRequest()
        } else {
            self.diagnosticDelegate?.getTextFieldEntryValue(indexID: textField.tag, textFieldValue: textField.text ?? "")
        }
    }
}
