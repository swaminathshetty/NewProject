//
//  KSDataMonitorCell.swift
//  KobelcoService
//
//  Created by Swaminath on 11/16/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSDataMonitorCell: UITableViewCell {

    @IBOutlet weak var monitorCellBGView: UIView!
    @IBOutlet weak var monitorCellCheckBox: UIImageView!
    @IBOutlet weak var monitorCellItemName: UILabel!
    @IBOutlet weak var monitorCellValue: UILabel!
    @IBOutlet weak var monitorCellUnit: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.monitorCellBGView.layer.cornerRadius = 6
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configureDataMonitorCellDetails(itemObject: [String: Any], selecteditems: [String], itemValue: Int) {
        guard let monitorCellDict = itemObject["name"] as? [String: Any] else { return }
        guard let monitorCellID = itemObject["id"] as? String else { return }
        guard let monitorCellUnit = itemObject["unit"] as? String else { return }
        guard let monitorCellName = monitorCellDict[KSSingletonManager.shared.languageCode] as? String else { return }
        self.monitorCellItemName.text = monitorCellName
        self.monitorCellUnit.text = monitorCellUnit
        let isType1Graph = KSSingletonManager.shared.isDataMonitorType1
        self.monitorCellCheckBox.image = UIImage(named: isType1Graph ? "checkBox" : "radioButtonUnselected")
        self.monitorCellValue.text = itemValue == 0 ? "-" : String(itemValue)
        for monitorName in selecteditems {
            if monitorCellID.contains(monitorName) {
                self.monitorCellCheckBox.image = UIImage(named: isType1Graph ? "checkedBox" : "radioButtonSelected")
            }
        }
    }
}
