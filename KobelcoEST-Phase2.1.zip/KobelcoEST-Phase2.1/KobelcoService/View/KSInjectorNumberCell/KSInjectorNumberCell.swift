//
//  KSInjectorNumberCell.swift
//  KobelcoService
//
//  Created by Swaminath on 9/27/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSInjectorNumberCell: UITableViewCell {
    
    @IBOutlet weak var injectorCellBGView: UIView!
    @IBOutlet weak var labelInjectorNumber: UILabel!
    @IBOutlet weak var textViewNumber: UITextView!
    @IBOutlet weak var buttonQRCode: UIButton!
    weak var injectorDelegate: KSInjectorPartDelegate?
    var isAlertShown: Bool = false

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        injectorCellBGView.layer.cornerRadius = 8
        injectorCellBGView.clipsToBounds = true
        textViewNumber.layer.borderWidth = 0.5
        textViewNumber.layer.borderColor = #colorLiteral(red: 0.6666666865, green: 0.6666666865, blue: 0.6666666865, alpha: 1)
        textViewNumber.layer.cornerRadius = 6
        textViewNumber.backgroundColor = #colorLiteral(red: 0.9192075729, green: 0.9192075729, blue: 0.9192075729, alpha: 1)
        self.isAlertShown = false
    }
    func configureInjectorCellDetails(injectorName: Int, injectorNumber: String) {
        self.labelInjectorNumber.text = "Inj. #\(injectorName)"
        self.textViewNumber.text = injectorNumber
    }
}

// MARK: Textfield delegate
extension KSInjectorNumberCell: UITextViewDelegate {
    // Called when user tap on textview.
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        self.injectorDelegate?.showConfirmationAlertIfRequired(UIType: "TEXTFIELD", indexID: textView.tag) { (isClickOnYes) in
            self.isAlertShown = isClickOnYes == true ? true : false
        }
        if self.isAlertShown {
            return true
        }
        return false
    }
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.count != 30 {
            textView.text = ""
            self.injectorDelegate?.showManualEntryInvalidQRCodeAlert(indexID: textView.tag)
        } else {
            self.injectorDelegate?.getTextFieldEntryQRValue(indexID: textView.tag, QRCodeValue: textView.text)
        }
    }
    // Condition check for textview null entry restriction.
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        print("textView.text.count: \(textView.text.count)")
        print("text.count: \(text.count)")
        if (textView.text.count == 0 && text == " ") || (textView.text.count > 29 && text.count > 0) {
            return false
        }
        return true
    }
}
