//
//  KSMemoryResetSubCell.swift
//  KobelcoService
//
//  Created by Swaminath on 9/26/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSMemoryResetSubCell: UITableViewCell {

    @IBOutlet weak var memoryResetCellBGView: UIView!
    @IBOutlet weak var buttonItemName: UIButton!
    @IBOutlet weak var labelValue: UILabel!
    @IBOutlet weak var labelUnit: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.memoryResetCellBGView.layer.cornerRadius = 6
        self.buttonItemName.titleLabel?.numberOfLines = 2
        //self.buttonItemName.titleLabel?.lineBreakMode = .byTruncatingTail
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    func configureResetCellTitle(itemObject: [String: Any], selecteditems: [String], itemValue: Int) {
        guard let itemNameDict = itemObject["itemName"] as? [String: Any] else { return }
        guard let itemNameID = itemObject["id"] as? String else { return }
        guard let itemUnit = itemObject["unit"] as? String else { return }
        guard let itemName = itemNameDict[KSSingletonManager.shared.languageCode] as? String else { return }
        self.buttonItemName.setTitle(itemName, for: .normal)
        self.buttonItemName.isSelected = false
        self.labelValue.text = itemValue == 0 ? "-" : String(itemValue)
        self.labelUnit.text = itemUnit.isEmpty ? "-" : itemUnit
        for item in selecteditems {
            if itemNameID.contains(item) {
                self.buttonItemName.isSelected = true
            }
        }
    }
}
