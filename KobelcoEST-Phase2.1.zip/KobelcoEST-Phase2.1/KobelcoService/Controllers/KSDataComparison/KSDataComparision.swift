//
//  KSDataComparision.swift
//  KobelcoService
//
//  Created by Swaminath on 9/27/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

class KSDataComparision: UIViewController {

    @IBOutlet weak var selectLogDataView: UIView!
    @IBOutlet weak var selectNormalDataView: UIView!
    @IBOutlet weak var logDataTableview: UITableView!
    @IBOutlet weak var normalDataTableview: UITableView!
    @IBOutlet weak var plotChartsButton: KSCustomButton!
    @IBOutlet weak var logDataHeaderTitle: UIButton!
    @IBOutlet weak var normalDataHeaderTitle: UIButton!
    var setParameters: [KSIsCheckBoxSelectedModel] = []
    var selectedParameter: [Int] = []
    var subdirs = [NSURL]()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        KSSingletonManager.shared.dataComparisionID = self.navigationController?.getScreenNavigationID() ?? 3
        self.setUpUIParameterRegistrationComponents()
        self.logDataTableview.register(UINib(nibName: "KSCheckBoxWithLabelCellTableViewCell", bundle: nil), forCellReuseIdentifier: "KSCheckBoxWithLabelCellTableViewCell")
        self.normalDataTableview.register(UINib(nibName: "KSCheckBoxWithLabelCellTableViewCell", bundle: nil), forCellReuseIdentifier: "KSCheckBoxWithLabelCellTableViewCell")
        self.configureComparisionGestureRecognizers()
        self.getLocalDirectoryJSONPath()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        KSSingletonManager.shared.dataComparisionID = self.navigationController?.getScreenNavigationID() ?? 3
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarColorWithButtonTitle(buttonTitle: localizedKey("DataComparision"))
        self.navigationItem.hidesBackButton = true
        self.logDataHeaderTitle.setTitle(localizedKey("SelectLogData"), for: .normal)
        self.normalDataHeaderTitle.setTitle(localizedKey("SelectNormalData"), for: .normal)
        self.plotChartsButton.setTitle(localizedKey("PlotCharts"), for: .normal)
        self.selectedParameter = []
        self.setParameters = subdirs.map {KSIsCheckBoxSelectedModel.init(nameValue: self.getStringFormURLDeletingPathExtension(url: $0), isSelectedValue: false)}
        self.logDataTableview.reloadData()
        self.checkPlotChartsButtonEnableOrNot()
        self.sendDiagnosticStopWebSocketRequest()
    }

    // Configure gesture recognizer for UIView
    fileprivate func configureComparisionGestureRecognizers() {
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(respondToComparisionSwipeGesture))
        swipeRight.direction = .right
        self.view.addGestureRecognizer(swipeRight)
        
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(respondToComparisionSwipeGesture))
        swipeLeft.direction = .left
        self.view.addGestureRecognizer(swipeLeft)
    }
    // Navigate to particular screen based on swipe direction.
    @objc func respondToComparisionSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case .right:
                //self.popOverToBackScreen(indexValue: KSSingletonManager.shared.dataMonitorNavigationID)
                self.navigation(to: Identifier.dataMonitor, isSwiped: true, rightSwipe: SwipeIdentifiers.left.rawValue)
            case .left:
                self.navigationToConfigurationStoryboard(to: Identifier.configuration)
            default:
                break
            }
        }
    }
    // Swami added below func on dec 2, 2020
    // Get Local directory json log data saving path.
    func getLocalDirectoryJSONPath() {
        let enumerator = FileManager().enumerator(at: KSTextFileString.getLogDataFilesLibraryDirectoryPath(path: DataMonitorLogDataFolder)!, includingPropertiesForKeys: [URLResourceKey.isDirectoryKey], options: .skipsSubdirectoryDescendants, errorHandler: nil)

        while let url = enumerator?.nextObject() as? NSURL {
            subdirs.append(url)
        }
    }
    
    func checkPlotChartsButtonEnableOrNot() {
        if self.selectedParameter.count != 0 {
            self.plotChartsButton.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
            self.plotChartsButton.isEnabled = true
        } else {
            self.plotChartsButton.setTitleColor(#colorLiteral(red: 0.2117647059, green: 0.5137254902, blue: 0.5294117647, alpha: 1), for: .normal)
            self.plotChartsButton.isEnabled = false
        }
    }
    
    fileprivate func setUpUIParameterRegistrationComponents() {
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.selectLogDataView.layer.cornerRadius = 6
        self.selectNormalDataView.layer.cornerRadius = 6
    }
    
    @IBAction func plotChartsButtonAction(_ sender: Any) {
        let plotChartVCObj = MAINSTORYBOARD.instantiateViewController(withIdentifier: "KSPlotCharts") as! KSPlotCharts
        for index in self.selectedParameter {
            plotChartVCObj.selectedGraphArray.append(self.subdirs[index])
        }
        self.navigationController?.pushViewController(plotChartVCObj, animated: true)
    }
}

// MARK: Tableview delegate
extension KSDataComparision: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == logDataTableview {
            return subdirs.count
        } else {
            return rowCountZeroCheckFunctionality(selectedTableView: tableView, rowCount: 0)
        }
    }

    // Condition check for tableview row count and add tableview background with records label if count == 0.
    fileprivate func rowCountZeroCheckFunctionality(selectedTableView: UITableView, rowCount: Int) -> Int {
        if rowCount == 0 {
            DispatchQueue.main.async {
                self.nullDataFilesLabel(tableView: selectedTableView)
            }
        } else {
            selectedTableView.backgroundView = nil
        }
        return rowCount
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == logDataTableview {
            let theParameterCell = tableView.dequeueReusableCell(withIdentifier: "KSCheckBoxWithLabelCellTableViewCell") as! KSCheckBoxWithLabelCellTableViewCell
            self.setupLogDataTableView(cellObj: theParameterCell, indexValue: indexPath.row)
            return theParameterCell
        } else { // Webserver textfile normal-data names.
            let theParameterCell = tableView.dequeueReusableCell(withIdentifier: "KSCheckBoxWithLabelCellTableViewCell") as! KSCheckBoxWithLabelCellTableViewCell
            return theParameterCell
        }
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == logDataTableview {
            let getParameters = self.setParameters[indexPath.row]
            if self.selectedParameter.count < 5 || getParameters.isSelected == true {
                self.setParameters[indexPath.row] = KSIsCheckBoxSelectedModel.init(nameValue: getParameters.name, isSelectedValue: !getParameters.isSelected)
                if !getParameters.isSelected {
                    self.selectedParameter.append(indexPath.row)
                } else {
                    self.selectedParameter = self.selectedParameter.filter {$0 != indexPath.row}
                }
                self.logDataTableview.reloadData()
            }
        }

        self.checkPlotChartsButtonEnableOrNot()
    }

    func setupLogDataTableView(cellObj: KSCheckBoxWithLabelCellTableViewCell, indexValue: Int) {
        let setParameter = self.setParameters[indexValue]
        cellObj.fillCellData(lableText: setParameter.name, isCheckBoxSelected: setParameter.isSelected)
    }

    // Called when there are no normal data files available.
    func nullDataFilesLabel(tableView: UITableView) {
        let noDataLabel = UILabel()
        noDataLabel.text = localizedKey("NoRecordsText") // Displays this text when tableview is empty
        noDataLabel.textColor = TABLEVIEWLABELCOLOR
        noDataLabel.font = UIFont.medium(ofSize: 18)
        noDataLabel.textAlignment = .center
        tableView.backgroundView = noDataLabel
    }
}
