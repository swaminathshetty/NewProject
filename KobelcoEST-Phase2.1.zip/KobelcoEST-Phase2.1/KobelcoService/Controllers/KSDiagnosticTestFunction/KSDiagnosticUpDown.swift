//
//  KSDiagnosticUpDown.swift
//  KobelcoService
//
//  Created by Guest L&T on 06/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

// Protocol for to get updated diagnostic details.
@objc protocol KSDiagnosticDelegate {
    // Used to get textfield entry value from diagnostic tableview cell.
    func getTextFieldEntryValue(indexID: Int, textFieldValue: String)
    // Used to get new signals item details from add parameter screen on click of configure.
    func updateNewlyAddedConfigureItems(selectedParameters: [[String: Any]])
    // Called when user sending empty textfield value from tableview cell.
    func sendStartRequest()
    // Called when user tap on tableview cell textfield, to stop diagnostic test.
    func sendStopRequest()
}
class KSDiagnosticUpDown: UIViewController {

    @IBOutlet weak var upDownHeaderView: UIView!
    @IBOutlet weak var upDownHeaderTitle: UIButton!
    @IBOutlet weak var upDownHeaderValue: UILabel!
    @IBOutlet weak var upDownHeaderUnit: UILabel!
    @IBOutlet weak var upDownDiagnosticTableView: UITableView!
    @IBOutlet weak var addParametersUpDown: UIButton!
    @IBOutlet weak var startButtonUpDown: UIButton!
    @IBOutlet weak var upArrowUpDown: UIButton!
    @IBOutlet weak var downArrowUpDown: UIButton!
    @IBOutlet weak var helpButtonUpDown: UIButton!
    fileprivate var upDownWriteArray = [[String: Any]]()
    fileprivate var upDownReadArray = [[String: Any]]()
    fileprivate var upDownWriteID = [String]()
    fileprivate var upDownWriteValue = [Int]()
    fileprivate var upDownWriteValues = [Int]()
    fileprivate var upDownReadIDs = [String]()
    fileprivate var upDownReadValues = [Int]()
    fileprivate var currentEditIndex = ""
    private var upDownCanViewSwipe = true
    @IBOutlet weak var upArrowWidthConst: NSLayoutConstraint!
    @IBOutlet weak var downArrowWidthConst: NSLayoutConstraint!
    fileprivate var textFieldMinValue = 0
    fileprivate var textFieldMaxValue = 10
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.setNavigationBarColorWithButtonTitle(buttonTitle: KSSingletonManager.shared.diagnosticNavigationTitle)
        self.navigationItem.setHidesBackButton(true, animated: true)
        KSSingletonManager.shared.diagnosticSubScreenID = self.navigationController?.getScreenNavigationID() ?? 3
        loadDiagnosticUpDownUIComponents()
        KSSingletonManager.shared.delegate = self
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(image: NAVIGATIONBACKICON, style: .plain, target: self, action: #selector(diagnocticBackAction))
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: NAVIGATIONRIGHTBARLOGO, style: .plain, target: self, action: #selector(diagnocticRightBarAction))
    }
    // Add custom values to diagnostic updown UI components.
    fileprivate func loadDiagnosticUpDownUIComponents() {
        self.view.backgroundColor = NAVIGATIONBARCOLOR
        self.upDownHeaderView.layer.cornerRadius = 6
        self.upDownHeaderTitle.setTitle(localizedKey("ItemNameText"), for: .normal)
        self.upDownHeaderValue.text = localizedKey("ValueText")
        self.upDownHeaderUnit.text = localizedKey("UnitText")
        startButtonUpDown.setTitle(localizedKey("StartText"), for: .normal)
        if KSSingletonManager.shared.explanationDiagnostic.isEmpty && KSSingletonManager.shared.attentionDiagnostic.isEmpty {
            self.helpButtonUpDown.isHidden = true
        }
        self.configureDiagnosticSubMenuGestureRecognizers()
        self.appendEmptyValuesToSwitchItemListArray()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        KSSingletonManager.shared.currentScreenName = "DiagnosticSubMenu"
        KSSingletonManager.shared.diagnosticSubScreenID = self.navigationController?.getScreenNavigationID() ?? 3
        KSSingletonManager.shared.delegate = self
    }
    // Check for diagnostic and datamonitor start process on click of back button.
    @objc func diagnocticBackAction(sender: UIBarButtonItem) {
        print("Back Action")
        if !KSSingletonManager.shared.isDiagnsoticStart {
            KSSingletonManager.shared.isDiagnsoticStart = false
            self.popOverToBackScreen(indexValue: KSSingletonManager.shared.diagnosticMainScreenID)
        }
    }
    // Condition check for diagnostic and datamonitor start process on click of rightbar home icon.
    @objc func diagnocticRightBarAction() {
        print("Dashboard Action")
        if KSSingletonManager.shared.isDataMonitorStart || KSSingletonManager.shared.isDiagnsoticStart {
        } else {
            self.clearAndResetAllDataAndNavigateToDashboard()
        }
    }
    // Configure gesture recognizer for UIView
    fileprivate func configureDiagnosticSubMenuGestureRecognizers() {
        let swipeRightMR = UISwipeGestureRecognizer(target: self, action: #selector(respondToDiagnosticSubMenuSwipeGesture))
        swipeRightMR.direction = .right
        self.view.addGestureRecognizer(swipeRightMR)
        
        let swipeLeftMR = UISwipeGestureRecognizer(target: self, action: #selector(respondToDiagnosticSubMenuSwipeGesture))
        swipeLeftMR.direction = .left
        self.view.addGestureRecognizer(swipeLeftMR)
    }
    // Navigate to particular screen based on swipe direction.
    @objc func respondToDiagnosticSubMenuSwipeGesture(gesture: UIGestureRecognizer) {
        guard upDownCanViewSwipe else { return }
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case .right:
                guard KSSingletonManager.shared.isDiagnsoticStart == false else {
                    if KSSingletonManager.shared.isDataMonitorStart {
                        self.navigation(to: Identifier.dataMonitor, isSwiped: true, rightSwipe: SwipeIdentifiers.left.rawValue)
                    }
                    return
                }
                guard KSSingletonManager.shared.isDataMonitorStart == false else {
                    self.navigation(to: Identifier.dataMonitor, isSwiped: true, rightSwipe: SwipeIdentifiers.left.rawValue)
                    return }
                self.popOverToBackScreen(indexValue: KSSingletonManager.shared.diagnosticMainScreenID)
            case .left:
                self.navigation(to: Identifier.dataMonitor, isSwiped: true)
            default:
                break
            }
        }
    }
    // By default append 0 in item values to display in tableview.
    fileprivate func appendEmptyValuesToSwitchItemListArray() {
        self.upDownReadArray.removeAll(keepingCapacity: false)
        self.upDownReadValues.removeAll(keepingCapacity: false)
        self.upDownWriteArray.removeAll(keepingCapacity: false)
        self.upDownReadIDs.removeAll(keepingCapacity: false)
        self.readAndWriteSignalsSeperation()
        for switchItemDict in upDownReadArray {
            upDownReadValues.append(0)
            guard let switchItemID = switchItemDict["id"] as? String else { return }
            upDownReadIDs.append(switchItemID)
        }
        print("upDownReadValues: \(upDownReadValues)")
        print("upDownReadIDs: \(upDownReadIDs)")
    }
    // Seperate Read and Write Dianostic Sub Menu Details.
    fileprivate func readAndWriteSignalsSeperation() {
        for switchItemObject in KSSingletonManager.shared.diagnosticSubMenuArray {
            guard let switchItemType = switchItemObject["type"] as? String else { return }
            if switchItemType == "ReadOnly" {
                self.upDownReadArray.append(switchItemObject)
            } else {
                self.upDownWriteArray.append(switchItemObject)
            }
        }
        self.appendEmptyValuesToWriteSignals()
    }
    // Append 0 default value to write Signal values.
    fileprivate func appendEmptyValuesToWriteSignals() {
        //Swami
        self.upDownWriteValues.removeAll(keepingCapacity: false)
        self.upDownWriteID.removeAll(keepingCapacity: false)
        if KSSingletonManager.shared.diagnosticMenuType != "UpDown" {
            upArrowWidthConst.constant = 0
            downArrowWidthConst.constant = 0
        }
        for writeItemsObject in upDownWriteArray {
            guard let writeItemID = writeItemsObject["id"] as? String else { return }
            self.upDownWriteID.append(writeItemID)
            guard let writeMinValue = writeItemsObject["minValue"] as? Int else { return }
            textFieldMinValue = writeMinValue
            self.upDownWriteValues.append(0)
            guard let writeMaxValue = writeItemsObject["maxValue"] as? Int else { return }
            textFieldMaxValue = writeMaxValue
        }
    }
    // Click on this button to add parameters from parameters screen.
    @IBAction func addParametersForDiagnosticUpDown(_ sender: Any) {
        /*let popUpStatus = showDataMonitorValidationPopUp()
        guard popUpStatus else { return }*/
        let addParameterScreen = MAINSTORYBOARD.instantiateViewController(withIdentifier: "KSAddParameters") as? KSAddParameters
        addParameterScreen?.diagnosticDelegate = self
        self.navigationController?.pushViewController(addParameterScreen!, animated: true)
    }
    
    // Its a toggle operation, start and stop websocket value readings.
    @IBAction func startActionForDiagnosticUpdown(_ sender: Any) {
        if KSSingletonManager.shared.isDiagnsoticStart { // Stop
            self.sendStopRequest()
            startAndStopTextBind(isStart: false, title: localizedKey("StartText"), canSwipe: true, isEnable: true)
            appendEmptyValuesToWriteSignals()
        } else { // Start
            /*let popUpStatus = showDataMonitorValidationPopUp()
             guard popUpStatus else { return }*/
            startAndStopTextBind(isStart: true, title: localizedKey("StopText"), canSwipe: false, isEnable: false)
            sendDiagnosticSocketRequest(writeIDs: upDownWriteID, writeValues: upDownWriteValues, interval: 200)
        }
    }
    fileprivate func showDataMonitorValidationPopUp() -> Bool {
        guard KSSingletonManager.shared.isDataMonitorStart == false else {
            super.navigationController?.navigationBar.isUserInteractionEnabled = false
            self.presentAlert(withTitle: INFORMATIONTITLE, message: DATAMONITORSTOPVALIDATION)
            return false
        }
        return true
    }
    // Called when user click on start or stop button.
    fileprivate func startAndStopTextBind(isStart: Bool, title: String, canSwipe: Bool, isEnable: Bool) {
        KSSingletonManager.shared.isDiagnsoticStart = isStart
        startButtonUpDown.setTitle(title, for: .normal)
        upDownCanViewSwipe = canSwipe
        addParametersUpDown.isEnabled = isEnable
        helpButtonUpDown.isEnabled = isEnable
        upArrowUpDown.isEnabled = isStart
        downArrowUpDown.isEnabled = isStart
        self.navigationController?.navigationBar.isUserInteractionEnabled = isEnable
    }
    // Send websocket request With read and write signal IDs
    func sendDiagnosticSocketRequest(writeIDs: [String], writeValues: [Int], interval: Int) {
        self.showLoader()
        self.upDownCanViewSwipe = false
        let mainID = KSSingletonManager.shared.diagnosticMainID
        let screenTitle = "DiagnosticTestFunction"
        let upDownCommand = DiagnosticStartRequest(screenName: screenTitle, frameType: mainID, writeSignals: writeIDs, writeValue: writeValues, readSignals: upDownReadIDs, periodicity: interval)
        guard let upDownRequestData = try? JSONEncoder().encode(upDownCommand) else { return }
        KSSingletonManager.shared.sendCommand(format: upDownRequestData)
    }
    // Click on this to perform up and down websocket request for value field.
    @IBAction func toggleUpAndDownArrowAction(_ sender: UIButton) {
        //guard currentEditIndex != "" else { return }
        if currentEditIndex == "" {
            currentEditIndex = "0"
        }
        let index = Int(currentEditIndex) ?? 0
        var userInputValue = upDownWriteValues[index]
        if sender.tag == 0 { // Up arrow(Increment)
            guard userInputValue != textFieldMaxValue else { return }
            userInputValue += 1
        } else { // Down arrow(Decrement)
            guard userInputValue != textFieldMinValue else { return }
            userInputValue -= 1
        }
        self.upDownWriteValues[index] = userInputValue
        self.sendUserInputWebSocketRequest(indexValue: index, inputString: userInputValue)
    }
    
    // Send websocket request with user input value.
    func sendUserInputWebSocketRequest(indexValue: Int, inputString: Int) {
        self.upDownWriteValues[indexValue] = inputString
        self.sendDiagnosticSocketRequest(writeIDs: self.upDownWriteID, writeValues: self.upDownWriteValues, interval: 200)
    }
    // Click on this to show help alertview.
    @IBAction func helpButtonActionForDiagnosticUpDown(_ sender: Any) {
        let upDownExplanation = KSSingletonManager.shared.explanationDiagnostic
        let upDownAttention = KSSingletonManager.shared.attentionDiagnostic
        DispatchQueue.main.async {
            if KSSingletonManager.shared.explanationDiagnostic.isEmpty && KSSingletonManager.shared.attentionDiagnostic.isEmpty {
            } else if KSSingletonManager.shared.attentionDiagnostic.isEmpty {
                self.presentAlert(withTitle: self.localizedKey("ExplanationTitle"), message: upDownExplanation)
            } else {
                self.presentAttributedStringAlert(message1: upDownExplanation, message2: upDownAttention) { (_ ) in
                }
            }
        }
    }
    // Check read signals available in the tableview list or not, before sending websocket request.
    fileprivate func checkReadSignalsCount() {
        guard upDownReadArray.count > 0 else {
            self.presentAlert(withTitle: ALERTTITLESTRING, message: "To Start Diagnostic Test, please add few read signals from add parameter screen and try again.")
            return
        }
    }
}

// MARK: Extension for add/remove child controllers.
extension KSDiagnosticUpDown: KSDiagnosticDelegate {
    // Get tableview cell textfield value via delegate function.
    func getTextFieldEntryValue(indexID: Int, textFieldValue: String) {
        let getTextFieldValue = Int(textFieldValue)
        DispatchQueue.main.async {
            if getTextFieldValue! < self.textFieldMinValue || getTextFieldValue! > self.textFieldMaxValue {
                self.presentAlertOKAction(withTitle: ALERTTITLESTRING, message: TEXTFIELDINVALIDENTRY) { [unowned self] (_) in
                    self.sendDiagnosticSocketRequest(writeIDs: self.upDownWriteID, writeValues: self.upDownWriteValues, interval: 200)
                }
            } else {
                self.currentEditIndex = String(indexID)
                self.sendUserInputWebSocketRequest(indexValue: indexID, inputString: Int(textFieldValue)!)
            }
        }
    }
    
    // Get added new signals from add parameter screen.
    func updateNewlyAddedConfigureItems(selectedParameters: [[String: Any]]) {
        for addSignalObject in selectedParameters {
            KSSingletonManager.shared.diagnosticSubMenuArray.append(addSignalObject)
        }
        self.appendEmptyValuesToSwitchItemListArray()
        self.upDownDiagnosticTableView.reloadData()
    }
    
    // Send diagnostic start request from tableview cell.
    func sendStartRequest() {
        currentEditIndex = ""
        //self.upDownWriteID.removeAll(keepingCapacity: false)
        //self.upDownWriteValue.removeAll(keepingCapacity: false)
        self.sendDiagnosticSocketRequest(writeIDs: self.upDownWriteID, writeValues: self.upDownWriteValue, interval: 200)
    }
    
    // Send diagnostic stop request from tableview cell.
    func sendStopRequest() {
        //guard KSSingletonManager.shared.isDiagnsoticStart else { return }
        self.upDownCanViewSwipe = false
        self.showLoader()
        self.sendDiagnosticStopWebSocketRequest()
    }
}

// MARK: Tableview delegates
extension KSDiagnosticUpDown: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        //return switchWriteArray.count > 0 ? 2 : 1
        return 2
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return section == 0 ? upDownWriteArray.count : upDownReadArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
             let switchTypeObject = upDownWriteArray[indexPath.row]
             let switchMenuType = switchTypeObject["type"] as? String
            // Load Diagnostic Write Signals.
             if switchMenuType == "Switch" {
                let switchCellIdentifier = "KSDiagnosticSwitchCell"
                let switchCell: KSDiagnosticSwitchCell?
                switchCell = tableView.dequeueReusableCell(withIdentifier: switchCellIdentifier) as? KSDiagnosticSwitchCell
                switchCell?.switchToggleButton.tag = indexPath.row
                switchCell?.configureDiagnosticSwitchCell(switchObject: upDownWriteArray[indexPath.row], switchInput: upDownWriteValues[indexPath.row])
                switchCell?.switchToggleButton.addTarget(self, action: #selector(diagnosticSwitchOnAndOffAction(_ :)), for: .touchUpInside)
                return switchCell!
             } else {
                self.upArrowUpDown.isHidden = false
                self.downArrowUpDown.isHidden = false
                let upDownCellIdentifier = "KSDiagnosticUpDownCell"
                let upDownCell: KSDiagnosticUpDownCell?
                upDownCell = tableView.dequeueReusableCell(withIdentifier: upDownCellIdentifier) as? KSDiagnosticUpDownCell
                upDownCell?.upDownTextField.tag = indexPath.row
                upDownCell?.diagnosticDelegate = self
                upDownCell?.configureDiagnosticUpDownCell(upDownObject: upDownWriteArray[indexPath.row], textFieldValue: upDownWriteValues[indexPath.row])
                return upDownCell!
             }
         // Load Diagnostic Read Signals.
         } else {
            let switchReadIdentifier = "KSDiagnosticNormalCell"
            let switchReadCell: KSDiagnosticNormalCell?
            switchReadCell = tableView.dequeueReusableCell(withIdentifier: switchReadIdentifier) as? KSDiagnosticNormalCell
            switchReadCell?.configureDiagnosticNormalCell(normalObject: upDownReadArray[indexPath.row], itemValue: upDownReadValues[indexPath.row])
            return switchReadCell!
         }
    }
    // Tap to store toggle switch write value for websocket write request.
     @objc func diagnosticSwitchOnAndOffAction(_ sender: UISwitch) {
        if KSSingletonManager.shared.isDiagnsoticStart { // Stop
            DispatchQueue.main.async {
                //Swami
                //self.upDownWriteID.removeAll(keepingCapacity: false)
                //self.upDownWriteValue.removeAll(keepingCapacity: false)
                let switchWriteObject = self.upDownWriteArray[sender.tag]
                guard let switchID = switchWriteObject["id"] as? String else { return }
                self.upDownWriteID[sender.tag] = switchID
                let toggleValue = sender.isOn == true ? 1 : 0
                //self.upDownWriteValue[sender.tag] = toggleValue
                self.upDownWriteValues[sender.tag] = toggleValue
                //self.sendStopRequest()
                self.sendDiagnosticSocketRequest(writeIDs: self.upDownWriteID, writeValues: self.upDownWriteValues, interval: 200)
            }
        } else {
            sender.isOn = !sender.isOn
            self.presentAlert(withTitle: ALERTTITLESTRING, message: DIAGNOSTICWRITEALERT)
        }
     }
}
// MARK: WebSocket Response Delegate
extension KSDiagnosticUpDown: KSWebSocketDelegates {
    func webSocketStringResponse(response: String) {
        guard let jsonDictionary = convertToDictionary(text: response) else { return }
        guard let screenTitle = jsonDictionary["screenName"] as? String else { return }
        if screenTitle == "DiagnosticTestFunction" {
            self.hideLoader()
            upDownCanViewSwipe = true
            let resposneKeys = jsonDictionary.keys
            // Condition check for 2 type responses. If response contains status key show success or failure message.
            if resposneKeys.contains("status") {
                guard let diagnosticStopStatus = jsonDictionary["status"] as? Int else { return }
                // Show unable to stop diagnostic alert for status 0
                // Show Machine not responding alert for status 2
                DispatchQueue.main.async {
                    if diagnosticStopStatus == 0 {
                        self.presentAlert(withTitle: ERRORTITLE, message: DIAGNOSTIC0STATUSALERT)
                        self.startButtonUpDown.setTitle(self.localizedKey("StopText"), for: .normal)
                        KSSingletonManager.shared.isDiagnsoticStart = true
                    } else if diagnosticStopStatus == 1 {
                        //self.appendEmptyValuesToWriteSignals()
                        //self.upDownDiagnosticTableView.reloadData()
                        KSSingletonManager.shared.isDiagnsoticStart = false
                    } else if diagnosticStopStatus == 2 {
                        self.startButtonUpDown.setTitle(self.localizedKey("StartText"), for: .normal)
                        KSSingletonManager.shared.isDiagnsoticStart = false
                        self.presentAlert(withTitle: ERRORTITLE, message: DIAGNOSTIC2STATUSALERT)
                    }
                }
            } else {
                // Read values from the websocket response and update to tableview.
                 guard let readSignalValues = jsonDictionary["values"] as? [Int] else { return }
                 DispatchQueue.main.async {
                    guard let writeResponseStatus = jsonDictionary["writeResponse"] as? Int else { return }
                    if writeResponseStatus == 0 {
                        self.startButtonUpDown.setTitle(self.localizedKey("StartText"), for: .normal)
                        KSSingletonManager.shared.isDiagnsoticStart = false
                        self.presentAlert(withTitle: ERRORTITLE, message: DOAGNOSTICERRORFORWRITE)
                    } else {
                        if readSignalValues.count == self.upDownReadArray.count {
                            KSSingletonManager.shared.isDiagnsoticStart = true
                            self.upDownReadValues.removeAll(keepingCapacity: false)
                            self.upDownReadValues = readSignalValues
                            self.upDownDiagnosticTableView.reloadData()
                            return
                        } else {
                            self.presentAlert(withTitle: ERRORINRESPONSETITLE, message: ERRORINRESPONSE)
                            return
                        }
                    }
                 }
            }
        }
    }
    // Called when error connection in websocket communication
    func webSocketErrorConnection(message: String) {
        self.hideLoader()
        upDownCanViewSwipe = true
        presentAlertOKAction(withTitle: ERRORTITLE, message: message) { (_ ) in
            KSSingletonManager.shared.connectWebSocket()
        }
    }
    // Called when internet is disconnected or network not reachable.
    func internetConnectionNotAvailable() {
        self.hideLoader()
        presentAlertOKAction(withTitle: ERRORTITLE, message: WIFIDISCONNECTEDMESSAGE) { (isOkTapped) in
            if isOkTapped {
                self.navigateToWiFiSettings()
            }
        }
    }
    // Websocket response timeout alert.
     func noWebSocketResponse(message: String) {
         self.hideLoader()
         presentAlert(withTitle: ERRORTITLE, message: message)
     }
}
