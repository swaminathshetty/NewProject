//
//  KSDataMonitor.swift
//  KobelcoService
//
//  Created by Swaminath on 9/27/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit
import Charts

// MARK: - KSDataMonitor Delegate methods
// Protocals for data monitor listview swipe up and down functionality.
@objc protocol KSMonitorDataDelegate {
    func addDataMonitorListChildController()
    func swipeUpAndDownTheChildController()
    func removeMonitorListChildController()
    func getAddParametersList(selectedParameters: [[String: Any]])
    func delegateStopDataMonitor()
    func getSelectedMonitorItems(monitorItems: [String])
}

// MARK: - Graph data structure
struct GraphData {
    let legendColor: UIColor
    let legendPoints: [Int]
}

class KSDataMonitor: UIViewController {

    @IBOutlet weak var monitorBGView: UIView!
    @IBOutlet weak var footerViewDataMonitor: UIView!
    @IBOutlet weak var addParameterButton: UIButton!
    @IBOutlet weak var type1Type2Segment: UISegmentedControl!
    @IBOutlet weak var startPlotGraphbutton: UIButton!
    @IBOutlet weak var mainChartDisplayView: UIView!
    @IBOutlet weak var graphTimeDisplayLabel: UILabel!
    @IBOutlet weak var chartViewBottomConstraint: NSLayoutConstraint!
    @IBOutlet weak var chartView: LineChartView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var noDataAvailableLabel: UILabel!

    fileprivate var dataMonitorListView: KSDataMonitorList?
    fileprivate var isMonitorViewPresented: Bool = true
    fileprivate var listViewYPosition = 0
    fileprivate let periodicityValue = 50
    //fileprivate var textFileReadValues = [[Int]]()
    var isLandscapeMode = false
    let addValueInChartViewBottomConstraint = 35
    
    var graphDictionaryValues = [String: GraphData]()
    var legendDataSetObject: [LegendDataSet] = []
    var lineChartData: [LineChartDataSet] = []
    var arrayMonitorSelectedItems: [String]?

    var toPointsDisplay = 0
    var drawgraphBackgroundTimer: Timer?
    let noDataText = ""

    // MARK: - View lifecycle method
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        KSSingletonManager.shared.currentScreenName = "DataMonitor"
        startPlotGraphbutton.setTitle(localizedKey("StartText"), for: .normal)
        self.loadDataMonitorUIComponents()
        self.setupUIData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationItem.hidesBackButton = true
        self.checkDataMinotorReadSignalsCount()
        self.setupInitialGraphData()
        self.addDataMonitorListChildController()
        self.view.sendSubviewToBack(self.mainChartDisplayView)
        self.view.sendSubviewToBack(self.monitorBGView)
        self.navigationController?.navigationBar.isUserInteractionEnabled = isNavigationBarDisabled()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        self.setNavigationBarColorWithButtonTitle(buttonTitle: localizedKey("DataMonitor"))
        self.navigationItem.hidesBackButton = true
        self.type1Type2Segment.setTitle(localizedKey("Type1text"), forSegmentAt: 0)
        self.type1Type2Segment.setTitle(localizedKey("Type2text"), forSegmentAt: 1)
        KSSingletonManager.shared.dataMonitorNavigationID = self.navigationController?.getScreenNavigationID() ?? 3
        isMonitorViewPresented = true
        KSSingletonManager.shared.delegate = self
        if KSSingletonManager.shared.isDataMonitorStart {
            self.setMainChartViewBottomConstraint()
            self.dataMonitorListView?.getSelectedMonitorListItem()
            self.setupInitialGraphData()
            self.createDictionaryForGraphDataDelegate()
        }
    }
    
    // Called when user navigate to someother screen
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        self.removeMonitorListChildController()
        KSSingletonManager.shared.isDataMonitorType1 = true
        isMonitorViewPresented = false
        self.stopDrawGraphBackgroundTimer()
    }

    // Set customs property values to data monitor UI components.
    fileprivate func loadDataMonitorUIComponents() {
        self.view.backgroundColor = NAVIGATIONBARCOLOR
        self.type1Type2Segment.layer.cornerRadius = 6
        self.type1Type2Segment.setSegmentTintColors()
        //listViewYPosition = Int(self.view.bounds.height - 240)
        self.configureDataMonitorGestureRecognizers()
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: NAVIGATIONRIGHTBARLOGO, style: .plain, target: self, action: #selector(dataMonitorRightBarAction))
    }
    // Condition check for diagnostic and datamonitor start process on click of rightbar home icon.
    @objc func dataMonitorRightBarAction() {
        print("Dashboard Action")
        if KSSingletonManager.shared.isDataMonitorStart || KSSingletonManager.shared.isDiagnsoticStart {
        } else {
            self.clearAndResetAllDataAndNavigateToDashboard()
        }
    }
    // Disable navigation bar userinteraction, if any diagnoctis or datamonitor in start mode.
    // Enable navigation bar userinteraction only if both diagnostic and datamonitor in not running state.
    fileprivate func isNavigationBarDisabled() -> Bool {
        if KSSingletonManager.shared.isDiagnsoticStart == true || KSSingletonManager.shared.isDataMonitorStart == true {
            return false
        } else {
            return true
        }
    }
    func setupUIData() {
        self.graphTimeDisplayLabel.text = ""
        self.noDataAvailableLabel.text = noDataText
        self.tableView.dataSource = self
        self.tableView.delegate = self
    }

    // MARK: - Identify screen orientation
    // todo: set the updated frame for footer monitor list view.
    // fixme: Again add copyright footer label after screen orientation to avoid constraint problem.
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        print("viewWillTransition listViewYPosition: \(listViewYPosition)")
        if isMonitorViewPresented {
            isLandscapeMode = UIDevice.current.orientation.isLandscape
            if listViewYPosition <= 68 {
                listViewYPosition = Int(UIDevice.current.orientation.isLandscape ? 35 : 68)
                self.adjustDataMonitorViewPosition()
            } else {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    self.listViewYPosition = Int(UIDevice.current.orientation.isLandscape ? (self.view.bounds.height - 75) : (self.view.bounds.height - 240))
                    self.adjustDataMonitorViewPosition()
                }
            }
        }
    }
    // Animate datamonitor tableview screen
    func adjustDataMonitorViewPosition() {
        UIView.transition(with: (self.dataMonitorListView?.view)!, duration: 0.3, options: [.curveLinear], animations: {
        self.dataMonitorListView?.view.frame = CGRect(x: 0, y: CGFloat(self.listViewYPosition), width: self.view.bounds.width, height: self.view.bounds.height - CGFloat(self.listViewYPosition))
        }, completion: { _ in
            self.setMainChartViewBottomConstraint()
        })
    }
    
    func setMainChartViewBottomConstraint() {
        if 0...(self.view.bounds.height/2) ~= (self.dataMonitorListView?.view.frame.height)! {
            self.chartViewBottomConstraint.constant = self.view.bounds.height - CGFloat(self.listViewYPosition + self.addValueInChartViewBottomConstraint)
            if self.arrayMonitorSelectedItems == nil {
                self.setBooleanValueForSomeController(booleanValue: true)
            } else if startPlotGraphbutton.title(for: .normal) == localizedKey("StartText") {
                self.setBooleanValueForSomeController(booleanValue: true)
            } else {
                self.setBooleanValueForSomeController(booleanValue: false)
            }
        } else {
            self.chartViewBottomConstraint.constant = 0
            self.setBooleanValueForSomeController(booleanValue: true)
            self.noDataAvailableLabel.isHidden = true
        }
    }
    
    // Hide unhide the UI Controller
    func setBooleanValueForSomeController(booleanValue: Bool) {
        self.chartView.isHidden = booleanValue
        self.tableView.isHidden = booleanValue
        self.graphTimeDisplayLabel.isHidden = booleanValue
        self.mainChartDisplayView.isHidden = booleanValue
        self.noDataAvailableLabel.isHidden = !booleanValue
    }

    // Configure gesture recognizer for UIView
    fileprivate func configureDataMonitorGestureRecognizers() {
        let swipeRightMR = UISwipeGestureRecognizer(target: self, action: #selector(respondToDataMonitorSwipeGesture))
        swipeRightMR.direction = .right
        self.view.addGestureRecognizer(swipeRightMR)
        
        let swipeLeftMR = UISwipeGestureRecognizer(target: self, action: #selector(respondToDataMonitorSwipeGesture))
        swipeLeftMR.direction = .left
        self.view.addGestureRecognizer(swipeLeftMR)
    }
    
    // Navigate to particular screen based on swipe direction.
    @objc func respondToDataMonitorSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case .right:
                // Popover to diagnostic sub screen if diagnostic start function is running.
                guard KSSingletonManager.shared.isDiagnsoticStart == false else {
                    print("Diganostic started")
                    self.popOverToBackScreen(indexValue: KSSingletonManager.shared.diagnosticSubScreenID)
                    return
                }
                // Disable swipe if only data monitor start operation is runnning.
                // Enable swipe if both diagnostic and data monitor start operations are running.
                guard KSSingletonManager.shared.isDataMonitorStart == false else {
                    print("Only data monitor start")
                    self.navigation(to: Identifier.diagnosticTest, isSwiped: true, rightSwipe: SwipeIdentifiers.left.rawValue)
                    return }
                print("Data monitor not running")
                KSSingletonManager.shared.clearDataMonitorGlobalArrayReadings()
                self.navigation(to: Identifier.diagnosticTest, isSwiped: true, rightSwipe: SwipeIdentifiers.left.rawValue)
            case .left:
                guard KSSingletonManager.shared.isDiagnsoticStart == false else { return }
                guard KSSingletonManager.shared.isDataMonitorStart == false else { return }
                KSSingletonManager.shared.clearDataMonitorGlobalArrayReadings()
                self.disableUIElementActions(title: localizedKey("StartText"), isStart: false)
                self.navigation(to: Identifier.dataComparision)
            default:
                break
            }
        }
    }
    
    // Condition check for hide and show UI elements.
    fileprivate func checkDataMinotorReadSignalsCount() {
        if KSSingletonManager.shared.dataMonitorSubMenu.count > 0 {
            self.disableFewFooterUIComponents(isEnabled: true)
        } else {
            self.disableFewFooterUIComponents(isEnabled: false)
        }
        guard KSSingletonManager.shared.isDataMonitorStart == false else {
            self.disableUIElementActions(title: localizedKey("StopText"), isStart: true)
            return }
    }
    
    // Click on this button to add more parameters from paramters screen and plot a line graph.
    @IBAction func addDataParameterButtonTapped(_ sender: Any) {
        let addMonitorParameterScreen = MAINSTORYBOARD.instantiateViewController(withIdentifier: "KSAddParameters") as? KSAddParameters
        addMonitorParameterScreen?.dataMonitorDelegate = self
        self.navigationController?.pushViewController(addMonitorParameterScreen!, animated: true)
    }
    
    // Display/plot graph based on type1/type2 segment selection.
    @IBAction func segmentControllerForType1AndType2(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0 { // Type1
            KSSingletonManager.shared.isDataMonitorType1 = true
        } else { // Type2
            KSSingletonManager.shared.isDataMonitorType1 = false
        }
        dataMonitorListView?.checkType1AndType2SegmentSelection()
    }
    
    // Used to send websocket request with selected parameters and save records in textfile for every 50 ms interval
    @IBAction func startDataParameterButtonTapped(_ sender: UIButton) {
        if KSSingletonManager.shared.isWebSocketConnected {
            guard KSSingletonManager.shared.dataMonitorSubMenu.count > 0 else { return }
            if startPlotGraphbutton.title(for: .normal) == localizedKey("StartText") {
                guard dataMonitorListView?.arrayMonitorSelectedItems.count ?? 0 > 0 else {
                    self.presentAlert(withTitle: ALERTTITLESTRING, message: DATAMONITORSTARTERROR)
                    return }
                self.disableUIElementActions(title: localizedKey("StopText"), isStart: true)
                sendDataMonitorStartWebSocketRequest()
            } else {
                // Send stop datamonitor request only if it in start mode.
                if KSSingletonManager.shared.isDataMonitorStart {
                    sendDataMonitorStopWebSocketRequest()
                } else {
                    self.showStopActionSheetOptions()
                }
            }
        } else {
            presentAlertOKAction(withTitle: ERRORTITLE, message: SOCKETRECONNECT) { (_ ) in
                KSSingletonManager.shared.connectWebSocket()
            }
        }
    }
    
    // On click of start button disable few UI tap actions.
    fileprivate func disableUIElementActions(title: String, isStart: Bool) {
        startPlotGraphbutton.setTitle(title, for: .normal)
        KSSingletonManager.shared.isDataMonitorStart = isStart
        self.type1Type2Segment.isEnabled = isStart
        self.addParameterButton.isEnabled = !isStart
        self.navigationController?.navigationBar.isUserInteractionEnabled = isNavigationBarDisabled()
    }
    
    // Default hide some UI Elements before start data monitoring.
    fileprivate func disableFewFooterUIComponents(isEnabled: Bool) {
        self.startPlotGraphbutton.isEnabled = isEnabled
        self.type1Type2Segment.isEnabled = isEnabled
    }
    // Send datamonitor read websocket request to get item values.
    fileprivate func sendDataMonitorStartWebSocketRequest() {
        self.setMainChartViewBottomConstraint()
        self.dataMonitorListView?.getSelectedMonitorListItem()
        KSSingletonManager.shared.textFileReadValues.removeAll(keepingCapacity: false)
        self.resetGraphJSONArrayValues()
        self.showLoader()
        let monitorStartCommand = ReadSubmenuSocketRequest(screenName: "DataMonitor", frameType: "StartRequest", readSignals: KSSingletonManager.shared.dataMonitorReadIDs, periodicity: periodicityValue)
        guard let monitorRequestData = try? JSONEncoder().encode(monitorStartCommand) else { return }
        KSSingletonManager.shared.sendCommand(format: monitorRequestData)
    }
    // Send datamonitor stop websocket request to stop operation.
    func sendDataMonitorStopWebSocketRequest() {
        self.showLoader()
        let monitorStopCommand = ResetSocketRequest(screenName: "DataMonitor", frameType: "StopRequest", periodicity: 0)
        guard let monitorStopRequest = try? JSONEncoder().encode(monitorStopCommand) else { return }
        KSSingletonManager.shared.sendCommand(format: monitorStopRequest)
    }
    
    // Show Action sheet options on click of stop button.
    fileprivate func showStopActionSheetOptions() {
        self.stopButtonConditionCheck()
        self.showActionSheet { (selectedActionItem) in
            switch selectedActionItem {
            case ActionSheetIdentifiers.save.rawValue:
                self.createlogDataJSONFile(saveJSONData: true, sendTextFile: false)
            case ActionSheetIdentifiers.delete.rawValue:
                self.setMainChartViewBottomConstraint()
            case ActionSheetIdentifiers.saveAndSend.rawValue:
                self.createlogDataJSONFile(saveJSONData: true, sendTextFile: true)
            case ActionSheetIdentifiers.sendAndDelete.rawValue:
                self.createlogDataJSONFile(saveJSONData: false, sendTextFile: true)
            default: break
            }
        }
    }
    // Enable stop button functionality.
    fileprivate func stopButtonConditionCheck() {
        self.disableUIElementActions(title: localizedKey("StartText"), isStart: false)
        self.type1Type2Segment.isEnabled = true
    }
    // Create logdata json file with all required key values.
    fileprivate func createlogDataJSONFile(saveJSONData: Bool, sendTextFile: Bool) {
        self.setMainChartViewBottomConstraint()
        // Get timestamp in required format.
        let getTimeStamp = KSSingletonManager.shared.getCurrentTimeStamp(format: "yyyyMMdd_HHmmss")
        // Get merged datamonitor graph json object.
        let graphJSONDict = KSTextFileString.createDataMonitorGraphJSON(timeStamp: getTimeStamp)
        // Concatenate machine name & timestamp.
        let monitorFileName = KSSingletonManager.shared.modelTypeName + "_" + getTimeStamp
        // Pass all above info for saving and sending textfile to activityindictaor.
        self.shareFileToMentionedPlatform(viewController: self, fileName: monitorFileName, jsonDict: graphJSONDict, canSave: saveJSONData, canSend: sendTextFile)
    }
    
    // Share file to any platform
    func shareFileToMentionedPlatform(viewController: UIViewController, fileName: String, jsonDict: [String: Any], canSave: Bool, canSend: Bool) {
        self.showLoader()
        if canSave {
            print("canSave")
            // Saving log data json into local library directory.
            KSTextFileString.saveJSONDataToLibrary(viewController: self, fileName: fileName, jsonDict: jsonDict)
            if canSend {
                print("canSend")
                self.showLoader()
                // Send textfile datamonitor details to share extension.
                self.openDataMonitorShareExtension()
            }
        } else if canSend {
            print("canSend")
            self.showLoader()
            self.openDataMonitorShareExtension()
        }
    }
    // Add 100 ms delay to open share extension.
    fileprivate func openDataMonitorShareExtension() {
        // Get textfile info for share extension.
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [unowned self] in
            self.sendTextFileDetailsToShareExtension()
        }
    }
    // Textfile functionality.
    fileprivate func sendTextFileDetailsToShareExtension() {
        // Get timestamp in required format.
        let getTimeStamp = KSSingletonManager.shared.getCurrentTimeStamp(format: "yyyyMMdd_HHmmss")
        // Convert textfile name to required format.
        let textFileName = KSSingletonManager.shared.modelTypeName + "_" + getTimeStamp
        // Writing log data text into local document directory and uploading to gmail & whatsapp.
        let textFileValues = KSSingletonManager.shared.textFileReadValues
        KSTextFileString.writeJSONDataToTextfile(viewController: self, valuesArray: textFileValues, fileName: textFileName, interval: periodicityValue)
    }

    // Get monitor list view y position
    fileprivate func getListViewYPosition() {
        print("getListViewYPosition: \(listViewYPosition)")
        if listViewYPosition <= 68 {
            listViewYPosition = Int(isLandscapeMode ? (self.view.bounds.height - 75) : (self.view.bounds.height - 240))
        } else {
            listViewYPosition = Int(isLandscapeMode ? 35 : 68)
        }
    }
    // Called whenever application receives memory warning.
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        print("didReceiveMemoryWarning")
    }
}

// MARK: - Data monitor delegates
extension KSDataMonitor: KSMonitorDataDelegate {
    // Get list item selected monitor items
    func getSelectedMonitorItems(monitorItems: [String]) {
        if monitorItems.isEmpty {
            self.arrayMonitorSelectedItems = nil
            self.setBooleanValueForSomeController(booleanValue: true)
        } else {
            self.arrayMonitorSelectedItems = [String]()
            self.arrayMonitorSelectedItems = monitorItems
            if 0...(self.view.bounds.height/2) ~= (self.dataMonitorListView?.view.frame.height)! {
                if self.startPlotGraphbutton.title(for: .normal) == localizedKey("StopText") {
                    self.setBooleanValueForSomeController(booleanValue: false)
                }
            }
        }
        if self.startPlotGraphbutton.title(for: .normal) == localizedKey("StopText") {
            self.updateLineGraph()
        }
    }

    // Add data monitor list child controller as a subview.
    func addDataMonitorListChildController() {
        dataMonitorListView = MAINSTORYBOARD.instantiateViewController(withIdentifier: Identifier.dataMonitorList.rawValue) as? KSDataMonitorList
        self.addChild(dataMonitorListView!)
        dataMonitorListView?.monitorDelegate = self
        print("yposition: \(self.listViewYPosition)")
        self.chartViewBottomConstraint.constant = self.view.bounds.height - CGFloat(self.listViewYPosition + self.addValueInChartViewBottomConstraint)
        listViewYPosition = Int(UIDevice.current.orientation.isLandscape ? (self.view.bounds.height - 100) : (self.view.bounds.height - 240))
        self.dataMonitorListView?.view.frame = CGRect(x: 0, y: CGFloat(self.listViewYPosition), width: self.view.bounds.width, height: self.view.bounds.height - CGFloat(listViewYPosition))
        self.view.addSubview((dataMonitorListView?.view)!)
        self.view.insertSubview((dataMonitorListView?.view)!, belowSubview: self.footerViewDataMonitor)
        dataMonitorListView?.didMove(toParent: self)
    }
    // Called when user tap on footer tableview child controller lined button.
    // Used to swipe up and down the footer tableview list.
    func swipeUpAndDownTheChildController() {
        self.getListViewYPosition()
        self.adjustDataMonitorViewPosition()
    }
    // Called to remove child controller when user disappears from screen.
    func removeMonitorListChildController() {
        dataMonitorListView?.willMove(toParent: nil)
        dataMonitorListView?.view.removeFromSuperview()
        dataMonitorListView?.removeFromParent()
    }
    // Get signals from data monitor add paramter screen.
    func getAddParametersList(selectedParameters: [[String: Any]]) {
        if selectedParameters.count > 0 {
            for monitorSignalObject in selectedParameters {
                KSSingletonManager.shared.dataMonitorSubMenu.append(monitorSignalObject)
            }
            disableFewFooterUIComponents(isEnabled: true)
            dataMonitorListView?.appendEmptyValuesToMonitorItemListArray()
            type1Type2Segment.selectedSegmentIndex = 0
            dataMonitorListView?.checkType1AndType2SegmentSelection()
        }
    }
    // Called from tableview cell when selected
    func delegateStopDataMonitor() {
        self.sendDataMonitorStopWebSocketRequest()
    }
    // Reset graph JSON array values to empty.
    func resetGraphJSONArrayValues() {
        KSSingletonManager.shared.commonForLoopToGetGraphDict { (index, setGraphDict) in
            var setEmptyArrayValues = setGraphDict
            setEmptyArrayValues["signalValues"] = [Int]()
            KSSingletonManager.shared.dataMonitorJSONArray[index] = setEmptyArrayValues
        }
    }
}
// MARK: WebSocket Response Delegate
extension KSDataMonitor: KSWebSocketDelegates {
    // Called when websocket connection established.
    func webSocketStringResponse(response: String) {
        self.hideLoader()
    }
    // Called from singleton class when data monitor stopped successfully.
    func showDataMonitorActionSheet() {
        self.hideLoader()
        self.showStopActionSheetOptions()
    }
    // Called when receiving expected websocket response on click of datamonitor start.
    func reloadMonitorSubTableView() {
        self.hideLoader()
        self.dataMonitorListView?.reloadDataMonitorTableview()
    }
    // Called when request and response signals are matching.
    func sendMonitorStopSocketRequest() {
        self.sendDataMonitorStopWebSocketRequest()
        self.presentAlert(withTitle: ERRORINRESPONSETITLE, message: ERRORINRESPONSE)
    }
    // Called when error connection in websocket communication
    func webSocketErrorConnection(message: String) {
        self.hideLoader()
        //self.upDownCanViewSwipe = true
        presentAlertOKAction(withTitle: ERRORTITLE, message: message) { (_ ) in
            KSSingletonManager.shared.connectWebSocket()
        }
    }
    // Called when internet is disconnected or network not reachable.
    func internetConnectionNotAvailable() {
        self.hideLoader()
        presentAlertOKAction(withTitle: ERRORTITLE, message: WIFIDISCONNECTEDMESSAGE) { (isOkTapped) in
            if isOkTapped {
                self.navigateToWiFiSettings()
            }
        }
    }
    // Websocket response timeout alert.
     func noWebSocketResponse(message: String) {
         self.hideLoader()
         presentAlert(withTitle: ERRORTITLE, message: message)
     }
    
    // Delegate method for creating the graph data
    func createDictionaryForGraphDataDelegate() {
        self.createDictionaryForGraphData()
    }
}
// MARK: - Create Graph Data and Bind into graph
extension KSDataMonitor {
    // Initial setup of graph
    func setupInitialGraphData() {
        chartView.chartDescription?.enabled = false
        chartView.noDataText = ""
        chartView.dragEnabled = true
        chartView.setScaleEnabled(true)
        chartView.pinchZoomEnabled = true
        chartView.legend.enabled = false
        chartView.rightAxis.enabled = false
        chartView.drawBordersEnabled = true
        chartView.borderColor = NSUIColor.gray
        chartView.drawGridBackgroundEnabled = true
        let leftAxis = chartView.leftAxis
        leftAxis.drawGridLinesEnabled = true
        leftAxis.granularityEnabled = true
    }

    // Create timer for bind data into graph
    func createDictionaryForGraphData() {
        if self.drawgraphBackgroundTimer == nil {
            self.drawgraphBackgroundTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateLineGraph), userInfo: nil, repeats: true)
        }
    }
    // Graph data receive bind into graph
    @objc func updateLineGraph() {
        DispatchQueue.main.async {
            self.graphDictionaryValues.removeAll()
            if self.arrayMonitorSelectedItems != nil {
                self.noDataAvailableLabel.isHidden = true
                for (monitorItemDict) in KSSingletonManager.shared.dataMonitorJSONArray {
                    guard let getSignalId = monitorItemDict["signalId"] as? String else { return }
                    let isSignalIdPresent = self.arrayMonitorSelectedItems?.contains(where: getSignalId.contains)
                    if isSignalIdPresent! {
                        guard let getValuesArray = monitorItemDict["signalValues"] as? [Int] else { return }
                        guard let getSignalName = monitorItemDict["signalName"] as? String else { return }
                        guard let getSignalColorInHex = monitorItemDict["signalColor"] as? String else { return }
                        let graphData = GraphData(legendColor: UIColor.colorFromHexString(getSignalColorInHex), legendPoints: getValuesArray)
                        self.graphDictionaryValues[getSignalName] = graphData
                        self.toPointsDisplay = getValuesArray.count
                    }
                }
            }

            self.drawLineChart()
        }
    }
    
    // Draw line graph
    func drawLineChart () {
        //self.noDataAvailableLabel.text = ""
        self.graphTimeDisplayLabel.text = "Time (Seconds)"
        let xAxis = chartView.xAxis
        xAxis.labelPosition = .bottom
        xAxis.drawAxisLineEnabled = true
        xAxis.axisMinimum = Double(self.getFrompointToDisplay(maxPoint: self.toPointsDisplay))
        xAxis.axisMaximum = Double(self.toPointsDisplay)
        xAxis.valueFormatter = XAxisValueFormatterForLineChart()
        
        self.setDataCount()
    }
    
    func setDataCount() {
        self.legendDataSetObject = []
        self.lineChartData = []
        
        for (key, values) in self.graphDictionaryValues {
            //print("key --> \(key) values --> \(values)")
            let yVals1 = (self.getFrompointToDisplay(maxPoint: self.toPointsDisplay)..<self.toPointsDisplay).map { (i) -> ChartDataEntry in
                return ChartDataEntry(x: Double(i), y: Double(values.legendPoints[i]))
            }

            let lds = LegendDataSet()
            lds.legendName = key
            lds.legendColor = values.legendColor
            let set1 = LineChartDataSet(entries: yVals1, label: "\(key)")
            set1.axisDependency = .right
            set1.setColor(values.legendColor)
            set1.lineWidth = 1
            set1.highlightEnabled = false
            set1.drawValuesEnabled = false
            set1.drawCirclesEnabled = false
            set1.drawCircleHoleEnabled = false
            self.lineChartData.append(set1)
            self.legendDataSetObject.append(lds)
        }
        
        let data = LineChartData(dataSets: self.lineChartData)
        chartView.data = data
        self.legendDataSetObject = self.legendDataSetObject.sorted { $0.legendName < $1.legendName }
        self.stopDrawGraphBackgroundTimer()
        self.tableView.reloadData()
    }
    
    func stopDrawGraphBackgroundTimer() {
        if self.drawgraphBackgroundTimer != nil {
            self.drawgraphBackgroundTimer?.invalidate()
            self.drawgraphBackgroundTimer = nil
        }
    }
    // Display only 100 points into graph
    func getFrompointToDisplay (maxPoint: Int) -> Int {
        if maxPoint > 100 {
            return maxPoint - 100
        }
        return 0
    }
}

// MARK: - Tableview delegate and datasource method
extension KSDataMonitor: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.graphDictionaryValues.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "KSLegendCell", for: indexPath) as! KSLegendCell
        cell.fillCellData(legendDataSet: legendDataSetObject[indexPath.row])
        return cell
    }
}
