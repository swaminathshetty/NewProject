//
//  KSNormalDataEditing.swift
//  KobelcoService
//
//  Created by Guest L&T on 07/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

class KSNormalDataEditing: UIViewController {

    @IBOutlet weak var topDataEditingView: UIView!
    @IBOutlet weak var topNormalDataTitle: UILabel!
    @IBOutlet weak var dataEditingTableView: UITableView!
    @IBOutlet weak var deleteDataEditing: UIButton!
    @IBOutlet weak var changeDataEditing: UIButton!
    
    var setParameters: [KSIsCheckBoxSelectedModel] = []
    var selectedFiles: [Int] = []
    var subdirs = [NSURL]()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Normal Data Editing")
        loadNormalDataComponents()
        self.dataEditingTableView.register(UINib(nibName: "KSCheckBoxWithLabelCellTableViewCell", bundle: nil), forCellReuseIdentifier: "KSCheckBoxWithLabelCellTableViewCell")

    }
    
    // Configure Normal data UI components.
    fileprivate func loadNormalDataComponents() {
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.topDataEditingView.layer.cornerRadius = 6
        self.topNormalDataTitle.text = "Normal Data List"
        self.deleteDataEditing.setTitle("Delete", for: .normal)
        self.changeDataEditing.setTitle("Change Name", for: .normal)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.fetchDataFromFolder()
    }
        
    func fetchDataFromFolder() {
        self.setParameters.removeAll()
        self.selectedFiles.removeAll()
        self.subdirs.removeAll()
        self.getLocalDirectoryJSONPath()
        self.setParameters = subdirs.map {KSIsCheckBoxSelectedModel.init(nameValue: self.getStringFormURLDeletingPathExtension(url: $0), isSelectedValue: false)}
        self.dataEditingTableView.reloadData()
        self.checkPlotChartsButtonEnableOrNot()
    }

    // Get Local directory json log data saving path.
    func getLocalDirectoryJSONPath() {
        let enumerator = FileManager().enumerator(at: KSTextFileString.getLogDataFilesLibraryDirectoryPath(path: DataMonitorLogDataFolder)!, includingPropertiesForKeys: [URLResourceKey.isDirectoryKey], options: .skipsSubdirectoryDescendants, errorHandler: nil)

        while let url = enumerator?.nextObject() as? NSURL {
            subdirs.append(url)
        }
    }

    func checkPlotChartsButtonEnableOrNot() {
        var isButtonEnabled = false
        if self.selectedFiles.count != 0 {
            self.deleteDataEditing.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
            self.changeDataEditing.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
            isButtonEnabled = true
            
            if self.selectedFiles.count == 1 {
                self.changeDataEditing.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
                self.changeDataEditing.isEnabled = true
            } else {
                self.changeDataEditing.setTitleColor(#colorLiteral(red: 0.2117647059, green: 0.5137254902, blue: 0.5294117647, alpha: 1), for: .normal)
                self.changeDataEditing.isEnabled = false
            }
        
        } else {
            self.deleteDataEditing.setTitleColor(#colorLiteral(red: 0.2117647059, green: 0.5137254902, blue: 0.5294117647, alpha: 1), for: .normal)
            self.changeDataEditing.setTitleColor(#colorLiteral(red: 0.2117647059, green: 0.5137254902, blue: 0.5294117647, alpha: 1), for: .normal)
            self.changeDataEditing.isEnabled = false
        }
        
        self.deleteDataEditing.isEnabled = isButtonEnabled
        self.changeDataEditing.isEnabled = isButtonEnabled
    }

    // User can delete single and multiple normal data files based on selected checkbox from tableview list.
    @IBAction func deleteNormalDataFiles(_ sender: Any) {
        self.presentAlertWithAction(title: CONFIRMATIONTITLE, message: DELETEALERT, action1Title: CANCELTITLE, action2Title: localizedKey("DeleteText")) { [unowned self] (isSuccess) in
            if isSuccess {
                for index in self.selectedFiles {
                    let fileUrl = self.subdirs [index]
                    try? FileManager.default.removeItem(at: fileUrl as URL)
                }
                self.fetchDataFromFolder()
            }
        }
    }
    
    // ChangeName button enabled when user want to change any data file name.
    @IBAction func changeNormalDataFileName(_ sender: Any) {
        var getFileUrl: NSURL = NSURL()
        for index in self.selectedFiles {
            getFileUrl = self.subdirs [index]
        }

        self.alertWithTextField(title: CHANGENAMETITLE, message: nil, placeholder: self.getStringFormURLDeletingPathExtension(url: getFileUrl)) { result in
            
            if result != self.getStringFormURLDeletingPathExtension(url: getFileUrl) {
                try? getFileUrl.setResourceValue(result, forKey: URLResourceKey.nameKey)
            }
            
            self.fetchDataFromFolder()
        }
    }
}

// MARK: Tableview Delegate
extension KSNormalDataEditing: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if setParameters.count == 0 {
            DispatchQueue.main.async {
                self.dataEditingTableView.backgroundView = KSSingletonManager.shared.nullDataFilesLabel(message: self.localizedKey("NoRecordsText"))
            }
        } else {
            self.dataEditingTableView.backgroundView = nil
        }
        return self.setParameters.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let theParameterCell = tableView.dequeueReusableCell(withIdentifier: "KSCheckBoxWithLabelCellTableViewCell") as! KSCheckBoxWithLabelCellTableViewCell
        self.setupLogDataTableView(cellObj: theParameterCell, indexValue: indexPath.row)
        return theParameterCell
    }
    
    func setupLogDataTableView(cellObj: KSCheckBoxWithLabelCellTableViewCell, indexValue: Int) {
        let setParameter = self.setParameters[indexValue]
        cellObj.fillCellData(lableText: setParameter.name, isCheckBoxSelected: setParameter.isSelected)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let getParameters = self.setParameters[indexPath.row]
        self.setParameters[indexPath.row] = KSIsCheckBoxSelectedModel.init(nameValue: getParameters.name, isSelectedValue: !getParameters.isSelected)
        if !getParameters.isSelected {
            self.selectedFiles.append(indexPath.row)
        } else {
            self.selectedFiles = self.selectedFiles.filter {$0 != indexPath.row}
        }
        self.dataEditingTableView.reloadData()

        self.checkPlotChartsButtonEnableOrNot()
    }
}
