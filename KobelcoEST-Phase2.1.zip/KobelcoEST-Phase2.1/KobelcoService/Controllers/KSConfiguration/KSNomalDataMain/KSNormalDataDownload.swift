//
//  KSNormalDataDownload.swift
//  KobelcoService
//
//  Created by Guest L&T on 08/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

class KSNormalDataDownload: UIViewController {

    @IBOutlet weak var topHeaderView: UIView!
    @IBOutlet weak var headerTextLabel: UILabel!
    @IBOutlet weak var dataDownloadTableView: UITableView!
    @IBOutlet weak var downloadNormalDataButton: KSCustomButton!
    
    var setParameters: [KSIsCheckBoxSelectedModel] = []
    var selectedFiles: [Int] = []
    var subdirs = ["Data 1", "Data 2", "Data 3", "Data 4"]

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Normal Data Acquisition")
        self.dataDownloadTableView.register(UINib(nibName: "KSCheckBoxWithLabelCellTableViewCell", bundle: nil), forCellReuseIdentifier: "KSCheckBoxWithLabelCellTableViewCell")
        self.loadDataDownloadViewComponents()
    }
    
    // Configure Normal data UI components.
    fileprivate func loadDataDownloadViewComponents() {
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.topHeaderView.layer.cornerRadius = 6
        self.headerTextLabel.text = "Normal Data List"
        self.downloadNormalDataButton.setTitle("Data Acquisition", for: .normal)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.fetchDataFromFolder()
    }

    func fetchDataFromFolder() {
        self.setParameters.removeAll()
        self.selectedFiles.removeAll()
        self.setParameters = subdirs.map {KSIsCheckBoxSelectedModel.init(nameValue: $0, isSelectedValue: false)}
        self.dataDownloadTableView.reloadData()
        self.checkPlotChartsButtonEnableOrNot()
    }

    // Click on this button to download selected normal data files from tableview.
    @IBAction func dataAcquisitionDataDownloadAction(_ sender: Any) {
    }
    
    func checkPlotChartsButtonEnableOrNot() {
        var isButtonEnabled = false
        if self.selectedFiles.count != 0 {
            self.downloadNormalDataButton.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
            isButtonEnabled = true
        } else {
            self.downloadNormalDataButton.setTitleColor(#colorLiteral(red: 0.2117647059, green: 0.5137254902, blue: 0.5294117647, alpha: 1), for: .normal)
        }
        
        self.downloadNormalDataButton.isEnabled = isButtonEnabled
    }

}

// MARK: Tableview Delegate
extension KSNormalDataDownload: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if setParameters.count == 0 {
            DispatchQueue.main.async {
                self.dataDownloadTableView.backgroundView = KSSingletonManager.shared.nullDataFilesLabel(message: self.localizedKey("NoRecordsText"))
            }
        } else {
            self.dataDownloadTableView.backgroundView = nil
        }
        return self.setParameters.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let theParameterCell = tableView.dequeueReusableCell(withIdentifier: "KSCheckBoxWithLabelCellTableViewCell") as! KSCheckBoxWithLabelCellTableViewCell
        self.setupLogDataTableView(cellObj: theParameterCell, indexValue: indexPath.row)
        return theParameterCell
    }
    
    func setupLogDataTableView(cellObj: KSCheckBoxWithLabelCellTableViewCell, indexValue: Int) {
        let setParameter = self.setParameters[indexValue]
        cellObj.fillCellData(lableText: setParameter.name, isCheckBoxSelected: setParameter.isSelected)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let getParameters = self.setParameters[indexPath.row]
        self.setParameters[indexPath.row] = KSIsCheckBoxSelectedModel.init(nameValue: getParameters.name, isSelectedValue: !getParameters.isSelected)
        if !getParameters.isSelected {
            self.selectedFiles.append(indexPath.row)
        } else {
            self.selectedFiles = self.selectedFiles.filter {$0 != indexPath.row}
        }
        self.dataDownloadTableView.reloadData()

        self.checkPlotChartsButtonEnableOrNot()
    }
}
