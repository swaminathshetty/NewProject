//
//  KSLogDataManagement.swift
//  KobelcoService
//
//  Created by Swaminath on 9/27/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

class KSLogDataManagement: UIViewController {

    @IBOutlet weak var logTopView: UIView!
    @IBOutlet weak var topViewLogTitle: UILabel!
    @IBOutlet weak var logDataTableView: UITableView!
    @IBOutlet weak var logDeleteButton: UIButton!
    @IBOutlet weak var logChangeNameButton: UIButton!
    @IBOutlet weak var logShareButton: UIButton!
    var setParameters: [KSIsCheckBoxSelectedModel] = []
    var selectedFiles: [Int] = []
    var subdirs = [NSURL]()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Log Data Management")
        loadLogDataComponents()
        self.logDataTableView.register(UINib(nibName: "KSCheckBoxWithLabelCellTableViewCell", bundle: nil), forCellReuseIdentifier: "KSCheckBoxWithLabelCellTableViewCell")
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.fetchDataFromFolder()
    }
    
    // Configure log data UI components.
    fileprivate func loadLogDataComponents() {
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.logTopView.layer.cornerRadius = 6
        self.topViewLogTitle.text = "Log Data(s)"
        self.logDeleteButton.setTitle("Delete", for: .normal)
        self.logChangeNameButton.setTitle("Change Name", for: .normal)
    }
    
    func fetchDataFromFolder() {
        self.setParameters.removeAll()
        self.selectedFiles.removeAll()
        self.subdirs.removeAll()
        self.getLocalDirectoryJSONPath()
        self.setParameters = subdirs.map {KSIsCheckBoxSelectedModel.init(nameValue: self.getStringFormURLDeletingPathExtension(url: $0), isSelectedValue: false)}
        self.logDataTableView.reloadData()
        self.checkPlotChartsButtonEnableOrNot()
    }

    // User can delete single as well as multiple data files.
    @IBAction func deleteLogDataFiles(_ sender: Any) {
        self.presentAlertWithAction(title: CONFIRMATIONTITLE, message: DELETEALERT, action1Title: CANCELTITLE, action2Title: localizedKey("DeleteText")) { [unowned self] (isSuccess) in
            if isSuccess {
                for index in self.selectedFiles {
                    let fileUrl = self.subdirs [index]
                    try? FileManager.default.removeItem(at: fileUrl as URL)
                }
                self.fetchDataFromFolder()
            }
        }
    }
    
    // At a time user can edit only single datafile name from the list.
    @IBAction func changeLogFileName(_ sender: Any) {
        var getFileUrl: NSURL = NSURL()
        for index in self.selectedFiles {
            getFileUrl = self.subdirs [index]
        }

        self.alertWithTextField(title: CHANGENAMETITLE, message: nil, placeholder: self.getStringFormURLDeletingPathExtension(url: getFileUrl)) { result in
            
            if result != self.getStringFormURLDeletingPathExtension(url: getFileUrl) {
                try? getFileUrl.setResourceValue(result, forKey: URLResourceKey.nameKey)
            }
            
            self.fetchDataFromFolder()
        }

    }

    // Click on this button to share single and mutiple data files based on user selection.
    @IBAction func shareLogFiles(_ sender: Any) {
    }
    
    // Get Local directory json log data saving path.
    func getLocalDirectoryJSONPath() {
        let enumerator = FileManager().enumerator(at: KSTextFileString.getLogDataFilesLibraryDirectoryPath(path: DataMonitorLogDataFolder)!, includingPropertiesForKeys: [URLResourceKey.isDirectoryKey], options: .skipsSubdirectoryDescendants, errorHandler: nil)

        while let url = enumerator?.nextObject() as? NSURL {
            subdirs.append(url)
        }
    }

}

// MARK: Tableview Delegate
extension KSLogDataManagement: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if setParameters.count == 0 {
            DispatchQueue.main.async {
                self.logDataTableView.backgroundView = KSSingletonManager.shared.nullDataFilesLabel(message: self.localizedKey("NoRecordsText"))
            }
        } else {
            self.logDataTableView.backgroundView = nil
        }
        return self.setParameters.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let theParameterCell = tableView.dequeueReusableCell(withIdentifier: "KSCheckBoxWithLabelCellTableViewCell") as! KSCheckBoxWithLabelCellTableViewCell
        self.setupLogDataTableView(cellObj: theParameterCell, indexValue: indexPath.row)
        return theParameterCell
    }
    
    func setupLogDataTableView(cellObj: KSCheckBoxWithLabelCellTableViewCell, indexValue: Int) {
        let setParameter = self.setParameters[indexValue]
        cellObj.fillCellData(lableText: setParameter.name, isCheckBoxSelected: setParameter.isSelected)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let getParameters = self.setParameters[indexPath.row]
        self.setParameters[indexPath.row] = KSIsCheckBoxSelectedModel.init(nameValue: getParameters.name, isSelectedValue: !getParameters.isSelected)
        if !getParameters.isSelected {
            self.selectedFiles.append(indexPath.row)
        } else {
            self.selectedFiles = self.selectedFiles.filter {$0 != indexPath.row}
        }
        self.logDataTableView.reloadData()

        self.checkPlotChartsButtonEnableOrNot()
    }

    func checkPlotChartsButtonEnableOrNot() {
        var isButtonEnabled = false
        if self.selectedFiles.count != 0 {
            self.logDeleteButton.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
            self.logShareButton.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
            isButtonEnabled = true
            
            if self.selectedFiles.count == 1 {
                self.logChangeNameButton.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
                self.logChangeNameButton.isEnabled = true
            } else {
                self.logChangeNameButton.setTitleColor(#colorLiteral(red: 0.2117647059, green: 0.5137254902, blue: 0.5294117647, alpha: 1), for: .normal)
                self.logChangeNameButton.isEnabled = false
            }
        
        } else {
            self.logDeleteButton.setTitleColor(#colorLiteral(red: 0.2117647059, green: 0.5137254902, blue: 0.5294117647, alpha: 1), for: .normal)
            self.logChangeNameButton.setTitleColor(#colorLiteral(red: 0.2117647059, green: 0.5137254902, blue: 0.5294117647, alpha: 1), for: .normal)
            self.logShareButton.setTitleColor(#colorLiteral(red: 0.2117647059, green: 0.5137254902, blue: 0.5294117647, alpha: 1), for: .normal)
            self.logChangeNameButton.isEnabled = false
        }
        
        self.logDeleteButton.isEnabled = isButtonEnabled
        self.logShareButton.isEnabled = isButtonEnabled
    }
}
