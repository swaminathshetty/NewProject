//
//  KSParameterEdit.swift
//  KobelcoService
//
//  Created by Guest L&T on 01/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

class KSParameterEdit: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var configureEditBGView: UIView!
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var footerView: UIView!
    @IBOutlet weak var textFieldParameter: UITextField!
    @IBOutlet weak var tableViewParameters: UITableView!
    @IBOutlet weak var buttonDelete: UIButton!
    @IBOutlet weak var buttonSave: UIButton!
    @IBOutlet weak var enginePumpSegmentRegistration: UISegmentedControl!
    @IBOutlet weak var segmentECUEdit: UISegmentedControl!
    var selectedFavoriteParameter = ""
    var ecuSignalsArray: [ECUSignalsModel] = []
    var pumpSignalsArray: [ECUSignalsModel] = []
    var setParameters: [KSIsCheckBoxSelectedModel] = []
    var plistHelepr = KSPlistReadAndWriteModel()
    var isBackButtonPressed = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadParameterEditComponents()
        self.setNavigationBarColorWithButtonTitle(buttonTitle: localizedKey("EditFavorite"))
        let output = plistHelepr.readPlistReturnDic(namePlist: ParameterRegistrationFile, key: selectedFavoriteParameter)
        self.tableViewParameters.register(UINib(nibName: "KSCheckBoxWithLabelCellTableViewCell", bundle: nil), forCellReuseIdentifier: "KSCheckBoxWithLabelCellTableViewCell")
        self.setECUPumpArrayValues(dicValue: output)
        self.textFieldParameter.delegate = self
        self.configureEditParameterGestureRecognizers()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.isDeleteButtonEnableOrNot()
        self.isSaveButtonEnableOrNot()
    }
    
    //Configure UI Components
    func loadParameterEditComponents() {
        self.view.backgroundColor = NAVIGATIONBARCOLOR
        self.configureEditBGView.backgroundColor = VIEWBACKGROUNDCOLOR
        self.headerView.layer.cornerRadius = 6
        self.enginePumpSegmentRegistration.layer.cornerRadius = 6
        self.segmentECUEdit.layer.cornerRadius = 6
        self.enginePumpSegmentRegistration.setTitle(localizedKey("Engine"), forSegmentAt: 0)
        self.enginePumpSegmentRegistration.setTitle(localizedKey("Pump"), forSegmentAt: 1)
        self.buttonDelete.setTitle(localizedKey("DeleteText"), for: .normal)
        self.buttonSave.setTitle(localizedKey("SaveText"), for: .normal)
        self.enginePumpSegmentRegistration.setSegmentTintColors()
        self.segmentECUEdit.setSegmentTintColors()
        self.textFieldParameter.text = self.selectedFavoriteParameter
    }
    // Configure gesture recognizer for UIView
    fileprivate func configureEditParameterGestureRecognizers() {
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(respondToEditParameterSwipeGesture))
        swipeRight.direction = .right
        self.view.addGestureRecognizer(swipeRight)
        
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(respondToEditParameterSwipeGesture))
        swipeLeft.direction = .left
        self.view.addGestureRecognizer(swipeLeft)
    }
    // Navigate to particular screen based on swipe direction.
    @objc func respondToEditParameterSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case .right:
                self.popOverToBackScreen(indexValue: KSSingletonManager.shared.configurationNavigationID)
            case .left:
                self.navigation(to: Identifier.dashboardScreen, isSwiped: true)
            default:
                break
            }
        }
    }
    
    @IBAction func deleteButtonTapAction(_ sender: Any) {
        self.presentAlertWithAction(title: CONFIRMATIONTITLE, message: DELETEALERT, action1Title: CANCELTITLE, action2Title: localizedKey("DeleteText")) { [unowned self] (isSuccess) in
            if isSuccess {
                self.plistHelepr.deleteValueFormPlist(namePlist: ParameterRegistrationFile, key: self.selectedFavoriteParameter)
                self.navigationController?.popViewController(animated: true)
            }
        }
    }
    
    @IBAction func saveButtonTapAction(_ sender: Any) {
        let item = self.setParameters.filter { $0.name.lowercased() == self.textFieldParameter.text!.lowercased()}
        if item.count == 1 && item[0].name.lowercased() != self.selectedFavoriteParameter.lowercased() {
            self.presentAlert(withTitle: ALERTTITLESTRING, message: NAMEEXISTMESSAGE)
            return
        }

        if selectedFavoriteParameter != self.textFieldParameter.text {
            self.plistHelepr.deleteValueFormPlist(namePlist: ParameterRegistrationFile, key: selectedFavoriteParameter)
        }

        self.parameterAddCaption(txtValue: self.textFieldParameter.text!)
        self.navigationController?.popViewController(animated: true)
    }

    // Toggle segment for engine and pump selection.
    // By default engine and ECU will select and display respective list in the parameter tableview.
    @IBAction func enginePumpRegistrationmainSegmentAction(_ sender: Any) {
        self.tableViewParameters.reloadData()
    }

    func setECUPumpArrayValues(dicValue: [String: Any]) {
        let ecuSignals = dicValue["ECUSignals"] as! [[String: Any]]
        self.ecuSignalsArray = ecuSignals.map {ECUSignalsModel.init(data: $0)}
        let pumpSignals = dicValue["pumpSignals"] as! [[String: Any]]
        self.pumpSignalsArray = pumpSignals.map {ECUSignalsModel.init(data: $0)}
    }

    func parameterAddCaption(txtValue: String) {
        var data: [String: Any]
        let ecuDictionary = self.ecuSignalsArray.map {$0.asDictionary}
        let pumpDictionary = self.pumpSignalsArray.map {$0.asDictionary}
        data = ["ECUSignals": ecuDictionary, "pumpSignals": pumpDictionary]
        plistHelepr.writePlist(namePlist: ParameterRegistrationFile, key: txtValue, data: data as AnyObject)
    }

    func isSaveButtonEnableOrNot() {
        var checkECUAndPumpValues = [ECUSignalsModel]()
        checkECUAndPumpValues = self.ecuSignalsArray.filter {$0.isSelected == true}
        checkECUAndPumpValues += self.pumpSignalsArray.filter {$0.isSelected == true}

        if self.textFieldParameter.text?.count != 0 && checkECUAndPumpValues.count != 0 {
            self.buttonSave.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
            self.buttonSave.isEnabled = true
        } else {
            self.buttonSave.setTitleColor(DISBALECOLOR, for: .normal)
            self.buttonSave.isEnabled = false
        }
    }

    func isDeleteButtonEnableOrNot() {
        if self.textFieldParameter.text?.count != 0 {
            self.buttonDelete.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
            self.buttonDelete.isEnabled = true
        } else {
            self.buttonDelete.setTitleColor(DISBALECOLOR, for: .normal)
            self.buttonDelete.isEnabled = false
        }
    }
}

// MARK: Tableview Delegate
extension KSParameterEdit: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.enginePumpSegmentRegistration.selectedSegmentIndex == 1 {
            return self.pumpSignalsArray.count
        } else {
            return self.ecuSignalsArray.count
        }
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let theParameterCell = tableView.dequeueReusableCell(withIdentifier: "KSCheckBoxWithLabelCellTableViewCell") as! KSCheckBoxWithLabelCellTableViewCell
        self.setUpTheParameterTableView(cellObj: theParameterCell, indexValue: indexPath.row)
        return theParameterCell
    }

    func setUpTheParameterTableView(cellObj: KSCheckBoxWithLabelCellTableViewCell, indexValue: Int) {
        var txtLabel = ""
        var isSelected = false
        if self.enginePumpSegmentRegistration.selectedSegmentIndex == 1 {
            txtLabel = self.pumpSignalsArray[indexValue].name[KSSingletonManager.shared.languageCode] as! String
            isSelected = self.pumpSignalsArray[indexValue].isSelected
        } else {
            txtLabel = self.ecuSignalsArray[indexValue].name[KSSingletonManager.shared.languageCode] as! String
            isSelected = self.ecuSignalsArray[indexValue].isSelected
        }

        cellObj.fillCellData(lableText: txtLabel, isCheckBoxSelected: isSelected)
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.parameterCheckBoxButtonPressed(indexValue: indexPath.row)
        self.isSaveButtonEnableOrNot()
    }
}

extension KSParameterEdit {
    func parameterCheckBoxButtonPressed(indexValue: Int) {
         if self.enginePumpSegmentRegistration.selectedSegmentIndex == 1 {
            var pump = self.pumpSignalsArray[indexValue]
            pump.isSelected = !pump.isSelected
            self.pumpSignalsArray[indexValue] = pump
         } else {
            var ecu = self.ecuSignalsArray[indexValue]
            ecu.isSelected = !ecu.isSelected
            self.ecuSignalsArray[indexValue] = ecu
         }
        let reloadIndex = IndexPath(row: indexValue, section: 0)
        self.tableViewParameters.reloadRows(at: [reloadIndex], with: .none)
    }
}

extension KSParameterEdit {
    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.text = textField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        self.isSaveButtonEnableOrNot()
        self.isDeleteButtonEnableOrNot()
    }

    /*func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if string.isEmpty {
            return true
        }
        let alphaNumericRegEx = "^[a-zA-Z0-9_ ]*$"
        let predicate = NSPredicate(format: "SELF MATCHES %@", alphaNumericRegEx)
        return predicate.evaluate(with: string)
    }*/
}
