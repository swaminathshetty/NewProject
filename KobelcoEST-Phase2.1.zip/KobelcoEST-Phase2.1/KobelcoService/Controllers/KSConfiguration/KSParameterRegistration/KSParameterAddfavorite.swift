//
//  KSParameterAddfavorite.swift
//  KobelcoService
//
//  Created by Admin on 11/5/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

protocol KSParameterAddfavoriteDelegate: class {
    func parameterAddCaption(txtValue: String)
}

extension KSParameterAddfavoriteDelegate {
    func parameterAddCaption(txtValue: String) {}
}

class KSParameterAddfavorite: UIViewController, UITextFieldDelegate {
    @IBOutlet weak var newParameterTextField: UITextField!
    @IBOutlet weak var createParameterButton: UIButton!
    weak var ksParameterAddfavoriteDelegate: KSParameterAddfavoriteDelegate?
    var setParameters: [KSIsCheckBoxSelectedModel] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.newParameterTextField.delegate = self
        self.setNavigationBarColorWithButtonTitle(buttonTitle: localizedKey("AddFavorite"))
        self.newParameterTextField.placeholder = localizedKey("CaptionPlaceHolder")
        self.createParameterButton.setTitle(localizedKey("Done"), for: .normal)
        self.newParameterTextField.setCustomTextFieldStyle()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.isDoneButtonEnableOrNot()
    }
    
    @IBAction func createNewParameterTapAction(_ sender: Any) {
        let item = self.setParameters.filter { $0.name.lowercased() == self.newParameterTextField.text?.lowercased()}
        if item.count == 1 {
            self.presentAlert(withTitle: ALERTTITLESTRING, message: NAMEEXISTMESSAGE)
            return
        }

        self.ksParameterAddfavoriteDelegate?.parameterAddCaption(txtValue: self.newParameterTextField.text!)
        self.navigationController?.popViewController(animated: true)
    }
    
    func isDoneButtonEnableOrNot() {
        if self.newParameterTextField.text?.count != 0 {
            self.createParameterButton.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .normal)
            self.createParameterButton.isEnabled = true
        } else {
            self.createParameterButton.setTitleColor(DISBALECOLOR, for: .normal)
            self.createParameterButton.isEnabled = false
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.text = textField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        self.isDoneButtonEnableOrNot()
    }

    /*func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if string.isEmpty {
            return true
        }
        let alphaNumericRegEx = "^[a-zA-Z0-9_ ]*$"
        let predicate = NSPredicate(format: "SELF MATCHES %@", alphaNumericRegEx)
        return predicate.evaluate(with: string)
    }*/
}
