//
//  KSModelTypeList.swift
//  KobelcoService
//
//  Created by Guest L&T on 21/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

class KSModelTypeList: UIViewController {

    @IBOutlet weak var tableViewData: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    fileprivate var filteredData = [[String: Any]]()
    weak var delegate: KSModelTypeDelegate!
    fileprivate var modelTypeArray: [[String: Any]]!
    fileprivate var areaNamesArray: [[String: Any]]!
    var modelTypeName = ""
    var selectedInput = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        searchBar.placeholder = (selectedInput == "MODELTYPE") ? localizedKey("ModelPlaceHolder") : localizedKey("AreaPlaceHolder")
        //searchBar.becomeFirstResponder()
        self.tableViewData.rowHeight = 44
        guard let modelData = KSSingletonManager.shared.modelTypeDefaults.value(forKey: MODELTYPEFILE) as? Data else { return }
        self.decodeModelTypeData(modelTypeData: modelData)
    }
    fileprivate func decodeModelTypeData(modelTypeData: Data) {
        DispatchQueue.main.async {
            guard let jsonDict = self.convertDataToDictionary(data: modelTypeData) else { return }
             guard let modelTypeList = jsonDict["modelTypeList"] as? [[String: Any]] else { return }
            if self.selectedInput == "MODELTYPE" {
                self.modelTypeArray = modelTypeList
                self.filteredData = modelTypeList
             } else {
                     let areaList = modelTypeList.filter({(dataDict: [String: Any]) -> Bool in
                         return (dataDict["name"] as! String).range(of: self.modelTypeName, options: .caseInsensitive) != nil
                     })
                     guard let filteredList = areaList[0]["area"] as? [[String: Any]] else { return }
                     self.areaNamesArray = filteredList
                     self.filteredData = filteredList
                 }
             }
        self.perform(#selector(loadTableViewData), with: self, afterDelay: 2)
    }

    @objc func loadTableViewData() {
        DispatchQueue.main.async {
            self.tableViewData.reloadData()
        }
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        filteredData.removeAll(keepingCapacity: false)
    }
}

// MARK: Tableview Delegate
extension KSModelTypeList: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "KSModelTypeCell", for: indexPath) as! KSModelTypeCell
        cell.labelTitle.text = filteredData[indexPath.row]["name"] as? String
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var selectedString = ""
        if selectedInput == "MODELTYPE" {
            guard let modelName = filteredData[indexPath.row]["name"] as? String else { return }
            selectedString = modelName
            KSSingletonManager.shared.modelTypeName = selectedString
            modelTypeArray.removeAll(keepingCapacity: false)
        } else {
            guard let typeName = filteredData[indexPath.row]["name"] as? String else { return }
            selectedString = typeName
            KSSingletonManager.shared.modelTypeSelection = filteredData[indexPath.row]["type"] as? String ?? ""
            areaNamesArray.removeAll(keepingCapacity: false)
        }
        print("KSSingletonManager.shared.modelTypeSelection: \(KSSingletonManager.shared.modelTypeSelection)")
        delegate.sendSelectedModelItem(selectedTF: selectedInput, selectedItem: selectedString)
        self.dismiss(animated: true, completion: nil)
    }
}

// MARK: - SearchBar Delegate
extension KSModelTypeList: UISearchBarDelegate {
    
    // Used to filter the strings based on the user input and showcase on tableview list
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        let mainArray: [[String: Any]] = (selectedInput == "MODELTYPE") ? modelTypeArray: areaNamesArray
        filteredData = searchText.isEmpty ? mainArray: mainArray.filter({(dataDict: [String: Any]) -> Bool in
            return (dataDict["name"] as! String).range(of: searchText, options: .caseInsensitive) != nil
            // this is where you determine whether to include the specific element, $0
        })
        tableViewData.reloadData()
    }
    
    // Dismiss viewcontroller by clicking on search cancel button
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.view.endEditing(true)
        self.dismiss(animated: true, completion: nil)
    }
}
