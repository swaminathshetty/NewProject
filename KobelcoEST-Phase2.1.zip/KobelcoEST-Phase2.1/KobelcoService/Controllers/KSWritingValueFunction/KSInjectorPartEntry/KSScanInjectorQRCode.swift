//
//  KSScanInjectorQRCode.swift
//  KobelcoService
//
//  Created by Guest L&T on 09/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit
import AVFoundation

class KSScanInjectorQRCode: UIViewController, AVCaptureMetadataOutputObjectsDelegate {

    @IBOutlet weak var scanHeaderTitle: UILabel!
    @IBOutlet weak var scanSubTitle: UILabel!
    @IBOutlet weak var scanQRView: UIView!
    fileprivate var isScanViewPresented = true
    // QRScan related properties
    fileprivate var captureSession: AVCaptureSession!
    fileprivate var previewLayer: AVCaptureVideoPreviewLayer!
    private let supportedCodeTypes = [AVMetadataObject.ObjectType.qr,
                                      AVMetadataObject.ObjectType.dataMatrix]
    fileprivate var isTourchOn = false
    let minimumZoom: CGFloat = 1.0
    let maximumZoom: CGFloat = 3.0
    var lastZoomFactor: CGFloat = 1.0
    weak var delegate: KSInjectorPartDelegate!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.scanHeaderTitle.text = QRHEADERTITLE
        self.scanSubTitle.text = QRBODYTEXT
        let pinchRecognizer = UIPinchGestureRecognizer(target: self, action: #selector(pinch(_ :)))
        self.scanQRView.addGestureRecognizer(pinchRecognizer)
        DispatchQueue.main.async {
            self.cameraPermissionRequest()
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if captureSession?.isRunning == false {
            captureSession.startRunning()
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.isScanViewPresented = false
        self.toggleTorch(on: false)
        self.removePreviewLayers()
    }
    // MARK: Identify screen orientation
    // todo: clear copyright label from footer before orientation changes
    // fixme: Again add copyright footer label after screen orientation to avoid constraint problem.
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        if isScanViewPresented {
            //if captureSession.isRunning {
                let iPhoneFrame = getWidthAndHeight()
                self.previewLayer.frame =  CGRect(x: 5, y: 5, width: iPhoneFrame.0, height: iPhoneFrame.1)
            //}
        }
    }
    // Get width and height values for all sizes phones in landscape mode.
    fileprivate func getWidthAndHeight() -> (CGFloat, CGFloat) {
        switch ISIPHONE {
        case ISIPHONE4ORLESS || ISIPHONE5:
            return UIDevice.current.orientation.isLandscape ? (200, 150) : (scanQRView.frame.width - 10, scanQRView.frame.height - 10)
        case ISIPHONE6OR7:
            return UIDevice.current.orientation.isLandscape ? (250, 235) : (324, 333)
        case ISIPHONE6P7P || ISIPHONEX:
            return UIDevice.current.orientation.isLandscape ? (302, 186) : (364, 504)
        default:
            return UIDevice.current.orientation.isLandscape ? (250, 164) : (scanQRView.frame.width - 10, scanQRView.frame.height - 10)
        }
    }
    // Tap to dismiss the current controller
    @IBAction func scanQRCodeBackTap(_ sender: Any) {
        if AVCaptureDevice.authorizationStatus(for: .video) == .authorized {
            self.removePreviewLayers()
        }
        self.dismiss(animated: true, completion: nil)
    }
    // Action for bottom flash icon, to toggle the flash light.
    @IBAction func flashLightButtonAction(_ sender: Any) {
        self.toggleTorch(on: isTourchOn ? false : true )
    }
    // Clear session and preview layers fom mainview.
    func removePreviewLayers() {
        if captureSession?.isRunning == true {
            captureSession.stopRunning()
            previewLayer.removeFromSuperlayer()
            previewLayer.removeAllAnimations()
        }
        captureSession.stopRunning()
    }
    // Requesting for camera access to scan QRCode.
    func cameraPermissionRequest() {
        if AVCaptureDevice.authorizationStatus(for: .video) ==  .authorized {
            // already authorized
            print("already authorized")
            DispatchQueue.main.async {
                self.configureVideoCapture()
            }
        } else {
            AVCaptureDevice.requestAccess(for: .video, completionHandler: { (granted: Bool) in
                if granted {
                    // access allowed
                    print("access allowed")
                    DispatchQueue.main.async {
                        self.configureVideoCapture()
                    }
                } else {
                    // access denied
                    print("access denied")
                    DispatchQueue.main.async {
                        self.presentAlertWithAction(title: ALERTTITLESTRING, message: QRCODEMESSAGE, action1Title: CANCELTITLE, action2Title: self.localizedKey("AllowCamera")) { (isAllowCamera) in
                            if isAllowCamera {
                                KSSingletonManager.openWifiSettings() // It will open iPhone general settings screen
                            }
                        }
                    }
                }
            })
        }
    }
    
    // configure QRCode session
    func configureVideoCapture() {
        captureSession = AVCaptureSession()
        guard let videoCaptureDevice = AVCaptureDevice.default(for: .video) else {
            self.presentAlertOKAction(withTitle: QRCODEERRORTITLE, message: QRCODEERRORMESSAGE) { (isOkClicked) in
                if isOkClicked {
                    self.removePreviewLayers()
                    self.dismiss(animated: true, completion: nil)
                }
            }
            return
        }
        let videoInput: AVCaptureDeviceInput
        do {
            videoInput = try AVCaptureDeviceInput(device: videoCaptureDevice)
        } catch {
            return
        }
        if captureSession.canAddInput(videoInput) {
            captureSession.addInput(videoInput)
        } else {
            self.presentAlert(withTitle: QRCODEERRORTITLE, message: QRCODEERRORMESSAGE)
            return
        }
        let metadataOutput = AVCaptureMetadataOutput()
        if captureSession.canAddOutput(metadataOutput) {
            captureSession.addOutput(metadataOutput)
            metadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
            metadataOutput.metadataObjectTypes = supportedCodeTypes

        } else {
            self.presentAlert(withTitle: QRCODEERRORTITLE, message: QRCODEERRORMESSAGE)
            return
        }
        self.addVideoPreviewLayer()
    }
    
    // Set video preview layer for scanning.
    func addVideoPreviewLayer() {
        previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        //setFramesForPreviewLayer()
        previewLayer.frame =  CGRect(x: 5, y: 5, width: scanQRView.frame.width - 10, height: scanQRView.frame.height - 10)
        previewLayer.videoGravity = .resizeAspectFill
        scanQRView?.layer.borderColor = UIColor.green.cgColor
        scanQRView?.layer.borderWidth = 5
        scanQRView.layer.addSublayer(previewLayer)
        
        captureSession.startRunning()
    }
    // Callback method to recieve qr scan output.
    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        captureSession.stopRunning()

        if let metadataObject = metadataObjects.first {
            guard let readableObject = metadataObject as? AVMetadataMachineReadableCodeObject else { return }
            guard let stringValue = readableObject.stringValue else { return }
            AudioServicesPlaySystemSound(SystemSoundID(kSystemSoundID_Vibrate))
            found(code: stringValue)
        }
    }
    // Read QRCode string.
    func found(code: String) {
        if code.count == 49 {
            let validQR = String(code.dropFirst(19))
            delegate.removeScanQRChildContoller(QRCode: validQR)
            self.dismiss(animated: true, completion: nil)
        } else {
            self.presentAlertOKAction(withTitle: ALERTTITLESTRING, message: SCANVALIDQRCODE) { [unowned self] (_) in
                self.captureSession.startRunning()
            }
        }
    }
    // Used to switch on/off the phone flash light.
    func toggleTorch(on: Bool) {
        guard let device = AVCaptureDevice.default(for: AVMediaType.video) else { isTourchOn = false; return }
        guard device.hasTorch else { isTourchOn = false; print("Torch isn't available"); return }
        do {
            try device.lockForConfiguration()
            device.torchMode = on ? .on : .off
            isTourchOn = on
            // Optional thing you may want when the torch it's on, is to manipulate the level of the torch
            if on { try device.setTorchModeOn(level: 1.0) }
            device.unlockForConfiguration()
        } catch {
            isTourchOn = false
            print("Torch can't be used")
        }
    }
    // Camera pinch to zoom option.
    @objc func pinch(_ pinch: UIPinchGestureRecognizer) {
        guard let device = AVCaptureDevice.default(for: AVMediaType.video) else { return }
        // Return zoom value between the minimum and maximum zoom values
        func minMaxZoom(_ factor: CGFloat) -> CGFloat {
            return min(min(max(factor, minimumZoom), maximumZoom), device.activeFormat.videoMaxZoomFactor)
        }
        func update(scale factor: CGFloat) {
            do {
                try device.lockForConfiguration()
                defer { device.unlockForConfiguration() }
                device.videoZoomFactor = factor
            } catch {
                print("\(error.localizedDescription)")
            }
        }
        let newScaleFactor = minMaxZoom(pinch.scale * lastZoomFactor)
        switch pinch.state {
        case .began: fallthrough
        case .changed: update(scale: newScaleFactor)
        case .ended:
            lastZoomFactor = minMaxZoom(newScaleFactor)
            update(scale: lastZoomFactor)
        default: break
        }
    }
}
