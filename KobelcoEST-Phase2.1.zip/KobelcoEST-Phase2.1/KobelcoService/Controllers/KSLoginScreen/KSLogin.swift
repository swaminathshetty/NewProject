//
//  KSLogin.swift
//  KobelcoService
//
//  Created by Guest L&T on 09/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSLogin: UIViewController {

    @IBOutlet weak var labelUserID: UILabel!
    @IBOutlet weak var labelPassword: UILabel!
    @IBOutlet weak var textFieldUserID: UITextField!
    @IBOutlet weak var textFieldPassword: UITextField!
    @IBOutlet weak var buttonSignIn: UIButton!
    @IBOutlet weak var ipAddressTextField: UITextField!
    
    fileprivate var isLoginViewPresented: Bool = true
    private let loginVM: KSLoginVM
    
    init(loginVM: KSLoginVM) {
        self.loginVM = loginVM
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        self.loginVM = KSLoginVM(model: LoginModel())
        super.init(coder: coder)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        isLoginViewPresented = true
    }
    // AutoHide iPhoneX/Pro footer line.
    override var prefersHomeIndicatorAutoHidden: Bool {
        return false
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = COPYRIGHTBGCOLOR
        setUpLoginUIComponents()
        // Setting default credentials
        self.textFieldUserID.text = "kobelcotaro"
        self.textFieldPassword.text = "kblc4192"
        self.ipAddressTextField.text = "10.9.40.186"
    }
    // Touch outside on view anywhere to hide keyboard.
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    func setUpLoginUIComponents() {
        self.labelUserID.font = UIFont.regular(ofSize: 17)
        self.labelPassword.font = UIFont.regular(ofSize: 17)
        self.textFieldUserID.setCustomTextFieldStyle()
        self.textFieldPassword.setCustomTextFieldStyle()
        self.labelUserID.text = localizedKey("UserIDText")
        self.labelPassword.text = localizedKey("PasswordText")
        self.textFieldUserID.placeholder = localizedKey("UserIDPlaceholder")
        self.textFieldPassword.placeholder = localizedKey("PasswordPlaceholder")
        self.buttonSignIn.setTitle(localizedKey("SignInText"), for: .normal)
        self.showCopyrightLabel()
    }
    
    // MARK: Identify screen orientation
    // todo: clear copyright label from footer before orientation changes
    // fixme: Again add copyright footer label after screen orientation to avoid constraint problem.
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        if isLoginViewPresented {
            self.hideCopyrightLabel()
            if UIDevice.current.orientation.isLandscape {
                self.showCopyrightLabel()
            } else {
                self.showCopyrightLabel()
            }
        }
    }
    
    // Enter UserID and password before clicking on this button for signin.
    @IBAction func signInButtonTap(_ sender: Any) {
        self.view.endEditing(true)
        do {
               _ = try loginVM.validateUserName(textFieldUserID.text)
               _ = try loginVM.validatePassword(textFieldPassword.text)
               _ = try loginVM.validateUserNameAndPassword(textFieldUserID.text, textFieldPassword.text)
            // After successfull authetication navigate to next screen
            if self.ipAddressTextField.text?.count ?? 0 > 8 {
                KSSingletonManager.shared.tempIPAddress = ipAddressTextField.text ?? ""
            self.showLoader()
            KSSingletonManager.shared.loadJson(filename: MODELTYPEFILE) { (modelTypeData) in
                KSSingletonManager.shared.modelTypeDefaults.set(modelTypeData, forKey: MODELTYPEFILE)
                KSSingletonManager.shared.modelTypeDefaults.synchronize()
                self.checkNetworkAvailability()
            }
            } else {
                self.presentAlert(withTitle: "Messsage", message: "Please enter valid IP Address for websocket communication.")
            }
           } catch {
                self.presentAlert(withTitle: localizedKey("SignInText"), message: "\(error.localizedDescription)")
           }
    }
    // MARK: Identify internet connection availability
    // todo: Open iPhone general Wi-Fi settings when network is not reachable
    // fixme: Navigate to next screen if iphone device is connected to any Wi-Fi network.
    fileprivate func checkNetworkAvailability() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            self.hideLoader()
            if appDelegate!.networkAvailability {
                if appDelegate!.isMobileInternet {
                    self.navigation(to: Identifier.connectScreen)
                } else {
                    self.navigation(to: Identifier.wifiSettingsScreen)
                }
            } else {
                self.navigation(to: Identifier.connectScreen)
            }
        }
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.hideCopyrightLabel()
        isLoginViewPresented = false
    }
}
