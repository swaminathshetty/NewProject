//
//  ModelTypeTests.swift
//  KobelcoServiceTests
//
//  Created by Swaminath on 10/4/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
import XCTest
@testable import KobelcoService

class ModelTypeTests: XCTestCase {
    var validation: KSModelTypeVM!
    override func setUp() {
        super.setUp()
        // Initializing modeltype viewmodel before the invocation of each test method in the class.
        validation = KSModelTypeVM()
    }
    
    // This method is called after the invocation of each test method in the class.
    override func tearDown() {
        validation = nil // Deallocating or clear object from memory
        super.tearDown()
    }
    // Checking for empty modeltype entry.
    func testIsModelTypeEmpty() throws {
        let expectedError = Validations.selectModelType
        var error: Validations?
        XCTAssertThrowsError(try validation.validateModelType("")) { thrownError in
            error =  thrownError as? Validations
        }
        XCTAssertEqual(expectedError, error)
        
        XCTAssertEqual(expectedError.errorDescription, error?.errorDescription)
    }
    // Testcase for nilvalue passing in modeltype.
    func testIsModelTypeNil() throws {
        let expectedError = Validations.selectModelType
        var error: Validations?
        XCTAssertThrowsError(try validation.validateModelType(nil)) { thrownError in
            error =  thrownError as? Validations
        }
        XCTAssertEqual(expectedError, error)
        
        XCTAssertEqual(expectedError.errorDescription, error?.errorDescription)
    }
    // Testcase for valid modeltype selection.
    func testIsValidModelTypeEntry() throws {
        XCTAssertNoThrow(try validation.validateModelType("YN15"))
    }
    // Checking for empty area entry.
    func testIsAreaEmpty() {
        let expectedError = Validations.selectArea
        var error: Validations?
        XCTAssertThrowsError(try validation.validateArea("")) { thrownError in
            error =  thrownError as? Validations
        }
        XCTAssertEqual(expectedError, error)
        
        XCTAssertEqual(expectedError.errorDescription, error?.errorDescription)
    }
    // Testcase for passing nilvalue in area testfield.
    func testIsAreaNil() {
        let expectedError = Validations.selectArea
        var error: Validations?
        XCTAssertThrowsError(try validation.validateArea(nil)) { thrownError in
            error =  thrownError as? Validations
        }
        XCTAssertEqual(expectedError, error)
        
        XCTAssertEqual(expectedError.errorDescription, error?.errorDescription)
    }
    // Testcase for valid area selection.
    func testIsValidAreaEntry() throws {
        XCTAssertNoThrow(try validation.validateModelType("India"))
    }
}
