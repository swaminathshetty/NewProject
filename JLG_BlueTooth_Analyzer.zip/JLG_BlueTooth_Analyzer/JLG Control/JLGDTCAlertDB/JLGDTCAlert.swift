import Foundation
import RealmSwift

class JLGDTCAlert: Object {
    let ﻿id = RealmOptional<Int>()
    let spn = RealmOptional<Int>()
    let fmi = RealmOptional<Int>()
    @objc dynamic var chargerErrorFault: String?
    @objc dynamic var chargerErrorFaultDescription: String?
    let jlgDTC = RealmOptional<Int>()
    @objc dynamic var jlgDTCDescription: String?
}
