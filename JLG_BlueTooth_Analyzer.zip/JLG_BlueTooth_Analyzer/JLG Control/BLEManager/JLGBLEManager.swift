//
//  JLGBLEManager.swift
//  JLG Control
//
//  Created by L&T on 17/04/18.
//  Copyright © 2018 L&T. All rights reserved.
//

import UIKit
import CoreBluetooth
//import Firebase

// MARK: - JLGBLEManager delegate protocol
/// Delegates of JLGBLEManager class to call from any screen which confirm to JLGBLEDelegate
protocol JLGBLEDelegate: class {
    func didDiscoverPeripherals(peripherals: [[String: Any]])
    func didConnectToPeripheral(peripheral: CBPeripheral)
    func didReadValue(_ value: String, for characteristic: CBCharacteristic)
    func didWriteValueForCharacteristic(_ characteristic: CBCharacteristic)
    func didDisconnectFromPeripheral(peripheral: CBPeripheral)
    func centralManagerDidUpdateBLEState(centralManager: CBCentralManager)
    func didAddNewPeripheral(peripherals: [[String: Any]])
}

/// For creating the optional delegate method in JLGBLEDelegate
extension JLGBLEDelegate {
    func didDiscoverPeripherals(peripherals: [[String: Any]]) {}
    func didConnectToPeripheral(peripheral: CBPeripheral) {}
    func didReadValue(_ value: String, for characteristic: CBCharacteristic) {}
    func didWriteValueForCharacteristic(_ characteristic: CBCharacteristic) {}
    func didDisconnectFromPeripheral(peripheral: CBPeripheral) {}
    func centralManagerDidUpdateBLEState(centralManager: CBCentralManager) {}
    func didAddNewPeripheral(peripherals: [[String: Any]]) {}
}

/// JLGBLEManager class is specifically designed to handle Bluetooth connectivity
class JLGBLEManager: NSObject, CBCentralManagerDelegate, CBPeripheralDelegate, JLGFleetScreenModelDelegate {

    // MARK: - Variables and Constants
    static let sharedInstance = JLGBLEManager()
    weak var delegate: JLGBLEDelegate?
    var centralManager: CBCentralManager!
    var activePeripheral: CBPeripheral?
    var characteristics = [String: CBCharacteristic]()
    let jlgBLEName = JLGStringConstants.kJLGBLEName
    var qrCodeSerialOrMachineDecalNumber: Substring = "SKIP"
    var authPinForAuthentication: Substring = ""
    var timerToReadRSSIValue: Timer?
    var timerForFleetScreen: Timer?
    var rssiValue: NSNumber = 0
    var peripheralsInfo = [[String: Any]]()
//    var timerToSortRSSIValue: Timer?
    // MARK: - View life cycle events
    override init() {
        super.init()
        centralManager = CBCentralManager(delegate: self, queue: nil)
    }

    // MARK: - Private methos to enable notification
    private func enableNotifications(_ enable: Bool) {
        guard let char = self.characteristics[kManufacturerNameCharacteristicsUUID] else { return }
        self.activePeripheral?.setNotifyValue(enable, for: char)
    }

    // MARK: - Selector methods scanTimeout
    @objc func scanTimeout() {
        self.stopScanningAndSortPeripherals()
        self.delegate?.didDiscoverPeripherals(peripherals: self.peripheralsInfo)
        self.stopTimerForFleetScreen()
    }

    // MARK: - Public methods
    /// Start looking for BLE devices
    func startScanning() {
        self.peripheralsInfo = []
        self.centralManager.scanForPeripherals(withServices: nil, options: nil)
        Timer.scheduledTimer(timeInterval: scanningTimeout, target: self, selector: #selector(JLGBLEManager.scanTimeout), userInfo: nil, repeats: false)
    }

    /// Start looking for BLE devices for Fleet screen
    func startScanningForFleetScreen() {
        self.stopScanning()
        self.stopTimerForFleetScreen()
        self.peripheralsInfo = []
        self.centralManager.scanForPeripherals(withServices: nil, options: nil)
        timerForFleetScreen = Timer.scheduledTimer(timeInterval: bmsScanningTimeout, target: self, selector: #selector(JLGBLEManager.scanTimeout), userInfo: nil, repeats: false)
    }

//    func startRSSITimerForFleetScreen() {
//        if timerToSortRSSIValue == nil {
//            timerToSortRSSIValue = Timer.scheduledTimer(timeInterval: responseTimeout, target: self, selector: #selector(JLGBLEManager.sortPeripheralsUsingRSSIValue), userInfo: nil, repeats: true)
//        }
//    }
//
//    func stopRSSITimerForFleetScreen() {
//        if timerToSortRSSIValue != nil {
//            timerToSortRSSIValue?.invalidate()
//            timerToSortRSSIValue = nil
//        }
//    }

    @objc func sortPeripheralsUsingRSSIValue() {
        self.delegate?.didAddNewPeripheral(peripherals: peripheralsInfo)
    }
    /// Stop looking for BLE devices
    func stopScanning() {
        if self.centralManager.isScanning == true {
            self.stopScanningAndSortPeripherals()
        }
    }

    /// Sort peripherals based on RSSI value stoping scanning
    func stopScanningAndSortPeripherals() {
        self.centralManager.stopScan()
        self.sortPeripherals()
    }

    /// Sort peripherals based on RSSI value
    func sortPeripherals() {
        self.peripheralsInfo.sort { ($0[JLGStringConstants.kRSSIValue] as! Int) > ($1[JLGStringConstants.kRSSIValue] as! Int) }
    }

    /// Connect to specific peripheral
    func connectToPeripheral(_ peripheral: CBPeripheral) {
        if self.centralManager.state != .poweredOn {
            return
        }
        self.centralManager.connect(peripheral, options: [CBConnectPeripheralOptionNotifyOnDisconnectionKey: NSNumber(value: true)])
    }

    /// Disconnect peripheral
    func disconnectFromPeripheral() {
        if self.activePeripheral != nil && self.activePeripheral?.state == .connected {
            self.centralManager.cancelPeripheralConnection(self.activePeripheral!)
            self.delegate?.didDisconnectFromPeripheral(peripheral: self.activePeripheral!)
            self.activePeripheral = nil
        }
    }

    // MARK: - Central manager delegates
    /// Callback method for discover any peripheral
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String: Any], rssi RSSI: NSNumber) {
        if peripheral.name == nil || peripheral.name != jlgBLEName {
            return
        }

        let manufacturerData = advertisementData["kCBAdvDataManufacturerData"]
        if manufacturerData != nil {
            //print("Hex Value:----> \(String(describing: manufacturerData))")
            let data = advertisementData["kCBAdvDataManufacturerData"] as! Data
            //let uInt8Array: [UInt8] = JLGIntByteConverter.dataBytesArrayToUInt8ArrayConverter(data: data)
            //print("uInt8Array Value:----> \(uInt8Array)")
            //return

            //let manufacturerStr: String = String(data: data, encoding: .utf8) ?? "No Data"
            guard let manufacturerStr: String = String(data: data, encoding: .ascii) else {
                return
            }

            var manufacturerStringArray = [String]()
            manufacturerStringArray = manufacturerStr.components(separatedBy: ",")

            /// Check where the manufacture string array count is greater than 2 or not, if its less than that then we don't get serial no.
            if !(manufacturerStringArray.count > 2) {
                print("manufacturerStringArray count ---> \(manufacturerStringArray.count)  array ---> \(manufacturerStringArray)")
                return
            }

            appendLog(text: "\(Date()): Hex Value:----> \(String(describing: manufacturerData))")
            //print ("Hex Value:----> \(String(describing: manufacturerData))")

            if let indexObject = peripheralsInfo.index(where: {($0[JLGStringConstants.kPeripheralInstance] as! CBPeripheral) == peripheral}) {
                let peripheralObject: NSDictionary = self.peripheralsInfo[indexObject] as NSDictionary
                let serialNumber = peripheralObject.value(forKey: JLGStringConstants.kSerialNumber)
                appendLog(text: "\(Date()): BLE Serial No.:----> \(String(describing: serialNumber)) and Device Count:----> \(String(describing: peripheralsInfo.count))")
                //print ("BLE Serial No.:----> \(String(describing: serialNumber)) and Device Count:----> \(String(describing: peripheralsInfo.count))")

                let getInstanceOfJLGFleetScreenModel = peripheralObject.value(forKey: JLGStringConstants.kJLGFleetScreenModelInstance) as! JLGFleetScreenModel
                getInstanceOfJLGFleetScreenModel.delegateJLGFleetScreenModel = self
                getInstanceOfJLGFleetScreenModel.updatePeripheralsInfoData(dataObject: data, objectOfJLGFleetScreenModel: getInstanceOfJLGFleetScreenModel)
                // Update RSSI value here
                self.peripheralsInfo[indexObject].updateValue(RSSI.intValue, forKey: JLGStringConstants.kRSSIValue)
            } else {
                var serialNumber: Substring = ""
                var vehiclePin: Substring = ""

                if manufacturerStringArray.count == 3 {
                    serialNumber = Substring(manufacturerStringArray[1])
                    vehiclePin = Substring(manufacturerStringArray[2])
                } else {
                    if manufacturerStr.count > 5 {
                        serialNumber = manufacturerStr.suffix(6)
                    }
                }

                appendLog(text: "\(Date()): BLE Serial No.:----> \(String(describing: serialNumber)) and Device Count:----> \(String(describing: peripheralsInfo.count))")
                //print ("BLE Serial No.:----> \(serialNumber) and Device Count:----> \(String(describing: peripheralsInfo.count))")

                peripheralsInfo.append([JLGStringConstants.kPeripheralInstance: peripheral,
                                        JLGStringConstants.kSerialNumber: serialNumber/*"100084"*/,
                    JLGStringConstants.kVehiclePin: vehiclePin,
                    JLGStringConstants.kRSSIValue: RSSI.intValue, JLGStringConstants.kJLGFleetScreenModelInstance: JLGFleetScreenModel.init(manufacturerData: data)])
                self.delegate?.didAddNewPeripheral(peripherals: peripheralsInfo)
            }
        }
    }

    /// FleetScreen Model Delegate 
    func didUpdateJLGFleetScreenModel() {
        self.delegate?.didAddNewPeripheral(peripherals: self.peripheralsInfo)
    }

    /// When device get connected with BLE module then this delegate function will get call
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        print("Connected to peripheral: \(peripheral.identifier.uuidString)")
        //Analytics.logEvent("rcs_ble_connected", parameters: [kUserID: userID, kTimeStamp: Date().PR2DateFormatterUTC()])
        isDisconnectedBLE = false
        self.activePeripheral = peripheral
        self.activePeripheral?.delegate = self
        self.activePeripheral?.discoverServices(nil)
        self.delegate?.didConnectToPeripheral(peripheral: peripheral)

        /// Enable below line when you want to read peripheral RSSI value (Future Use)
        //timerToReadRSSIValue = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(readRSSIValue), userInfo: nil, repeats: true)
    }

    /// When device get disconnected with BLE module then this delegate funciton will get call
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        print("Disconnected to peripheral: \(peripheral.identifier.uuidString)")
        //Analytics.logEvent("rcs_ble_disconnected", parameters: [kUserID: userID, kTimeStamp: Date().PR2DateFormatterUTC()])
        isDisconnectedBLE = true
        if self.activePeripheral != nil {
            self.delegate?.didDisconnectFromPeripheral(peripheral: self.activePeripheral!)
        }
        JLGCommunicationManager.sharedInstance.didDisconnectPeripheral(fromPeripheral: peripheral)
        stopReadingRSSIValue()
    }

    /// Invoked whenever the central manager's state has been updated
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        print("Update status of central: \(central.state)")
        if centralManager.state == .poweredOff {
            isDeviceBluetoothOff = true
        } else if centralManager.state == .poweredOn && (JLGBLEManager.sharedInstance.activePeripheral == nil || JLGBLEManager.sharedInstance.activePeripheral?.state != .connected) {
            isDeviceBluetoothOff = false
        }
        self.delegate?.centralManagerDidUpdateBLEState(centralManager: central)
    }

    // MARK: CBPeripheral delegates
    /// This method returns the result of discoverServices. If the service(s) were read successfully, they can be retrieved
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        if error != nil {
            print("[ERROR] Error discovering services: \(error.debugDescription)")
            return
        }
        for service in peripheral.services! {
            peripheral.discoverCharacteristics(nil, for: service)
        }
    }

    /// This method returns the result of a discoverCharacteristics:forService. If the characteristic(s) were read successfully, they can be retrieved
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        if error != nil {
            print("[ERROR] Error discovering characteristics: \(error.debugDescription)")
            return
        }
        for characteristic in service.characteristics! {
            //print("didDiscoverCharacteristicsFor \(characteristic)")

            self.characteristics[characteristic.uuid.uuidString] = characteristic
            if notifyToValidNotifiableCharacteristics(charUUID: characteristic.uuid.uuidString) {
                self.activePeripheral?.setNotifyValue(true, for: characteristic)
            }
            if (characteristic.uuid.uuidString != kBtAuthSignatureCharacteristicsUUID) &&
                characteristic.uuid.uuidString != kOTAReprogrammingDataStreamCharacteristicUUID &&
                characteristic.uuid.uuidString != kBtAuthenticatedCharacteristicsUUID &&
                characteristic.uuid.uuidString != kBtVehiclePinUpdateCharacteristicsUUID &&
                characteristic.uuid.uuidString != kProtobufStreamUUID {
                self.activePeripheral?.readValue(for: characteristic)
            }
        }
        enableNotifications(true)
    }

    func notifyToValidNotifiableCharacteristics(charUUID: String) -> Bool {
        if (charUUID == kBtAuthenticatedCharacteristicsUUID ||
            charUUID == kBtRemStatusCharacteristicsUUID ||
            charUUID == kBtRemoteInitCharacteristicsUUID ||
            charUUID == kBtWarningIndicatorCharacteristicUUID ||
            charUUID == kBtBatteryStatusCharacteristicUUID ||
            charUUID == kBtFuelLevelCharacteristicUUID) ||
            charUUID == kOTAReprogrammingDataStreamCharacteristicUUID ||
            charUUID == kProtobufStreamUUID {
            return true
        } else {
            return false
        }
    }

    /// This method is invoked after a readValueForCharacteristic, or upon receipt of a notification/indication
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        if error != nil {
            print("[ERROR] Error updating value: \(error.debugDescription) \n For Characteristic: \(characteristic)")
            return
        } else {
            JLGCommunicationManager.sharedInstance.recievedDataFromBLEModule(updatedCharacteristic: characteristic)
        }
    }

    /// This method returns the result of a writeValue:forCharacteristic:type: call
    func peripheral(_ peripheral: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?) {
        if error != nil {
            print("[ERROR] Error Writing value: \(error.debugDescription) \n For Characteristic: \(characteristic)")
            return
        } else {
            self.delegate?.didWriteValueForCharacteristic(characteristic)
        }
    }

    /// readData used to read value form any characteristics
    func readData(charUUID: String) {
        guard let char = self.characteristics[charUUID] else { return }
        self.activePeripheral?.readValue(for: char)
    }

    /// p is used to write data to particular characteristics
    func writeData(data: Data, charUUID: String, withResponse: Bool) {
        if self.activePeripheral?.state == CBPeripheralState.disconnected {
            return
        }
        guard let char = self.characteristics[charUUID] else { return }
        self.activePeripheral?.writeValue(data, for: char, type: (withResponse == true) ? .withResponse : .withoutResponse)
    }

    /// writeString is used to write string value to particular characteristics
    func writeString(string: NSString, charUUIDToWrite: String) {
        let data = NSData(bytes: string.utf8String, length: string.length)
        self.writeRawData(data: data, charUUID: charUUIDToWrite)
    }

    /// writeRawData is used to write raw value to particular characteristics
    func writeRawData(data: NSData, charUUID: String) {
        /// Send data to peripheral
        guard let char = self.characteristics[charUUID] else { return }

        /// Send data in lengths of <= 20 bytes
        let dataLength = data.length
        let limit = 20

        if dataLength <= limit {
            /// Below limit, send as-is
            self.activePeripheral?.writeValue(data as Data, for: char, type: .withoutResponse)
        } else {
            /// Above limit, send in lengths <= 8 bytes
            var len = limit
            var loc = 0
            var idx = 0 /// for debug

            while loc < dataLength {

                let rmdr = dataLength - loc
                if rmdr <= len {
                    len = rmdr
                }

                let range = NSMakeRange(loc, len)
                var newBytes = [UInt8](repeating: 0, count: len)
                data.getBytes(&newBytes, range: range)
                let newData = NSData(bytes: newBytes, length: len)
                self.activePeripheral?.writeValue(newData as Data, for: char, type: .withResponse)

                loc += len
                idx += 1
            }
        }
    }

    // MARK: - Read RSSI value
    @objc func readRSSIValue() {
        self.activePeripheral?.readRSSI()
    }

    /// Callback method to read RSSI value
    func peripheral(_ peripheral: CBPeripheral, didReadRSSI RSSI: NSNumber, error: Error?) {
        print("RSSI Value: \(RSSI)")
        rssiValue = RSSI
    }

    func stopReadingRSSIValue() {
        if timerToReadRSSIValue != nil {
            timerToReadRSSIValue?.invalidate()
            timerToReadRSSIValue = nil
        }
    }

    func stopTimerForFleetScreen() {
        if timerForFleetScreen != nil {
            timerForFleetScreen?.invalidate()
            timerForFleetScreen = nil
        }
    }
}
