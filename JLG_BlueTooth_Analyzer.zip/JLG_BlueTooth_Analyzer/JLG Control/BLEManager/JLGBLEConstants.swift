//
//  JLGBLEConstants.swift
//  JLG Control
//
//  Created by L&T on 17/04/18.
//  Copyright © 2018 L&T. All rights reserved.
//

import Foundation

/// Scan timeout
let scanningTimeout: Double = 5
let responseTimeout: Double = 10
let bmsScanningTimeout: Double = 20

let kAuthenticationInvalid = 0
let kAuthenticationExpire = 255
/*
 Device Information 180A
 Module Information 357e0100-c4d6-408f-a80c-b64ef40ac0f3
 JLG Authentication Service 357e0200-c4d6-408f-a80c-b64ef40ac0f3
 JLG Scissor Remote Control Service 357e0300-c4d6-408f-a80c-b64ef40ac0f3
 JLG Service Connect Service 357e0400-c4d6-408f-a80c-b64ef40ac0f3
 JLG Vehicle Status Service 357e0500-c4d6-408f-a80c-b64ef40ac0f3
 JLG DTC Information Service 357e0600-c4d6-408f-a80c-b64ef40ac0f3
 */
let kDeviceInformationServicesUUID = "180A"
let kUnKnownServicesUUID = "9E110200-C035-45ED-B09C-20FA58217A2A"
let kJLGModuleInformationServiceUUID = "357E0100-C4D6-408F-A80C-B64EF40AC0F3"
let kJLGAuthenticationServiceUUID = "357E0200-C4D6-408F-A80C-B64EF40AC0F3"
let kJLGScissorRemoteControlServiceUUID = "357E0300-C4D6-408F-A80C-B64EF40AC0F3"

/*
 [DEBUG] Found characteristics for peripheral: DBCDAC84-A3FF-8C2D-BB8D-126CC4E4AF36
 *********************  DEVICE INFORMATION SERVICE CHARACTERISTIC UUIDS **********************
 
 Manufacturer Name String 2A29
 Model Number String 2A24
 Serial Number String 2A25
 Firmware Revision String 2A26
 Software Revision String 2A28
 */
let kManufacturerNameCharacteristicsUUID = "2A29"// properties = 0x2, value = (null), notifying = NO>
let kModelNumberCharacteristicsUUID = "2A24"// properties = 0x2, value = (null), notifying = NO>
let kSerialNumberCharacteristicsUUID = "2A25"// properties = 0x2, value = (null), notifying = NO>
let kFirmwareRevisionCharacteristicsUUID = "2A26"// properties = 0x2, value = (null), notifying = NO>
let kSoftwareRevisionCharacteristicsUUID = "2A28"// properties = 0x2, value = (null), notifying = NO> ----NOT PRESENT

let kUnKnownCharacteristicsUUID01 = "9E110201-C035-45ED-B09C-20FA58217A2A"// properties = 0x16, value = (null), notifying = NO>
let kUnKnownCharacteristicsUUID02 = "9E110202-C035-45ED-B09C-20FA58217A2A"// properties = 0x2, value = (null), notifying = NO>

/*
 ****************** MODULE INFORMATION SERVICE CHARACTERISTIC UUIDS ******************
 Battery Voltage *0101*
 Digital Input State *0102*
 Analog input voltages *0103*
 CAN Voltages *0104*
 Temperature *0105*
 BtVehiclePinUpdate *106*
 */
let kBatteryVoltageCharacteristicsUUID = "357E0101-C4D6-408F-A80C-B64EF40AC0F3"// properties = 0x2, value = (null), notifying = NO
let kDigitalInputStateCharacteristicsUUID = "357E0102-C4D6-408F-A80C-B64EF40AC0F3"// properties = 0x2, value = (null), notifying = NO
let kAnalogInputvoltagesCharacteristicsUUID = "357E0103-C4D6-408F-A80C-B64EF40AC0F3"// properties = 0x2, value = (null), notifying = NO
let kCANVoltagesCharacteristicsUUID = "357E0104-C4D6-408F-A80C-B64EF40AC0F3"// properties = 0x2, value = (null), notifying = NO
let kTemperatureCharacteristicsUUID = "357E0105-C4D6-408F-A80C-B64EF40AC0F3"// properties = 0x2, value = (null), notifying = NO
let kBtVehiclePinUpdateCharacteristicsUUID = "357E0106-C4D6-408F-A80C-B64EF40AC0F3"// properties = 0x2, value = (null), notifying = NO

/*
 **************** JLG AUTHENTICATION SERVICE UUIDS ****************
 BtAuthFreshness *0201*
 BtAuthPin *0202*
 BtAuthSignature *0203*
 BtAuthenticated *0204*
 BtAuthSessionKey *0205*
 */
let kBtAuthFreshnesCharacteristicsUUID = "357E0201-C4D6-408F-A80C-B64EF40AC0F3"// properties = 0x2, value = (null), notifying = NO>
let kBtAuthPinCharacteristicsUUID = "357E0202-C4D6-408F-A80C-B64EF40AC0F3"// properties = 0x6, value = (null), notifying = NO>
let kBtAuthSignatureCharacteristicsUUID = "357E0203-C4D6-408F-A80C-B64EF40AC0F3"// properties = 0x6, value = (null), notifying = NO>
let kBtAuthenticatedCharacteristicsUUID = "357E0204-C4D6-408F-A80C-B64EF40AC0F3"// properties = 0x6, value = (null), notifying = NO ----NOT PRESENT
let kBtAuthSessionKeyEncryptedCharacteristicsUUID = "357E0205-C4D6-408F-A80C-B64EF40AC0F3"// properties = 0x6, value = (null), notifying = NO ----NOT PRESENT

/*
 ***************** JLG REMOTE CONTROL SERVICE ********************
 BtRemEStop *0301*
 BtRemStop *0302*
 BtRemLift *0303*
 BtRemDrive *0304*
 BtRemSteer *0305*
 BtHiLoTorque *0306*
 BtHornEnable *0307*
 BtWatchdog *0308*
 BtRemStatus *0309*
 */
let kBtRemoteInitCharacteristicsUUID = "357E030A-C4D6-408F-A80C-B64EF40AC0F3"// properties = 0x2, value = (null), notifying = NO>

let kBtRemStopCharacteristicsUUID = "357E0302-C4D6-408F-A80C-B64EF40AC0F3"// properties = 0x46, value = (null), notifying = NO
let kBtRemEStopCharacteristicsUUID = "357E0301-C4D6-408F-A80C-B64EF40AC0F3"// properties = 0x46, value = (null), notifying = NO
let kBtRemLiftCharacteristicsUUID = "357E0303-C4D6-408F-A80C-B64EF40AC0F3"//properties = 0x46, value = (null), notifying = NO
let kBtRemDriveCharacteristicsUUID = "357E0304-C4D6-408F-A80C-B64EF40AC0F3"// properties = 0x46, value = (null), notifying = NO
let kBtRemSteerCharacteristicsUUID = "357E0305-C4D6-408F-A80C-B64EF40AC0F3"// properties = 0x6, value = (null), notifying = NO>
let kBtHiLoTorqueCharacteristicsUUID = "357E0306-C4D6-408F-A80C-B64EF40AC0F3"// properties = 0x2, value = (null), notifying = NO>

let kBtHornEnableCharacteristicsUUID = "357E0307-C4D6-408F-A80C-B64EF40AC0F3"// properties = 0x46, value = (null), notifying = NO ----NOT PRESENT
let kBtWatchdogCharacteristicsUUID = "357E0308-C4D6-408F-A80C-B64EF40AC0F3"// properties = 0x6, value = (null), notifying = NO>
let kBtRemStatusCharacteristicsUUID = "357E0309-C4D6-408F-A80C-B64EF40AC0F3"// properties = 0x2, value = (null), notifying = NO> ----NOT PRESENT

/*
 ------JLG SERVICE CONNECT SERVICE-------
 BtServiceRequest *0401*
 BtVehType *0402*
 BtVehModel *0403*
 BtVehMarket *0404*
 BtVehSwVersion *0405*
 BtVehHwVersion *0406*
 BtRemoteControl *0410*
 BtVehicleStatus *0411*
 BtDtcInfo *0412
 */

let kBtVehHwVersionCharacteristicUUID = "357E0406-C4D6-408F-A80C-B64EF40AC0F3"
/*
 -------- JLG VEHICLE STATUS SERVICE -------
 BtWarningIndicator *0501*
 BtBatteryStatus *0502*
 BtFuelLevel *0503*
 */
let kBtWarningIndicatorCharacteristicUUID = "357E0501-C4D6-408F-A80C-B64EF40AC0F3"
let kBtBatteryStatusCharacteristicUUID = "357E0502-C4D6-408F-A80C-B64EF40AC0F3"
let kBtFuelLevelCharacteristicUUID = "357E0503-C4D6-408F-A80C-B64EF40AC0F3"

/*
-------- JLG PORTOBUF SERVICE -------
Protobuf Data Stream *0601*
*/
let kProtobufStreamUUID = "357E0601-C4D6-408F-A80C-B64EF40AC0F3"

/*
 -------- JLG OTA REPROGRAMMING DATA STREAM SERVICE -------
 OTA Reprogramming Data Stream *0701*
 */
let kOTAReprogrammingDataStreamCharacteristicUUID = "357E0701-C4D6-408F-A80C-B64EF40AC0F3"
