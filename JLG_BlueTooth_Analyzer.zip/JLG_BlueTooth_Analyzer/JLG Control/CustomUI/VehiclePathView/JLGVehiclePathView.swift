//
//  VehiclePathView.swift
//  JLG Control
//
//  Created by L&T on 09/04/18.
//  Copyright © 2018 L&T. All rights reserved.
//

import UIKit

class JLGVehiclePathView: UIView {
    // MARK: - Variables and Constants
    var view: UIView!
    @IBOutlet var vehicleView: UIView!
    @IBOutlet weak var vehicleImageView: UIImageView!
    @IBOutlet weak var indicationImageView: UIImageView!
    var initialVehicleFrame: CGRect?
    var vehicleMovingSpace: CGFloat?

    // MARK: - Initializer method
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        view = Bundle.main.loadNibNamed("JLGVehiclePathView", owner: self, options: nil)![0] as? UIView
        self.addSubview(view)
        view.frame = self.bounds
    }

    // MARK: - Override methods
    override func layoutSubviews() {
        super.layoutSubviews()
        self.layoutIfNeeded()
        self.initialVehicleFrame = vehicleView.frame
        self.vehicleMovingSpace = (self.initialVehicleFrame?.origin.y)!
    }

    // MARK: - Public methods
    /// Move vehicle forward and reverse
    func calculateFrameAndAnimateVehicleView(_ value: Int8) {
        if value == 0 && value != 100 {
            self.animateVehicleViewToNewFrame(self.initialVehicleFrame!)
            return
        }
        let valueToMove = self.vehicleMovingSpace! / 100 * CGFloat(value)
        var newFrame = self.initialVehicleFrame
        newFrame?.origin.y -= valueToMove
        self.animateVehicleViewToNewFrame(newFrame!)
    }

    /// Change vehicle image with left/right forward wheel
    func changeVehicleDirection(_ direction: SteerDirection) {
        if direction == .Left {
            animateVehicleViewToLeftOrRight(.Left)
        } else if direction == .Right {
            animateVehicleViewToLeftOrRight(.Right)
        } else {
            animateVehicleViewToLeftOrRight(.None)
        }
    }

    // MARK: - Private methods
    /// Animate vehicle forward or reverse
    func animateVehicleViewToNewFrame(_ frame: CGRect) {
        UIView.animate(withDuration: 0.4, animations: {
            self.vehicleImageView.image = #imageLiteral(resourceName: "DriveIndicationNormal")
            self.vehicleView.frame = frame
        })
    }

    /// Change vehicle image left, right or normal
    func animateVehicleViewToLeftOrRight(_ direction: SteerDirection) {
        UIView.animate(withDuration: 0.4, animations: {
            switch direction {
            case .Left: self.vehicleImageView.image = #imageLiteral(resourceName: "DriveIndicationLeft")
            case .Right: self.vehicleImageView.image = #imageLiteral(resourceName: "DriveIndicationRight")
            default: self.vehicleImageView.image = #imageLiteral(resourceName: "DriveIndicationNormal")
            }
        })
    }

}
