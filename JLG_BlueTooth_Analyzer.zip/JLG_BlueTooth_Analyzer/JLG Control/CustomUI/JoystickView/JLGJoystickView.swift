//
//  JoystickView.swift
//  JLG Control
//
//  Created by L&T on 06/04/18.
//  Copyright © 2018 L&T. All rights reserved.
//

import UIKit
import AudioToolbox
//import Firebase

/// Drive direction enum
public enum DriveDirection: Int {
    case None = 0
    case Forward
    case Reverse

    var description: String {
        switch self {
        case .None: return "None"
        case .Forward: return "Forward"
        case .Reverse: return "Reverse"
        }
    }
}

/// Steer direction enum
public enum SteerDirection: Int {
    case None = 0
    case Left
    case Right

    var description: String {
        switch self {
        case .None: return "None"
        case .Left: return "Left"
        case .Right: return "Right"
        }
    }
}

// MARK: - JoystickView delegate protocol
protocol JLGJoystickViewDelegate: class {
    func didChangeDriveValue(_ value: Int8, driveDirection: DriveDirection)
    func didChangeSteerValue(_ value: Int8, steerDirection: SteerDirection)
    func didRecenterJoystick(_ driveValue: Int8, steerValue: Int8)
    func goingOutOfJoystickArea()
}

class JLGJoystickView: UIView {

    // MARK: - Variable and Constants
    @IBOutlet var joyStickButton: UIButton!
    @IBOutlet weak var joyStickInnerView: UIView!
    @IBOutlet weak var ripplingImageView: UIImageView!

    var dragButtonPanGesture: UIPanGestureRecognizer!
    var buttonWidth: CGFloat = 0.0
    var initialCenter: CGPoint?
    var leftCenter: CGPoint?
    var rightCenter: CGPoint?
    var initialLeftMarginCenter: CGPoint?
    var initialRightMarginCenter: CGPoint?
    var forwardCenter: CGPoint?
    var backwardCenter: CGPoint?
    var initialForwardMarginCenter: CGPoint?
    var initialBackwardMarginCenter: CGPoint?
    var view: UIView!
    weak var delegate: JLGJoystickViewDelegate?
    var vehicleDriveDirection: DriveDirection = .None
    var vehicleSteerDirection: SteerDirection = .None
    var shouldChangeXY = true

    var driveValue: Int8 = 0
    var steerValue: Int8 = 0

    var timerForAnimation: Timer?
    var counterForAnimation = 0

    var driveStartTime = Date()
    var driveEndTime = Date()

    // MARK: - Initializer method
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        view = Bundle.main.loadNibNamed("JLGJoystickView", owner: self, options: nil)![0] as? UIView
        self.addSubview(view)
        view.frame = self.bounds

        /// Add pan gesture on joystick button
        dragButtonPanGesture = UIPanGestureRecognizer(target: self, action: #selector(handlePanGesture))
        joyStickButton.addGestureRecognizer(dragButtonPanGesture)
        dragButtonPanGesture.maximumNumberOfTouches = 1

        /// Start timer to show rippling effect on joystick button
        timerForAnimation = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(startJoystickRippling), userInfo: nil, repeats: true)
    }

    // MARK: - Joystick rippling animation method
    /// Start rippling effect on imageview
    @objc func startJoystickRippling() {
        counterForAnimation += 1
        if counterForAnimation == 5 {
            counterForAnimation = 1
        }
        switch counterForAnimation {
        case 1: ripplingImageView.image = #imageLiteral(resourceName: "JoytickImage")
        case 2: ripplingImageView.image = #imageLiteral(resourceName: "JoystickRipplingImage1")
        case 3: ripplingImageView.image = #imageLiteral(resourceName: "JoystickRipplingImage2")
        case 4: ripplingImageView.image = #imageLiteral(resourceName: "JoystickRipplingImage3")
        default: ripplingImageView.image = #imageLiteral(resourceName: "JoytickImage")
        }
    }

    /// Stop rippling effect on imageview
    func stopJoystickRippling() {
        counterForAnimation = 0
        if timerForAnimation != nil {
            timerForAnimation?.invalidate()
            timerForAnimation = nil
            ripplingImageView.isHidden = true
        }
    }

    // MARK: - Override methods
    override func layoutSubviews() {
        super.layoutSubviews()

        buttonWidth = joyStickButton.frame.width / 2
        initialCenter = self.center

        self.joyStickButton.layer.cornerRadius = buttonWidth

        leftCenter = CGPoint(x: self.frame.origin.x + buttonWidth, y: (initialCenter?.y)!)
        rightCenter = CGPoint(x: self.frame.origin.x + self.frame.width - buttonWidth, y: (initialCenter?.y)!)

        let steerInitialValue = (self.view.frame.width / 2) * 0.325 - buttonWidth + 6

        initialLeftMarginCenter = CGPoint(x: (initialCenter?.x)! - steerInitialValue, y: (initialCenter?.y)!)
        initialRightMarginCenter = CGPoint(x: (initialCenter?.x)! + steerInitialValue, y: (initialCenter?.y)!)

        forwardCenter = CGPoint(x: (initialCenter?.x)!, y: self.frame.origin.y + buttonWidth)
        backwardCenter = CGPoint(x: (initialCenter?.x)!, y: self.frame.origin.y + self.frame.height - buttonWidth)

        initialForwardMarginCenter = CGPoint(x: (initialCenter?.x)!, y: (initialCenter?.y)! - 10)
        initialBackwardMarginCenter = CGPoint(x: (initialCenter?.x)!, y: (initialCenter?.y)! + 10)
    }

    // MARK: - Pan gesture handler methods dragging the joystick view
    /// This method will get called when you start moving your finger
    @objc func handlePanGesture(_ sender: UIPanGestureRecognizer) {
        /// Inside joystick area
        if self.frame.contains(dragButtonPanGesture.location(in: self.superview)) {
            if shouldChangeXY {
                changeDriveAndSteerValue(isInsideRegion: true, isReachedLeftOrRightBorder: false, isReachedTopOrBottomBorder: false)
            } else if self.joyStickInnerView.frame.contains(dragButtonPanGesture.location(in: self.joyStickInnerView)) {
                shouldChangeXY = true
                changeDriveAndSteerValue(isInsideRegion: false, isReachedLeftOrRightBorder: false, isReachedTopOrBottomBorder: true)
            } else {
                changeDriveAndSteerValue(isInsideRegion: false, isReachedLeftOrRightBorder: false, isReachedTopOrBottomBorder: true)
            }
            /// Outside joystick area
        } else {
            if dragButtonPanGesture.state == UIGestureRecognizerState.ended || dragButtonPanGesture.state == UIGestureRecognizerState.cancelled {
                self.recenterDragButton()
            }
            self.delegate?.goingOutOfJoystickArea()
        }
    }

    /// Helper method to change drive and steer value
    func changeDriveAndSteerValue(isInsideRegion: Bool, isReachedLeftOrRightBorder: Bool, isReachedTopOrBottomBorder: Bool) {
        let translation = dragButtonPanGesture.translation(in: self.superview)
        dragButtonPanGesture.setTranslation(CGPoint.zero, in: self.superview)
        let button = dragButtonPanGesture.view as! UIButton

        let newcenter: CGPoint
        if isInsideRegion {
            newcenter = CGPoint(x: button.center.x + translation.x, y: button.center.y + translation.y)
        } else if isReachedLeftOrRightBorder {
            newcenter = CGPoint(x: button.center.x, y: button.center.y + translation.y)
        } else if isReachedTopOrBottomBorder {
            newcenter = CGPoint(x: button.center.x + translation.x, y: button.center.y)
        } else {
            newcenter = CGPoint(x: button.center.x, y: button.center.y)
        }
        let superCenter = self.superview?.convert(newcenter, from: self)

        let viewFrame = self.frame
        let permissibleRect = CGRect(x: viewFrame.origin.x + buttonWidth, y: viewFrame.origin.y + buttonWidth, width: viewFrame.width - (2 * buttonWidth), height: viewFrame.height - (2 * buttonWidth))

        if permissibleRect.contains(superCenter!) {
            button.center = newcenter

            /// Upadte drive value based on finger movement
            DispatchQueue.global(qos: .userInitiated).async {
                let (driveValue, direction) = self.calculateDriveValue(superCenter!)
                DispatchQueue.main.async {
                    self.driveValue = driveValue
                    self.delegate?.didChangeDriveValue(self.driveValue, driveDirection: direction)
                }
            }

            /// Update steer value based on finger movement
            DispatchQueue.global(qos: .userInitiated).async {
                let (steerValue, direction) = self.calculateSteerValue(superCenter!)
                DispatchQueue.main.async {
                    self.steerValue = steerValue
                    self.delegate?.didChangeSteerValue(self.steerValue, steerDirection: direction)
                }
            }
        }

        if dragButtonPanGesture.state == UIGestureRecognizerState.began {
            driveStartTime = Date()
            self.stopJoystickRippling()
        }

        if dragButtonPanGesture.state == UIGestureRecognizerState.ended || dragButtonPanGesture.state == UIGestureRecognizerState.cancelled {
            self.recenterDragButton()
        }
    }

    /// Cancelling the pan gesture
    func cancelPanGesture() {
        /// Make pan gesture disable and center the joystick
        self.recenterDragButton()
        dragButtonPanGesture.isEnabled = false
        dragButtonPanGesture.isEnabled = true
    }

    /// Reset the joystick button to center with animation
    func recenterDragButton() {
        driveEndTime = Date()
        //let driveDuration = String(driveEndTime.minutes(from: driveStartTime)) + ":" + String(driveEndTime.seconds(from: driveStartTime))
        //Analytics.logEvent("rcs_drive_start", parameters: [kUserID: userID, kTimeStamp: Date().PR2DateFormatterUTC(), kDriveStart: driveStartTime.PR2DateFormatterUTC(), kDriveStop: driveEndTime.PR2DateFormatterUTC(), kDriveDuration: driveDuration])
        UIView.animate(withDuration: 0.05, animations: {
            self.joyStickButton.center = self.view.center
        }, completion: { _ in
            self.driveValue = 0
            self.steerValue = 0
            self.delegate?.didRecenterJoystick(self.driveValue, steerValue: self.steerValue)
        })
    }

    // MARK: - Drive and Steer calculation methods
    /// Steer calculation method
    func calculateSteerValue(_ center: CGPoint) -> (Int8, SteerDirection) {
        if center.x <= (initialLeftMarginCenter?.x)! {
            /// Negative
            return (Int8(-100), .Left)
        } else if center.x >= (initialRightMarginCenter?.x)! {
            /// Positive
            return (Int8(100), .Right)
        }
        return (0, .None)
    }

    /// Drive calculation method
    func calculateDriveValue(_ center: CGPoint) -> (Int8, DriveDirection) {
        if center.y >= (initialBackwardMarginCenter?.y)! {
            /// Negative
            let partMoved = center.y - (initialBackwardMarginCenter?.y)!
            let noOfParts = (backwardCenter?.y)! - (initialBackwardMarginCenter?.y)!
            let value = ((noOfParts - partMoved) / noOfParts) * 100
            return (Int8(floor(value)) - 100, .Reverse)
        } else if center.y <= (initialForwardMarginCenter?.y)! {
            /// Positive
            let partMoved =  (initialForwardMarginCenter?.y)! - center.y
            let noOfParts = (initialForwardMarginCenter?.y)! - (forwardCenter?.y)!
            let value = ((noOfParts - partMoved) / noOfParts) * 100
            return (100 - Int8(value.rounded()), .Forward)
        }
        return (0, .None)
    }

}
