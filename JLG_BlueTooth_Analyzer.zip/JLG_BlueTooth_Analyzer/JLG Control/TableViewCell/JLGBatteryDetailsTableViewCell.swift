//
//  JLGBatteryDetailsTableViewCell.swift
//  JLG Control
//
//  Created by Apple on 26/11/19.
//  Copyright © 2019 L&T. All rights reserved.
//

import UIKit

protocol JLGBatteryDetailsTableViewCellDelegate: class {
    func isCellExpand(isExpand: Bool)
    func openDatePickerForBatteryInstallation()
    func warningDetailInformationView()
}

class JLGBatteryDetailsTableViewCell: UITableViewCell {

    var serialScreenModelObject: JLGSerialScreenModel!
    var isExpand: Bool!
    weak var batteryDetailsCellDelegate: JLGBatteryDetailsTableViewCellDelegate?

    @IBOutlet weak var modelLabel: UILabel!
    @IBOutlet weak var assetIdLabel: UILabel!
    @IBOutlet weak var batteryTypeLabel: UILabel!
    @IBOutlet weak var batterySizeLabel: UILabel!
    @IBOutlet weak var installationDateLabel: UILabel!
    @IBOutlet weak var chargingAlgorithmLabel: UILabel!
    @IBOutlet weak var moreInfoButton: UIButton!
    @IBOutlet weak var batteryInstallationDateButton: UIButton!
    @IBOutlet weak var assetIdTextField: CustomTextField!

    @IBOutlet weak var warningButton: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        /// For Unit and UI Testing
        if CommandLine.arguments.contains(JLGTestingConstant.kEnableTesting) {
            self.assigningAccessibilityIdentifier()
        }
    }

    // MARK: - Fill cell data based on model
    func fillCellData(dic: NSDictionary) {
        self.setHideOrShowWarningIcon()
        self.setMachineModelNumber()
        let bleSerialNumber = dic.value(forKey: JLGStringConstants.kSerialNumber) as! String
        self.setAssetID(bleSerialNumberValue: bleSerialNumber)
        self.setBatteryType()
        self.setBatterySize()
        self.setInstallationDate()
        self.setChargingAlgorithm()
        self.setShowMoreOrLessButtonLabel()
    }

    /// Set Warning Icon
    func setHideOrShowWarningIcon() {
        if serialScreenModelObject.alarmAlertStatusModel.machineAlarmActive || serialScreenModelObject.alarmAlertStatusModel.machineAlertActive {
            self.warningButton.isHidden = false
        } else {
            self.warningButton.isHidden = true
        }
    }

    /// Set Model Number
    func setMachineModelNumber() {
        var machineModelText = JLGStringConstants.kUnknownText
        let jlgMachineModelParser = JLGMachineModelParser()
        if let vehicleMarket = serialScreenModelObject.serviceConnectModel?.vehicleType, let vehicleModel = serialScreenModelObject.serviceConnectModel?.vehicleModel {
            let machineModel = jlgMachineModelParser.parseCanVenType(byte: UInt8(vehicleMarket), mByte: UInt8(vehicleModel))
            if machineModel != "" {
                machineModelText = machineModel
            }
        }
        self.modelLabel.text = JLGStringConstants.kModelIDLabel + spaceString + machineModelText
    }

    /// Set Asset ID
    func setAssetID(bleSerialNumberValue: String) {
        self.assetIdLabel.text = JLGStringConstants.kAssetIDLabel
        var assetIDText = serialScreenModelObject.assetIdModel.assetID
        if assetIDText == zeroString || assetIDText == "" {
            if let machineSerialNo = serialScreenModelObject.serialNumberModel?.serialNumber {
                assetIDText = machineSerialNo
            }

            if assetIDText == zeroString || assetIDText == "" {
                assetIDText = bleSerialNumberValue
            }
        }
        self.assetIdTextField.text = assetIDText
    }

    /// Set Battery Type
    func setBatteryType() {
        if let batteryType = serialScreenModelObject.batteryInfoModel.batteryType {
            batteryTypeLabel.text = JLGStringConstants.kBatteryType + spaceString + self.parseBatteryType(bType: batteryType)
        } else {
            batteryTypeLabel.text = JLGStringConstants.kBatteryType + spaceString + JLGStringConstants.kUnknownText
        }
    }

    /// Set Battery Size
    func setBatterySize() {
        if let batterySize = serialScreenModelObject.batteryInfoModel.batterySize {
            batterySizeLabel.text = JLGStringConstants.kBatterySize + spaceString + String(batterySize) + JLGStringConstants.kBatterySizeUnit
        } else {
            batterySizeLabel.text = JLGStringConstants.kBatterySize + spaceString + JLGStringConstants.kUnknownText
        }
    }

    /// Set installation date
    func setInstallationDate() {
        installationDateLabel.text = JLGStringConstants.kInstallationDate + spaceString + getUnixDate(unixDate: serialScreenModelObject.batteryInfoModel.batteryInstallDate)
    }

    /// Set charger algorithm
    func setChargingAlgorithm() {
        if let chargerAlgorithm = serialScreenModelObject.batteryInfoModel.chargerAlgorithm {
            chargingAlgorithmLabel.text = JLGStringConstants.kChargingAlgorithm + spaceString + String(chargerAlgorithm)
        } else {
            chargingAlgorithmLabel.text = JLGStringConstants.kChargingAlgorithm + spaceString + JLGStringConstants.kUnknownText
        }
    }

    /// Set More and Less text to button and hide and show the other labels
    func setShowMoreOrLessButtonLabel() {
        hideUnhideLabel(isHidden: !isExpand)
        if isExpand {
            self.moreInfoButton.setTitle(JLGStringConstants.kLessInfo, for: .normal)
        } else {
            self.moreInfoButton.setTitle(JLGStringConstants.kMoreInfo, for: .normal)
        }
    }

    func hideUnhideLabel(isHidden: Bool) {
        batteryTypeLabel.isHidden = isHidden
        batterySizeLabel.isHidden = isHidden
        installationDateLabel.isHidden = isHidden
        chargingAlgorithmLabel.isHidden = isHidden
        batteryInstallationDateButton.isHidden = isHidden
    }

    @IBAction func moreInfoButtonAction(_ sender: Any) {
        var moreInfoButtonText = self.moreInfoButton.titleLabel?.text
        if moreInfoButtonText == JLGStringConstants.kMoreInfo {
            moreInfoButtonText = JLGStringConstants.kLessInfo
            self.batteryDetailsCellDelegate?.isCellExpand(isExpand: true)
        } else {
            moreInfoButtonText = JLGStringConstants.kMoreInfo
            self.batteryDetailsCellDelegate?.isCellExpand(isExpand: false)
        }
    }
    @IBAction func batteryInstallationDateButtonAction(_ sender: Any) {
        self.batteryDetailsCellDelegate?.openDatePickerForBatteryInstallation()
    }

    func parseBatteryType(bType: String) -> String {
        switch bType {
        case JLGStringConstants.kFLA: return JLGStringConstants.kFLAFullForm
        case JLGStringConstants.kAGM: return JLGStringConstants.kAGMFullForm
        case JLGStringConstants.kLithiumIon: return JLGStringConstants.kLithiumIonFullForm
        default: return JLGStringConstants.kUnknownText
        }
    }

    @IBAction func warningButtonAction(_ sender: Any) {
        self.batteryDetailsCellDelegate?.warningDetailInformationView()
    }

}

extension JLGBatteryDetailsTableViewCell {
    /// Assigning Accessibility Identifier For UI Testing
    func assigningAccessibilityIdentifier() {
        if #available(iOS 11.0, *) {
            warningButton.accessibilityAttributedLabel = NSAttributedString(string: JLGTestingConstant.kJLGSerialScreenWarningButton)
            moreInfoButton.accessibilityAttributedLabel = NSAttributedString(string: JLGTestingConstant.kJLGSerialScreenMoreInfoButton)
            batteryInstallationDateButton.accessibilityAttributedLabel = NSAttributedString(string: JLGTestingConstant.kJLGSerialScreenBatteryInstallationDateButton)
        }
    }
}
