//
//  JLGPreviousChargeTableViewCell.swift
//  JLG Control
//
//  Created by Apple on 26/11/19.
//  Copyright © 2019 L&T. All rights reserved.
//

import UIKit

protocol JLGPreviousChargeDelegate: class {
    func isDisplayDropLevelData(isDropData: Bool)
}

class JLGPreviousChargeTableViewCell: UITableViewCell {
    @IBOutlet weak var previousChargeInfoView: UIView!
    @IBOutlet weak var previousChargeInfoLabel: UILabel!
    @IBOutlet weak var thunderBoltButton: UIButton!
    @IBOutlet weak var dropButton: UIButton!
    weak var chargeDelegate: JLGPreviousChargeDelegate?

    override func awakeFromNib() {
        super.awakeFromNib()
        /// For Unit and UI Testing
        if CommandLine.arguments.contains(JLGTestingConstant.kEnableTesting) {
            self.assigningAccessibilityIdentifier()
        }
    }

    // MARK: - Fill cell data based on model
    func fillCellData(isDropDataShow: Bool, serialScreenModelObj: JLGSerialScreenModel) {
        var previousChargeText = JLGStringConstants.kUnknownText

        if let chargerTimeSinceLastCharge = serialScreenModelObj.batteryInfoModel.chargerTimeSinceLastCharge, chargerTimeSinceLastCharge != 0 {
            let getHour = self.secondsToHours(seconds: chargerTimeSinceLastCharge)

            if getHour == 0 {
                previousChargeText = JLGStringConstants.kLessThan1HrsAgo
            } else if getHour > 71 {
                previousChargeText = JLGStringConstants.kGreaterThan72HrsAgo
            } else {
                previousChargeText = "\(getHour) \(JLGStringConstants.kHrsAgo)"
            }
        }

        var batterySOC = JLGStringConstants.kUnknownText
        if let chargeTo = serialScreenModelObj.batteryInfoModel.lastChargeSocReached {
            batterySOC = String(chargeTo) + percentageString
        }

        previousChargeInfoView.isHidden = false
        if previousChargeText == JLGStringConstants.kUnknownText || batterySOC == JLGStringConstants.kUnknownText {
            previousChargeInfoView.isHidden = true
        }

        previousChargeInfoLabel.text = "\(JLGStringConstants.kPreviousChargeEnded) \(previousChargeText)\n\(JLGStringConstants.kChargedTo) \(batterySOC)"
    }

    func secondsToHours (seconds: Int) -> (Int) {
      return (seconds / 3600)
    }

    // MARK: - Button actions
    @IBAction func thunderBolButtonAction(_ sender: Any) {
        self.chargeDelegate?.isDisplayDropLevelData(isDropData: false)
        thunderBoltButton.setImage(UIImage(named: "ThunderBoltWithBox_Black"), for: .normal)
        dropButton.setImage(UIImage(named: "DropIconWithBox_Grey"), for: .normal)
    }

    @IBAction func dropButtonAction(_ sender: Any) {
        self.chargeDelegate?.isDisplayDropLevelData(isDropData: true)
        thunderBoltButton.setImage(UIImage(named: "ThunderBoltWithBox_Grey"), for: .normal)
        dropButton.setImage(UIImage(named: "DropIconWithBox_Blue"), for: .normal)
    }
}

extension JLGPreviousChargeTableViewCell {
    /// Assigning Accessibility Identifier For UI Testing
    func assigningAccessibilityIdentifier() {
        if #available(iOS 11.0, *) {
            dropButton.accessibilityAttributedLabel = NSAttributedString(string: JLGTestingConstant.kJLGSerialScreenDropButton)
        }
    }
}
