//
//  JLGSelectModelCell.swift
//  JLG Control
//
//  Created by Apple on 31/01/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class JLGSelectModelCell: UITableViewCell {

    @IBOutlet weak var modelLabel: UILabel!

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        accessoryType = selected ? .checkmark : .none
    }

}
