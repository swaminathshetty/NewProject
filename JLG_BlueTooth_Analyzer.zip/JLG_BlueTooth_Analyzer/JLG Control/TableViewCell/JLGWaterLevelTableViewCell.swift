//
//  JLGWaterLevelTableViewCell.swift
//  JLG Control
//
//  Created by Apple on 03/03/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

protocol JLGWaterLevelTableViewCellDelegate: class {
    func openDatePickerForWaterLevelMaintenanceDate()
}

class JLGWaterLevelTableViewCell: UITableViewCell {
    @IBOutlet weak var waterLevelInformationNotAvailableLabel: UILabel!
    @IBOutlet weak var mainStackView: UIStackView!
    @IBOutlet weak var waterDropImage: UIImageView!
    @IBOutlet var viewsCollection: [UIView]!
    @IBOutlet weak var lastRefileDateLabel: UILabel!
    @IBOutlet weak var estimatedFluidLevelLabel: UILabel!
    @IBOutlet weak var view1: UIView!
    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var view3: UIView!
    @IBOutlet weak var view4: UIView!
    @IBOutlet weak var view5: UIView!
    @IBOutlet weak var view6: UIView!
    @IBOutlet weak var view7: UIView!
    @IBOutlet weak var view8: UIView!
    @IBOutlet weak var view9: UIView!
    @IBOutlet weak var view10: UIView!
    @IBOutlet weak var view11: UIView!
    @IBOutlet weak var view12: UIView!

    var divideBy = 8.33
    weak var waterLevelCellDelegate: JLGWaterLevelTableViewCellDelegate?

    /// Show water level in three colors 
    let redColor = NSUIColor(red: 234.0/255.0, green: 37.0/255.0, blue: 38.0/255.0, alpha: 1.0)
    let yellowColor = NSUIColor(red: 255.0/255.0, green: 198.0/255.0, blue: 17.0/255.0, alpha: 1.0)
    let greenColor = NSUIColor(red: 7.0/255.0, green: 142.0/255.0, blue: 0.0/255.0, alpha: 1.0)

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        mainStackView.isHidden = true
        waterLevelInformationNotAvailableLabel.isHidden = true
        waterLevelInformationNotAvailableLabel.text = JLGStringConstants.kWaterLevelInformation

        for view in viewsCollection {
            view.backgroundColor = .lightGray
        }
    }

    func fillCellData(serialScreenModelObj: JLGSerialScreenModel) {
        if let batteryType = serialScreenModelObj.batteryInfoModel.batteryType, batteryType == JLGStringConstants.kFLA {
            mainStackView.isHidden = false
            let estimatedBatteryMaintPercent = serialScreenModelObj.batteryInfoModel.estimatedBatteryMaintPercent
            self.estimatedFluidLevelLabel.text = JLGStringConstants.kEstimatedFluidLevel

            self.lastRefileDateLabel.text = JLGStringConstants.kLastRefillDate + spaceString + getUnixDate(unixDate: serialScreenModelObj.batteryInfoModel.lastBatteryMaintDate)
            self.setWaterLevelViewBackgroundColor(batteryPercentage: estimatedBatteryMaintPercent)
        } else {
            waterLevelInformationNotAvailableLabel.isHidden = false
        }
    }

    func setWaterLevelViewBackgroundColor(batteryPercentage: Int) {
        let divideResult = Int(Double(batteryPercentage) / divideBy)
        if divideResult != 0 {
            for tag in 1...divideResult {
                switch tag {
                case 1: view1.backgroundColor = redColor
                case 2: view2.backgroundColor = redColor
                case 3: view3.backgroundColor = yellowColor
                case 4: view4.backgroundColor = yellowColor
                case 5: view5.backgroundColor = greenColor
                case 6: view6.backgroundColor = greenColor
                case 7: view7.backgroundColor = greenColor
                case 8: view8.backgroundColor = greenColor
                case 9: view9.backgroundColor = greenColor
                case 10: view10.backgroundColor = greenColor
                case 11: view11.backgroundColor = greenColor
                case 12: view12.backgroundColor = greenColor

                default: break
                }
            }
        }
    }

    @IBAction func datePickerButtonAction(_ sender: Any) {
        self.waterLevelCellDelegate?.openDatePickerForWaterLevelMaintenanceDate()
    }
}
