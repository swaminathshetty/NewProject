//
//  JLGBatteryStatusTableViewCell.swift
//  JLG Control
//
//  Created by Apple on 26/11/19.
//  Copyright © 2019 L&T. All rights reserved.
//

import UIKit

class JLGBatteryStatusTableViewCell: UITableViewCell {
    @IBOutlet weak var batteryIcon: UIImageView!
    @IBOutlet weak var batteryPercentageLabel: UILabel!
    @IBOutlet weak var thunderBoltIcon: UIImageView!
    @IBOutlet weak var pluggedInIcon: UIImageView!
    @IBOutlet weak var vacValueLabel: UILabel!
    @IBOutlet weak var vacLabel: UILabel!
    @IBOutlet weak var vdcValueLabel: UILabel!
    @IBOutlet weak var vacStackView: UIStackView!
    @IBOutlet weak var notVACStackView: UIStackView!

    // MARK: - Fill cell data based on model
    func fillCellData(serialScreenModelObj: JLGSerialScreenModel) {
        let imageStr = getImageName(percentValue: serialScreenModelObj.batteryInfoModel.batterySoc)
        self.batteryIcon.image = UIImage(named: imageStr)
        self.batteryPercentageLabel.text = getBatteryPercentageText(percentValue: serialScreenModelObj.batteryInfoModel.batterySoc)
        self.vdcValueLabel.text = String(serialScreenModelObj.batteryInfoModel.batteryVoltage)
        self.vacValueLabel.text = String(serialScreenModelObj.batteryInfoModel.acVoltage)
        self.isShowNotSymbolView(isShow: serialScreenModelObj.batteryInfoModel.acConnectionStatus)
        if serialScreenModelObj.batteryInfoModel.acConnectionStatus && (80...270).contains(serialScreenModelObj.batteryInfoModel.acVoltage) {
            pluggedInIcon.image = UIImage(named: JLGStringConstants.kConnectPlug)
        } else {
            pluggedInIcon.image = UIImage(named: JLGStringConstants.kPlugConnectedWarning)
        }

        /// Charger state is only for thunder Bolt Icon
        let chargerState = self.parseChargerStatus(cStatus: serialScreenModelObj.batteryInfoModel.chargerState)
        thunderBoltIcon.image = UIImage(named: chargerState)

        if serialScreenModelObj.batteryInfoModel.acVoltage < 5 {
            self.isShowNotSymbolView(isShow: false)
        }
    }

    func isShowNotSymbolView(isShow: Bool) {
        vacStackView.isHidden = !isShow
        notVACStackView.isHidden = isShow
    }

    func parseChargerStatus(cStatus: String) -> String {
        /*
         enum CHARGER_STATES
         {
            IDLE = 0;
            CHARGING = 1;
            STANDBY = 2;
            BATTERY_FAIL = 13;
            CHARGER_FAIL = 14;
            CHARGER_STATE_UNKNOWN = 15;
         }
         */
        switch cStatus {
        case JLGStringConstants.kCHARGING: return JLGStringConstants.kChargeIcon
        default: return JLGStringConstants.kChargeIconYellow
        }
    }
}
