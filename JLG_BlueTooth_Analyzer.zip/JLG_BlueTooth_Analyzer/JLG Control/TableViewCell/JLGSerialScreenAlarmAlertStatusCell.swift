//
//  JLGSerialScreenAlarmAlertStatusCell.swift
//  JLG Control
//
//  Created by Admin on 3/26/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class JLGSerialScreenAlarmAlertStatusCell: UITableViewCell {
    @IBOutlet weak var alarmAlertLabel: UILabel!
}
