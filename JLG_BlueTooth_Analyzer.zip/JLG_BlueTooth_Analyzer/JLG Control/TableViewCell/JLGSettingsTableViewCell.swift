//
//  JLGSettingsTableViewCell.swift
//  JLG Control
//
//  Created by L&T on 19/05/18.
//  Copyright © 2018 L&T. All rights reserved.
//

import UIKit

class JLGSettingsTableViewCell: UITableViewCell {

    // MARK: - Variables and Constants
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var versionLabel: UILabel!
    @IBOutlet weak var customButton: UIButton!

    // MARK: - Fill cell data based on model
    func fillCellData(_ item: [String: Any]) {
        titleLabel.text = item[JLGStringConstants.kTitle] as? String ?? ""
        versionLabel.text = item[JLGStringConstants.kVersion] as? String ?? ""
        let buttonImage = item[JLGStringConstants.kImage] as? String ?? ""
        if buttonImage != "" {
            if item[JLGStringConstants.kIsImageRequired] as? Bool ?? false {
                customButton.setBackgroundImage(UIImage(named: buttonImage), for: .disabled)
                customButton.setTitle(item[JLGStringConstants.kImageTitle] as? String ?? "", for: .disabled)
            }
        }
    }
}
