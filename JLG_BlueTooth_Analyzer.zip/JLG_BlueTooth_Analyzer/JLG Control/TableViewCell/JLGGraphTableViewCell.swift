//
//  JLGGraphTableViewCell.swift
//  JLG Control
//
//  Created by Apple on 26/11/19.
//  Copyright © 2019 L&T. All rights reserved.
//

import UIKit
import Charts

protocol JLGGraphCellDelegate: class {
    func isDisplayWeekWiseGraph(isWeekWiseGraph: Bool)
    func infoButtonActionDelegate()
}

class JLGGraphTableViewCell: UITableViewCell {
    @IBOutlet weak var barChartView: BarChartView!
    @IBOutlet weak var lineChartView: LineChartView!
    @IBOutlet weak var segmentControl: UISegmentedControl!
    weak var graphDelegate: JLGGraphCellDelegate?
    @IBOutlet weak var barChartViewHeight: NSLayoutConstraint!
    @IBOutlet weak var lineChartViewHeight: NSLayoutConstraint!
    @IBOutlet weak var batteryInfoButton: UIButton!
    @IBOutlet weak var batteryLevel: UILabel!
    let lightRedColor = NSUIColor(red: 254.0/255.0, green: 150.0/255.0, blue: 151.0/255.0, alpha: 1.0)
    let darkRedColor = NSUIColor(red: 188.0/255.0, green: 25.0/255.0, blue: 27.0/255.0, alpha: 1.0)
    let lightGreenColor = NSUIColor(red: 145.0/255.0, green: 222.0/255.0, blue: 180.0/255.0, alpha: 1.0)
    let darkGreenColor = NSUIColor(red: 45.0/255.0, green: 187.0/255.0, blue: 118.0/255.0, alpha: 1.0)

    fileprivate var serialScreenSharedObj = JLGSerialScreenModel.sharedInstance

    override func awakeFromNib() {
        super.awakeFromNib()
        /// For Unit and UI Testing
        if CommandLine.arguments.contains(JLGTestingConstant.kEnableTesting) {
            self.assigningAccessibilityIdentifier()
        }
        // Initialization code
        barChartViewHeight.constant = 150
        lineChartViewHeight.constant = 158
        setSegmentControlTintColorForIos13(segmentControl: segmentControl)
    }

    @IBAction func infoButtonAction(_ sender: Any) {
        self.graphDelegate?.infoButtonActionDelegate()
    }

    @IBAction func segmentControlAction(_ sender: Any) {
        switch segmentControl.selectedSegmentIndex {
        case 0:
        self.isShowBarChart(isHidden: true)
        self.graphDelegate?.isDisplayWeekWiseGraph(isWeekWiseGraph: false)
        self.fillCellData(isWeekBatteryReport: false)

        case 1:
        self.isShowBarChart(isHidden: false)
        self.graphDelegate?.isDisplayWeekWiseGraph(isWeekWiseGraph: true)
        self.fillCellData(isWeekBatteryReport: true)

        default:
            break
        }
    }

    func isShowBarChart(isHidden: Bool) {
        self.barChartView.isHidden = !isHidden
        self.lineChartView.isHidden = isHidden
    }

    // MARK: - Fill cell data based on model

    func returnBatterySOC(chargingStatus: String) -> Double? {
        var batterySOC: Double! = nil
        for lastCycle in serialScreenSharedObj.lastChargeCycleData where lastCycle.batteryState ==  chargingStatus {
            batterySOC = Double(lastCycle.batterySoc)
        }

        return batterySOC
    }

    func lastCycleGraph() -> [Double] {
        let startOfChargeValue: Double? = self.returnBatterySOC(chargingStatus: JLGStringConstants.kStartOfCharge)
        let chargingValue: Double? = self.returnBatterySOC(chargingStatus: JLGStringConstants.kCharging)
        let startOfDischargeValue: Double? = self.returnBatterySOC(chargingStatus: JLGStringConstants.kStartOfDischarge)
        let dischargingValue: Double? = self.returnBatterySOC(chargingStatus: JLGStringConstants.kDischarging)

        let zeroValue = 0.0

        var chargingArray: [Double] = []

        /// Start of charging to charging
        if var scv = startOfChargeValue, let cv = chargingValue {
            while scv < cv {
                chargingArray.append(scv)
                scv += 5
            }

            if cv != chargingArray.last {
                chargingArray.append(cv)
            }
        } else {
            /// Start of charging to Start of Discharging
            if var scv = startOfChargeValue, let sdv = startOfDischargeValue {
                while scv < sdv {
                    chargingArray.append(scv)
                    scv += 5
                }

                if sdv != chargingArray.last {
                    chargingArray.append(sdv)
                }
            }
        }

        /// Start of Discharging to Discharging
        if var sdv = startOfDischargeValue, let dv = dischargingValue {
            /// adding middle gap
            if chargingArray.count != 0 {
                chargingArray.append(zeroValue)
            }

            while sdv >= dv {
                chargingArray.append(sdv)
                sdv -= 5
            }

            if dv != chargingArray.last {
                chargingArray.append(dv)
            }
        }

        return chargingArray
    }

    func lastFiveCycleGraph() -> [Double] {
        var chargingArray: [Double] = []

        for fiveCycleData in serialScreenSharedObj.lastFiveCycleData {
            chargingArray.append(Double(fiveCycleData.batterySoc))
        }

        return chargingArray
    }

    func fillCellData (isWeekBatteryReport: Bool) {
        self.isShowBarChart(isHidden: !isWeekBatteryReport)
        var months: [String] = []
        var unitsSold: [Double]!
        if isWeekBatteryReport {
            self.batteryLevel.text = JLGStringConstants.kActivity
            segmentControl.selectedSegmentIndex = 1
            let lastFiveCycleGraphData = self.lastFiveCycleGraph()
            if lastFiveCycleGraphData.count != 0 {
                for _ in 0...(lastFiveCycleGraphData.count - 1) {
                    months.append("")
                }
            }

            unitsSold = lastFiveCycleGraphData
        } else {
            self.batteryLevel.text = JLGStringConstants.kBatteryLevel
            segmentControl.selectedSegmentIndex = 0
            let lastCycleGraphData = self.lastCycleGraph()
            if lastCycleGraphData.count != 0 {
                for _ in 0...(lastCycleGraphData.count - 1) {
                    months.append("")
                }
            }

            unitsSold = lastCycleGraphData
        }

        self.setChart(dataPoints: months, values: unitsSold)
    }

    func setChart(dataPoints: [String], values: [Double]) {
        if segmentControl.selectedSegmentIndex == 0 {
            let dataEntries = (0..<dataPoints.count).map { (i) -> BarChartDataEntry in
//                let logValue = log2(values[i])
//                return BarChartDataEntry(x: Double(i), yValues: [logValue])
                return BarChartDataEntry(x: Double(i), yValues: [values[i]])
            }

            let chartDataSet = BarChartDataSet(entries: dataEntries, label: "")
            chartDataSet.setColors(NSUIColor(red: 89.0/255.0, green: 87.0/255.0, blue: 87.0/255.0, alpha: 1.0))
            chartDataSet.barBorderColor = .black
            //chartDataSet.colors = ChartColorTemplates.materialWithRange(dataEntries: values)
            let chartData = BarChartData(dataSets: [chartDataSet])
            chartData.setDrawValues(false)

            barChartView.data = chartData
            //self.setLimitLineForBarChart(chartView: barChartView)
            self.setLimitLineForLineChart(chartView: barChartView)

            barChartView.xAxis.valueFormatter = XAxisValueFormatterForBarChart()
            barChartView.xAxis.drawGridLinesEnabled = false
            barChartView.xAxis.enabled = true

            self.setupCommonProperties(chartView: barChartView)
        } else {
            let yVals1 = (0..<dataPoints.count).map { (i) -> ChartDataEntry in
                return ChartDataEntry(x: Double(i), y: values[i])
            }

            let set3 = LineChartDataSet(entries: yVals1, label: "")
            set3.axisDependency = .right
            set3.lineWidth = 1.75
            set3.circleRadius = 5.0
            set3.circleHoleRadius = 2.5
            set3.setColor(.black)
            // For colored
            //set3.setColors(ChartColorTemplates.materialWithRange(dataEntries: values), alpha: 1.0)
            // For colored circle
            set3.circleColors = ChartColorTemplates.materialWithRange(dataEntries: values)
            //set3.setCircleColor(.black)

            let data = LineChartData(dataSets: [set3])
            data.setValueTextColor(.black)
            data.setValueFont(.systemFont(ofSize: 9))
            data.setValueFormatter(LineChartDataValueFormater())
            lineChartView.data = data
            lineChartView.minOffset = 18
            self.setLimitLineForLineChart(chartView: lineChartView)

            lineChartView.xAxis.valueFormatter = XAxisValueFormatterForLineChart()
            lineChartView.xAxis.drawGridLinesEnabled = true
            lineChartView.xAxis.enabled = true

            self.setupCommonProperties(chartView: lineChartView)
        }
    }

    func setupCommonProperties(chartView: BarLineChartViewBase) {
        chartView.xAxis.labelPosition = .bottom
        chartView.chartDescription?.enabled = false
        chartView.legend.enabled = false
        chartView.leftAxis.drawGridLinesEnabled = false // or make it as true for more line grids
        chartView.leftAxis.drawLabelsEnabled = false

        // Number formatting of YAxis
        chartView.rightAxis.enabled = true
        chartView.rightAxis.axisMinimum = 0
        chartView.rightAxis.axisMaximum = 100
        chartView.rightAxis.labelCount = 5
        chartView.rightAxis.valueFormatter = YAxisValueFormatterForLineChart()

//        if segmentControl.selectedSegmentIndex == 0 {
//            chartView.rightAxis.axisMinimum = 0.0
//            chartView.rightAxis.axisMaximum = 6.6
//            chartView.rightAxis.labelCount = 3
//            chartView.rightAxis.drawGridLinesEnabled = false
//            chartView.rightAxis.valueFormatter = YAxisValueFormatterForBarChart()
//        } else {
//            chartView.rightAxis.axisMinimum = 0
//            chartView.rightAxis.axisMaximum = 100
//            chartView.rightAxis.labelCount = 5
//            chartView.rightAxis.valueFormatter = YAxisValueFormatterForLineChart()
//        }
    }

    func setLimitLineForLineChart(chartView: BarLineChartViewBase) {
        let leftAxis = chartView.leftAxis
        leftAxis.removeAllLimitLines()
        var index = 0
        while index < 20 {
            let ll1 = ChartLimitLine(limit: Double(81 + index), label: "")
            ll1.lineWidth = barChartViewHeight.constant / 100
            ll1.drawLabelEnabled = false
            ll1.lineColor = lightGreenColor
            ll1.lineDashLengths = [0, 0]
            leftAxis.addLimitLine(ll1)

            let ll2 = ChartLimitLine(limit: Double(0 + index), label: "")
            ll2.lineWidth = barChartViewHeight.constant / 100
            ll2.drawLabelEnabled = false
            ll2.lineColor = lightRedColor
            ll2.lineDashLengths = [0, 0]
            leftAxis.addLimitLine(ll2)

            index += 1
        }

        leftAxis.axisMaximum = 100
        leftAxis.axisMinimum = 0
        leftAxis.drawLimitLinesBehindDataEnabled = true
    }

    func setLimitLineForBarChart(chartView: BarLineChartViewBase) {
        let leftAxis = chartView.leftAxis
        leftAxis.removeAllLimitLines()
        var greenLineIndex = 0.0
        while greenLineIndex < 0.4 {
            let ll1 = ChartLimitLine(limit: 6.3 + greenLineIndex, label: "")
            ll1.lineWidth = 2
            ll1.drawLabelEnabled = false
            switch greenLineIndex {
            case 0.0:
                ll1.lineColor = darkGreenColor
            default:
                ll1.lineColor = lightGreenColor
            }

            leftAxis.addLimitLine(ll1)
            greenLineIndex += 0.1
        }

        var redLineIndex = 0.0
        while redLineIndex < 4.33 {
            let ll2 = ChartLimitLine(limit: 0.0 + redLineIndex, label: "")
            ll2.lineWidth = 2
            ll2.drawLabelEnabled = false
            switch redLineIndex {
            case 4.3...:
                 ll2.lineColor = darkRedColor
            default:
                ll2.lineColor = lightRedColor
            }
            leftAxis.addLimitLine(ll2)
            redLineIndex += 0.1
        }

        leftAxis.axisMaximum = 6.6
        leftAxis.axisMinimum = 0.0
        leftAxis.drawLimitLinesBehindDataEnabled = true
    }
}

class ExtendIAxisValueFormatter: NSObject, IAxisValueFormatter {
    public let numFormatter: NumberFormatter

    override init() {
        numFormatter = NumberFormatter()
        numFormatter.numberStyle = .percent
        numFormatter.maximumFractionDigits = 1
        numFormatter.multiplier = 1
        numFormatter.percentSymbol = percentageString
    }

    func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        return numFormatter.string(from: NSNumber(floatLiteral: value))!
    }
}

class YAxisValueFormatterForBarChart: ExtendIAxisValueFormatter {
    public override func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        switch value {
        case 0: return "0%"
        case 4: return "20%"
        case 6: return "80%"
        default:
            return ""
        }
    }
}

class YAxisValueFormatterForLineChart: ExtendIAxisValueFormatter {}

class XAxisValueFormatterForBarChart: ExtendIAxisValueFormatter {
    public override func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        return ""
    }
}

class XAxisValueFormatterForLineChart: ExtendIAxisValueFormatter {
    public override func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        if value == axis?.axisMaximum {
            return JLGStringConstants.kMostRecent
        }

        return ""
    }
}

class LineChartDataValueFormater: NSObject, IValueFormatter {
    let numFormatter: NumberFormatter

    override init() {
        numFormatter = NumberFormatter()
        numFormatter.numberStyle = .percent
        numFormatter.maximumFractionDigits = 1
        numFormatter.multiplier = 1
        numFormatter.percentSymbol = percentageString
    }

    func stringForValue(_ value: Double, entry: ChartDataEntry, dataSetIndex: Int, viewPortHandler: ViewPortHandler?) -> String {
        return numFormatter.string(from: NSNumber(floatLiteral: value))!
//        switch value {
//        case 0: return ""
//        default: return numFormatter.string(from: NSNumber(floatLiteral: value))!
//        }
    }
}

extension JLGGraphTableViewCell {
    /// Assigning Accessibility Identifier For UI Testing
    func assigningAccessibilityIdentifier() {
        if #available(iOS 11.0, *) {
            batteryInfoButton.accessibilityAttributedLabel = NSAttributedString(string: JLGTestingConstant.kJLGSerialScreenBatteryInfoButton)
            segmentControl.accessibilityAttributedLabel = NSAttributedString(string: JLGTestingConstant.kJLGSerialScreenSegmentController)
        }
    }
}
