//
//  JLGFleetTableViewCell.swift
//  JLG Control
//
//  Created by Apple on 11/11/19.
//  Copyright © 2019 L&T. All rights reserved.
//

import UIKit

class JLGFleetTableViewCell: UITableViewCell {

    @IBOutlet weak var warningImageView: UIImageView!
    @IBOutlet weak var modelLabel: UILabel!
    @IBOutlet weak var assetIDLabel: UILabel!
    @IBOutlet weak var batteryImageView: UIImageView!
    @IBOutlet weak var batteryPercentageLabel: UILabel!
    @IBOutlet weak var machinePlugOrNotImageView: UIImageView!

    fileprivate let iSZeroValueOne = "\u{07}\u{02}0\0\0\0\0\0\0\0\0\0\0"
    fileprivate let iSZeroValueTwo = "\u{07}\u{03}0\0\0\0\0\0\0\0\0\0\0"

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        modelLabel.numberOfLines = 0
        modelLabel.lineBreakMode = .byCharWrapping
        assetIDLabel.numberOfLines = 0
        assetIDLabel.lineBreakMode = .byCharWrapping
        self.warningImageView.isHidden = true
        self.batteryImageView.isHidden = true
        self.batteryPercentageLabel.isHidden = true
        self.machinePlugOrNotImageView.isHidden = true
    }

    // MARK: - Fill cell data based on model
    func fillCellData(dir: NSDictionary) {
        let model: JLGFleetScreenModel = dir.value(forKey: JLGStringConstants.kJLGFleetScreenModelInstance) as! JLGFleetScreenModel

        let bleSerialNumberValue = dir.value(forKey: JLGStringConstants.kSerialNumber) as! String
        /// For creating dummy data comment above lines and uncomment below line
        // let bleSerialNumberValue = "100828"

        /// Set warning icon
        if model.isAlertAlarmActive {
            self.warningImageView.isHidden = false
        } else {
            self.warningImageView.isHidden = true
        }

        /// Set Model number
        self.modelLabel.text = JLGStringConstants.kModelIDLabel + spaceString + model.machineModel

        /// Set Asset ID or machine serial number or BLE serial number
        var assetIDText = model.assetId1 + model.assetId2
        if self.checkValueIsBlankOrZero(inputString: assetIDText) {
            assetIDText = model.machineSn
            if self.checkValueIsBlankOrZero(inputString: assetIDText) {
                assetIDText = bleSerialNumberValue
            }
        }

        self.assetIDLabel.text = JLGStringConstants.kAssetIDLabel + spaceString + assetIDText

        /// Set battery percentage and battery icon
        if model.batteryPercentage != JLGStringConstants.kUnknownText {
            self.batteryPercentageLabel.isHidden = false
            var batteryPercentageText = ""
            let batteryContains = model.batteryPercentage.contains(dotString)
            if !batteryContains {
                self.batteryImageView.isHidden = false
                let getBatteryPercentage = model.batteryPercentage
                let batteryPercentageInt: Int = Int(getBatteryPercentage) ?? 0
                batteryPercentageText = getBatteryPercentageText(percentValue: batteryPercentageInt)
                let imageStr = getImageName(percentValue: batteryPercentageInt)
                self.batteryImageView.image = UIImage(named: imageStr)
            } else {
                batteryPercentageText = model.batteryPercentage + JLGStringConstants.kBatteryPercentageVoltUnit
                self.batteryImageView.isHidden = true
            }

            self.batteryPercentageLabel.text = batteryPercentageText
        } else {
            self.batteryPercentageLabel.isHidden = true
            self.batteryImageView.isHidden = true
        }

        /// Set machine plug icon
        if model.isConnectedWithACPower != JLGStringConstants.kUnknownText {
            self.machinePlugOrNotImageView.isHidden = false
            self.machinePlugOrNotImageView.image = UIImage(named: model.isConnectedWithACPower)
        } else {
            self.machinePlugOrNotImageView.isHidden = true
        }
    }

    /// Checking asset id and machine serial no is zero or blank
    func checkValueIsBlankOrZero(inputString: String) -> Bool {
        if inputString == iSZeroValueOne || inputString == iSZeroValueTwo || inputString == zeroString || inputString == "" {
            return true
        }
        return false
    }
}
