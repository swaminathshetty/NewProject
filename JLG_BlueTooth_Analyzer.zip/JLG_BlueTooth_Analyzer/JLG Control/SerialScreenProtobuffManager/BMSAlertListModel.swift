//
//  BMSAlertListModel.swift
//  JLG Control
//
//  Created by Admin on 4/9/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
/// Binding BMS Alert List protobuf response
struct BMSAlertListModel {
    var bmsAlertsModel = [BMSAlertsModel]()

    init(data: [String: Any]) {
        if let bmsAlertList = data["bmsAlertList"] as? [[String: Any]] {
            for bmsAlertListObj in bmsAlertList {
                let obj = BMSAlertsModel.init(data: bmsAlertListObj)
                self.bmsAlertsModel.append(obj)
            }
        }
    }
}
/// Binding BMS Alerts protobuf response
struct BMSAlertsModel {
    var alertActive: Bool
    var alertId: String
    var count: Int

    init(data: [String: Any]) {
        alertActive = data["alertActive"] as? Bool ?? false
        alertId = data["alertId"] as? String ?? ""
        count = data["count"] as? Int ?? 0
    }
}
