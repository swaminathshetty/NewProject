//
//  ServiceConnectModel.swift
//  JLG Control
//
//  Created by Admin on 5/5/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit
/// Binding Service Connect protobuf response
class ServiceConnectModel: NSObject {
    var vehicleBrand: Int
    var vehicleMarket: Int
    var vehicleModel: Int?
    var vehicleOwner: Int
    var vehicleSoftwareVersionString: String
    var vehicleType: Int?
    var vehicleVersion: Int
    var serviceConnectFeatures: ServiceConnectFeatures?

    init(data: [String: Any]) {
        vehicleBrand = data["vehicleBrand"] as? Int ?? 0
        vehicleMarket = data["vehicleMarket"] as? Int ?? 0
        vehicleModel = data["vehicleModel"] as? Int
        vehicleOwner = data["vehicleOwner"] as? Int ?? 0
        vehicleSoftwareVersionString = data["vehicleSoftwareVersionString"] as? String ?? ""
        vehicleType = data["vehicleType"] as? Int
        vehicleVersion = data["vehicleVersion"] as? Int ?? 0
        serviceConnectFeatures = data["serviceConnectFeatures"] as? ServiceConnectFeatures
    }
}

class ServiceConnectFeatures: NSObject {
    var batteryMonitoring: Bool
    var remoteControl: Bool
    var vehicleStatus: Bool

    init(data: [String: Any]) {
        batteryMonitoring = data["batteryMonitoring"] as? Bool ?? false
        remoteControl = data["remoteControl"] as? Bool ?? false
        vehicleStatus = data["vehicleStatus"] as? Bool ?? false
    }
}
