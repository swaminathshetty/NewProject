//
//  AnalyzerMessageModel.swift
//  JLG Control
//
//  Created by LTTS_iMac_Conti on 17/08/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class AnalyzerDataModel: NSObject {
    var lineData: String = ""
    var lineType: String = ""
    var isCharBlink: Bool = false
    var positionOfCharBlink: Int = 0
//    init(data: [String: Any]) {
//        lineData = data["lineData"] as? String ?? ""
//        lineType = data["lineType"] as? String ?? ""
//    }
}
