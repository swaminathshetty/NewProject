//
//  BatteryHistoryModel.swift
//  JLG Control
//
//  Created by Apple on 17/03/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
/// Binding Battery History protobuf response
struct BatteryHistoryModel {
    var lastChargeCycleModel = [LastChargeCycleModel]()
    var lastFiveCyclesModel = [LastFiveCyclesModel]()

    init(data: [String: Any]) {
        if let lastChargeCycle = data["lastChargeCycle"] as? [[String: Any]] {
            for lastChargeCycleObj in lastChargeCycle {
                let obj = LastChargeCycleModel.init(data: lastChargeCycleObj)
                self.lastChargeCycleModel.append(obj)
            }
        }

        if let lastFiveCycle = data["lastFiveCycles"] as? [[String: Any]] {
            for lastFiveCycleObj in lastFiveCycle {
                let obj = LastFiveCyclesModel.init(data: lastFiveCycleObj)
                self.lastFiveCyclesModel.append(obj)
            }
        }
    }
}
/// Binding Last Charge Cycle protobuf response
struct LastChargeCycleModel {
    var batterySoc: Int
    var timeStamp: Int
    var batteryState: String

    init(data: [String: Any]) {
        batterySoc = data["batterySoc"] as? Int ?? 0
        timeStamp = data["timeStamp"] as? Int ?? 0
        batteryState = data["batteryState"] as? String ?? ""
    }
}
/// Binding Last Five Cycles protobuf response
struct LastFiveCyclesModel {
    var batterySoc: Int
    var timeStamp: Int
    var batteryState: String

    init(data: [String: Any]) {
        batterySoc = data["batterySoc"] as? Int ?? 0
        timeStamp = data["timeStamp"] as? Int ?? 0
        batteryState = data["batteryState"] as? String ?? ""
    }
}
