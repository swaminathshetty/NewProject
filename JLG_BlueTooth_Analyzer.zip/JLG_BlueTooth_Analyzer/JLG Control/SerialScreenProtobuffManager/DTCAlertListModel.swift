//
//  DTCAlertListModel.swift
//  JLG Control
//
//  Created by Admin on 4/14/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit
/// Binding DTC Alert List protobuf response
struct DTCAlertListModel {
    var dtcAlertNumber = [Int]()
    init(data: [String: Any]) {
        if let dtcNumbers = data["dtcNumber"] as? [Int] {
            for dtcNumbers in dtcNumbers {
                self.dtcAlertNumber.append(dtcNumbers)
            }
        }
    }
}
