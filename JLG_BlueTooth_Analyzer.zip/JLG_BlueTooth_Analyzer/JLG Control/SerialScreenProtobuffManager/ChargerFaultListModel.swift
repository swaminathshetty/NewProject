//
//  ChargerFaultListModel.swift
//  JLG Control
//
//  Created by Admin on 3/24/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
/// Binding Charger Fault List protobuf response
struct ChargerFaultListModel {
    var faultCodesModel = [FaultCodesModel]()

    init(data: [String: Any]) {
        if let faultCodes = data["faultCodes"] as? [[String: Any]] {
            for faultCodesObj in faultCodes {
                let obj = FaultCodesModel.init(data: faultCodesObj)
                self.faultCodesModel.append(obj)
            }
        }
    }
}
/// Binding Fault Codes protobuf response
struct FaultCodesModel {
    var fmi: Int
    var spn: Int

    init(data: [String: Any]) {
        fmi = data["fmi"] as? Int ?? 0
        spn = data["spn"] as? Int ?? 0
    }
}
