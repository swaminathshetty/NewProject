//
//  ResponseModel.swift
//  JLG Control
//
//  Created by Apple on 12/03/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
/// Write data in protobuf response
struct ResponseModel {
    var responseType: String
    var dataValue: String

    init(data: [String: Any]?) {
        if let dataObj = data {
            responseType = dataObj["responseType"] as? String ?? ""
            dataValue = dataObj["data"] as? String ?? ""
        } else {
            responseType = ""
            dataValue = ""
        }
    }
}
