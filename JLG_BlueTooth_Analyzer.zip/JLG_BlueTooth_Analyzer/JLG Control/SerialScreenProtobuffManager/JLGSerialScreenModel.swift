//
//  JLGSerialScreenModel.swift
//  JLG Control
//
//  Created by Apple on 09/03/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

protocol JLGSerialScreenModelDelegate: class {
    func updateSerialScreen()
    func doNotUpdatedSerialScreen()
    func protobufResponseData(requestType: String)
    func protobufFailResponseData(requestType: String)
    func updateBluetoothAnalyzerData()
    func updateBTAAnalyzerScreen()
}

extension JLGSerialScreenModelDelegate {
    func updateSerialScreen() {}
    func doNotUpdatedSerialScreen() {}
    func protobufResponseData(requestType: String) {}
    func protobufFailResponseData(requestType: String) {}
    func updateBluetoothAnalyzerData() {}
    func updateBTAAnalyzerScreen() {}
}

class JLGSerialScreenModel: NSObject {
    // MARK: - Variables and Constants
    static let sharedInstance = JLGSerialScreenModel()
    var delegateJLGSerialScreenModel: JLGSerialScreenModelDelegate?
    var batteryInfoModel: BatteryInfoModel! = nil
    var assetIdModel: AssetIdModel! = nil
    var serialNumberModel: SerialNumberModel?
    var responseModel: ResponseModel! = nil
    var batteryHistoryModel: BatteryHistoryModel! = nil
    var writeRequestType: String = ""
    var lastFiveCycleData = [LastFiveCyclesModel]()
    var lastChargeCycleData = [LastChargeCycleModel]()
    var chargerFaultListModel: ChargerFaultListModel! = nil
    var faultCodesModelData = [FaultCodesModel]()
    var alarmAlertStatusModel: AlarmAlertStatusModel! = nil
    var bmsAlertListModel: BMSAlertListModel! = nil
    var bmsAlertListModelData = [BMSAlertsModel]()
    var dtcAlertListModel: DTCAlertListModel! = nil
    var dtcAlertListModelData = [Int]()
    var timerGetDataFromProtobuf: Timer?
    var serviceConnectModel: ServiceConnectModel?
    var analyzerDataModel: AnalyzerDataModel! = nil
    
    
    /// Clear all values
    func resetAllValue() {
        writeRequestType = ""
        responseModel = nil
        assetIdModel = nil
        serialNumberModel = nil
        batteryHistoryModel = nil
        chargerFaultListModel = nil
        bmsAlertListModel = nil
        dtcAlertListModel = nil
        serviceConnectModel = nil
        analyzerDataModel = nil
        self.clearAllDataArray()
    }

    func clearAllDataArray() {
        batteryInfoModel = nil
        alarmAlertStatusModel = nil
        lastFiveCycleData.removeAll()
        lastChargeCycleData.removeAll()
        faultCodesModelData.removeAll()
        bmsAlertListModelData.removeAll()
        dtcAlertListModelData.removeAll()
    }

    /// Common request method
    func commonRequestForProtoBuf(serializeData: Data) {
        var serializeDataArray: [UInt8] = JLGIntByteConverter.dataBytesArrayToUInt8ArrayConverter(data: serializeData)
        /// Adding UInt8 element in second position
        serializeDataArray.insert(UInt8(0), at: 0)
        /// Adding UInt8 element in first position
        serializeDataArray.insert(UInt8(serializeData.count), at: 0)
        print("serializeDataArray --> \(serializeDataArray)")
        appendLog(text: "\(Date()): Protobuf Request Serialize Data --> \(serializeDataArray)")
        let intByteConv = JLGIntByteConverter.uInt8arrayToDataConverter(valueArray: serializeDataArray)
        JLGBLEManager.sharedInstance.writeData(data: intByteConv, charUUID: kProtobufStreamUUID, withResponse: false)
    }

    /// Create request using request type
    func createPrtobufRequest(reqType: ProtobufRequestType) {
        var env = Jlg_Envelope()

        switch reqType {
        case .bmsBatteryInfo:
            env.request.requestType = Jlg_Requests_BasicRequest.BASIC_REQUEST_TYPES.bmsBatteryInfo

        case .bmsHistory:
            env.request.requestType = Jlg_Requests_BasicRequest.BASIC_REQUEST_TYPES.bmsHistory

        case .bmsEsrInfo:
            env.request.requestType = Jlg_Requests_BasicRequest.BASIC_REQUEST_TYPES.bmsEsrInfo

        case .bmsAlerts:
            env.request.requestType = Jlg_Requests_BasicRequest.BASIC_REQUEST_TYPES.bmsAlerts

        case .diagDtcList:
            env.request.requestType = Jlg_Requests_BasicRequest.BASIC_REQUEST_TYPES.diagDtcList

        case .diagChargerFaultList:
            env.request.requestType = Jlg_Requests_BasicRequest.BASIC_REQUEST_TYPES.diagChargerFaultList

        case .infoAssetID:
            env.request.requestType = Jlg_Requests_BasicRequest.BASIC_REQUEST_TYPES.infoAssetID

        case .infoSerialNumber:
            env.request.requestType = Jlg_Requests_BasicRequest.BASIC_REQUEST_TYPES.infoSerialNumber

        case .alarmAlertStatus:
            env.request.requestType = Jlg_Requests_BasicRequest.BASIC_REQUEST_TYPES.diagAlarmAlertStatus

        case .serviceConnect:
            env.request.requestType = Jlg_Requests_BasicRequest.BASIC_REQUEST_TYPES.serviceConnect
            
            /// Bluetooth Analyzer Message
        case .analyzerMessage_start:
            env.analyzerMessage.command = Jlg_Analyzer_AnalyzerMessage.AnalyzerCommand.acStart
            
        case .analyzerMessage_stop:
            env.analyzerMessage.command = Jlg_Analyzer_AnalyzerMessage.AnalyzerCommand.acStop
            
        case .analyzerMessage_enter:
            env.analyzerMessage.command = Jlg_Analyzer_AnalyzerMessage.AnalyzerCommand.acEnter
            
        case .analyzerMessage_escape:
            env.analyzerMessage.command = Jlg_Analyzer_AnalyzerMessage.AnalyzerCommand.acEscape

        case .analyzerMessage_up:
            env.analyzerMessage.command = Jlg_Analyzer_AnalyzerMessage.AnalyzerCommand.acUp
            
        case .analyzerMessage_down:
            env.analyzerMessage.command = Jlg_Analyzer_AnalyzerMessage.AnalyzerCommand.acDown
            
        case .analyzerMessage_right:
            env.analyzerMessage.command = Jlg_Analyzer_AnalyzerMessage.AnalyzerCommand.acRight
            
        case .analyzerMessage_left:
            env.analyzerMessage.command = Jlg_Analyzer_AnalyzerMessage.AnalyzerCommand.acLeft
            }

        let serialize: Data = try! env.serializedData()
        self.commonRequestForProtoBuf(serializeData: serialize)
    }

    /// Parse protobuf response
    func parseProtobufResponse(dataValue: Data) {
        do {
            if let jsonData = try JSONSerialization.jsonObject(with: dataValue, options: []) as? [String: Any] {
                print("protobuf json response --> \(jsonData)")
                appendLog(text: "\(Date()): protobuf in json response --> \(jsonData)")

                if let response = jsonData["response"] as? [String: Any] {
                    self.invalidateProtobufTimer()
                    responseModel = ResponseModel.init(data: response)
                    self.delegateJLGSerialScreenModel?.protobufResponseData(requestType: writeRequestType)
                } /*else if let analyzerMessage = jsonData["analyzerMessage"] as? [String: Any] {
                    self.setAnalyzerMessageData(json: analyzerMessage)
                }*/ else {
                    self.setBatteryInfoModelData(json: jsonData)
                    self.setMachineInfoData(json: jsonData)
                    self.setBatteryHistoryData(json: jsonData)
                    self.setChargerFaultListData(json: jsonData)
                    self.setAlarmAlertStatusData(json: jsonData)
                    self.setBMSAlertListModelData(json: jsonData)
                    self.setDTCAlertListModelData(json: jsonData)
                    self.setServiceConnectModelData(json: jsonData)
                    self.checkAllParameter()
                    self.checkAssetIDAndModelNo()
                }
            }
        } catch let error as NSError {
            print("Failed to load: \(error.localizedDescription)")
            self.delegateJLGSerialScreenModel?.doNotUpdatedSerialScreen()
        }
    }
    
    /// Parse Battery Info Data
    func setBatteryInfoModelData (json: [String: Any]) {
        if let batteryInfo = json["batteryInfo"] as? [String: Any] {
            batteryInfoModel = BatteryInfoModel.init(data: batteryInfo)
        }
    }

    /// Parse Machine Info asset ID and serial number Data
    func setMachineInfoData (json: [String: Any]) {
        if let machineInfo = json["machineInfo"] as? [String: Any] {
            if let _ = machineInfo["assetId"] as? String {
                assetIdModel = AssetIdModel.init(data: machineInfo)
            }

            if let _ = machineInfo["serialNumber"] as? String {
                serialNumberModel = SerialNumberModel.init(data: machineInfo)
            }
        }
    }

    /// Parse Battery History Data
    func setBatteryHistoryData (json: [String: Any]) {
        if let batteryHistory = json["batteryHistory"] as? [String: Any] {
            batteryHistoryModel = BatteryHistoryModel.init(data: batteryHistory)

            if batteryHistoryModel.lastChargeCycleModel.count != 0 {
                for lastCycleCyclesObj in batteryHistoryModel.lastChargeCycleModel {
                    lastChargeCycleData.append(lastCycleCyclesObj)
                }
            }
            batteryHistoryModel.lastChargeCycleModel = lastChargeCycleData

            if batteryHistoryModel.lastFiveCyclesModel.count != 0 {
                for lastFiveCyclesObj in batteryHistoryModel.lastFiveCyclesModel {
                    lastFiveCycleData.append(lastFiveCyclesObj)
                }
            }
            batteryHistoryModel.lastFiveCyclesModel = lastFiveCycleData
        }
    }

    /// Parse Charger Fault List Data
    func setChargerFaultListData (json: [String: Any]) {
        if let chargerFaultList = json["chargerFaultList"] as? [String: Any] {
            chargerFaultListModel = ChargerFaultListModel.init(data: chargerFaultList)

            if chargerFaultListModel.faultCodesModel.count != 0 {
                for faultCodesModelObj in chargerFaultListModel.faultCodesModel {
                    faultCodesModelData.append(faultCodesModelObj)
                }
            }
            chargerFaultListModel.faultCodesModel = faultCodesModelData
        }
    }

    /// Parse Alarm Alert Status Data
    func setAlarmAlertStatusData (json: [String: Any]) {
        if let alarmAlertStatus = json["alarmAlertStatus"] as? [String: Any] {
            alarmAlertStatusModel = AlarmAlertStatusModel.init(data: alarmAlertStatus)
        }
    }

    /// Parse BMS Alert List Data
    func setBMSAlertListModelData (json: [String: Any]) {
        if let bmsAlerts = json["bmsAlerts"] as? [String: Any] {
            bmsAlertListModel = BMSAlertListModel.init(data: bmsAlerts)

            if bmsAlertListModel.bmsAlertsModel.count != 0 {
                for bmsAlertObj in bmsAlertListModel.bmsAlertsModel {
                    bmsAlertListModelData.append(bmsAlertObj)
                }
            }
            bmsAlertListModel.bmsAlertsModel = bmsAlertListModelData
        }
    }

    /// Parse DTC List Data
    func setDTCAlertListModelData (json: [String: Any]) {
        if let dtcAlerts = json["dtcList"] as? [String: Any] {
            dtcAlertListModel = DTCAlertListModel.init(data: dtcAlerts)

            if dtcAlertListModel.dtcAlertNumber.count != 0 {
                for dtcAlertNumberObj in dtcAlertListModel.dtcAlertNumber {
                    dtcAlertListModelData.append(dtcAlertNumberObj)
                }
            }

            for dtcAlertNo in dtcAlertListModelData {
                if dtcAlertNo == 44136 || dtcAlertNo == 99365 {
                    dtcAlertListModelData.removeObject(object: dtcAlertNo)
                }
            }

            dtcAlertListModel.dtcAlertNumber = dtcAlertListModelData
        }
    }

    /// Parse Service Connect Data
    func setServiceConnectModelData (json: [String: Any]) {
        if let serviceConnect = json["serviceConnect"] as? [String: Any] {
            serviceConnectModel = ServiceConnectModel.init(data: serviceConnect)
        }
    }
    /// Parse bluetooth analyzer protobuf response
    func parseProtobufBluetoothAnalyzerResponse (data: Jlg_Analyzer_AnalyzerMessage) {
        appendLog(text: "\(Date()): analyzerMessage --> \(data.analyzerData)")
        print("analyzerMessage --> \(data.analyzerData)")

//        print("analyzerMessage --> \(data.analyzerData.lineData)")
//        print("analyzerMessage count --> \(data.analyzerData.lineData.count)")
//        print("analyzerMessage textFormatString --> \(data.analyzerData.textFormatString())")
//        print("analyzerMessage toHexString --> \(data.analyzerDat a.lineData.bytes)")
//        print("analyzerMessage --> \(data.analyzerData.lineData.description)")
        
        if analyzerDataModel != nil {
            analyzerDataModel = nil
        }

        var lineDataArray = data.analyzerData.lineData
//        print("analyzerMessage toHexString --> \(data.analyzerData.lineData.toHexString())")
//        print("analyzerMessage lineDataArray --> \(lineDataArray)")

        analyzerDataModel = AnalyzerDataModel()
        if data.analyzerData.lineType.rawValue == 0 {
            analyzerDataModel.lineType = kTopLine
        } else {
            analyzerDataModel.lineType = kBottomLine
            
            let itemsArray = ["b0", "b1", "b2", "b3", "b4", "b5", "b6", "b7", "b8", "b9", "B0", "B1", "B2", "B3", "B4", "B5", "B6", "B7", "B8", "B9",]
            let hexString = data.analyzerData.lineData.toHexString()
            appendLog(text: "\(Date()): hexString --> \(hexString)")
            print("hexString --> \(hexString)")
            /// Check value is content or not
            let isItemsArrayDataPresent = itemsArray.contains(where: hexString.contains)
            if isItemsArrayDataPresent {
                /// Get the position and set the value
                for item in itemsArray {
                    if let range: Range<String.Index> = hexString.range(of: item) {
                        var index: Int = hexString.distance(from: hexString.startIndex, to: range.lowerBound)
                        /// Value must be even
                        if index % 2 == 0 {
                            //print("index: \(index)") //index: 2
                            index = index/2
                            analyzerDataModel.isCharBlink = true
                            analyzerDataModel.positionOfCharBlink = index

                            switch item {
                            case "b0", "B0": lineDataArray[index] = 48
                            case "b1", "B1": lineDataArray[index] = 49
                            case "b2", "B2": lineDataArray[index] = 50
                            case "b3", "B3": lineDataArray[index] = 51
                            case "b4", "B4": lineDataArray[index] = 52
                            case "b5", "B5": lineDataArray[index] = 53
                            case "b6", "B6": lineDataArray[index] = 54
                            case "b7", "B7": lineDataArray[index] = 55
                            case "b8", "B8": lineDataArray[index] = 56
                            case "b9", "B9": lineDataArray[index] = 57
                            default: break
                            }
                        }

                        break
                    }
                }
            }
        }

        analyzerDataModel.lineData = String(data: lineDataArray, encoding: .ascii) ?? ""
        self.delegateJLGSerialScreenModel?.updateBluetoothAnalyzerData()
    }

//    /// Parse Analyzer Message Data
//    func setAnalyzerMessageData (json: [String: Any]) {
//        if let analyzerData = json["analyzerData"] as? [String: Any] {
//            analyzerDataModel = AnalyzerDataModel.init(data: analyzerData)
//            self.delegateJLGSerialScreenModel?.updateBluetoothAnalyzerData()
//        }
//    }
    
    /// Check battery info and alarm and alert status parameters having value or not
    /// After call the delegate method
    func checkAllParameter() {
        if batteryInfoModel == nil || alarmAlertStatusModel == nil {
            return
        }

        self.delegateJLGSerialScreenModel?.updateSerialScreen()
    }

    func checkAssetIDAndModelNo() {
        if assetIdModel == nil || serialNumberModel == nil || serviceConnectModel == nil {
            return
        }
        self.delegateJLGSerialScreenModel?.updateBTAAnalyzerScreen()
    }
    
    // MARK: - Write data in protobuf methods
    /// Write asset ID
    func writeAssetIdInProtobuf(value: String) {
        timerGetDataFromProtobuf = Timer.scheduledTimer(timeInterval: responseTimeout, target: self, selector: #selector(protobufFailResponse), userInfo: nil, repeats: false)

        writeRequestType = JLGStringConstants.kAssetIdUpdated
        var env = Jlg_Envelope()
        env.machineInfo = Jlg_Responses_MachineInfo()
        env.machineInfo.assetID = value
        let serialize: Data = try! env.serializedData()
        // Set message
        self.commonRequestForProtoBuf(serializeData: serialize)
    }
    /// Write Serial Number
    func writeSerialNumberInProtobuf(value: String) {
        timerGetDataFromProtobuf = Timer.scheduledTimer(timeInterval: responseTimeout, target: self, selector: #selector(protobufFailResponse), userInfo: nil, repeats: false)

        writeRequestType = JLGStringConstants.kAssetIdUpdated
        var env = Jlg_Envelope()
        env.machineInfo = Jlg_Responses_MachineInfo()
        env.machineInfo.serialNumber = value
        let serialize: Data = try! env.serializedData()
        // Set message
        self.commonRequestForProtoBuf(serializeData: serialize)
    }
    /// Write Battery Installation Date and Battery Maintenance Date
    func writeDateInBLEUsingProtobuf(dateInt: Int, isInstallationDate: Bool) {
        timerGetDataFromProtobuf = Timer.scheduledTimer(timeInterval: responseTimeout, target: self, selector: #selector(protobufFailResponse), userInfo: nil, repeats: false)

        var env = Jlg_Envelope()
        env.batteryInfo = Jlg_Responses_Bms_BatteryInfo()

        if isInstallationDate {
            writeRequestType = JLGStringConstants.kBatteryInstallationDateUpdated
            env.batteryInfo.batteryInstallDate = UInt32(dateInt)
        } else {
            writeRequestType = JLGStringConstants.kBatteryMaintenanceDateUpdated
            env.batteryInfo.lastBatteryMaintDate = UInt32(dateInt)
        }
        let serialize: Data = try! env.serializedData()
        // Set message
        self.commonRequestForProtoBuf(serializeData: serialize)
    }

    @objc func protobufFailResponse() {
        self.invalidateProtobufTimer()
        responseModel = ResponseModel.init(data: nil)
        self.delegateJLGSerialScreenModel?.protobufFailResponseData(requestType: writeRequestType)
    }

    func invalidateProtobufTimer() {
        if timerGetDataFromProtobuf != nil {
            timerGetDataFromProtobuf?.invalidate()
            timerGetDataFromProtobuf = nil
        }
    }
}
