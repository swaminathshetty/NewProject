//
//  BatteryInfoModel.swift
//  JLG Control
//
//  Created by Apple on 10/03/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation

/// Binding Asset ID protobuf response
struct AssetIdModel {
    var assetID: String

    init(data: [String: Any]) {
        assetID = data["assetId"] as? String ?? ""
    }
}
/// Binding Serial Number protobuf response
struct SerialNumberModel {
    var serialNumber: String

    init(data: [String: Any]) {
        serialNumber = data["serialNumber"] as? String ?? ""
    }
}
/// Binding Battery Info protobuf response
struct BatteryInfoModel {
    var batterySoc: Int
    var batteryVoltage: Double
    var batterySize: Int?
    var batteryType: String?
    var acConnectionStatus: Bool
    var acVoltage: Int
    var chargerState: String
    var chargerAlgorithm: Int?
    var estimatedBatteryMaintPercent: Int
    var lastBatteryMaintDate: Int
    var batteryInstallDate: Int
    var chargerTimeSinceLastCharge: Int?
    var lastChargeSocReached: Int?

    init(data: [String: Any]) {
        batterySoc = data["batterySoc"] as? Int ?? 0
        batteryVoltage = data["batteryVoltage"] as? Double ?? 0.0
        batterySize = data["batterySize"] as? Int
        batteryType = data["batteryType"] as? String
        acConnectionStatus = data["acConnectionStatus"] as? Bool ?? false
        acVoltage = data["acVoltage"] as? Int ?? 0
        chargerState = data["chargerState"] as? String ?? ""
        chargerAlgorithm = data["chargerAlgorithm"] as? Int
        estimatedBatteryMaintPercent = data["estimatedBatteryMaintPercent"] as? Int ?? 0
        lastBatteryMaintDate = data["lastBatteryMaintDate"] as? Int ?? 0
        batteryInstallDate = data["batteryInstallDate"] as? Int ?? 0
        chargerTimeSinceLastCharge = data["chargerTimeSinceLastCharge"] as? Int
        lastChargeSocReached = data["lastChargeSocReached"] as? Int
    }
}
