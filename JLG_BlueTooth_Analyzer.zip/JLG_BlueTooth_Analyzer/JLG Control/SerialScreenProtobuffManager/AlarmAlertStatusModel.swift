//
//  AlarmAlertStatusModel.swift
//  JLG Control
//
//  Created by Admin on 3/24/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
/// Binding Alarm Alert Status protobuf response
struct AlarmAlertStatusModel {

    var machineAlarmActive: Bool
    var machineAlertActive: Bool

    init(data: [String: Any]) {
        machineAlarmActive = data["machineAlarmActive"] as? Bool ?? false
        machineAlertActive = data["machineAlertActive"] as? Bool ?? false
    }
}
