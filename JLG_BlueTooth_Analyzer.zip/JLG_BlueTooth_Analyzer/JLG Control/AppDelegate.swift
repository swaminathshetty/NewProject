//
//  AppDelegate.swift
//  JLG Control
//
//  Created by L&T on 16/04/18.
//  Copyright © 2018 L&T. All rights reserved.
//

import UIKit
import AVFoundation

//import Firebase
//import Fabric
//import Crashlytics

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    // MARK: - Variables and Constants
    var window: UIWindow?
    var backgroundTaskIdentifier: UIBackgroundTaskIdentifier = UIBackgroundTaskInvalid
    var backgroundTimer: Timer?
    var timerCounter: Int8 = 0

    // MARK: - App Delegate Life cycle events
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        //configureGA()
        //FirebaseApp.configure()
        //Fabric.with([Crashlytics.self])
        registerForNotifications()
        //userID = createUserID()
        //self.logUser()
        self.createLogFileForCrash()
        return true
    }

    // Callback method when app resign active mode
    func applicationWillResignActive(_ application: UIApplication) {
        print("applicationWillResignActive")
        //Analytics.logEvent("rcs_resign_active", parameters: [kUserID: userID, kTimeStamp: Date().PR2DateFormatterUTC()])
        JLGCommunicationManager.sharedInstance.stopForegroundTimer()
        backgroundTimer = Timer.scheduledTimer(timeInterval: 5, target: self, selector: #selector(update), userInfo: nil, repeats: true)
    }

    // Callback method when app enter into background mode
    func applicationDidEnterBackground(_ application: UIApplication) {
        print("applicationDidEnterBackground")
        //Analytics.logEvent("rcs_background", parameters: [kUserID: userID, kTimeStamp: Date().PR2DateFormatterUTC()])
        JLGCommunicationManager.sharedInstance.restAllRemServiceValues()
        JLGCommunicationManager.sharedInstance.resetAllCommands()
        backgroundTaskIdentifier = UIApplication.shared.beginBackgroundTask { [weak self] in
            self?.stopBackgroundTimer()
        }
        if backgroundTimer == nil {
            backgroundTimer = Timer.scheduledTimer(timeInterval: 5, target: self, selector: #selector(update), userInfo: nil, repeats: true)
        }
    }

    // Callback method when app enter into foreground mode
    func applicationWillEnterForeground(_ application: UIApplication) {
        print("applicationWillEnterForeground")
        //Analytics.logEvent("rcs_foreground", parameters: [kUserID: userID, kTimeStamp: Date().PR2DateFormatterUTC()])
        stopBackgroundTimer()
        startForegroundTimerIfRequired()
    }

    // Callback method when app become active
    func applicationDidBecomeActive(_ application: UIApplication) {
        print("applicationDidBecomeActive")
        //Analytics.logEvent("rcs_become_active", parameters: [kUserID: userID, kTimeStamp: Date().PR2DateFormatterUTC()])
        stopBackgroundTimer()
        startForegroundTimerIfRequired()
    }

    // Callback method when app about to terminate
    func applicationWillTerminate(_ application: UIApplication) {
        print("applicationWillTerminate")
        //Analytics.logEvent("rcs_terminate", parameters: [kUserID: userID, kTimeStamp: Date().PR2DateFormatterUTC()])

        /// Stop background timer, reset all values (Drive, Steer, Lift) and disconnect BLE
        stopBackgroundTimer()
        JLGCommunicationManager.sharedInstance.restAllRemServiceValues()
        JLGCommunicationManager.sharedInstance.resetAllCommands()
        JLGBLEManager.sharedInstance.disconnectFromPeripheral()
    }

    // MARK: - Custom Methods
    /// Create unique id for every new installation with date and time
    /*func createUserID() -> String {
        var userID = UserDefaults.standard.value(forKey: "UserID") as? String ?? ""
        if userID == "" {
            userID = "rcs_user_" + Date().PR2DateFormatterUTC()
            UserDefaults.standard.set(userID, forKey: "UserID")
            UserDefaults.standard.synchronize()
            return userID
        } else {
            return userID
        }
    }
    
    /// Set user id in crashlytics
    func logUser() {
        //Crashlytics.sharedInstance().setUserIdentifier(userID)
    }*/

    /// Set up Google Analytics
    func configureGA() {
        guard let gai = GAI.sharedInstance() else {
            assert(false, "Google Analytics is not configured correctly.")
            return
        }
        gai.tracker(withTrackingId: JLGStringConstants.kAnalyticsTrackingID)
        gai.dispatchInterval = 20
        gai.trackUncaughtExceptions = true
        gai.logger.logLevel = .verbose
    }

    /// Registered for notification for any AVAudioSessionInterruption handling
    func registerForNotifications() {
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(handleInterruption),
                                               name: .AVAudioSessionInterruption,
                                               object: AVAudioSession.sharedInstance())
    }

    @objc func handleInterruption(_ notification: Notification) {
        guard let info = notification.userInfo,
            let typeValue = info[AVAudioSessionInterruptionTypeKey] as? UInt,
            let _ = AVAudioSessionInterruptionType(rawValue: typeValue) else {
                return
        }
    }

    /// Check for 5 minutes timeout and take appropriate action
    @objc func update() {
        timerCounter += 1
        //print("Background timerCounter: \(timerCounter)")
        if timerCounter >= 60 {
            DispatchQueue.main.async {
                //Analytics.logEvent("rcs_session_timeout_background", parameters: [kUserID: userID, kTimeStamp: Date().PR2DateFormatterUTC()])

                isTimeExceed5Minutes = true
                JLGBLEManager.sharedInstance.stopScanning()
                if isDisconnectedBLE || isDeviceBluetoothOff {
                    NotificationCenter.default.post(name: .notificationIdentifierForAppRouteToScanVC, object: nil)
                } else if isJLGBMSSerialScreenViewControllerOpen {
                    NotificationCenter.default.post(name: .notificationIdentifierForSerialScreenDisconnectBLE, object: nil)
                    NotificationCenter.default.post(name: .notificationIdentifierForAppRouteToMainHomeVC, object: nil)
                } else {
                    JLGBLEManager.sharedInstance.disconnectFromPeripheral()
                }
                self.stopBackgroundTimer()
            }
        } else {
            JLGCommunicationManager.sharedInstance.getModuleInformationValue()
        }
    }

    /// Stop background task
    func stopBackgroundTimer() {
        timerCounter = 0
        let app: UIApplication = UIApplication.shared
        app.endBackgroundTask(self.backgroundTaskIdentifier)
        if self.backgroundTimer != nil {
            self.backgroundTimer?.invalidate()
            self.backgroundTimer = nil
        }
    }

    /// Start foreground timer if required
    func startForegroundTimerIfRequired() {
        if JLGCommunicationManager.sharedInstance.shouldStartForegroungTimer {
            JLGCommunicationManager.sharedInstance.stopForegroundTimer()
            JLGCommunicationManager.sharedInstance.startForegroundTimer()
        }
    }

    /// Capture log if any crash happen in release mode
    func createLogFileForCrash() {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentsDirectory = paths[0]
        let fileName = JLGStringConstants.kLogFileName
        let logFilePath = (documentsDirectory as NSString).appendingPathComponent(fileName)
        freopen(logFilePath.cString(using: String.Encoding.ascii)!, "a+", stderr)
        self.addApplicationVersion()
    }
    
    func addApplicationVersion() {
        /// Get version number of ios app
        var appVersion = ""
        var appBuild = ""
        if let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String {
            appVersion = version + kBetaVersion
        }

        /// Get build number of ios app
        if let build = Bundle.main.infoDictionary?["CFBundleVersion"] as? String {
            appBuild = build
        }

        appendLog(text: "\(Date()): Application version --> \(appVersion) and build no. \(appBuild)")
    }
}
