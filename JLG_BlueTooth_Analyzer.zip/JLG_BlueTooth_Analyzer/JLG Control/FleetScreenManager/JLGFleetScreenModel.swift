//
//  JLGFleetScreenModel.swift
//  JLG Control
//
//  Created by Apple on 16/12/19.
//  Copyright © 2019 L&T. All rights reserved.
//

import Foundation
protocol JLGFleetScreenModelDelegate: class {
    func didUpdateJLGFleetScreenModel()
}

/// Class make @objc and @objc dynamic because we are using KOV and KVC in this class
@objc class JLGFleetScreenModel: NSObject {
    var delegateJLGFleetScreenModel: JLGFleetScreenModelDelegate?

    @objc dynamic var assetId1: String = ""
    @objc dynamic var assetId2: String = ""
    //@objc dynamic var machineType: String = ""
    @objc dynamic var machineModel: String = ""
    @objc dynamic var energyStorage: String = ""
    @objc dynamic var isConnectedWithACPower: String = JLGStringConstants.kUnknownText
    //@objc dynamic var isWaringActive = false
    @objc dynamic var isAlertAlarmActive = false
    @objc dynamic var batteryPercentage: String = JLGStringConstants.kUnknownText
    @objc dynamic var machineSn: String = ""

    /// For creating dummy data
    init(assetId1: String, assetId2: String, machineModel: String, isConnectedWithACPower: String, isAlertAlarmActive: Bool, batteryPercentage: String) {
        self.assetId1 = assetId1
        self.assetId2 = assetId2
        self.machineModel = machineModel
        self.isConnectedWithACPower = isConnectedWithACPower
        self.isAlertAlarmActive = isAlertAlarmActive
        self.batteryPercentage = batteryPercentage
    }

    init(manufacturerData: Data) {
        super.init()
        /// Check the current peripheral information is available in peripheralsInfo array
        self.updatePeripheralsInfoData(dataObject: manufacturerData, objectOfJLGFleetScreenModel: nil)
    }

    func getStringFrom(dataObject: Data) -> String {
        let manufacturerStr: String = String(data: dataObject, encoding: .ascii) ?? ""
        return manufacturerStr.substringFromTo(from: 1, to: 14)
    }

    /// Add or update the Peripheral information base on UInt8 value
    func updatePeripheralsInfoData (dataObject: Data, objectOfJLGFleetScreenModel: JLGFleetScreenModel?) {
        let uInt8Array: [UInt8] = JLGIntByteConverter.dataBytesArrayToUInt8ArrayConverter(data: dataObject)
        //print ("uInt8Array --> \(uInt8Array)")

        if uInt8Array.count > 13 {
            let ObjectUInt8: UInt8 = uInt8Array[2]
            switch ObjectUInt8 {
            /// Get Alarm Alert status
            case 0:
                appendLog(text: "\(Date()): Topic (Upper Nibble) and Application (Lower Nibble) -> 00 --> \(uInt8Array)")
                let checkAlarmAlert = self.parseAlarmAlertWarningStatus(byte: uInt8Array[4])
                self.setValue(forKey: ["isAlertAlarmActive"], getValue: [checkAlarmAlert], selfClassObject: objectOfJLGFleetScreenModel)

            /// Get the machine type
            case 1:
            appendLog(text: "\(Date()): Topic (Upper Nibble) and Application (Lower Nibble) -> 01 --> \(uInt8Array)")
            let jlgMachineModelParser = JLGMachineModelParser()
            let modelNumber = jlgMachineModelParser.parseCanVenType(byte: uInt8Array[6], mByte: uInt8Array[7])
            self.setValue(forKey: ["machineModel"], getValue: [modelNumber], selfClassObject: objectOfJLGFleetScreenModel)

            /// Get the Machine SN
            case 2:
            appendLog(text: "\(Date()): Topic (Upper Nibble) and Application (Lower Nibble) -> 02 --> \(uInt8Array)")
            let getString = self.getStringFrom(dataObject: dataObject)
            self.setValue(forKey: ["machineSn"], getValue: [getString], selfClassObject: objectOfJLGFleetScreenModel)

            /// Get the asset ID 1
            case 3:
            appendLog(text: "\(Date()): Topic (Upper Nibble) and Application (Lower Nibble) -> 03 --> \(uInt8Array)")
            let getString = self.getStringFrom(dataObject: dataObject)
            self.setValue(forKey: ["assetId1"], getValue: [getString], selfClassObject: objectOfJLGFleetScreenModel)

            /// Get the asset ID 2
            case 4:
            appendLog(text: "\(Date()): Topic (Upper Nibble) and Application (Lower Nibble) -> 04 --> \(uInt8Array)")
            let getString = self.getStringFrom(dataObject: dataObject)
            self.setValue(forKey: ["assetId2"], getValue: [getString], selfClassObject: objectOfJLGFleetScreenModel)

            case 16:
                appendLog(text: "\(Date()): Topic (Upper Nibble) and Application (Lower Nibble) -> 10 --> \(uInt8Array)")
                /// Get AC Input status
                // print("uInt8Array --> \(uInt8Array)")
                var checkPowerSupply = self.parseACInputStatus(byte: uInt8Array[10])
                /// Check if AC voltage less than 80
                if checkPowerSupply != JLGStringConstants.kDisconnectPlug {
                    let vacValue = Int(uInt8Array[11]) * 2
                    appendLog(text: "\(Date()): VAC actual Value \(Int(uInt8Array[11])) and multiply value  \(vacValue) plug value \(JLGStringConstants.kConnectPlug)")

                    if (80...270).contains(vacValue) && checkPowerSupply == JLGStringConstants.kConnectPlug {
                        checkPowerSupply = JLGStringConstants.kConnectPlug
                    } else {
                        checkPowerSupply = JLGStringConstants.kPlugConnectedWarning
                    }
                }

                /// Get Warning status
                /// Remove this check
                //let checkWarning = self.parseAlarmAlertWarningStatus(byte: uInt8Array[4])

                /// Get Battery SOC
                var uInt8String: String = String(uInt8Array[5])

                /// Battery in voltage
                /// If Battery is UInt8 value is 255 then it convert into voltage
                if uInt8Array[5] == 255 {
                    let byte3 = String(fullBinary: uInt8Array[6]).suffix(8)
                    let byte4 = String(fullBinary: uInt8Array[7]).suffix(8)
                    let concatStr = "\(byte4)\(byte3)"
                    let getIntValue = self.getValueFromBinaryString(binaryString: concatStr)
                    let volt: Double = Double(getIntValue) * 0.1
                    uInt8String = String(String(volt).prefix(4))
                }

                self.setValue(forKey: ["isConnectedWithACPower", "batteryPercentage"], getValue: [checkPowerSupply, uInt8String], selfClassObject: objectOfJLGFleetScreenModel)

            default:
                break
            }
        }
    }

    /// Set the value to particular object
    func setValue(forKey: [String], getValue: [Any], selfClassObject: JLGFleetScreenModel?) {
        var index = 0
        if let classObject = selfClassObject {
            var isChangeVal = false
            while index<forKey.count {
                /// Change String Value
                if let setValueStr = getValue[index] as? String {
                    let getObjectValue = classObject.value(forKey: forKey[index]) as! String
                    if getObjectValue != setValueStr {
                        classObject.setValue(setValueStr, forKey: forKey[index])
                        isChangeVal = true
                    }
                }
                /// Change Bool Value
                if let setValueBool = getValue[index] as? Bool {
                    let getObjectValue = classObject.value(forKey: forKey[index]) as! Bool
                    if getObjectValue != setValueBool {
                        classObject.setValue(setValueBool, forKey: forKey[index])
                        isChangeVal = true
                    }
                }

                if (index+1 == forKey.count) && isChangeVal {
                    self.delegateJLGFleetScreenModel?.didUpdateJLGFleetScreenModel()
                }

                index+=1
            }

            return
        }

        while index<forKey.count {
            self.setValue(getValue[index], forKey: forKey[index])
            index+=1
        }
    }

    /// Get the value form binary string
    private func getValueFromBinaryString(binaryString: String) -> Int {
        let requiredValue = Int(binaryString, radix: 2) ?? 255
        return requiredValue
    }

}

/// Dummy Values
// for 01 = [83, 7, 1, 0, 255, 255, 255, 02, 255, 255, 0, 0, 0, 0, 80, 72, 57, 48, 50, 51, 54, 49, 49, 57, 44, 50, 48, 48, 56, 52, 48, 44]
// for 16 = [83, 7, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 80, 72, 57, 48, 50, 51, 54, 49, 49, 57, 44, 50, 48, 48, 56, 50, 50, 44]
//for 16 Battery volt = [83, 7, 16, 0, 255, 255, 1, 2, 3, 255, 0, 0, 0, 0, 80, 72, 57, 48, 50, 51, 54, 49, 49, 57, 44, 50, 48, 48, 48, 49, 52, 44]
// for 01 = [83, 7, 1, 0, 255, 255, 1, 2, 3, 255, 0, 0, 0, 0, 80, 72, 57, 48, 50, 51, 54, 49, 49, 57, 44, 50, 48, 48, 56, 48, 49, 44, 48, 48, 50, 48, 48, 48, 48, 50]
