//
//  JLGMachineModelParser.swift
//  JLG Control
//
//  Created by Admin on 5/5/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit
import Foundation

class JLGMachineModelParser {
    /// Retrieve model number
    func parseCanVenTypeName(byte: UInt8) -> CanVenType {
        switch byte {
        case 00 : return .model0
        case 01 : return .model1
        case 02 : return .model2
        case 03 : return .model3
        case 04 : return .model4
        case 05 : return .model5
        case 06 : return .model6
        case 07 : return .model7
        case 08 : return .model8
        case 09 : return .model9
        case 10 : return .model10
        case 11 : return .model11
        default: return .other
        }
    }

    func parseCanVenType(byte: UInt8, mByte: UInt8) -> String {
        switch byte {
        case 00: return self.parseCanVenModel_ElectricScissor(modelByte: mByte).rawValue
        case 01: return self.parseCanVenModel_EngineScissor(modelByte: mByte).rawValue
        case 02: return self.parseCanVenModel_AllElectricScissor(modelByte: mByte).rawValue
        default: return ""
        }
    }

    private func parseCanVenModel_ElectricScissor(modelByte: UInt8) -> CanVenModelElectricScissor {
        // #lizard forgives the complexity        
        switch modelByte {
        case 00: return .model0
        case 01: return .model1
        case 02: return .model2
        case 03: return .model3
        case 04: return .model4
        case 05: return .model5
        case 06: return .model6
        case 07: return .model7
        case 08: return .model8
        case 09: return .model9
        case 10: return .model10
        case 11: return .model11
        case 12: return .model12
        case 13: return .model13
        case 14: return .model14
        case 15: return .model15
        case 16: return .model16
        case 17: return .model17
        case 18: return .model18
        case 19: return .model19
        case 20: return .model20
        case 21: return .model21
        case 22: return .model22
        case 23: return .model23
        case 24: return .model24
        case 25: return .model25
        case 26: return .model26
        case 27: return .model27
        case 28: return .model28
        case 29: return .model29
        default: return .other
        }
    }

    private func parseCanVenModel_EngineScissor(modelByte: UInt8) -> CanVenModelEngineScissor {
        switch modelByte {
        case 00: return .model0
        case 01: return .model1
        case 02: return .model2
        case 03: return .model3
        case 04: return .model4
        case 05: return .model5
        default: return .other
        }
    }

    private func parseCanVenModel_AllElectricScissor(modelByte: UInt8) -> CanVenModelAllElectricScissor {
        switch modelByte {
        case 00: return .model0
        case 01: return .model1
        case 02: return .model2
        case 03: return .model3
        default: return .other
        }
    }
}
