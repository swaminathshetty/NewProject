//
//  JLGFleetScreenParserFunctions.swift
//  JLG Control
//
//  Created by Apple on 29/01/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation

/// For the UInt8 16 or 10
extension JLGFleetScreenModel {
//    func parseACInputStatus(byte: UInt8) -> Bool {
//        switch byte {
//        case 01: return true
//        default: return false
//        }
//    }
//    func parseAlarmAlertWarningStatus(byte: UInt8) -> Bool {
//        switch byte {
//        case 01, 02, 04, 08: return true
//        default: return false
//        }
//    }

    // Check Alarm Alert Warning Status
    func parseAlarmAlertWarningStatus(byte: UInt8) -> Bool {
        let bitsArray = JLGIntByteConverter.bitsFrom(byte)
        let lastBit = bitsArray [bitsArray.endIndex - 1]
        let secondLastBit = bitsArray [bitsArray.endIndex - 2]

        if lastBit.rawValue == 1 || secondLastBit.rawValue == 1 {
            return true
        }
        
        return false
//        switch byte {
//        case 00: return false
//        default: return true
//        }
    }

    /// Check AC Input Status
    func parseACInputStatus(byte: UInt8) -> String {
        switch byte {
        case 00: return JLGStringConstants.kDisconnectPlug
        case 01: return JLGStringConstants.kConnectPlug
        default: return JLGStringConstants.kPlugConnectedWarning
        }
    }
}
