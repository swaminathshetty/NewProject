//
//  JLGEnumeration.swift
//  JLG Control
//
//  Created by Apple on 29/01/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation

/// CanVenType
enum CanVenType: String {
    case model0 = "Electric Scissor"
    case model1 = "Engine Scissor"
    case model2 = "AllElectricScissor"
    case model3 = "Electric Boom"
    case model4 = "Engine Boom"
    case model5 = "Hybrid Boom"
    case model7 = "Engine Telehandler"
    case model6, model8, model10, model11 = "Reserved"
    case model9 = "Electric Vertical"
    case other = ""
}

/// CanVenModel Electric Scissor
enum CanVenModelElectricScissor: String {
    case model0 = "No Model"
    case model1 = "Unknown"
    case model2 = "1532R"
    case model3 = "1932R"
    case model4 = "R2632"
    case model5 = "R3246"
    case model6 = "R4045"
    case model7 = "ERT2669"
    case model8 = "ERT3369"
    case model9 = "ERT4069"
    case model10 = "ERT4769"
    case model11 = "R1532i"
    case model12 = "R1932i"
    case model13 = "R1932"
    case model14 = "ES1330L"
    case model15 = "ES1530L"
    case model16 = "1230ES"
    case model17 = "1930ES"
    case model18 = "2032ES"
    case model19 = "2632ES"
    case model20 = "2646ES"
    case model21 = "3246ES"
    case model22 = "ES1532"
    case model23 = "ES1532i"
    case model24 = "ES1932"
    case model25 = "ES1932i"
    case model26 = "ES2632"
    case model27 = "ES3246"
    case model28 = "ES4045"
    case model29 = "ES1530LC"
    case other = ""
}

/// CanVenModel Engine Scissor
enum CanVenModelEngineScissor: String {
    case model0 = "No Model"
    case model1 = "Unknown"
    case model2 = "RT2669"
    case model3 = "RT3369"
    case model4 = "RT4069"
    case model5 = "RT4769"
    case other = ""
}

/// CanVenModel All Electric Scissor
enum CanVenModelAllElectricScissor: String {
    case model0 = "No Model"
    case model1 = "Unknown"
    case model2 = "AE1932"
    case model3 = "AE1230"
    case other = ""
}

/// Protobuf Enum
enum ProtobufRequestType: String {
    case bmsBatteryInfo = "battery_info"
    case bmsHistory = "battery_history"
    case bmsEsrInfo = "esr_info"
    case bmsAlerts = "bms_alerts"
    case diagDtcList = "dtc_list"
    case diagChargerFaultList = "charger_fault_list"
    case infoSerialNumber, infoAssetID = "machine_info"
    case alarmAlertStatus = "alarm_alert_status"
    case serviceConnect = "service_connect"
    case analyzerMessage_start = "analyzer_message_start"
    case analyzerMessage_stop = "analyzer_message_stop"
    case analyzerMessage_enter = "analyzer_message_enter"
    case analyzerMessage_escape = "analyzer_message_escape"
    case analyzerMessage_up = "analyzer_message_up"
    case analyzerMessage_right = "analyzer_message_right"
    case analyzerMessage_down = "analyzer_message_down"
    case analyzerMessage_left = "analyzer_message_left"
}
