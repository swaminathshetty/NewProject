//
//  JLGCommunicationManager.swift
//  JLG Control
//
//  Created by L&T on 19/04/18.
//  Copyright © 2018 L&T. All rights reserved.
//

import UIKit
import CoreBluetooth
//import Firebase
import CryptoSwift

/// Horn enum
enum BtCanHornEnableEnum: UInt8 {
    case Low = 0
    case High = 1
}

/// Tourque enum
enum BtCanHiLoTorqueEnum: UInt8 {
    case Low = 0
    case High = 1
}

/// Remote init enum
enum BtCanRemoreInitEnum: UInt8 {
    case Stop = 0
    case Start = 1
}

/// Remote stop enum
enum BtCanRemStopEnum: UInt8 {
    case Start = 0
    case Stop = 1
}

/// Remote E stop enum
enum BtCanRemEStopEnum: UInt8 {
    case Start = 0
    case Stop = 1
}

/// Drive, Steer, Lift struct
struct BtCanRem_Drive_Steer_Lift_Values {
    var drive: Int8 = 0
    var steer: Int8 = 0
    var lift: Int8 = 0
}

/// Analog input voltage status struct
struct BtAnalogInputVotageStatus {
    var GPIO1: UInt16
    var GPIO2: UInt16

    init() {
        GPIO1 = 0
        GPIO2 = 0
    }
}

/// Remote status struct
struct BtRemStatus {
    var btControlSystemReady: UInt8
    var btCommandTimeout: UInt8
    var btRemCommTimeout: UInt8
    var btHiLoTorqueStatus: UInt8
    var btRemDriveStatus: Int8
    var btRemSteerStatus: Int8
    var btRemLiftStatus: Int8
    var btGroundMode: UInt8
    var btStowed: UInt8
    var btVehicleCharging: UInt8
    var btVehicleSafeMode: UInt8

    init() {
        btControlSystemReady = 0
        btCommandTimeout = 0
        btRemCommTimeout = 0
        btHiLoTorqueStatus = 0
        btRemDriveStatus = 0
        btRemSteerStatus = 0
        btRemLiftStatus = 0
        btGroundMode = 0
        btStowed = 0
        btVehicleCharging = 1
        btVehicleSafeMode = 0
    }
}

// MARK: - JLGCommunicationManager class
/// This singleton class is design to communicate between mobile and can2ble device
class JLGCommunicationManager: NSObject {

    // MARK: - Variables and constants
    static let sharedInstance = JLGCommunicationManager()
    public var moduleInformation: JLGModuleInformationModel!

    var driveValue: Int8 = 0
    var steerValue: Int8 = 0
    var liftValue: Int8 = 0

    var driveOldValue: Int8 = 0
    var steerOldValue: Int8 = 0

    var btRemStopCommandSent: Bool = false
    var btRemEStopCommandSent: Bool = false

    var btRemoteInitValue: BtCanRemoreInitEnum = .Stop

    var btWatchdogValue: Int = 0
    var isWatchdogResponseReceived = true

    var btHornEnableValue: BtCanHornEnableEnum = .Low
    var btHiLoTorqueValue: BtCanHiLoTorqueEnum = .Low

    var btCanRemStopEnum: BtCanRemStopEnum = .Start
    var btCanRemEStopEnum: BtCanRemEStopEnum = .Start

    var btRemStatus: BtRemStatus = BtRemStatus()
    var btAnalogInputVoltage: BtAnalogInputVotageStatus = BtAnalogInputVotageStatus()

    var shouldConfigureMachineDecal = false
    var authFressnessValue: UInt32 = 0

    var isVehicleIsNotStowed = false
    //var shouldDisableDrive = false
    var showTimeOutAlert: Bool = false
    var batteryPercentageValue: UInt8 = 0
    var warningIndicatorValue: UInt8 = 0
    var vehicleBLEVersion = ""
    var vehicleGIVersion = ""
    var foregroundTimer: Timer?
    var foregroundTimerCounter: Int = 0
    var shouldStartForegroungTimer = false
    var authenticationValue: UInt8 = 0
    var authenticationTimer: Timer?
    var otaReprogrammingStatus = ""

    let sharedSecretKey = [UInt8](hex: "0x41E5B91946BBF9B1FA5C56994F2FB373") ///[65, 229, 185, 25, 70, 187, 249, 177, 250, 92, 86, 153, 79, 47, 179, 115]

    // MARK: - Custom methods
    /// Initialize model
    override init() {
        super.init()
        moduleInformation =  JLGModuleInformationModel(batteryVoltage: 0, digitalInputState: 0, analogInputVoltages: 0, canVoltages: 0, temperature: 0)!
    }

    /// To fetch the complete module information
    func getModuleInformationValue() {
        readBatteryVoltage()
        readDigital_Input_State()
        readAnalog_Input_voltages()
        readCAN_Voltages()
        readTemperature()
    }

    /// Read Battery Voltage Characteristic
    func readBatteryVoltage() {
        JLGBLEManager.sharedInstance.readData(charUUID: kBatteryVoltageCharacteristicsUUID)
    }
    /// Read Digital Input State Characteristic
    func readDigital_Input_State() {
        JLGBLEManager.sharedInstance.readData(charUUID: kDigitalInputStateCharacteristicsUUID)
    }
    /// Read Analog Input voltages Characteristic
    func readAnalog_Input_voltages() {
        JLGBLEManager.sharedInstance.readData(charUUID: kAnalogInputvoltagesCharacteristicsUUID)
    }
    /// Read CAN Voltages Characteristic
    func readCAN_Voltages() {
        JLGBLEManager.sharedInstance.readData(charUUID: kCANVoltagesCharacteristicsUUID)
    }
    /// Read Temperature Characteristic
    func readTemperature() {
        JLGBLEManager.sharedInstance.readData(charUUID: kTemperatureCharacteristicsUUID)
    }

    /// To fetch the information while after connected to can2ble
    func getServiceConnectValue() {
        readBtVehHwVersion()
    }

    /// Read Vehicle Hardware Version Characteristic
    func readBtVehHwVersion() {
        JLGBLEManager.sharedInstance.readData(charUUID: kBtVehHwVersionCharacteristicUUID)
    }

    func didDisconnectPeripheral(fromPeripheral: CBPeripheral) {
        restAllRemServiceValues()
        if isTimeExceed5Minutes {
            NotificationCenter.default.post(name: .notificationIdentifierForAppRouteToScanVC, object: nil)
        }
    }

    // MARK: - Notification received from CAN2BLE
    /// If any characteristic have update the value or write callback comes then recievedDataFromBLEModule will be get called
    func recievedDataFromBLEModule(updatedCharacteristic: CBCharacteristic) {
        // #lizard forgives the complexity

        let data = updatedCharacteristic.value
        if data == nil {
            return
        }

        switch updatedCharacteristic.uuid.uuidString {
        case kProtobufStreamUUID : do {

            //========================
            do {
                var serializeDataArray: [UInt8] =  JLGIntByteConverter.dataBytesArrayToUInt8ArrayConverter(data: data!)
                //print("Response Data --> \(serializeDataArray)")
                appendLog(text: "\(Date()): Protobuf Response Serialize Data --> \(serializeDataArray)")
                print("Protobuf Response Serialize Data --> \(serializeDataArray)")
                if serializeDataArray.count - 2 != Int(serializeDataArray[0]) {
                    hideLoadingIndicator()
                    NotificationCenter.default.post(name: .notificationIdentifierForProtobufMissMatchArray, object: nil)
                    return
                }

                serializeDataArray.remove(at: 0)
                serializeDataArray.remove(at: 0)
                //print("Response Data after removing first two bytes--> \(serializeDataArray)")
                ///=========Comment Below code for create dummy============
                let intByteConvert = JLGIntByteConverter.uInt8arrayToDataConverter(valueArray: serializeDataArray)
                let decodedInfo = try Jlg_Envelope(serializedData: intByteConvert)
                if decodedInfo.analyzerMessage.hasAnalyzerData {
                    JLGSerialScreenModel.sharedInstance.parseProtobufBluetoothAnalyzerResponse(data: decodedInfo.analyzerMessage)
                    print("decodedInfo \(decodedInfo.analyzerMessage)")

                } else {
                    let jsonString = try decodedInfo.jsonString()
                    let data = Data(jsonString.utf8)
                    print("decodedInfo Print  \(decodedInfo)")
                    appendLog(text: "\(Date()): Protobuf Response Decoded Info --> \(decodedInfo)")
                    JLGSerialScreenModel.sharedInstance.parseProtobufResponse(dataValue: data)
                }
                ///====================================================

                ///==========Create Dummy For Serial Screen=============
//                for stringData in createSerialScreenDummyData() {
//                    self.createSerialScreenDummyDataForTesting(stringData: stringData)
//                }
                ///===================================
                ///==========Create Dummy For Bluetooth Analyzer=============
//                self.createDummyDataForBluetoothAnalyzer()
                ///===================================

            } catch {
                print("Error in Serialization")
            }

            //=======================
            }

        /// OTA Reprogramming Data Stream notification
        case kOTAReprogrammingDataStreamCharacteristicUUID: do {
            let asciiString = String(data: data!, encoding: String.Encoding.ascii)
            otaReprogrammingStatus = asciiString ?? ""
            NotificationCenter.default.post(name: .notificationIdentifierForOTAReprogramming, object: nil)
            }

        /// Remote init notification
        case kBtRemoteInitCharacteristicsUUID: do {
            let number = JLGIntByteConverter.dataToUInt8Converter(data: (data)!)
            print("Remote init received: \(number)")

            if number == 0 {
                //Analytics.logEvent("rcs_received_bt_remote_init", parameters: [kUserID: userID, kTimeStamp: Date().PR2DateFormatterUTC(), kValue: String(number)])
                NotificationCenter.default.post(name: .notificationIdentifierForExitRemoteMode, object: nil)
            }
            }

        /// Remote status notification
        case kBtRemStatusCharacteristicsUUID: do {
            btRemStatus = JLGIntByteConverter.dataBytesArrayToMixTypeArrayConverter(data: data!)
            print("Remote status recieved: \(btRemStatus)")
            NotificationCenter.default.post(name: .notificationIdentifierForRemoteStatus, object: nil)

            /// Timeout notification
            if btRemStatus.btCommandTimeout == 1 {
                //Analytics.logEvent("rcs_received_bt_command_timeout", parameters: [kUserID: userID, kTimeStamp: Date().PR2DateFormatterUTC(), kValue: String(btRemStatus.btCommandTimeout)])
            }
            }

        /// Firmware revision notification
        case kFirmwareRevisionCharacteristicsUUID: do {
            let asciiString = String(data: data!, encoding: String.Encoding.ascii)
            print("Firmware revision string (BLE Version) received: \(String(describing: asciiString))")
            appendLog(text: "\(Date()): Firmware revision string (BLE Version) received: \(String(describing: asciiString))")

            let vehicleBLEVersionFull = asciiString ?? ""
            /// Setting the vehicle BLE version as App
            if let range = vehicleBLEVersionFull.range(of: ",Bootloader") {
                let firstPart = String(vehicleBLEVersionFull[vehicleBLEVersionFull.startIndex..<range.lowerBound])
                vehicleBLEVersion = firstPart.chopPrefix(5)
                /// Setting the vehicle BLE version as GI (Golden Image)
                vehicleGIVersion = String(vehicleBLEVersionFull.suffix(4))
            }
            }

        /// Warning notification
        case kBtWarningIndicatorCharacteristicUUID: do {
            let number = JLGIntByteConverter.dataToUInt8Converter(data: (data)!)
            print("Warning recieved: \(number)")
            warningIndicatorValue = number
            if number == 1 {
                //Analytics.logEvent("rcs_received_bt_warning", parameters: [kUserID: userID, kTimeStamp: Date().PR2DateFormatterUTC(), kValue: String(number)])
            }
            NotificationCenter.default.post(name: .notificationIdentifierForWarningStatus, object: number)
            }

        /// Battery status received
        case kBtBatteryStatusCharacteristicUUID: do {
            let number = JLGIntByteConverter.dataToUInt8Converter(data: (data)!)
            print("Battery status recieved: \(number)")
            batteryPercentageValue = number
            NotificationCenter.default.post(name: .notificationIdentifierForBatteryStatus, object: number)
            }

        /// Vehicle hardware version notification
        case kBtVehHwVersionCharacteristicUUID: do {
            /// Future Use
            //let asciiString = String(data: data!, encoding: String.Encoding.ascii)
            //print("Vehicle hardware version string received: \(String(describing: asciiString))")
            }

        /// Vehicle horn enable notification
        case kBtHornEnableCharacteristicsUUID: do {
            /// Future use
            //let number = JLGIntByteConverter.dataToUInt8Converter(data: (data)!)
            //print("Horn Enable Recieved: \(number)");
            }

        /// Vehicle torque notification
        case kBtHiLoTorqueCharacteristicsUUID: do {
            let number = JLGIntByteConverter.dataToUInt8Converter(data: (data)!)
            print("Vehicle torque recieved: \(number)")
            btHiLoTorqueValue = (number == 0) ? .Low : .High
            }

        /// Watchdog notification
        case kBtWatchdogCharacteristicsUUID: do {
            return
            /// Future use
            //let number = JLGIntByteConverter.dataToUInt8Converter(data: (data)!)
            //print("Watchdog data acknowledgement recieved: \(number)");
            }

        /// Remote drive notification
        case kBtRemDriveCharacteristicsUUID: do {
            /// Future use
            //let number = JLGIntByteConverter.dataToInt8Converter(data: (data)!)
            //print("Remote drive acknowledgement recieved: \(number)");
            }

        /// Remote steer notification
        case kBtRemSteerCharacteristicsUUID: do {
            /// Future use
            //let number = JLGIntByteConverter.dataToInt8Converter(data: (data)!)
            //print("Remote steer acknowledgement recieved: \(number)");
            }

        /// Battery voltage notification
        case kBatteryVoltageCharacteristicsUUID: do {
            let number = JLGIntByteConverter.dataToUInt16Converter(data: (data)!)
            print("Battery voltage recieved: \(number)")
            self.moduleInformation.batteryVoltage = number
            }

        /// Digital input state notification
        case kDigitalInputStateCharacteristicsUUID: do {
            self.moduleInformation.digitalInputState = 0
            }

        /// Analog input voltage notification
        case kAnalogInputvoltagesCharacteristicsUUID: do {
            btAnalogInputVoltage = JLGIntByteConverter.dataBytesArrayToAnalogInputVoltageConverter(data: data!)
            }

        /// CAN voltage received
        case kCANVoltagesCharacteristicsUUID: do {
            self.moduleInformation.canVoltages = 0
            }

        /// Temperature notification
        case kTemperatureCharacteristicsUUID: do {
            let number = JLGIntByteConverter.dataToInt8Converter(data: (data)!)
            self.moduleInformation.temperature = number
            }

        /// Fuel level received
        case kBtFuelLevelCharacteristicUUID: do {
            /// Future use
            //let number = JLGIntByteConverter.dataToUInt8Converter(data: (data)!)
            //print("Fuel level recieved: \(number)");
            }

        /// Auth freshnes notification
        case kBtAuthFreshnesCharacteristicsUUID: do {
            authFressnessValue = JLGIntByteConverter.dataToUInt32Converter(data: (data)!)
            if authFressnessValue != 0 && !shouldConfigureMachineDecal {
                authenticationCommand(btAuthFreshness: authFressnessValue)
            }
            print("Auth freshnes received: \(authFressnessValue)")
            }

        /// Auth pin notification
        case kBtAuthPinCharacteristicsUUID: do {
            let number = JLGIntByteConverter.dataToUInt32Converter(data: (data)!)
            print("Auth pin received: \(number)")
            }

        /// Authenticated notification
        case kBtAuthenticatedCharacteristicsUUID: do {
            invalidateAuthenticationTimer()
            let number = JLGIntByteConverter.dataToUInt8Converter(data: (data)!)
            print("Authenticated value received: \(number)")
            authenticationValue = number
            if authenticationValue == 1 {
                generateSessionKey()
            }
            NotificationCenter.default.post(name: .notificationIdentifierForAuthentication, object: nil)
            }

        default: do {
            return
            }
        }
    }

    // MARK: - Authentication Timer
    func invalidateAuthenticationTimer() {
        if authenticationTimer != nil {
            authenticationTimer?.invalidate()
            authenticationTimer = nil
        }
    }

    // MARK: - Athentication timer expire
    @objc func authenticationTimerExpire() {
        authenticationValue = 0
        NotificationCenter.default.post(name: .notificationIdentifierForAuthentication, object: nil)
    }

    // MARK: - Write data into BLE
    /// Authentication (btAuthSignature)
    func authenticationCommand(btAuthFreshness: UInt32) {
        /// Convert btAuthFreshness UInt32 -> HexaDecimal -> [UInt8]
        let btAuthFreshnessDecimal = btAuthFreshness
        let btAuthFreshnessHexString = String(format: "%02X", btAuthFreshnessDecimal) // 12345678
        var btAuthFreshnessArray = [UInt8](hex: btAuthFreshnessHexString) // [18, 52, 86, 120]
        if btAuthFreshnessArray.count < 4 {
            btAuthFreshnessArray.insert(0, at: 0)
        }
        print("btAuthFreshnessHexString: \(btAuthFreshnessHexString)")

        /// Convert QR Code substring -> UInt32 -> HexaDecimal -> [UInt8]
        let btAuthPinSubstring: Substring = JLGBLEManager.sharedInstance.authPinForAuthentication
        let btAuthPinDecimal = UInt32(btAuthPinSubstring)!
        JLGBLEManager.sharedInstance.writeData(data: JLGIntByteConverter.uInt32ToDataConverter(value: btAuthPinDecimal), charUUID: kBtAuthPinCharacteristicsUUID, withResponse: false)
        let btAuthPinHexString = String(format: "%02X", btAuthPinDecimal) // 30D72
        let btAuthPinArray = [UInt8](hex: ("000" + btAuthPinHexString)) // [0, 3, 13, 114]
        print("btAuthPinHexString: \(btAuthPinHexString)")

        /// Creat message for btAuthSignature
        let message: [UInt8] = [btAuthFreshnessArray[3], btAuthFreshnessArray[2], btAuthFreshnessArray[1], btAuthFreshnessArray[0], btAuthPinArray[3], btAuthPinArray[2], btAuthPinArray[1], btAuthPinArray[0]] // [120, 86, 52, 18, 114, 13, 3, 0]
        print("signature message hex string: \(message.toHexString())")

        /// Using AES-128-CMAC algorithm to create btAuthSignature
        let btAuthSignature = try! CMAC(key: sharedSecretKey).authenticate(message)
        JLGBLEManager.sharedInstance.writeData(data: JLGIntByteConverter.uInt8arrayToDataConverter(valueArray: btAuthSignature), charUUID: kBtAuthSignatureCharacteristicsUUID, withResponse: false)

        print("btAuthSignature: \(btAuthSignature)") // [50, 33, 199, 226, 114, 187, 156, 210, 37, 252, 197, 131, 31, 167, 230, 196]
        print("btAuthSignature.toHexString(): \(btAuthSignature.toHexString())") // 3221c7e272bb9cd225fcc5831fa7e6c4

        authenticationTimer = Timer.scheduledTimer(timeInterval: responseTimeout, target: self, selector: #selector(authenticationTimerExpire), userInfo: nil, repeats: false)
    }

    /// Session key generation
    func generateSessionKey() {
        // Create random alphanumeric with fixed length 16 bytes
        let randomString = String.random(length: 16)
        let randomStringData = Data(randomString.utf8)
        let randomHexString = randomStringData.map { String(format: "%02x", $0) }.joined()
        print("Session key plain hexadecimal: \(randomHexString)")

        /// Using AES-128-ECB algorithm to create btAuthSignature
        let sessionKey = [UInt8](hex: randomHexString)
        let encryptedSessionKey = try! AES(key: sharedSecretKey, blockMode: ECB(), padding: .noPadding).encrypt(sessionKey)
        JLGBLEManager.sharedInstance.writeData(data: JLGIntByteConverter.uInt8arrayToDataConverter(valueArray: encryptedSessionKey), charUUID: kBtAuthSessionKeyEncryptedCharacteristicsUUID, withResponse: false)

        print("encryptedSessionKey: \(encryptedSessionKey)") // [224, 123, 55, 55, 47, 145, 7, 1, 218, 243, 8, 71, 178, 179, 195, 141]
        print("encryptedSessionKey.toHexString(): \(encryptedSessionKey.toHexString())") // e07b37372f910701daf30847b2b3c38d

        /// Decrypt encrypted data coming from BLE (Future Use)
        /*
         let dec = try! AES(key: sharedSecretKey, blockMode: ECB(), padding: .noPadding).decrypt(encryptedSessionKey)
         print("dec: \(dec)")
         print("dec hex: \(dec.toHexString())")
         print(sessionKey == dec)
         */
    }

    /// Remote init command
    func btRemoteInitCommand(remoteInitValue: BtCanRemoreInitEnum) {
        print("Remote init value: \(remoteInitValue.rawValue))")
        resetWatchdogValue()
        JLGBLEManager.sharedInstance.writeData(data: JLGIntByteConverter.uInt8ToDataConverter(value: remoteInitValue.rawValue), charUUID: kBtRemoteInitCharacteristicsUUID, withResponse: false)
        btRemoteInitValue = remoteInitValue
    }

    /// btRemStopCommandValue to Start Or Stop the sending Drive/Steer/Lift Command to BLE module
    func btRemStopCommand() {
        print("Remote Stop Command Sent, Value = \(btCanRemStopEnum.rawValue)")
        JLGBLEManager.sharedInstance.writeData(data: JLGIntByteConverter.uInt8ToDataConverter(value: btCanRemStopEnum.rawValue), charUUID: kBtRemStopCharacteristicsUUID, withResponse: false)
    }

    /// btRemEStopCommandValue to Start Or Stop the sending Drive/Steer/Lift Command to BLE module
    func btRemEStopCommand() {
        print("Remote E Stop Command Sent, Value = \(btCanRemEStopEnum.rawValue)")
        JLGBLEManager.sharedInstance.writeData(data: JLGIntByteConverter.uInt8ToDataConverter(value: btCanRemEStopEnum.rawValue), charUUID: kBtRemEStopCharacteristicsUUID, withResponse: true)
    }

    /// btRemDriveCommand to send Drive Command to BLE module
    func btRemDriveCommand() {
        if driveValue >= -100 && driveValue <= 100 {
            /// Uncomment below lines when you don't want to send repeated values (Future Use)
            //if self.driveValue != self.driveOldValue {
            //self.driveOldValue = self.driveValue
            JLGBLEManager.sharedInstance.writeData(
                data: JLGIntByteConverter.int8ToDataConverter(value: self.driveValue),
                charUUID: kBtRemDriveCharacteristicsUUID, withResponse: false)
            //}
        }
    }

    /// btRemDriveCommand to send Drive Command to BLE module
    func btRemDriveCommand(dValue: Int8) {
        if dValue >= -100 && dValue <= 100 {
            /// Uncomment below lines when you don't want to send repeated values (Future Use)
            //if dValue != self.driveOldValue {
            //self.driveOldValue = dValue
            JLGBLEManager.sharedInstance.writeData(
                data: JLGIntByteConverter.int8ToDataConverter(value: dValue),
                charUUID: kBtRemDriveCharacteristicsUUID, withResponse: false)
            //}
        }
    }

    /// btRemSteerCommand to send Steer Command to BLE module
    func btRemSteerCommand() {
        if steerValue == -100 || steerValue == 100 || steerValue == 0 {
            /// Uncomment below lines when you don't want to send repeated values (Future Use)
            //if self.steerValue != self.steerOldValue {
            //self.steerOldValue = self.steerValue
            JLGBLEManager.sharedInstance.writeData(
                data: JLGIntByteConverter.int8ToDataConverter(value: self.steerValue),
                charUUID: kBtRemSteerCharacteristicsUUID, withResponse: false)
            //}
        }
    }

    /// btRemLiftCommand to send Lift Command to BLE module
    func btRemLiftCommand() {
        if liftValue >= -100 && liftValue <= 100 {
            JLGBLEManager.sharedInstance.writeData(
                data: JLGIntByteConverter.int8ToDataConverter(value: liftValue),
                charUUID: kBtRemSteerCharacteristicsUUID, withResponse: false)
        }
    }

    /// btWatchdogCommand to send watchdog command to BLE module
    func btWatchdogCommand() {
        if isWatchdogResponseReceived {
            isWatchdogResponseReceived = false
            self.btUpdateIncrementalWatchdogCommand(incrementalWatchdogValue: UInt8(btWatchdogValue))
            self.btWatchdogValue += 1
            if self.btWatchdogValue > UInt8.max {
                btWatchdogValue = 0
            }
        }
    }

    /// Write watchdog value in BLE
    func btUpdateIncrementalWatchdogCommand(incrementalWatchdogValue: UInt8) {
        JLGBLEManager.sharedInstance.writeData(data: JLGIntByteConverter.uInt8ToDataConverter(value: incrementalWatchdogValue), charUUID: kBtWatchdogCharacteristicsUUID, withResponse: true)
    }

    /// Write horn value in BLE
    func btHornEnableCommand(hornEnableValue: BtCanHornEnableEnum) {
        JLGBLEManager.sharedInstance.writeData(data: JLGIntByteConverter.uInt8ToDataConverter(value: hornEnableValue.rawValue), charUUID: kBtHornEnableCharacteristicsUUID, withResponse: false)
    }

    /// Write torque value in BLE
    func btHiLoTorqueCommand(hiLoTorqueValue: BtCanHiLoTorqueEnum) {
        JLGBLEManager.sharedInstance.writeData(data: JLGIntByteConverter.uInt8ToDataConverter(value: hiLoTorqueValue.rawValue), charUUID: kBtHiLoTorqueCharacteristicsUUID, withResponse: false)
        btHiLoTorqueValue = hiLoTorqueValue
    }

    /// Remote stop command
    func btRemStopCommand(remStopValue: BtCanRemStopEnum) {
        print("btCanRem StopEnum.rawValue ::::: \(remStopValue.rawValue)")
        JLGBLEManager.sharedInstance.writeData(data: JLGIntByteConverter.uInt8ToDataConverter(value: remStopValue.rawValue), charUUID: kBtRemStopCharacteristicsUUID, withResponse: false)
    }

    /// Remote E stop command
    func btRemEStopCommand(remEStopValue: BtCanRemEStopEnum) {
        print("btCanRem E StopEnum.rawValue ::::: \(remEStopValue.rawValue)")
        JLGBLEManager.sharedInstance.writeData(data: JLGIntByteConverter.uInt8ToDataConverter(value: remEStopValue.rawValue), charUUID: kBtRemEStopCharacteristicsUUID, withResponse: true)
    }

    /// OTA Reprogramming Data Stream Command
    func otaReprogrammingDataStreamCommand(data: Data) {
        JLGBLEManager.sharedInstance.writeData(data: data, charUUID: kOTAReprogrammingDataStreamCharacteristicUUID, withResponse: false)
    }

    /// Vehicle pin command (machine decal)
    func btVehiclePinUpdateCommand(string: NSString) {
        let data = NSData(bytes: string.utf8String, length: string.length)
        JLGBLEManager.sharedInstance.writeData(data: data as Data, charUUID: kBtVehiclePinUpdateCharacteristicsUUID, withResponse: true)
    }

    // MARK: - Send data in every 100 ms
    /// Write data in every 100 ms (Drive, Steer, Lift and Watchdog)
    @objc func repeatSendCommandIn100MiliSecondsDuration() {
        btWatchdogCommand()
        if btRemStopCommandSent == true {
            btRemDriveCommand()
            btRemSteerCommand()
            if liftValue != 0 {
                btRemLiftCommand()
            }
        }
    }

    // MARK: - Reset Drive, Steer and Lift values
    /// Reset values when finger goes off
    func fingerOffStopSendingCommands() {
        btCanRemStopEnum = .Stop
        btRemStopCommand()
        restAllRemServiceValues()
    }

    /// Reset values when click on Emergency stop
    func mobRemEStopSendingCommands() {
        btCanRemEStopEnum = .Stop
        btRemEStopCommand()
        restAllRemServiceValuesForBtRemEStop()
    }

    /// updateDriveValue will be get called when joystick being dragged
    func updateDriveValue(driveUpdatedValue: Int8) {
        driveValue = driveUpdatedValue
        if btRemStopCommandSent == false {
            btRemStopCommandSent = true
            btRemStopCommand()
            resetDriveValue()
            btRemDriveCommand()
        }
    }

    /// updateSteerValue will be get called when joystick being dragged
    func updateSteerValue(steerUpdatedValue: Int8) {
        steerValue = steerUpdatedValue
        if btRemStopCommandSent == false && steerValue != 0 {
            btRemStopCommandSent = true
            btRemStopCommand()
            resetSteerValue()
            btRemSteerCommand()
        }
    }

    /// updateLiftValue will be get called when joystick being dragged
    func updateLiftValue(liftUpdatedValue: Int8) {
        liftValue = liftUpdatedValue
    }

    /// restAllRemServiceValues to again prepair for sending next set of commands
    func restAllRemServiceValues() {
        resetSteerValue()
        resetLiftValue()
        resetDriveValue()
        btRemStopCommandSent = false
        btCanRemStopEnum = .Start
        btRemEStopCommandSent = false
        btCanRemEStopEnum = .Start
        btWatchdogValue = 0
        anaylzerCount = 0
    }

    /// restAllRemServiceValues for btRemEStop
    func restAllRemServiceValuesForBtRemEStop() {
        resetSteerValue()
        resetLiftValue()
        resetDriveValue()
        btRemEStopCommandSent = false
        btCanRemEStopEnum = .Start
        btWatchdogValue = 0
    }

    /// resetDriveValue individually
    func resetDriveValue() {
        driveValue = 0
        btRemDriveCommand()
    }

    /// resetSteerValue individually
    func resetSteerValue() {
        steerValue = 0
        btRemSteerCommand()
    }

    /// resetLiftValue individually
    func resetLiftValue() {
        liftValue = 0
        btRemLiftCommand()
    }

    /// resetWatchdogValue individually
    func resetWatchdogValue() {
        btWatchdogValue = 0
    }

    /// Reset all commands Drive, Steer and Lift
    func resetAllCommands() {
        restAllRemServiceValues()
    }

    // MARK: - Foreground timer
    /// Start foreground timer
    func startForegroundTimer() {
        foregroundTimerCounter = 0
        stopForegroundTimer()
        foregroundTimer = Timer.scheduledTimer(timeInterval: 30, target: self, selector: #selector(calculate5MinutesTime), userInfo: nil, repeats: true)
        shouldStartForegroungTimer = true
    }

    /// Stop foreground timer
    func stopForegroundTimer() {
        foregroundTimerCounter = 0
        if foregroundTimer != nil {
            foregroundTimer?.invalidate()
            foregroundTimer = nil
        }
    }

    /// Calculate 5 minute inactivity in foreground
    @objc func calculate5MinutesTime() {
        foregroundTimerCounter += 1
        print("Foreground timer counter ::::: \(foregroundTimerCounter)")

        if foregroundTimerCounter == 10 {
            //Analytics.logEvent("rcs_session_timeout_foreground", parameters: [kUserID: userID, kTimeStamp: Date().PR2DateFormatterUTC()])
            isTimeExceed5Minutes = true
            stopForegroundTimer()
            JLGBLEManager.sharedInstance.stopScanning()
            if isDisconnectedBLE || isDeviceBluetoothOff {
                NotificationCenter.default.post(name: .notificationIdentifierForDismissDisconnectBLEAlert, object: nil)
                NotificationCenter.default.post(name: .notificationIdentifierForAppRouteToScanVC, object: nil)
            } else {
                NotificationCenter.default.post(name: .notificationIdentifierForSessionTimeout, object: nil)
                perform(#selector(disconnectBLEConnection), with: self, afterDelay: 5)
            }
        }
    }

    /// Disconnect bluetooth connection
    @objc func disconnectBLEConnection() {
        if isTimeExceed5Minutes {
            NotificationCenter.default.post(name: .notificationIdentifierForDismissDisconnectBLEAlert, object: nil)
            JLGBLEManager.sharedInstance.disconnectFromPeripheral()
        }
    }

    func createSerialScreenDummyDataForTesting(stringData: String) {
        do {
            let decodedInfo = try Jlg_Envelope(textFormatString: stringData)
            let jsonString = try decodedInfo.jsonString()
            let data = Data(jsonString.utf8)
            JLGSerialScreenModel.sharedInstance.parseProtobufResponse(dataValue: data)
        } catch {
            print("Error in Serialization")
        }
    }
    
    var anaylzerCount = 0
    func createDummyDataForBluetoothAnalyzer() {
        //print ("Which Array --> \(createSerialScreenDummyData()[anaylzerCount]) Count: \(anaylzerCount)")
        self.createSerialScreenDummyDataForBluetoothAnalyzerTesting(stringData: createSerialScreenDummyData()[anaylzerCount])

//        if (createSerialScreenDummyData().count - 1) != anaylzerCount {
//            anaylzerCount += 1
//        } else {
//            anaylzerCount = 0
//        }

            anaylzerCount += 1

            if (createSerialScreenDummyData().count - 1) == anaylzerCount {
                anaylzerCount = 0
            }
    }
    
    func createSerialScreenDummyDataForBluetoothAnalyzerTesting(stringData: String) {
        do {
            let decodedInfo = try Jlg_Envelope(textFormatString: stringData)
            JLGSerialScreenModel.sharedInstance.parseProtobufBluetoothAnalyzerResponse(data: decodedInfo.analyzerMessage)
        } catch {
            print("Error in Serialization")
        }
    }

}
