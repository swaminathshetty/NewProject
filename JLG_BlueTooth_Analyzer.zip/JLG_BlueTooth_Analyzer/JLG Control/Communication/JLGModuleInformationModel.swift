//
//  JLGModuleInformationModel.swift
//  JLG Control
//
//  Created by L&T on 19/04/18.
//  Copyright © 2018 L&T. All rights reserved.
//

import UIKit

class JLGModuleInformationModel {

    var batteryVoltage: UInt16 = 0
    var digitalInputState: Int8 = 0
    var analogInputVoltages: Int16 = 0
    var canVoltages: Int16 = 0
    var temperature: Int8 = 0

    init?(batteryVoltage: UInt16?, digitalInputState: Int8?, analogInputVoltages: Int16?, canVoltages: Int16?, temperature: Int8?) {
        /// Initialize stored properties.
        self.batteryVoltage = batteryVoltage!
        self.digitalInputState = digitalInputState!
        self.analogInputVoltages = analogInputVoltages!
        self.canVoltages = canVoltages!
        self.temperature = temperature!
    }

}
