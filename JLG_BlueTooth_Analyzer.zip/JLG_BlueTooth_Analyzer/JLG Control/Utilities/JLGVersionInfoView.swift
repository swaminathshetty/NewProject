//
//  JLGVersionInfoView.swift
//  JLG Control
//
//  Created by LTTS_iMac_Conti on 10/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class JLGVersionInfoView : UIView {

    let firstLabel : UILabel = {
        var appVersion = ""
        if let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String {
            appVersion = version + kBetaVersion
        }

        let label = UILabel()
        label.numberOfLines = 0
        label.text = "App Version: " + "\(appVersion)"
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        label.backgroundColor = UIColor.blue
        label.adjustsFontForContentSizeCategory = true
        label.adjustsFontSizeToFitWidth = true
        label.sizeToFit()
        return label
    }()

    let secondLabel : UILabel = {
        let label = UILabel()
        label.text = "CAN Version: " + "\(JLGCommunicationManager.sharedInstance.vehicleBLEVersion)" + ", GI: " + "\(JLGCommunicationManager.sharedInstance.vehicleGIVersion)"
        label.numberOfLines = 0
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        label.backgroundColor = UIColor.red
        label.adjustsFontForContentSizeCategory = true
        label.adjustsFontSizeToFitWidth = true
        return label
    }()

    init() {
        super.init(frame: UIScreen.main.bounds)

        let windowHeight : CGFloat = 70
        let windowWidth  : CGFloat = 100

        self.backgroundColor = UIColor.yellow;
        self.frame = CGRect(x: 0, y: 0, width: windowWidth, height: windowHeight)
        self.center = CGPoint(x: 320, y: 110)
        
        
        let stackview = UIStackView()
        stackview.axis = .vertical
        stackview.spacing = 0
        stackview.translatesAutoresizingMaskIntoConstraints = false
        stackview.addArrangedSubview(firstLabel)
        firstLabel.widthAnchor.constraint(equalToConstant: windowWidth).isActive = true
        firstLabel.heightAnchor.constraint(equalToConstant: windowHeight/2).isActive = true

        stackview.addArrangedSubview(secondLabel)
        secondLabel.widthAnchor.constraint(equalToConstant: windowWidth).isActive = true
        secondLabel.heightAnchor.constraint(equalToConstant: windowHeight/2).isActive = true

        self.addSubview(stackview)
        stackview.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        stackview.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true

        
        return;
    }

    required init?(coder aDecoder: NSCoder) { fatalError("init(coder:) has not been implemented")}
}
