//
//  JLGAlertMessageBluetoothTurnOff.swift
//  JLG Control
//
//  Created by Apple on 16/07/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation

protocol JLGAlertMessageBluetoothTurnOffDelegate: class {
    func commonActionForBluetoothTurnOff()
    func didSelectBluetoothTurnOffSettingButton()
    func didSelectBluetoothTurnOffOkButton()
}

extension JLGAlertMessageBluetoothTurnOffDelegate {
    func commonActionForBluetoothTurnOff() {}
    func didSelectBluetoothTurnOffSettingButton() {}
    func didSelectBluetoothTurnOffOkButton() {}
}

class JLGAlertMessageBluetoothTurnOff: NSObject {
    weak var delegate: JLGAlertMessageBluetoothTurnOffDelegate?

    func showAlertIfBLEIsOff(viewController: UIViewController) {
        let alert = UIAlertController(title: JLGStringConstants.kAlertMessageBluetoothTurnOff, message: "", preferredStyle: UIAlertControllerStyle.alert)
        let actionSettings = UIAlertAction(title: JLGStringConstants.kAlertActionSettings, style: .default) { _ in
            guard let settingsUrl = URL(string: UIApplicationOpenSettingsURLString) else {
                return
            }
            if UIApplication.shared.canOpenURL(settingsUrl) {
                if #available(iOS 10.0, *) {
                    UIApplication.shared.open(NSURL(string: UIApplicationOpenSettingsURLString)! as URL, options: [:], completionHandler: nil)
                } else {
                    /// Fallback on earlier versions
                    UIApplication.shared.openURL(NSURL(string: UIApplicationOpenSettingsURLString)! as URL)
                }
            }

            self.delegate?.commonActionForBluetoothTurnOff()
            self.delegate?.didSelectBluetoothTurnOffSettingButton()
        }
        alert.addAction(actionSettings)
        alert.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionOK, style: .default) { _ in
            self.delegate?.commonActionForBluetoothTurnOff()
            self.delegate?.didSelectBluetoothTurnOffOkButton()
        })
        viewController.present(alert, animated: true, completion: nil)
    }
}
