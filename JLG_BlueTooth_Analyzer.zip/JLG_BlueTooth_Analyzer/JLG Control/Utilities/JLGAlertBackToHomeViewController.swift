//
//  JLGAlertBackToHomeViewController.swift
//  JLG Control
//
//  Created by Apple on 17/07/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation

protocol JLGAlertBackToHomeViewControllerDelegate: class {
    func didSelectBackToHomeConfirmButton()
    func didSelectBackToHomeCancelButton()
}

extension JLGAlertBackToHomeViewControllerDelegate {
    func didSelectBackToHomeConfirmButton() {}
    func didSelectBackToHomeCancelButton() {}
}

class JLGAlertBackToHomeViewController: NSObject {
    weak var delegate: JLGAlertBackToHomeViewControllerDelegate?
    var alertJLGBackToHomeVC = UIAlertController()

    func showAlertForBackToHomeViewController(viewController: UIViewController) {
         alertJLGBackToHomeVC = UIAlertController(title: JLGStringConstants.kAlertTitle, message: JLGStringConstants.kAlertBackToHomeViewController, preferredStyle: UIAlertControllerStyle.alert)
        alertJLGBackToHomeVC.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionConfirm, style: .default) { _ in
            NotificationCenter.default.post(name: .notificationIdentifierForSerialScreenDisconnectBLE, object: nil)
            self.delegate?.didSelectBackToHomeConfirmButton()
        })

            alertJLGBackToHomeVC.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionCancel, style: .default) { _ in
                self.delegate?.didSelectBackToHomeCancelButton()
            })
        viewController.present(alertJLGBackToHomeVC, animated: true, completion: nil)
    }

    func removeAlertForBackToHomeViewController() {
        alertJLGBackToHomeVC.dismiss(animated: true, completion: nil)
    }
}
