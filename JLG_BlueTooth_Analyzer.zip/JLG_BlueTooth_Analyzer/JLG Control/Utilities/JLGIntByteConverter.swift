//
//  JLGIntByteConverter.swift
//  JLG Control
//
//  Created by L&T on 19/04/18.
//  Copyright © 2018 L&T. All rights reserved.
//

import UIKit

/// Extensions to convert Data into specific format using Swift 'Generics'
extension Data {

    init<T>(from value: T) {
        var value = value
        self.init(buffer: UnsafeBufferPointer(start: &value, count: 1))
    }

    func to<T>(type: T.Type) -> T {
        return self.withUnsafeBytes { $0.pointee }
    }

    func scanValue<T>(start: Int, length: Int) -> T {
        return self.subdata(in: start..<start+length).withUnsafeBytes { $0.pointee }
    }

}

// MARK: - Int to Byte and vice versa converter class
class JLGIntByteConverter {
    enum Bit: UInt8, CustomStringConvertible {
        case zero, one

        var description: String {
            switch self {
            case .one:
                return "1"
            case .zero:
                return "0"
            }
        }
    }
    
    static func bit(_ i: Int, of uint8: UInt8) -> Bit {
      let first8PowersOf2 = (0...7).map { return UInt8(1) << $0 }
      return (uint8 & first8PowersOf2[i] != 0) ? Bit.one : Bit.zero
    }

    static func bitsFrom(_ uint8: UInt8) -> [Bit] {
      return Array((0...7)).reversed().map { bit($0, of: uint8) }
    }

    /// dataToInt8Converter is use to convert data bytes into signed Int8
    static func dataToInt8Converter(data: Data) -> Int8 {
        let number = data.withUnsafeBytes { (pointer: UnsafePointer<Int8>) -> Int8 in
            return pointer.pointee
        }
        return number
    }

    /// dataToUInt8Converter is use to convert data bytes into unsigned UInt8
    static func dataToUInt8Converter(data: Data) -> UInt8 {
        let number = data.withUnsafeBytes { (pointer: UnsafePointer<UInt8>) -> UInt8 in
            return pointer.pointee
        }
        return number
    }

    /// dataToInt16Converter is use to convert data bytes into signed Int16
    static func dataToInt16Converter(data: Data) -> Int16 {
        let number = data.withUnsafeBytes { (pointer: UnsafePointer<Int16>) -> Int16 in
            return pointer.pointee
        }
        return number
    }

    /// dataToUInt16Converter is use to convert data bytes into unsigned UInt16
    static func dataToUInt16Converter(data: Data) -> UInt16 {
        let number = data.withUnsafeBytes { (pointer: UnsafePointer<UInt16>) -> UInt16 in
            return pointer.pointee
        }
        return number
    }

    /// dataToInt32Converter is use to convert data bytes into unsigned Int32
    static func dataToInt32Converter(data: Data) -> Int32 {
        let number = data.withUnsafeBytes { (pointer: UnsafePointer<Int32>) -> Int32 in
            return pointer.pointee
        }
        return number
    }

    /// dataToUInt32Converter is use to convert data bytes into unsigned UInt32
    static func dataToUInt32Converter(data: Data) -> UInt32 {
        let number = data.withUnsafeBytes { (pointer: UnsafePointer<UInt32>) -> UInt32 in
            return pointer.pointee
        }
        return number
    }

    /// dataBytesArrayToUInt8ArrayConverter is use to convert data bytes into [UInt8]
    static func dataBytesArrayToUInt8ArrayConverter (data: Data) -> [UInt8] {
        let array = data.withUnsafeBytes { (pointer: UnsafePointer<UInt8>) -> [UInt8] in
            let buffer = UnsafeBufferPointer(start: pointer,
                                             count: data.count)
            return Array<UInt8>(buffer)
        }
        return array
    }

    /// dataBytesArrayToAnalogInputVoltageConverter is use to convert data bytes into BtAnalogInputVotageStatus
    static func dataBytesArrayToAnalogInputVoltageConverter (data: Data) -> BtAnalogInputVotageStatus {
        var btAnalogInputVoltageStatus: BtAnalogInputVotageStatus = BtAnalogInputVotageStatus()
        btAnalogInputVoltageStatus.GPIO1 = data.scanValue(start: 0, length: 2)
        btAnalogInputVoltageStatus.GPIO2 = data.scanValue(start: 2, length: 2)
        return btAnalogInputVoltageStatus
    }

    /// dataBytesArrayToMixTypeArrayConverter Converter is use to convert data bytes into BtRemStatus
    static func dataBytesArrayToMixTypeArrayConverter (data: Data) -> BtRemStatus {
        var btRemStatus: BtRemStatus = BtRemStatus()

        btRemStatus.btControlSystemReady = data.scanValue(start: 0, length: 1)
        btRemStatus.btCommandTimeout = data.scanValue(start: 1, length: 1)
        btRemStatus.btControlSystemReady = data.scanValue(start: 2, length: 1)
        btRemStatus.btHiLoTorqueStatus = data.scanValue(start: 3, length: 1)
        btRemStatus.btRemDriveStatus = data.scanValue(start: 4, length: 1)
        btRemStatus.btRemSteerStatus = data.scanValue(start: 5, length: 1)
        btRemStatus.btRemLiftStatus = data.scanValue(start: 6, length: 1)
        btRemStatus.btGroundMode = data.scanValue(start: 7, length: 1)
        btRemStatus.btStowed = data.scanValue(start: 8, length: 1)
        btRemStatus.btVehicleCharging = data.scanValue(start: 9, length: 1)
        btRemStatus.btVehicleSafeMode = data.scanValue(start: 10, length: 1)

        return btRemStatus
    }

    /// int8ToDataConverter is use to convert int8 into data bytes
    static func int8ToDataConverter(value: Int8) -> Data {
        var number = Int8(value)
        let enableByte = Data(bytes: &number, count: MemoryLayout<Int8>.size)
        return enableByte
    }

    /// uInt8ToDataConverter is use to convert uInt8 into data bytes
    static func uInt8ToDataConverter(value: UInt8) -> Data {
        var number = UInt8(value)
        let enableByte = Data(bytes: &number, count: MemoryLayout<UInt8>.size)
        return enableByte
    }

    /// uInt32ToDataConverter is use to convert uInt32 into data bytes
    static func uInt32ToDataConverter(value: UInt32) -> Data {
        var number = UInt32(value)
        let enableByte = Data(bytes: &number, count: MemoryLayout<UInt32>.size)
        return enableByte
    }

    /// uInt8arrayToDataConverter is use to convert [uInt8] into data bytes
    static func uInt8arrayToDataConverter(valueArray: [UInt8]) -> Data {
        return Data(bytes: valueArray)
    }

}

extension String {
    /// Convert value into binary
    init<B: FixedWidthInteger>(fullBinary value: B) {
        self = value.words.reduce(into: "") {
            $0.append(contentsOf: repeatElement("0", count: $1.leadingZeroBitCount))
            $0.append(String($1, radix: 2))
        }
    }
}

//private func getValueFromBinaryString(binaryString: String) -> Int {
//    let requiredValue = Int(binaryString, radix: 2) ?? 0xFF
//    return requiredValue
//}
