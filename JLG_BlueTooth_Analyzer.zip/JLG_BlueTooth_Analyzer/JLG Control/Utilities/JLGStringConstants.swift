//
//  JLGStringConstants.swift
//  JLG Control
//
//  Created by L&T on 20/04/18.
//  Copyright © 2018 L&T. All rights reserved.
//

import UIKit

class JLGStringConstants {

    /// Alert Titles
    static let kAlertTitle = "Alert"
    static let kAlertTitleTimeOut = "Timeout"
    static let kAlertTitleBLEDisconnected = "Connection Lost"
    static let kAlertTitleDisconnectJLGLift = "Disconnect Machine"
    static let kAlertTitleSessionTimeout = "Session Timeout"
    static let kAlertTitleJLGLiftNotFound = "Valid Machine Not Found"
    static let kAlertTitleCameraAccessDenied = "Camera Access Denied"
    static let kAlertTitleSuccess = "Success"
    static let kAlertTitleError = "Error"
    static let kAlertTitleMachineDecal = "Configure Machine Decal?"
    static let kAlertTitleMachineDecalSuccess = "Configured Successfully"
    static let kAlertTitleBatteryInstallationDate = "Battery Installation Date"
    static let kAlertTitleLastRefillDate = "Last Refill Date"

    /// Alert Messages
    static let kAlertMessageTimeOut = "Timeout occurred, please press 'Drive' to re-enter remote mode."
    static let kAlertMessageBluetoothTurnOff = "Turn On Bluetooth to Allow \"JLG Mobile Control\" to Connect to Accessories"
    static let kAlertMessageNoDeviceFound = "Unable to locate a valid machine."
    static let kAlertMessageBLEDisconnected = "Bluetooth connection is lost, please reconnect."
    static let kAlertMessageDisconnection = "Are you sure that you want to disconnect from this machine?"
    static let kAlertMessageSessionTimeout = "Please scan again to connect to machine."
    static let kAlertMessageExpired = "This app has been updated. Please check the App Store® for the latest version."
    static let kAlertMessageCameraAccessDenied = "Please enable camera to capture QR code."
    static let kAlertMessageDrive = "Drive is disabled due to the below machine condition(s):\n"
    static let kAlertMessageNotStowed = "\nNot in stowed position"
    static let kAlertMessageNotGround = "\nNot in ground mode"
    static let kAlertMessageCharging = "\nIn charging state"
    static let kAlertMessageSafeMode = "\nIn safe mode"
    static let kAlertMessageAuthenticationInvalid = "Authentication failed, please try again."
    static let kAlertMessageAuthenticationExpire = "Authentication failed due to exceeding maximum attemts. Please restart the machine and try again."
    static let kAlertMessageOTAFirmwareUpgrade = "The software needs to be updated to continue to use this App."
    static let kAlertMessageReadingBinaryFile = "Error reading binary file."
    static let kAlertMessageBinaryFileNotFound = "Binary file not found."
    static let kAlertMessageOTAReprogrammingSuccess = "Software successfully updated."
    static let kAlertMessageOTAReprogrammingError = "OTA reprogramming error: %@"
    static let kAlertMessageOTAReprogrammingUnknownResponse = "OTA reprogramming unknown response: %@"
    static var kAlertMessageVersionNotSupported = "Machine Bluetooth software is outdated."
    static var kAlertMessageBLERestart = "Software update failed. Please turn off the machine and try again."
    static let kAlertMessageMachineDecal = "Do you want to configure this machine decal with the connected machine?"
    static let kAlertMessageMachineDecalNotSupported = "Invalid machine decal"
    static let kAlertMessageMachineDecalSuccess = "Please turn off the machine and restart to save configuration."
    static let kAlertMessageMachineDecalScanAllPeripheral = "No more active machines found."
    static let kAlertActiveDeviceFound = "No machine found. Please try again."
    static let kAlertNoModelFound = "No machine model found."
    static let kAlertNotInRange = "Machine not available or not in the range"
    static let kAlertBackToFleetView = "Back to Fleet View"
    static let kAlertBackToFleetViewMessage = "Reverting back to Fleet View will require disconnecting Bluetooth to this machine.\nDo you want to continue?"
    static let kAlertAssetIDUpdateSuccessfully = "Asset ID successfully updated."
    static let kAlertAssetIDUpdateFailed = "Asset ID failed to update."
    static let kAlertAssetIDNotEmpty = "Please enter Asset ID."
    static let kAlertAssetIDNotZero = "Please do not enter Asset ID as Zero."
    static let kAlertBatteryMaintenanceDateUpdateSuccessfully = "Last refill date updated successfully."
    static let kAlertBatteryMaintenanceDateUpdateFailed = "Last refill date failed to update."
    static let kAlertBatteryInstallationDateSuccessfully = "Battery installation date updated successfully."
    static let kAlertBatteryInstallationDateUpdateFailed = "Battery installation date failed to update."
    static let kAlertBatteryInstallDate = "Are you sure you want to update the battery install date?"
    static let kAlertWaterLevelInstallDate = "Are you sure you want to update the water level refill date and reset the water line level?"
    static let kAlertBackToHomeViewController = "Navigating away from this page will requiring disconnecting Bluetooth from this machine. Do you want to continue?"
    static let kAlertDataNotReceiveFormProtobuf = "Data not receive from Machine."
    /// Alert Actions
    static let kAlertActionOK = "OK"
    static let kAlertActionCancel = "Cancel"
    static let kAlertActionDisconnect = "Disconnect"
    static let kAlertActionSettings = "Settings"
    static let kAlertActionRetry = "Retry"
    static let kAlertActionUpgrade = "Upgrade"
    static let kAlertActionUpdate = "Update"
    static let kAlertActionNo = "No"
    static let kAlertActionYes = "Yes"
    static let kAlertActionConfirm = "Confirm"
    static let kAlertActionDone = "Done"

    /// Peripherals Info
    static let kPeripheralInstance = "PeripheralInstance"
    static let kSerialNumber = "SerialNumber"
    static let kVehiclePin = "VehiclePin"
    static let kRSSIValue = "RSSIValue"
    static let kMachineType = "MachineType"
    static let kEnergyStorage = "EnergyStorage"
    static let kAssetId1 = "AssetId1"
    static let kAssetId2 = "AssetId2"
    static let kWarningStatus = "WarningStatus"
    static let kModelString = "ModelString"
    static let kAssetID = "AssetID"
    static let kBatteryPercentage = "BatteryPercentage"
    static let kJLGFleetScreenModelInstance = "JLGFleetScreenModelInstance"

    /// JLGBMSFleetTabViewController And JLGBMSSerialScreenViewController Constants
    static let kAssetIDLabel = "Asset ID:"
    static let kModelIDLabel = "Model:"
    static let kBatteryType = "Battery Type:"
    static let kBatterySize = "Battery Size:"
    static let kInstallationDate = "Installation Date:"
    static let kChargingAlgorithm = "Charging Algorithm:"
    static let kLowText = "low"
    static let kMostRecent = "Most Recent"
    static let kAboveHundredValuePercentage = "100%"
    static let kMoreInfo = "show more"
    static let kLessInfo = "show less"
    static let kWaterLevelInformation = "Water Level information is not\napplicable for this battery"
    static let kActivity = "ACTIVITY"
    static let kBatteryLevel = "BATTERY LEVEL"
    static let kPreviousChargeEnded = "Previous Charge ended:"
    static let kChargedTo = "Charged to:"
    static let kLastRefillDate = "Last Refill Date:"
    static let kEstimatedFluidLevel = "Estimated Fluid Level"
    static let kLessThan1HrsAgo = "< 1 hr ago"
    static let kGreaterThan72HrsAgo = "> 72 hrs ago"
    static let kHrsAgo = "hrs ago"
    static let kFLAFullForm = "Flooded Lead Acid"
    static let kAGMFullForm = "Absorbent Glass Mat"
    static let kLithiumIonFullForm = "Lithium Ion"

    /// Menu options
    static let kConfigureDecal = "Configure Machine Decal"
    static let kTermsAndConditions = "Terms & Conditions"
    static let kUserManual = "User Manual"
    static let kHome = "Home"

    /// BLE Firmware upgrade
    static let kPleaseWait = "Please wait..."
    static let kInProgress = "Software update in progress. Do not power off this device."

    /// Binary files
    static let kBinaryFileName = "JLGBLE_v00.52_analyzer_rev4_extended_text"
    static let kGIBinaryFileName = "JLGBLE_v00.55_GoldenImage_OTA"
    static let kBinaryFileType = "bin"

    /// Universal Constants
    static let kLogFileName = "JLG_iOS_Log.txt"
    static let kJLGBLEName = "JLG BLE"

    /// Relam files
    static let kRelamDBFileName = "JLGDTCAlertDB_v1.0"
    static let kRelamDBFileType = "realm"
    static let kRelamDBUserDefaults = "RealmDBName"
    static let kRelamJSONFileName = "JLGDTCAlertJSON_v1.0"
    static let kJSONFileType = "json"
    static let kRelamJSONUserDefaults = "RealmJSONUserDefaults"
    static let kRelamDBKey = "XqjIDA34BAIpcYBEuGHzVKS4JMtXYkzkYWXuL04AXFbv27K9yVvWuCOF6KO3a4zf"

    /// Terms and Conditions (Black)
    static let kAgreementHtmlText = "<p class=\"p1\" style=\"text-align: center;\"><span style=\"font-size: 18pt; color: #ffffff;\"><strong>Terms &amp; Conditions</strong></span></p><p class=\"p3\"><span style=\"font-size: 14pt; color: #cccccc;\"><span class=\"s1\">Unauthorized person</span><span class=\"s2\">s are</span><span class=\"s1\"> not allowed to use this JLG Mobile Control App.&nbsp; By downloading, installing, and using the app, or clicking the &ldquo;I Agree&rdquo; button, you are acknowledging and agreeing that: </span></span></p><ul><li class=\"p3\"><span style=\"font-size: 14pt; color: #cccccc;\"><span class=\"s1\">Person using this JLG Mobile Control App </span><span class=\"s2\">has</span><span class=\"s1\"> read and understood the appropriate Operator and Safety Manual in its entirety.</span></span></li><li class=\"p3\"><span style=\"font-size: 14pt; color: #cccccc;\"><span class=\"s1\">Person using this JLG Mobile Control App </span><span class=\"s2\">has</span><span class=\"s1\"> been properly trained in the use of the subject Scissor lift and the JLG Mobile Control App, and has authorization from an authorized person to utilize both the equipment and the JLG Mobile Control App. </span></span></li><li class=\"p3\"><span class=\"s1\" style=\"font-size: 14pt; color: #cccccc;\">Person using this Mobile Control App must read, understand, and obey all applicable employer, local, and governmental regulations as they pertain to your utilization and application of this app and the machine which is operating.</span></li><li class=\"p3\"><span class=\"s1\" style=\"font-size: 14pt; color: #cccccc;\">You are subject to the <a style=\"color: #cccccc;\" href=\"https://www.jlg.com/en/eula-mobile-control\">JLG Mobile Control App End User License Agreement</a> and the JLG <a style=\"color: #cccccc;\" href=\"https://www.jlg.com/en/privacy-policy\">Privacy Policy</a>.</span></li><li class=\"p3\"><span class=\"s1\" style=\"font-size: 14pt; color: #cccccc;\">The JLG Mobile Control App End User License Agreement:</span><ul><li class=\"p3\"><span class=\"s1\" style=\"font-size: 14pt; color: #cccccc;\">Grants authorized users a non-exclusive, non-transferable, non-sublicensable limited license to use the JLG Mobile Control App.</span></li><li class=\"p3\"><span class=\"s1\" style=\"font-size: 14pt; color: #cccccc;\">Prohibits that you directly or indirectly modify or use, beyond the scope of license, the software or any intellectual property (of JLG or other parties) therein.</span></li><li class=\"p3\"><span class=\"s1\" style=\"font-size: 14pt; color: #cccccc;\">Disclaims any applicable warranties, and provides that JLG and its affiliates will not be held responsible for any system service failure or misuse of the software that results in personal injury or property damage.</span></li><li class=\"p3\"><span class=\"s1\" style=\"font-size: 14pt; color: #cccccc;\">Allows JLG to unilaterally change the terms of the End User License Agreement at any time.</span></li></ul></li><li class=\"p3\"><span class=\"s1\" style=\"font-size: 14pt; color: #cccccc;\"><a style=\"color: #cccccc;\" href=\"https://www.jlg.com/en/privacy-policy\">The JLG Privacy Policy</a> explains how we treat data and protect privacy. </span></li></ul>"
    static let kProperChargingPracticesHtmlText = "<p class=\"p1\" style=\"text-align: center;\"><span style=\"font-size: 18pt; color: #000000;\"><strong>Tips for Improved Battery Life</strong></span></p><ul><li class=\"p3\"><span style=\"font-size: 14pt; color: #000000;\"><span class=\"s1\">It is considered a best practice to maintain an 80% State of Charge (SoC) or higher at all times, as shown by the green region on the cycle charts.</span></span></li><li class=\"p3\"><span style=\"font-size: 14pt; color: #000000;\"><span class=\"s1\">Allowing SoC to drop below 20% drastically reduces the battery life, as shown by the red region on the cycle charts.</span></span></li><li class=\"p3\"><span class=\"s1\" style=\"font-size: 14pt; color: #000000;\">Flooded lead acid batteries can freeze when discharged in cold climates.</span></li><li class=\"p3\"><span class=\"s1\" style=\"font-size: 14pt; color: #000000;\">Allowing the water level in flooded lead acid batteries to fall below threshold will cause irreversible capacity loss.</span></li><li class=\"p3\"><span class=\"s1\" style=\"font-size: 14pt; color: #000000;\">Ensure that only distilled water is added to batteries.</span></li></ul><br><p class=\"p3\" style=\"text-align: left;\"><span style=\"font-size: 14pt; color: #000000;\"><span class=\"s1\">For more detailed information, please visit JLG Mobile Control at </span></span></p><p class=\"p3\" style=\"text-align: left;\"><span style=\"font-size: 14pt; color: #000000;\"><span class=\"s1\">https://www.jlg.com/en/mobilecontrol</span></span></p>"

    /// JLGQRCodeScanViewController Constants
    static let kQRCodeDetected = "No QR code is detected"
    static let kQRCodeAuthenticating = "Authenticating..."
    static let kConnected = "Connected"
    static let kScanSuccessful = "Scan successful"

    /// JLGInfoTabViewController Constants
    static let kSettings = "Settings"
    static let kTitle = "Title"
    static let kVersion = "Version"
    static let kImage = "Image"
    static let kIsImageRequired = "IsImageRequired"
    static let kImageTitle = "ImageTitle"
    static let kManual = "Manual"
    static let kLegal = "Legal"
    static let kRegulatory = "Regulatory"
    static let kForwardArrow = "ForwardArrow"
    static let kMachineBLEVersion = "Machine Software Version"
    static let kAppVersion = "App Version"
    static let kUpdateAvailable = "UpdateAvailable"
    static let kUnknownText = "Unknown"
    static let kThreeDash = "---"
    static let kJLGOnlineExpress = "JLG Online Express"
    static let kJLGLibrary = "JLG Library"

    /// Legal and regulatory web link
    //static let kManualWebLink =  "https://csapps-t.jlg.com/MobileControl-SupplementManuals/Browse.aspx"
    static let kManualWebLink = "https://csapps.jlg.com/OnlineManuals/browse.aspx?path=Wireless+Devices%2fMobile+Control%2fSupplement+Manual&title=PDF+Manuals&refkey=HTTPS%3a%2f%2fWWW.JLG.COM%2fEN%2fMOBILECONTROL&link="
    static let kLegalWebLink = "https://www.jlg.com/en/fcc-mobile-control"
    static let kRegulatoryWebLink = "https://www.jlg.com/en/eula-mobile-control"

    /// Internet connectivity
    static let kNetworkError = "Network Error"
    static let kNetworkErrorMessage = "Please check your network connection and try again"

    /// App Store URL
    static let kAppStoreURL = "itms-apps://itunes.apple.com/app/id1437420933"

    /// Google Analytics Tracking ID
    static let kAnalyticsTrackingID = "UA-2417957-16"

    /// Image Name
    static let kFifteenToTwenty = "FifteenToTwenty"
    static let kTweentyfiveToThirty = "TweentyfiveToThirty"
    static let kThirtyfiveToFiftyfive = "ThirtyfiveToFiftyfive"
    static let kSixtyToSeventyfive = "SixtyToSeventyfive"
    static let kEightyToHundred = "EightyToHundred"
    static let kZeroToTen = "ZeroToTen"
    static let kConnectPlug = "ConnectPlug"
    static let kPlugConnectedWarning = "PlugConnectedWarning"
    static let kDisconnectPlug = "DisconnectPlug"
    static let kJLGMobileControlLogo = "JlgMobileControlLogo"
    static let kBackwardArrow = "BackwardArrow"

    /// Protobuf String
    static let kBatteryInfo = "battery_info"
    static let kBatteryHistory = "battery_history"
    static let kEsrInfo = "esr_info"
    static let kBmsAlerts = "bms_alerts"
    static let kDtcList = "dtc_list"
    static let kChargerFaultList = "charger_fault_list"
    static let kMachineInfo = "machine_info"
    static let kAlarmAlertStatus = "alarm_alert_status"
    static let kService_connect = "service_connect"
    static let kAssetIdUpdated = "AssetID_Updated"
    static let kAssetIdNotUpdated = "AssetID_Not_Updated"
    static let kBatteryInstallationDateUpdated = "Battery_Installation_Date_Updated"
    static let kBatteryInstallationDateNotUpdated = "Battery_Installation_Date_Not_Updated"
    static let kBatteryMaintenanceDateUpdated = "Battery_Maintenance_Date_Updated"
    static let kBatteryMaintenanceDateNotUpdated = "Battery_Maintenance_Date_Not_Updated"
    static let kACK = "ACK"
    static let kNACK = "NACK"
    static let kUNKNOWN = "UNKNOWN"
    static let kStartOfCharge = "START_OF_CHARGE"
    static let kCharging = "CHARGING"
    static let kStartOfDischarge = "START_OF_DISCHARGE"
    static let kDischarging = "DISCHARGING"

    /// Battery Type
    static let kFLA = "FLA"
    static let kAGM = "AGM"
    static let kLithiumIon = "LITHIUM_ION"
    static let kBatteryUnknown = "BATTERY_UNKNOWN"

    /// Charger Status
    static let kIDLE = "IDLE"
    static let kCHARGING = "CHARGING"
    static let kSTANDBY = "STANDBY"
    static let kBatteryFail = "BATTERY_FAIL"
    static let kChargerFail = "CHARGER_FAIL"
    static let kChargerStateUnknown = "CHARGER_STATE_UNKNOWN"
    static let kChargeIcon = "ChargeIcon"
    static let kChargeIconYellow = "ChargeIconYellow"
    static let kBA_FREEZE_WARNING = "BA_FREEZE_WARNING"
    static let kBA_LOW_WATER_WARNING = "BA_LOW_WATER_WARNING"
    static let kBA_DISCHARGED_BATTERY = "BA_DISCHARGED_BATTERY"
    static let kBA_DEEP_DISCHARGED_BATTERY = "BA_DEEP_DISCHARGED_BATTERY"
    static let kBA_LOW_SOC_CHARGING = "BA_LOW_SOC_CHARGING"
    static let kText_BA_FREEZE_WARNING = "Freeze Warning - Battery has potential of freezing electrolyte"
    static let kText_BA_LOW_WATER_WARNING = "Low Water Warning - Electrolyte level is predicted to be low, check battery electrolyte level"
    static let kText_BA_DISCHARGED_BATTERY = "Discharge Battery"
    static let kText_BA_DEEP_DISCHARGED_BATTERY = "Deeply Discharged Battery"
    static let kText_BA_LOW_SOC_CHARGING = "Low SOC Charging Practices - Last 5 charge cycle show poor charging practices, consider complete battery charge."
    static let kWarnings = "Active Alerts"
    static let kNoWarnings = "No Active Alerts"
    static let kTitleChargingPractices = "Charging Practices"

    /// Battery Units
    static let kBatteryPercentageVoltUnit = "V"
    static let kBatterySizeUnit = "Ah"

    /// Series Type
    static let kSeriesText = "Series"
    static let kNoModelSeriesText = "No Model"
    static let kUnknownSeriesText = "Unknown"
    static let kAESeriesText = "AE"
    static let kERTSeriesText = "ERT"
    static let kESSeriesText = "ES"
    static let kRTSeriesText = "RT"
    static let kRSeriesText = "R"
    
    /// Bluetooth Analyzer Image
    static let kBTAControlButtonDefault = "BTAControlButtonDefault"
    static let kBTAControlButtonDownArrowPress = "BTAControlButtonDownArrowPress"
    static let kBTAControlButtonEnterPress = "BTAControlButtonEnterPress"
    static let kBTAControlButtonEscPress = "BTAControlButtonEscPress"
    static let kBTAControlButtonLeftArrowPress = "BTAControlButtonLeftArrowPress"
    static let kBTAControlButtonRightArrowPress = "BTAControlButtonRightArrowPress"
    static let kBTAControlButtonUpArrowPress = "BTAControlButtonUpArrowPress"
}
