//
//  JLGFleetScreenDummyData.swift
//  JLG Control
//
//  Created by Apple on 14/01/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation

extension JLGBMSFleetTabViewController {
    func createDummyData() {
        let jlgFSM1 = JLGFleetScreenModel(assetId1: "02003746383", assetId2: "", machineModel: "2032ES", isConnectedWithACPower: JLGStringConstants.kConnectPlug, isAlertAlarmActive: true, batteryPercentage: "0")
        JLGBLEManager.sharedInstance.peripheralsInfo.append([JLGStringConstants.kJLGFleetScreenModelInstance: jlgFSM1])

        let jlgFSM2 = JLGFleetScreenModel(assetId1: "3723409832", assetId2: "", machineModel: "2032ES", isConnectedWithACPower: JLGStringConstants.kPlugConnectedWarning, isAlertAlarmActive: false, batteryPercentage: "20")
        JLGBLEManager.sharedInstance.peripheralsInfo.append([JLGStringConstants.kJLGFleetScreenModelInstance: jlgFSM2])

        let jlgFSM3 = JLGFleetScreenModel(assetId1: "837479347", assetId2: "", machineModel: "2032ES", isConnectedWithACPower: JLGStringConstants.kConnectPlug, isAlertAlarmActive: false, batteryPercentage: "30")
        JLGBLEManager.sharedInstance.peripheralsInfo.append([JLGStringConstants.kJLGFleetScreenModelInstance: jlgFSM3])

        let jlgFSM4 = JLGFleetScreenModel(assetId1: "Site7Lot55", assetId2: "", machineModel: "R3246", isConnectedWithACPower: JLGStringConstants.kDisconnectPlug, isAlertAlarmActive: false, batteryPercentage: "55")
        JLGBLEManager.sharedInstance.peripheralsInfo.append([JLGStringConstants.kJLGFleetScreenModelInstance: jlgFSM4])

        let jlgFSM5 = JLGFleetScreenModel(assetId1: "9876432", assetId2: "", machineModel: "2646ES", isConnectedWithACPower: JLGStringConstants.kPlugConnectedWarning, isAlertAlarmActive: true, batteryPercentage: "80")
        JLGBLEManager.sharedInstance.peripheralsInfo.append([JLGStringConstants.kJLGFleetScreenModelInstance: jlgFSM5])

        let jlgFSM6 = JLGFleetScreenModel(assetId1: "Site92Lot7", assetId2: "", machineModel: "R4045", isConnectedWithACPower: JLGStringConstants.kConnectPlug, isAlertAlarmActive: false, batteryPercentage: "75")
        JLGBLEManager.sharedInstance.peripheralsInfo.append([JLGStringConstants.kJLGFleetScreenModelInstance: jlgFSM6])

        let jlgFSM7 = JLGFleetScreenModel(assetId1: "Site10ID48738", assetId2: "", machineModel: "R3246", isConnectedWithACPower: JLGStringConstants.kDisconnectPlug, isAlertAlarmActive: true, batteryPercentage: "45")
        JLGBLEManager.sharedInstance.peripheralsInfo.append([JLGStringConstants.kJLGFleetScreenModelInstance: jlgFSM7])

        let jlgFSM8 = JLGFleetScreenModel(assetId1: "Site10ID48739", assetId2: "", machineModel: "ERT2669", isConnectedWithACPower: JLGStringConstants.kDisconnectPlug, isAlertAlarmActive: true, batteryPercentage: "85")
        JLGBLEManager.sharedInstance.peripheralsInfo.append([JLGStringConstants.kJLGFleetScreenModelInstance: jlgFSM8])

        let jlgFSM9 = JLGFleetScreenModel(assetId1: "Site10ID48740", assetId2: "", machineModel: "RT2669", isConnectedWithACPower: JLGStringConstants.kDisconnectPlug, isAlertAlarmActive: false, batteryPercentage: "60")
        JLGBLEManager.sharedInstance.peripheralsInfo.append([JLGStringConstants.kJLGFleetScreenModelInstance: jlgFSM9])

        let jlgFSM10 = JLGFleetScreenModel(assetId1: "Site10ID48741", assetId2: "", machineModel: "AE1932", isConnectedWithACPower: JLGStringConstants.kConnectPlug, isAlertAlarmActive: false, batteryPercentage: "20")
        JLGBLEManager.sharedInstance.peripheralsInfo.append([JLGStringConstants.kJLGFleetScreenModelInstance: jlgFSM10])

        hideLoadingIndicator()
        self.invalidateTimer()
        self.bmsFeetTableView.reloadData()
    }
}
