//
//  JLGTestingConstant.swift
//  JLG Control
//
//  Created by Apple on 26/12/19.
//  Copyright © 2019 L&T. All rights reserved.
//

import Foundation

struct JLGTestingConstant {
    /// ViewController constants
    static let kEnableTesting = "EnableTesting"
    static let kLoadingIndicatorView = "LoadingIndicatorView"

    /// JLGAgreementViewController
    static let kJLGAgreementVC = "JLGAgreementViewController"
    static let kIAgreeButton = "I Agree"
    static let kAgreementTextView = "AgreementTextView"

    /// JLGAgreementViewController
    static let kJLGMainHomeVC = "JLGMainHomeViewController"
    static let kBatteryMgmtView = "BatteryMgmtView"
    static let kRemoteControlView = "RemoteControlView"
    static let kBluetoothAnalzerView = "BluetoothAnalzerView"

    /// JLGBMSFleetTabViewController
    static let kJLGFleetVC = "JLGBMSFleetTabViewController"
    static let kJLGFleetTableView = "JLGFleetTableView"
    static let kFleetScreenSegmentControl = "FleetScreenSegmentControl"
    static let kJLGFleetTableViewCell = "JLGFleetTableViewCell_"
    static let kJLGFleetTableViewCellZero = "JLGFleetTableViewCell_0"

    /// JLGQRCodeViewController
    static let kJLGQRCodeVC = "JLGQRCodeViewController"
    static let kScanQRcodeButton = "ScanQRcodeButton"
    static let kMenuButton = "MenuButton"

    /// JLGQRCodeViewController
    static let kJLGHomeVC = "JLGRCSTabViewController"
    static let kDriveButton = "DriveButton"
    static let kHornButton = "HornButton"
    static let kParkedStatusButton = "ParkedStatusButton"
    static let kBatteryStatusButton = "BatteryStatusButton"
    static let kRightBarCustomButton = "RightBarCustomButton"

    /// JLGRCSTabBarController
    static let kJLGRCSTabBarController = "JLGRCSTabBarController"

    /// JLGInfoTabViewController
    static let kJLGSettingsVC = "JLGInfoTabViewController"
    static let kJLGSettingsTableView = "JLGSettingsTableView"
    static let kJLGSettingsTableViewCell = "JLGSettingsTableViewCell_"
    static let kJLGSettingsTableViewCellZero = "JLGSettingsTableViewCell_0"

    /// JLGManualViewController
    static let kJLGManualVC = "JLGManualViewController"
    static let kJLGManualWebView = "JLGManualWebView"

    /// JLGRCSVehicleControlViewController
    static let kJLGVehicleControlVC = "JLGRCSVehicleControlViewController"
    static let kTorqueHiLoButton = "TorqueHiLoButton"
    static let kEStopButton = "EStopButton"
    static let kVCHornButton = "HornButton"
    static let kJoystickLeftOuterView = "JoystickLeftOuterView"
    static let kJoystickRightOuterView = "JoystickRightOuterView"
    static let kJoystickTopOuterView = "JoystickTopOuterView"
    static let kJoystickBottomOuterView = "JoystickBottomOuterView"
    static let kJoyStickButton = "JoyStickButton"

    /// JLGBMSSerialScreenViewController
    static let kJLGSerialScreenVC = "JLGBMSSerialScreenViewController"
    static let kJLGSerialScreenTableView = "JLGSerialScreenTableView"
    static let kJLGSerialScreenWarningButton = "JLGSerialScreenWarningButton"
    static let kJLGSerialScreenMoreInfoButton = "JLGSerialScreenMoreInfoButton"
    static let kJLGSerialScreenBatteryInfoButton = "JLGSerialScreenBatteryInfoButton"
    static let kJLGSerialScreenSegmentController = "JLGSerialScreenSegmentController"
    static let kJLGSerialScreenDropButton = "JLGSerialScreenDropButton"
    static let kJLGSerialScreenBatteryInstallationDateButton = "JLGSerialScreenBatteryInstallationDateButton"
    /// JLGBMSAlarmAlertStatusViewController
    static let kJLGBMSAlarmAlertStatusViewControllerVC = "JLGBMSAlarmAlertStatusViewController"
    static let kJLGBMSAlarmAlertStatusViewControllerCancelButton = "JLGBMSAlarmAlertStatusViewControllerCancelButton"

    /// JLGBMSProperChargingPracticesViewController
    static let kJLGProperChargingPracticesVC = "JLGBMSProperChargingPracticesViewController"
    static let kJLGProperChargingPracticesCancelButton = "JLGProperChargingPracticesCancelButton"

    /// JLGBMSSelectMachineModelViewController
    static let kJLGSelectMachineModelVC = "JLGBMSSelectMachineModelViewController"
    static let kJLGSelectMachineModelDoneButton = "JLGSelectMachineModelDoneButton"
    static let kJLGSelectMachineModelTableView = "JLGSelectMachineModelTableView"
    static let kJLGSelectModelCell = "JLGSelectModelCell_"
    static let kJLGSelectModelCellZero = "JLGSelectModelCell_0"
}
