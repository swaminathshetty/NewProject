//
//  JLGExtension.swift
//  JLG Control
//
//  Created by L&T on 04/05/18.
//  Copyright © 2018 L&T. All rights reserved.
//

import Foundation
import UIKit
import CommonCrypto

// MARK: - Date extension methods
extension Date {

    /// Returns the amount of years from another date
    func years(from date: Date) -> Int {
        return Calendar.current.dateComponents([.year], from: date, to: self).year ?? 0
    }
    /// Returns the amount of months from another date
    func months(from date: Date) -> Int {
        return Calendar.current.dateComponents([.month], from: date, to: self).month ?? 0
    }
    /// Returns the amount of weeks from another date
    func weeks(from date: Date) -> Int {
        return Calendar.current.dateComponents([.weekOfMonth], from: date, to: self).weekOfMonth ?? 0
    }
    /// Returns the amount of days from another date
    func days(from date: Date) -> Int {
        return Calendar.current.dateComponents([.day], from: date, to: self).day ?? 0
    }
    /// Returns the amount of hours from another date
    func hours(from date: Date) -> Int {
        return Calendar.current.dateComponents([.hour], from: date, to: self).hour ?? 0
    }
    /// Returns the amount of minutes from another date
    func minutes(from date: Date) -> Int {
        return Calendar.current.dateComponents([.minute], from: date, to: self).minute ?? 0
    }
    /// Returns the amount of seconds from another date
    func seconds(from date: Date) -> Int {
        return Calendar.current.dateComponents([.second], from: date, to: self).second ?? 0
    }
    /// Returns the amount of nanoseconds from another date
    func nanoseconds(from date: Date) -> Int {
        return Calendar.current.dateComponents([.nanosecond], from: date, to: self).nanosecond ?? 0
    }
    /// Returns the a custom time interval description from another date
    func offset(from date: Date) -> String {
        if years(from: date)   > 0 { return "\(years(from: date))y"   }
        if months(from: date)  > 0 { return "\(months(from: date))M"  }
        if weeks(from: date)   > 0 { return "\(weeks(from: date))w"   }
        if days(from: date)    > 0 { return "\(days(from: date))d"    }
        if hours(from: date)   > 0 { return "\(hours(from: date))h"   }
        if minutes(from: date) > 0 { return "\(minutes(from: date))m" }
        if seconds(from: date) > 0 { return "\(seconds(from: date))s" }
        if nanoseconds(from: date) > 0 { return "\(nanoseconds(from: date))ns" }
        return ""
    }

    /// Return date string after converting with date formatter
    func PR2DateFormatterUTC() -> String {
        return DateFormatter.PR2DateFormatterUTC.string(from: self)
    }

}

// MARK: - DateFormatter extension methods
extension DateFormatter {
    fileprivate static let PR2DateFormatterUTC: DateFormatter = {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSS"
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC") // Current time zone
        dateFormatter.locale = Locale(identifier: "en_US_POSIX") // Set locale to reliable US_POSIX
        return dateFormatter
    }()
}

// MARK: - Button extension methods
extension UIButton {

    /// Check curent position while click on any region
    open override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        return self.bounds.contains(point) ? self : nil
    }

    /// Add blink animation on button
    func blink(enabled: Bool = true, duration: CFTimeInterval = 1.0, stopAfter: CFTimeInterval = 0.0 ) {
        enabled ? (UIView.animate(withDuration: duration, //Time duration you want,
            delay: 0.0,
            options: [.curveEaseInOut, .autoreverse, .repeat],
            animations: { [weak self] in self?.alpha = 0.5 },
            completion: { [weak self] _ in self?.alpha = 1.0 })) : self.layer.removeAllAnimations()
        if !stopAfter.isEqual(to: 0.0) && enabled {
            DispatchQueue.main.asyncAfter(deadline: .now() + stopAfter) { [weak self] in
                self?.layer.removeAllAnimations()
            }
        }
    }

    /// Add zoom in and out animation on button
    func zoomInAndOut(enabled: Bool = true, duration: CFTimeInterval = 1.0, stopAfter: CFTimeInterval = 0.0 ) {
        enabled ? (UIView.animate(withDuration: duration, //Time duration you want,
            delay: 0.0,
            options: [.curveEaseInOut, .autoreverse, .repeat],
            animations: { self.transform = CGAffineTransform(scaleX: 0.75, y: 0.75)},
            completion: nil)) : self.layer.removeAllAnimations()
        if !stopAfter.isEqual(to: 0.0) && enabled {
            DispatchQueue.main.asyncAfter(deadline: .now() + stopAfter) { [weak self] in
                self?.layer.removeAllAnimations()
            }
        }
    }

}

// MARK: - String extensions
extension String {

    /// Convert html string to swift Attributed String
    var htmlToAttributedString: NSAttributedString? {
        guard let data = data(using: .utf8) else { return NSAttributedString() }
        do {
            return try NSAttributedString(data: data, options: [NSAttributedString.DocumentReadingOptionKey.documentType: NSAttributedString.DocumentType.html], documentAttributes: nil)
        } catch {
            return NSAttributedString()
        }
    }

    /// Convert Attributed String to Swift String
    var htmlToString: String {
        return htmlToAttributedString?.string ?? ""
    }

    /// Remove some char from string
    func chopPrefix(_ count: Int = 1) -> String {
        return count>self.count ? self : String(self[index(self.startIndex, offsetBy: count)...])
    }

    /// Alphanumeric character set
    static var chars: [Character] = {
        return "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".map({$0})
    }()

    /// Generate random string
    static func random(length: Int) -> String {
        var partial: [Character] = []
        for _ in 0..<length {
            let rand = Int(arc4random_uniform(UInt32(chars.count)))
            partial.append(chars[rand])
        }
        return String(partial)
    }

    // Get substring from two string
    func slice(from: String, to: String) -> String? {
        return (range(of: from)?.upperBound).flatMap { substringFrom in
            (range(of: to, range: substringFrom..<endIndex)?.lowerBound).map { substringTo in
                String(self[substringFrom..<substringTo])
            }
        }
    }

}

// MARK: - UIViewControler extensions
extension UIViewController {

    /// Show alert with title, message and action title
    func showAlertWithTitleAndMessage(title: String, message: String, actionTitle: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: actionTitle, style: .cancel, handler: nil)
        alert.addAction(action)
        self.present(alert, animated: true, completion: nil)
    }

    func showNetworkError() {
        showAlertWithTitleAndMessage(title: JLGStringConstants.kNetworkError, message: JLGStringConstants.kNetworkErrorMessage, actionTitle: JLGStringConstants.kAlertActionOK)
    }

    open override func awakeFromNib() {
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
    }
}

// MARK: - Custom Notification Names
/// Custom notification names for callback methods when any event occures
extension Notification.Name {
    static let notificationIdentifierForExitRemoteMode = Notification.Name(
        rawValue: "NotificationIdentifierForExitRemoteMode")
    static let notificationIdentifierForAppRouteToScanVC = Notification.Name(
        rawValue: "NotificationIdentifierForAppRouteToScanVC")
    static let notificationIdentifierForBatteryStatus = Notification.Name(
        rawValue: "NotificationIdentifierForBatteryStatus")
    static let notificationIdentifierForWarningStatus = Notification.Name(
        rawValue: "NotificationIdentifierForWarningStatus")
    static let notificationIdentifierForRemoteStatus = Notification.Name(
        rawValue: "NotificationIdentifierForRemoteStatus")
    static let notificationIdentifierForSessionTimeout = Notification.Name(
        rawValue: "NotificationIdentifierForSessionTimeout")
    static let notificationIdentifierForAuthentication = Notification.Name(
        rawValue: "notificationIdentifierForAuthentication")
    static let notificationIdentifierForOTAReprogramming = Notification.Name(
        rawValue: "notificationIdentifierForOTAReprogramming")
    static let notificationIdentifierForBMSHomeTabBar = Notification.Name(
        rawValue: "notificationIdentifierForBMSHomeTabBar")
    static let notificationIdentifierForAppRouteToRCS = Notification.Name(
        rawValue: "notificationIdentifierForAppRouteToRCS")
    static let notificationIdentifierForBMSHomeTabBarSerialScreen = Notification.Name(
        rawValue: "notificationIdentifierForBMSHomeTabBarSerialScreen")
    static let notificationIdentifierForAppRouteToRCSSerialScreen = Notification.Name(
        rawValue: "notificationIdentifierForAppRouteToRCS")
    static let notificationIdentifierForProtobufMissMatchArray = Notification.Name(
        rawValue: "notificationIdentifierForProtobufMissMatchArray")
    static let notificationIdentifierForAppRouteToMainHomeVC = Notification.Name(
        rawValue: "notificationIdentifierForAppRouteToMainHomeVC")
    static let notificationIdentifierForDisconnectBLEInRCSApp = Notification.Name(
        rawValue: "notificationIdentifierForDisconnectBLEInRCSApp")
    static let notificationIdentifierForDismissDisconnectBLEAlert = Notification.Name(
        rawValue: "notificationIdentifierForDismissDisconnectBLEAlert")
    static let notificationIdentifierForSerialScreenDisconnectBLE = Notification.Name(
        rawValue: "notificationIdentifierForSerialScreenDisconnectBLE")
    static let notificationIdentifierForDismissPresentViewController = Notification.Name(
        rawValue: "notificationIdentifierForDismissPresentViewController")
    static let notificationIdentifierForJLGBTADisconnectBLE = Notification.Name(
        rawValue: "notificationIdentifierForJLGBTADisconnectBLE")
}

// MARK: - Custom NSMutableAttributedString
/// An attributed string extension to achieve colors on text.
extension NSMutableAttributedString {
    func setColor(color: UIColor, forText stringValue: String) {
        let range: NSRange = self.mutableString.range(of: stringValue, options: .caseInsensitive)
        self.addAttribute(NSAttributedStringKey.foregroundColor, value: color, range: range)
    }
}

/// Remove element at perticular index
extension Array where Element: Equatable {
    mutating func removeObject(object: Iterator.Element) {
        if let index = self.index(of: object) {
            self.remove(at: index)
        }
    }
}

/// Remove common elements form array
extension Array where Element: Hashable {
    func removingDuplicates() -> [Element] {
        var addedDict = [Element: Bool]()

        return filter {
            addedDict.updateValue(true, forKey: $0) == nil
        }
    }

    mutating func removeDuplicates() {
        self = self.removingDuplicates()
    }
}

extension UIStackView {
    func addBackground(color: UIColor) {
        let subView = UIView(frame: bounds)
        subView.backgroundColor = color
        subView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        insertSubview(subView, at: 0)
    }
}

extension UINavigationController {
    var previousViewController: UIViewController? {
        return viewControllers.count > 1 ? viewControllers[viewControllers.count - 2] : nil
    }
}

extension String {
    func sha512() -> Data? {
        let stringData = data(using: String.Encoding.utf8)!
        var result = Data(count: Int(CC_SHA512_DIGEST_LENGTH))
        _ = result.withUnsafeMutableBytes { resultBytes in
            stringData.withUnsafeBytes { stringBytes in
                CC_SHA512(stringBytes, CC_LONG(stringData.count), resultBytes)
            }
        }
        return result
    }
}

extension String {
    func substringFromTo(from: Int, to: Int) -> String {
        let start = index(startIndex, offsetBy: from)
        let end = index(start, offsetBy: to - from)
        return String(self[start ..< end])
    }
}

extension String {

    var length: Int {
        return count
    }

    subscript (i: Int) -> String {
        return self[i ..< i + 1]
    }

    func substring(fromIndex: Int) -> String {
        return self[min(fromIndex, length) ..< length]
    }

    func substring(toIndex: Int) -> String {
        return self[0 ..< max(0, toIndex)]
    }

    subscript (r: Range<Int>) -> String {
        let range = Range(uncheckedBounds: (lower: max(0, min(length, r.lowerBound)),
                                            upper: min(length, max(0, r.upperBound))))
        let start = index(startIndex, offsetBy: range.lowerBound)
        let end = index(start, offsetBy: range.upperBound - range.lowerBound)
        return String(self[start ..< end])
    }
}

extension String {
    var isNumeric : Bool {
        return NumberFormatter().number(from: self) != nil
    }
}

/// Tap Gesture Recognizer
class TapGestureReplicator:UIGestureRecognizer {
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent) {
        // Checking the count of touches .
        // If number of finger used in gesture is not equal to one , then gesture should fail.
        guard touches.count == 1 , let _ = touches.first else {
            self.state = .failed
            return
        }
        self.state = .began
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent) {
        guard touches.count == 1 , let _ = touches.first else {
            self.state = .failed
            return
        }
        self.state = .ended
    }
    
}
