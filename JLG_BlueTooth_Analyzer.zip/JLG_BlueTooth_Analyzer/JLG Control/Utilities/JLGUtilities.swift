//
//  JLGUtilities.swift
//  JLG Control
//
//  Created by L&T on 14/05/18.
//  Copyright © 2018 L&T. All rights reserved.
//

import Foundation
import UIKit
import SystemConfiguration
import RealmSwift

// MARK: - Constants
/// Theme color
let themeColor = UIColor.init(red: 236.0/255.0, green: 87.0/255.0, blue: 32.0/255.0, alpha: 1.0)
let tintColor = UIColor.init(red: 235.0/255.0, green: 86.0/255.0, blue: 32.0/255.0, alpha: 1.0)

/// 0 -> Redirect to QR scanning, 1 -> Redirect to Home Screen (btRemEStop/Manual)
var flagForDisconnectPeripheral = 0

var isTimeExceed5Minutes = false
var isOTAFirmwareUpgradeSuccessful = false
var isDeviceBluetoothOff = true
var isDisconnectedBLE = false
var userID = ""

/// Constants for Firebase Analytics
let kUserID = "rcs_userid"
let kTimeStamp = "rcs_timestamp"
let kValue = "rcs_value"
let kDriveStart = "rcs_drive_start"
let kDriveStop = "rcs_drive_stop"
let kDriveDuration = "rcs_drive_duration"

/// Versions for CAN2BLE and OTA firmware upgrade
let minimumVersionToSupportOTAFirmwareUpgrade = 0.26
let currentVersionOfBinaryFile = 0.52
let currentVersionOfGIBinaryFile = 0.55

/// Log file name
var logFileName = JLGStringConstants.kLogFileName

/// RealmSwift Object
let realmConfiguration = Realm.Configuration(encryptionKey: JLGStringConstants.kRelamDBKey.sha512(), readOnly: true)

/// Main storyboard Object
let mainStoryboard = UIStoryboard(name: "Main", bundle: nil)
let jlgBMSFlowStoryBoard = UIStoryboard(name: "JLGBMSFlow", bundle: nil)
let jlgBTAFlowStoryBoard = UIStoryboard(name: "JLGBluetoothAnalyzerFlow", bundle: nil)

/// For checking zero, space and dot objects
let spaceString = " "
let dotString = "."
let zeroString = "0"
let percentageString = "%"

var getRCSTabBarControllerPreviousIndex = 0
var getBMSTabBarControllerPreviousIndex = 0
var getBTATabBarControllerPreviousIndex = 0
var isJLGBMSSerialScreenViewControllerOpen = false

// BluetoothAnalyzer Flow
var isJLGBTAAnalyzerFlowStart = false
let kTopLine = "TOP_LINE"
let kBottomLine = "BOTTOM_LINE"

let kBetaVersion = "B6"
// MARK: - Show/Hide loading view
var loadingView: UIView?

func showLoadingIndicator(_ mainView: UIView) {
    loadingView = UIView(frame: mainView.frame)
    loadingView!.backgroundColor = .black
    loadingView!.alpha = 0.5
    mainView.addSubview(loadingView!)

    let loadingIndicator = UIActivityIndicatorView()
    loadingIndicator.center = loadingView!.center
    loadingIndicator.hidesWhenStopped = true
    loadingIndicator.activityIndicatorViewStyle = .whiteLarge
    loadingIndicator.startAnimating()
    loadingView!.addSubview(loadingIndicator)
}

func hideLoadingIndicator() {
    loadingView?.removeFromSuperview()
    loadingView = nil
}

// MARK: - Append data into log file
func appendLog(text: String) {
    if let documentDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
        let fileURL = documentDirectory.appendingPathComponent(JLGStringConstants.kLogFileName)
        do {
            let fileHandle = try FileHandle(forWritingTo: fileURL)
            fileHandle.seekToEndOfFile()
            fileHandle.write(text.data(using: .utf8)!)
            fileHandle.write("\n".data(using: .utf8)!)
            fileHandle.closeFile()
        } catch {
            print("Error writing to log file ::::: \(error)")
        }
    }
}

//func appendLog(text: String) {
//    if let documentDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
//        let fileURL = documentDirectory.appendingPathComponent(logFileName)
//        do {
//            let fileHandle = try FileHandle(forWritingTo: fileURL)
//            fileHandle.seekToEndOfFile()
//            fileHandle.write(text.data(using: .utf8)!)
//            fileHandle.closeFile()
//        } catch {
//            print("Error writing to file ::::: \(error)")
//        }
//    }
//}

// MARK: - Set print only for debug mode
func print(_ items: Any...) {
    #if DEBUG
    Swift.print(items[0])
    #endif
}

// Check internet connectivity
public class Reachability {

    class func isConnectedToNetwork() -> Bool {

        var zeroAddress = sockaddr_in(sin_len: 0, sin_family: 0, sin_port: 0, sin_addr: in_addr(s_addr: 0), sin_zero: (0, 0, 0, 0, 0, 0, 0, 0))
        zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)

        let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {zeroSockAddress in
                SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)
            }
        }

        var flags: SCNetworkReachabilityFlags = SCNetworkReachabilityFlags(rawValue: 0)
        if SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) == false {
            return false
        }

        let isReachable = (flags.rawValue & UInt32(kSCNetworkFlagsReachable)) != 0
        let needsConnection = (flags.rawValue & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
        let ret = (isReachable && !needsConnection)
        return ret
    }

}

// Stop scanning when remove Fleet screen viewController
func stopFleetScreenScanning() {
    let fleetVC = jlgBMSFlowStoryBoard.instantiateViewController(withIdentifier: "JLGBMSFleetTabViewController") as! JLGBMSFleetTabViewController
    fleetVC.stopScanningViaOtherVC()
}

// Set tint color to segment controller above iOS 13
func setSegmentControlTintColorForIos13(segmentControl: UISegmentedControl) {
    if #available(iOS 13.0, *) {
        segmentControl.selectedSegmentTintColor = tintColor
        let titleTextAttributes = [NSAttributedString.Key.foregroundColor: tintColor]
        segmentControl.setTitleTextAttributes(titleTextAttributes, for: .normal)
        let titleTextAttributes1 = [NSAttributedString.Key.foregroundColor: UIColor.white]
        segmentControl.setTitleTextAttributes(titleTextAttributes1, for: .selected)
    }
}

/**
 *
 * Convert unix time to human readable time. Return empty string if unixtime
 * argument is 0. Note that EMPTY_STRING = ""
 *
 * @param unixdate the time in unix format, e.g. 1482505225
 * @param timezone the user's time zone, e.g. EST, PST
 * @return the date and time converted into human readable String format
 *
 **/

func getUnixDate(unixDate: Int) -> String {
    if unixDate == 0 {return "00/00/0000"}
    let date = NSDate(timeIntervalSince1970: TimeInterval(unixDate))
    let dateFormatter = DateFormatter()
    dateFormatter.timeZone = TimeZone(abbreviation: "UTC") // Current time zone
    dateFormatter.locale = Locale(identifier: "en_US_POSIX") // Set locale to reliable US_POSIX
    dateFormatter.dateFormat = "MM/dd/yyyy" //Specify your format that you want
    let dateString = dateFormatter.string(from: date as Date)
    return "\(dateString)"
}

func getTwoWeekOldDateFormCurrentDate() -> Date {
    let currentDate: Date = Date()
    var calendar: Calendar = Calendar(identifier: Calendar.Identifier.gregorian)

    guard let timeZone = TimeZone(identifier: "UTC") else { return currentDate}
    calendar.timeZone = timeZone

    var components: DateComponents = DateComponents()
    components.calendar = calendar

    components.setValue(-14, for: .day)
    if let minDate: Date = calendar.date(byAdding: components, to: currentDate) {
        return minDate
    }

    return currentDate
}

// Get battery image with respective battery percentage
func getImageName(percentValue: Int) -> String {
    switch percentValue {
    case 10...20: return JLGStringConstants.kFifteenToTwenty
    case 21...30: return JLGStringConstants.kTweentyfiveToThirty
    case 31...55: return JLGStringConstants.kThirtyfiveToFiftyfive
    case 56...79: return JLGStringConstants.kSixtyToSeventyfive
    case 80...: return JLGStringConstants.kEightyToHundred
    default : return JLGStringConstants.kZeroToTen
    }
}

// Get battery percentage string with respective SOC value
func getBatteryPercentageText(percentValue: Int) -> String {
    switch percentValue {
    case 0...20: return JLGStringConstants.kLowText
    case 21...100: return String(percentValue) + percentageString
    default: return JLGStringConstants.kAboveHundredValuePercentage
    }
}

class CustomTextField: UITextField {

    override func layoutSubviews() {
        super.layoutSubviews()

        for view in subviews {
            if let button = view as? UIButton {
                button.setImage(button.image(for: .normal)?.withRenderingMode(.alwaysTemplate), for: .normal)
                button.tintColor = .darkGray
            }
        }
    }
}

// Share file to any platform
func shareFileToAnyPlatform(viewController: UIViewController) {
    if let documentDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
        let fileURL = documentDirectory.appendingPathComponent(JLGStringConstants.kLogFileName)
        // Create the Array which includes the files you want to share
        var filesToShare = [Any]()

        // Add the path of the text file to the Array
        filesToShare.append(fileURL)

        // Make the activityViewController which shows the share-view
        let activityViewController = UIActivityViewController(activityItems: filesToShare, applicationActivities: nil)

        // Show the share-view
        viewController.present(activityViewController, animated: true, completion: nil)
    } else {
        print("failed to share file")
    }
}
