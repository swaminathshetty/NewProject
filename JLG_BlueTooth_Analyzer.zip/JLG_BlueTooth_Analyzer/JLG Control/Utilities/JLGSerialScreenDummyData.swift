//
//  JLGProtobufRequest.swift
//  JLG Control
//
//  Created by Admin on 4/9/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

extension JLGCommunicationManager {
    func createSerialScreenDummyData() -> [String] {
        var dataArray = [String]()
/*
        let string1 = "battery_info {battery_soc: 80 battery_voltage: 24.0 battery_size: 200 battery_type: FLA ac_connection_status: true ac_voltage: 100 charger_state: STANDBY charger_algorithm: 14 charger_time_since_last_charge: 675000 estimated_battery_maint_percent: 100 last_battery_maint_date: 1590364800 battery_install_date: 1590364800 last_charge_soc_reached: 90}"
        let string2 = "machine_info { asset_id: '9876432'} "
        let string3 = "battery_history { last_charge_cycle { battery_soc: 0 time_stamp: 640004 battery_state: START_OF_CHARGE } last_charge_cycle { battery_soc: 100 time_stamp: 640006 battery_state: START_OF_DISCHARGE } last_charge_cycle { battery_soc: 0 time_stamp: 640007 battery_state: DISCHARGING } }"
        let string4 = "battery_history { last_five_cycles { battery_soc: 0 time_stamp: 639988 battery_state: START_OF_CHARGE } last_five_cycles { battery_soc: 80 time_stamp: 639990 battery_state: START_OF_DISCHARGE } last_five_cycles { battery_soc: 60 time_stamp: 639992 battery_state: START_OF_CHARGE } last_five_cycles { battery_soc: 99 time_stamp: 639994 battery_state: START_OF_DISCHARGE } last_five_cycles { battery_soc: 40 time_stamp: 639995 battery_state: START_OF_CHARGE } last_five_cycles { battery_soc: 100 time_stamp: 639996 battery_state: START_OF_DISCHARGE } } "
        let string5 = "battery_history { last_five_cycles { battery_soc: 50 time_stamp: 639998 battery_state: START_OF_CHARGE } last_five_cycles { battery_soc: 100 time_stamp: 639999 battery_state: START_OF_DISCHARGE } last_five_cycles { battery_soc: 20 time_stamp: 640000 battery_state: START_OF_CHARGE } last_five_cycles { battery_soc: 100 time_stamp: 640003 battery_state: START_OF_DISCHARGE } last_five_cycles { battery_soc: 30 time_stamp: 640004 battery_state: START_OF_CHARGE } } "
//        let string6 = "charger_fault_list { fault_codes { spn: 7 fmi: 16 } fault_codes { spn: 77 fmi: 8 } fault_codes { spn: 123 fmi: 4 } fault_codes { spn: 579 fmi: 22 } fault_codes { spn: 7410 fmi: 0 } fault_codes { spn: 9978 fmi: 11 } } "
        let string6 = "charger_fault_list { fault_codes { spn: 4993 fmi: 5 } fault_codes { spn: 4992 fmi: 16 } fault_codes { spn: 4992 fmi: 18 } fault_codes { spn: 524161 fmi: 32 } fault_codes { spn: 524160 fmi: 31 }}"
//        let string7 = "dtc_list { dtc_number: 123 dtc_number: 234 dtc_number: 99999 dtc_number: 123456 } "
        let string7 = "dtc_list { dtc_number: 44137 dtc_number: 44136 dtc_number: 001} "
        let string8 = "alarm_alert_status { machine_alarm_active: true charger_alarm_active: false charger_alert_active: true } "
        let string9 = "bms_alerts { bms_alert_list { alert_id: BA_FREEZE_WARNING alert_active: true count: 1 } bms_alert_list { alert_id: BA_LOW_WATER_WARNING alert_active: true count: 1 } bms_alert_list { alert_id: BA_DISCHARGED_BATTERY alert_active: true count: 2 } bms_alert_list { alert_id: BA_DEEP_DISCHARGED_BATTERY alert_active: true count: 1 } bms_alert_list { alert_id: BA_LOW_SOC_CHARGING alert_active: true count: 0} } "
        let string10 = "machine_info { serial_number: 'Serial123'}"
        let string11 = "service_connect {vehicle_type: 0 vehicle_model: 20 vehicle_market: 3}"

        dataArray.append(string1)
        dataArray.append(string2)
        dataArray.append(string3)
        dataArray.append(string4)
        dataArray.append(string5)
        dataArray.append(string6)
        dataArray.append(string7)
        dataArray.append(string8)
        dataArray.append(string9)
        dataArray.append(string10)
        dataArray.append(string11)
*/
        /// Bluetooth Analyzer Dummy Data

        let bta_Top_Line1 = "analyzer_message { analyzer_data { line_data: 'test text 133456' line_type: TOP_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Top_Line1)
        //}//
/*
        let bta_Bottom_Line1 = "analyzer_message { analyzer_data { line_data: 'BATTERY VOLTAGE ' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line1)
        //}//

        let bta_Bottom_Line2 = "analyzer_message { analyzer_data { line_data: 'ATTERY VOLTAGE L' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line2)
        //}//

        let bta_Bottom_Line3 = "analyzer_message { analyzer_data { line_data: 'TTERY VOLTAGE LO' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line3)
        //}//

        let bta_Bottom_Line4 = "analyzer_message { analyzer_data { line_data: 'TERY VOLTAGE LOW' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line4)
        //}//
        
        let bta_Bottom_Line15 = "analyzer_message { analyzer_data { line_data: 'ERY VOLTAGE LOW ' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line15)
        //}//

        let bta_Bottom_Line16 = "analyzer_message { analyzer_data { line_data: 'RY VOLTAGE LOW B' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line16)
        //}//

        let bta_Bottom_Line17 = "analyzer_message { analyzer_data { line_data: 'Y VOLTAGE LOW BA' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line17)
        //}//

        let bta_Bottom_Line18 = "analyzer_message { analyzer_data { line_data: ' VOLTAGE LOW BAT' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line18)
        //}//

        let bta_Bottom_Line19 = "analyzer_message { analyzer_data { line_data: 'VOLTAGE LOW BATT' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line19)
        //}//

        let bta_Bottom_Line20 = "analyzer_message { analyzer_data { line_data: 'OLTAGE LOW BATTE' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line20)
        //}//

        let bta_Bottom_Line21 = "analyzer_message { analyzer_data { line_data: 'LTAGE LOW BATTER' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line21)
        //}//

        let bta_Bottom_Line22 = "analyzer_message { analyzer_data { line_data: 'TAGE LOW BATTERY' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line22)
        //}//

        let bta_Bottom_Line23 = "analyzer_message { analyzer_data { line_data: 'AGE LOW BATTERY ' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line23)
        //}//

        let bta_Bottom_Line24 = "analyzer_message { analyzer_data { line_data: 'GE LOW BATTERY V' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line24)
        //}//

        let bta_Bottom_Line25 = "analyzer_message { analyzer_data { line_data: 'E LOW BATTERY VO' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line25)
        //}//

        let bta_Bottom_Line26 = "analyzer_message { analyzer_data { line_data: ' LOW BATTERY VOL' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line26)
        //}//

        let bta_Bottom_Line27 = "analyzer_message { analyzer_data { line_data: 'LOW BATTERY VOLT' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line27)
        //}//

        let bta_Bottom_Line28 = "analyzer_message { analyzer_data { line_data: 'OW BATTERY VOLTA' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line28)
        //}//

        let bta_Bottom_Line29 = "analyzer_message { analyzer_data { line_data: 'W BATTERY VOLTAG' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line29)
        //}//

        let bta_Bottom_Line30 = "analyzer_message { analyzer_data { line_data: ' BATTERY VOLTAGE' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line30)
        //}//

        let bta_Bottom_Line31 = "analyzer_message { analyzer_data { line_data: 'BATTERY VOLTAGE ' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line31)
        //}//
*/
        /*
        //--
        let bta_Bottom_Line32 = "analyzer_message { analyzer_data { line_data: 'BATTERY CHARGER ' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line32)
        //}//

        let bta_Bottom_Line33 = "analyzer_message { analyzer_data { line_data: 'ATTERY CHARGER -' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line33)
        //}//

        let bta_Bottom_Line34 = "analyzer_message { analyzer_data { line_data: 'TTERY CHARGER - ' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line34)
        //}//

        let bta_Bottom_Line35 = "analyzer_message { analyzer_data { line_data: 'TERY CHARGER - F' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line35)
        //}//

        let bta_Bottom_Line36 = "analyzer_message { analyzer_data { line_data: 'ERY CHARGER - FA' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line36)
        //}//
        
        let bta_Bottom_Line37 = "analyzer_message { analyzer_data { line_data: 'RY CHARGER - FAU' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line37)
        //}//

        let bta_Bottom_Line38 = "analyzer_message { analyzer_data { line_data: 'Y CHARGER - FAUL' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line38)
        //}//
        
        let bta_Bottom_Line39 = "analyzer_message { analyzer_data { line_data: ' CHARGER - FAULT' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line39)
        //}//

        let bta_Bottom_Line40 = "analyzer_message { analyzer_data { line_data: 'CHARGER - FAULT ' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line40)
        //}//
        
        let bta_Bottom_Line41 = "analyzer_message { analyzer_data { line_data: 'HARGER - FAULT 5' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line41)
        //}//

        let bta_Bottom_Line42 = "analyzer_message { analyzer_data { line_data: 'ARGER - FAULT 52' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line42)
        //}//

        let bta_Bottom_Line43 = "analyzer_message { analyzer_data { line_data: 'RGER - FAULT 524' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line43)
        //}//

        let bta_Bottom_Line44 = "analyzer_message { analyzer_data { line_data: 'GER - FAULT 5240' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line44)
        //}//

        let bta_Bottom_Line45 = "analyzer_message { analyzer_data { line_data: 'ER - FAULT 52403' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line45)
        //}//

        let bta_Bottom_Line46 = "analyzer_message { analyzer_data { line_data: 'R - FAULT 524035' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line46)
        //}//

        let bta_Bottom_Line47 = "analyzer_message { analyzer_data { line_data: ' - FAULT 524035:' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line47)
        //}//

        let bta_Bottom_Line48 = "analyzer_message { analyzer_data { line_data: '- FAULT 524035:9' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line48)
        //}//

        let bta_Bottom_Line49 = "analyzer_message { analyzer_data { line_data: ' FAULT 524035:9 ' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line49)
        //}//

        let bta_Bottom_Line50 = "analyzer_message { analyzer_data { line_data: 'FAULT 524035:9  ' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line50)
        //}//
        
        let bta_Bottom_Line51 = "analyzer_message { analyzer_data { line_data: 'AULT 524035:9   ' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line51)
        //}//

        let bta_Bottom_Line52 = "analyzer_message { analyzer_data { line_data: 'ULT 524035:9   B' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line52)
        //}//

        let bta_Bottom_Line53 = "analyzer_message { analyzer_data { line_data: 'LT 524035:9   BA' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line53)
        //}//
        
        let bta_Bottom_Line54 = "analyzer_message { analyzer_data { line_data: 'T 524035:9   BAT' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line54)
        //}//

        let bta_Bottom_Line55 = "analyzer_message { analyzer_data { line_data: ' 524035:9   BATT' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line55)
        //}//

        let bta_Bottom_Line56 = "analyzer_message { analyzer_data { line_data: '524035:9   BATTE' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line56)
        //}//

        let bta_Bottom_Line57 = "analyzer_message { analyzer_data { line_data: '24035:9   BATTER' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line57)
        //}//

        let bta_Bottom_Line58 = "analyzer_message { analyzer_data { line_data: '4035:9   BATTERY' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line58)
        //}//

        let bta_Bottom_Line59 = "analyzer_message { analyzer_data { line_data: '035:9   BATTERY ' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line59)
        //}//

        let bta_Bottom_Line60 = "analyzer_message { analyzer_data { line_data: '35:9   BATTERY C' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line60)
        //}//

        let bta_Bottom_Line61 = "analyzer_message { analyzer_data { line_data: '5:9   BATTERY CH' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line61)
        //}//

        let bta_Bottom_Line62 = "analyzer_message { analyzer_data { line_data: ':9   BATTERY CHA' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line62)
        //}//

        let bta_Bottom_Line63 = "analyzer_message { analyzer_data { line_data: '9   BATTERY CHAR' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line63)
        //}//

        let bta_Bottom_Line64 = "analyzer_message { analyzer_data { line_data: '   BATTERY CHARG' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line64)
        //}//

        let bta_Bottom_Line65 = "analyzer_message { analyzer_data { line_data: '  BATTERY CHARGE' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line65)
        //}//

        let bta_Bottom_Line66 = "analyzer_message { analyzer_data { line_data: ' BATTERY CHARGER' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line66)
        //}//

        let bta_Bottom_Line67 = "analyzer_message { analyzer_data { line_data: 'BATTERY CHARGER ' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line67)
        //}//
*/
        //--
        /*
        let bta_Bottom_Line5 = "analyzer_message { analyzer_data { line_data: 'BATTERY VOLTAGE ' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line5)
        }

        let bta_Bottom_Line6 = "analyzer_message { analyzer_data { line_data: 'ATTERY VOLTAGE H' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line6)
        }

        let bta_Bottom_Line7 = "analyzer_message { analyzer_data { line_data: 'TTERY VOLTAGE HI' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line7)
        }
        
        let bta_Bottom_Line8 = "analyzer_message { analyzer_data { line_data: 'TERY VOLTAGE HIG' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line8)
        }

        let bta_Bottom_Line9 = "analyzer_message { analyzer_data { line_data: 'ERY VOLTAGE HIGH' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line9)
        }

        let bta_Bottom_Line10 = "analyzer_message { analyzer_data { line_data: 'BATTERY VOLTAGE ' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line10)
        }

        let bta_Bottom_Line11 = "analyzer_message { analyzer_data { line_data: 'ATTERY VOLTAGE M' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line11)
        }

        let bta_Bottom_Line12 = "analyzer_message { analyzer_data { line_data: 'TTERY VOLTAGE MI' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line12)
        }

        let bta_Bottom_Line13 = "analyzer_message { analyzer_data { line_data: 'TERY VOLTAGE MID' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line13)
        }
        
        let bta_Bottom_Line14 = "analyzer_message { analyzer_data { line_data: 'NO Data' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line14)
        }
*/

        let bta_Bottom_Line72 = "analyzer_message { analyzer_data { line_data: '5:DRIVE PREVENTE\000' line_type: BOTTOM_LINE }}"
        //for _ in 0...5 {
           dataArray.append(bta_Bottom_Line72)
        //}//

        let bta_Bottom_Line73 = "analyzer_message { analyzer_data { line_data: '5:RIVE PREVENTED\000' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line73)
        //}//

        let bta_Bottom_Line74 = "analyzer_message { analyzer_data { line_data: '5:IVE PREVENTED \000' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line74)
        //}//

        let bta_Bottom_Line75 = "analyzer_message { analyzer_data { line_data: '5:VE PREVENTED -\000' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line75)
        //}//

        let bta_Bottom_Line76 = "analyzer_message { analyzer_data { line_data: '5:E PREVENTED - \000' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line76)
        //}//

        let bta_Bottom_Line77 = "analyzer_message { analyzer_data { line_data: '5: PREVENTED - C\000' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line77)
        //}//

        let bta_Bottom_Line78 = "analyzer_message { analyzer_data { line_data: '5:PREVENTED - CH\000' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line78)
        //}//

        let bta_Bottom_Line79 = "analyzer_message { analyzer_data { line_data: '5:REVENTED - CHA\000' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line79)
        //}//

        let bta_Bottom_Line80 = "analyzer_message { analyzer_data { line_data: '5:EVENTED - CHAR\000' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line80)
        //}//

        let bta_Bottom_Line81 = "analyzer_message { analyzer_data { line_data: '5:VENTED - CHARG\000' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line81)
        //}//

        let bta_Bottom_Line82 = "analyzer_message { analyzer_data { line_data: '5:ENTED - CHARGE\000' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line82)
        //}//

        let bta_Bottom_Line83 = "analyzer_message { analyzer_data { line_data: '5:NTED - CHARGER\000' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line83)
        //}//

        let bta_Bottom_Line84 = "analyzer_message { analyzer_data { line_data: '5:TED - CHARGER \000' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line84)
        //}//

        let bta_Bottom_Line85 = "analyzer_message { analyzer_data { line_data: '5:ED - CHARGER  \000' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line85)
        //}//

        let bta_Bottom_Line86 = "analyzer_message { analyzer_data { line_data: '5:D - CHARGER   \000' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line86)
        //}//
        
        let bta_Bottom_Line87 = "analyzer_message { analyzer_data { line_data: '5: - CHARGER   D\000' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line87)
        //}//

        let bta_Bottom_Line88 = "analyzer_message { analyzer_data { line_data: '5:- CHARGER   DR\000' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line88)
        //}//

        let bta_Bottom_Line89 = "analyzer_message { analyzer_data { line_data: '5: CHARGER   DRI\000' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line89)
        //}//

        let bta_Bottom_Line90 = "analyzer_message { analyzer_data { line_data: '5:CHARGER   DRIV\000' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line90)
        //}//

        let bta_Bottom_Line91 = "analyzer_message { analyzer_data { line_data: '5:HARGER   DRIVE\000' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line91)
        //}//

        let bta_Bottom_Line92 = "analyzer_message { analyzer_data { line_data: '5:ARGER   DRIVE \000' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line92)
        //}//

        let bta_Bottom_Line93 = "analyzer_message { analyzer_data { line_data: '5:RGER   DRIVE P\000' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line93)
        //}//

        let bta_Bottom_Line94 = "analyzer_message { analyzer_data { line_data: '5:GER   DRIVE PR\000' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line94)
        //}//

        let bta_Bottom_Line95 = "analyzer_message { analyzer_data { line_data: '5:ER   DRIVE PRE\000' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line95)
        //}//
        
        let bta_Bottom_Line96 = "analyzer_message { analyzer_data { line_data: '5:R   DRIVE PREV\000' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line96)
        //}//

        let bta_Bottom_Line97 = "analyzer_message { analyzer_data { line_data: '5:   DRIVE PREVE\000' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line97)
        //}//

        let bta_Bottom_Line98 = "analyzer_message { analyzer_data { line_data: '5:  DRIVE PREVEN\000' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line98)
        //}//

        let bta_Bottom_Line99 = "analyzer_message { analyzer_data { line_data: '5: DRIVE PREVENT\000' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line99)
        //}//

        let bta_Bottom_Line100 = "analyzer_message { analyzer_data { line_data: '5:DRIVE PREVENTE\000' line_type: BOTTOM_LINE }}"
        //for _ in 0...3 {
           dataArray.append(bta_Bottom_Line100)
        //}//

        return dataArray
    }
}
