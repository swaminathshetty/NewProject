//
//  GoogleAnalyticsViewController.swift
//  JLG Control
//
//  Created by Mark Duchesne on 6/6/19.
//  Copyright © 2019 L&T. All rights reserved.
//

import UIKit

class GoogleAnalyticsViewController: GAITrackedViewController {
    override func viewDidLoad() {
        self.screenName = NSStringFromClass(type(of: self)).components(separatedBy: ".").last
        super.viewDidLoad()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        GAI.sharedInstance()?.dispatch()
    }
}
