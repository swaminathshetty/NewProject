//
//  JLGRCSTabBarController.swift
//  JLG Control
//
//  Created by L&T on 18/04/18.
//  Copyright © 2018 L&T. All rights reserved.
//

import UIKit

class JLGRCSTabBarController: UITabBarController {

    // MARK: - View life cycle events
    override func viewDidLoad() {
        super.viewDidLoad()
        /// For Unit and UI Testing
        if CommandLine.arguments.contains(JLGTestingConstant.kEnableTesting) {
            assigningAccessibilityIdentifier()
        }

        self.selectedIndex = 1

        /// Setup appearance of tab bar
        let appearance = UITabBarItem.appearance(whenContainedInInstancesOf: [JLGRCSTabBarController.self])
        appearance.setTitleTextAttributes([NSAttributedStringKey.foregroundColor: UIColor.gray], for: .normal)
        appearance.setTitleTextAttributes([NSAttributedStringKey.foregroundColor: themeColor], for: .selected)
    }

}

extension JLGRCSTabBarController {
    /// Assigning Accessibility Identifier For UI Testing
    func assigningAccessibilityIdentifier() {
        if #available(iOS 11.0, *) {
            self.tabBar.accessibilityIdentifier = JLGTestingConstant.kJLGRCSTabBarController
        }
    }
}
