//
//  JLGBTAHelpViewController.swift
//  JLG Control
//
//  Created by LTTS_iMac_Conti on 11/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class JLGBTAHelpViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.titleView = UIImageView(image: UIImage(named: JLGStringConstants.kJLGMobileControlLogo))

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        getBTATabBarControllerPreviousIndex = 3
    }

}
