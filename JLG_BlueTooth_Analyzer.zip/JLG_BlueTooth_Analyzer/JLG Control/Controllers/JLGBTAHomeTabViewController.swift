//
//  JLGBTAHomeTabViewController.swift
//  JLG Control
//
//  Created by Apple on 21/07/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class JLGBTAHomeTabViewController: GoogleAnalyticsViewController, JLGAlertBackToHomeViewControllerDelegate {
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.titleView = UIImageView(image: UIImage(named: JLGStringConstants.kJLGMobileControlLogo))
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.showAlertBackToHome()
    }
}

// MARK: - JLGBMSHomeTabViewController Delegate
extension JLGBTAHomeTabViewController {
    func showAlertBackToHome() {
        let backToHomeVC = JLGAlertBackToHomeViewController()
        backToHomeVC.showAlertForBackToHomeViewController(viewController: self)
        backToHomeVC.delegate = self
    }

    func didSelectBackToHomeConfirmButton() {
        NotificationCenter.default.post(name: .notificationIdentifierForJLGBTADisconnectBLE, object: nil)
        isJLGBTAAnalyzerFlowStart = false
        NotificationCenter.default.post(name: .notificationIdentifierForAppRouteToMainHomeVC, object: nil)
    }

    func didSelectBackToHomeCancelButton() {
        if let tabBar = self.tabBarController as? JLGBTATabBarController {
            tabBar.selectedIndex = getBTATabBarControllerPreviousIndex
        }
    }
}
