//
//  JLGBTAAnalyzerViewController.swift
//  JLG Control
//
//  Created by Apple on 21/07/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit
import CoreBluetooth

class JLGBTAAnalyzerViewController: GoogleAnalyticsViewController, JLGSerialScreenModelDelegate, JLGBLEDelegate {
    @IBOutlet weak var controllerViewBackgroundImage: UIImageView!
    @IBOutlet weak var topLineLabel: UILabel!
    @IBOutlet weak var bottomLineLabel: UILabel!
    @IBOutlet weak var modelLabel: UILabel!
    @IBOutlet weak var assetIDLabel: UILabel!
    @IBOutlet weak var escButton: UIButton!
    @IBOutlet weak var upArrowButton: UIButton!
    @IBOutlet weak var enterButton: UIButton!
    @IBOutlet weak var leftArrowButton: UIButton!
    @IBOutlet weak var rightArrowButton: UIButton!
    @IBOutlet weak var downArrowButton: UIButton!
    @IBOutlet weak var rightBarCustomButton: UIButton!
    
    fileprivate var serialScreenSharedObject = JLGSerialScreenModel.sharedInstance
    fileprivate var topLineText = ""
    fileprivate var bottomLineText = ""
    fileprivate var serialNumber = ""
    fileprivate var isCharFlashing = false

    var shouldRetryToConnect = true
    var isConnectedToJLGBLE = false
    var peripheralsArray: [[String: Any]]?
    var isDisconnectByBTANotification = false
    var qrCodeScanVCDictionary: NSDictionary?

    // MARK: - View life cycle events
    override func viewDidLoad() {
        super.viewDidLoad()
        //Create appInfo View
        //let cv = JLGVersionInfoView.init()
        //self.view.addSubview(cv)
        
        self.navigationItem.titleView = UIImageView(image: UIImage(named: JLGStringConstants.kJLGMobileControlLogo))
        NotificationCenter.default.addObserver(self, selector: #selector(disconnectBLEOnBTA), name: .notificationIdentifierForJLGBTADisconnectBLE, object: nil)
        JLGBLEManager.sharedInstance.delegate = self
        flagForDisconnectPeripheral = 0
        self.initialSetUp()
        self.addButtonsTapGesture()
        self.sendProtobufRequest()

        let peripheralDictionaryKey = JLGBLEManager.sharedInstance.qrCodeSerialOrMachineDecalNumber.count == 8 ? JLGStringConstants.kVehiclePin : JLGStringConstants.kSerialNumber
        for (index, peripheralDictionary) in JLGBLEManager.sharedInstance.peripheralsInfo.enumerated() where peripheralDictionary[peripheralDictionaryKey] as! Substring == JLGBLEManager.sharedInstance.qrCodeSerialOrMachineDecalNumber {
            let peripheralObj: NSDictionary = JLGBLEManager.sharedInstance.peripheralsInfo[index] as NSDictionary
            self.serialNumber = peripheralObj.value(forKey: JLGStringConstants.kSerialNumber) as! String
        }
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        getBTATabBarControllerPreviousIndex = 1
    }
    
    /// Set initial values
    func initialSetUp() {
        self.topLineText = ""
        self.bottomLineText = ""
        self.topLineLabel.text = ""
        self.bottomLineLabel.text = ""
        self.modelLabel.text = JLGStringConstants.kModelIDLabel
        self.assetIDLabel.text = JLGStringConstants.kAssetIDLabel
    }
    
    /// Send request protobuf request
    func sendProtobufRequest() {
        self.serialScreenSharedObject.delegateJLGSerialScreenModel = self
        self.serialScreenSharedObject.createPrtobufRequest(reqType: .infoSerialNumber)
        self.serialScreenSharedObject.createPrtobufRequest(reqType: .infoAssetID)
        self.serialScreenSharedObject.createPrtobufRequest(reqType: .serviceConnect)
        self.serialScreenSharedObject.createPrtobufRequest(reqType: .analyzerMessage_start)
    }
    
    /// Stop protobuf request and set initial values
    func stopProtobufRequest(){
        self.serialScreenSharedObject.createPrtobufRequest(reqType: .analyzerMessage_stop)
        self.initialSetUp()
    }
    
    /// When notification is received form home tab or connect tab
    @objc func disconnectBLEOnBTA() {
        //self.serialScreenSharedObject.createPrtobufRequest(reqType: .analyzerMessage_stop)
        isDisconnectByBTANotification = true
        JLGBLEManager.sharedInstance.stopScanning()
        JLGBLEManager.sharedInstance.disconnectFromPeripheral()
        self.serialScreenSharedObject.resetAllValue()
        NotificationCenter.default.removeObserver(self, name: .notificationIdentifierForJLGBTADisconnectBLE, object: nil)
    }
    
    /// Navigation bar right corner button action
    @IBAction func rightBarCustomButtonAction(_ sender: Any) {
        if JLGBLEManager.sharedInstance.activePeripheral == nil || JLGBLEManager.sharedInstance.activePeripheral?.state != .connected {
            self.tryToConnectToBLE()
        } else {
            self.showAlertForDisconnectPermission()
        }
    }
    
    /// Show alert to ask disconnect permission
    func showAlertForDisconnectPermission() {
        let alertControllerForDisconnection = UIAlertController(title: JLGStringConstants.kAlertTitleDisconnectJLGLift, message: JLGStringConstants.kAlertMessageDisconnection, preferredStyle: UIAlertControllerStyle.alert)
        alertControllerForDisconnection.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionCancel, style: .default, handler: nil))
        alertControllerForDisconnection.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionDisconnect, style: .default) { _ in
            self.disconnectBluetooth()
        })
        self.present(alertControllerForDisconnection, animated: true, completion: nil)
    }

    // MARK: - Disconnect bluetooth connection
    func disconnectBluetooth() {
        if flagForDisconnectPeripheral == 1 {
            flagForDisconnectPeripheral = 0
            self.showAlertForBLEConnectionLost(title: JLGStringConstants.kAlertTitleBLEDisconnected, message: JLGStringConstants.kAlertMessageBLEDisconnected)
            updateUIForDisconnection()
        } else {
            hideLoadingIndicator()
            showLoadingIndicator(self.tabBarController!.view)
            JLGBLEManager.sharedInstance.disconnectFromPeripheral()
        }
    }

    /// Show alert if bluetooth connection is lost
    func showAlertForBLEConnectionLost(title: String, message: String) {
        hideLoadingIndicator()
        self.stopProtobufRequest()
        JLGBLEManager.sharedInstance.delegate = self
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionOK, style: .default, handler: nil))
        alert.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionRetry, style: .default) { _ in
            self.tryToConnectToBLE()
        })
        self.present(alert, animated: true, completion: nil)
    }

    /// Update UI for disconnection
    func updateUIForDisconnection() {
        shouldRetryToConnect = true
        self.updateNavigationRightBarItem(withImage: "BluetoothDisconnected")
        isDisconnectedBLE = true
    }

    /// Update navigation right custom button image
    func updateNavigationRightBarItem(withImage imageName: String) {
        rightBarCustomButton.setImage(UIImage(named: imageName), for: .normal)
    }
}

// MARK: - JLG Serial Screen Model Delegate
extension JLGBTAAnalyzerViewController {
    /// Set Model Number
    func setMachineModelNumber() {
        var machineModelText = JLGStringConstants.kUnknownText
        let jlgMachineModelParser = JLGMachineModelParser()
        if let vehicleMarket = serialScreenSharedObject.serviceConnectModel?.vehicleType, let vehicleModel = serialScreenSharedObject.serviceConnectModel?.vehicleModel {
            let machineModel = jlgMachineModelParser.parseCanVenType(byte: UInt8(vehicleMarket), mByte: UInt8(vehicleModel))
            if machineModel != "" {
                machineModelText = machineModel
            }
        }
        self.modelLabel.text = JLGStringConstants.kModelIDLabel + spaceString + machineModelText
    }

    // Set AssetID
    func setAssetID(bleSerialNumberValue: String) {
        var assetIDText = serialScreenSharedObject.assetIdModel.assetID
        if assetIDText == zeroString || assetIDText == "" {
            if let machineSerialNo = serialScreenSharedObject.serialNumberModel?.serialNumber {
                assetIDText = machineSerialNo
            }

            if assetIDText == zeroString || assetIDText == "" {
                assetIDText = bleSerialNumberValue
            }
        }
        self.assetIDLabel.text = JLGStringConstants.kAssetIDLabel + spaceString + assetIDText
    }

    /// Delegate method for update the Set Asset ID and Machine Model Number
    func updateBTAAnalyzerScreen() {
        self.setMachineModelNumber()
        self.setAssetID(bleSerialNumberValue: self.serialNumber)
    }

    /// Set values in top and bottom line
    func updateLabelData() {
        self.topLineLabel.text = self.topLineText
        self.bottomLineLabel.text = self.bottomLineText
    }

    /// Delegate method for Set bottom line data
    func updateBluetoothAnalyzerData() {
        let lineData = self.serialScreenSharedObject.analyzerDataModel.lineData
        if self.serialScreenSharedObject.analyzerDataModel.lineType == kTopLine {
            self.setTopLineText(lineData: lineData)
        } else if self.serialScreenSharedObject.analyzerDataModel.isCharBlink {
            self.setBottomLineTextWithCharBlink(lineData: lineData)
        } else {
            self.setBottomLineText(lineData: lineData)
        }
    }
    
    func setTopLineText(lineData: String) {
        if self.topLineText != lineData {
            self.topLineText = lineData
            self.updateLabelData()
        }
    }
    
    func setBottomLineTextWithCharBlink(lineData: String) {
        let attributedString = NSMutableAttributedString(string: lineData)
        let myRange = NSRange(location: self.serialScreenSharedObject.analyzerDataModel.positionOfCharBlink, length: 1)
        
        var anotherAttribute: [NSAttributedString.Key : Any] = [NSAttributedString.Key.backgroundColor: UIColor.clear]
        if isCharFlashing {
            anotherAttribute = [NSAttributedString.Key.backgroundColor: UIColor.black]
        }
        isCharFlashing = !isCharFlashing

        attributedString.addAttributes(anotherAttribute, range: myRange)
        self.bottomLineLabel.attributedText = attributedString
    }

    func setBottomLineText(lineData: String) {
        if self.bottomLineText != lineData {
            self.bottomLineText = lineData
            self.updateLabelData()
        }
    }
    
}

// MARK: - Adding all six button Gesture
extension JLGBTAAnalyzerViewController {
    func addButtonsTapGesture() {
        let tapGesture_EscButton = TapGestureReplicator(target: self, action: #selector(tapPressGestureRecognizer_EscButton(_:)))
        self.escButton.addGestureRecognizer(tapGesture_EscButton)
        
        let tapGesture_UpArrowButton = TapGestureReplicator(target: self, action: #selector(tapPressGestureRecognizer_upArrowButton(_:)))
        self.upArrowButton.addGestureRecognizer(tapGesture_UpArrowButton)
        
        let tapGesture_EnterButton = TapGestureReplicator(target: self, action: #selector(tapPressGestureRecognizer_EnterButton(_:)))
        self.enterButton.addGestureRecognizer(tapGesture_EnterButton)

        let tapGesture_LeftArrowButton = TapGestureReplicator(target: self, action: #selector(tapPressGestureRecognizer_LeftArrowButton(_:)))
        self.leftArrowButton.addGestureRecognizer(tapGesture_LeftArrowButton)

        let tapGesture_RightArrowButton = TapGestureReplicator(target: self, action: #selector(tapPressGestureRecognizer_RightArrowButton(_:)))
        self.rightArrowButton.addGestureRecognizer(tapGesture_RightArrowButton)

        let tapGesture_DownArrowButton = TapGestureReplicator(target: self, action: #selector(tapPressGestureRecognizer_DownArrowButton(_:)))
        self.downArrowButton.addGestureRecognizer(tapGesture_DownArrowButton)
    }
    
    
    @objc func tapPressGestureRecognizer_EscButton(_ sender: UIGestureRecognizer) {
        if sender.state == .began {
            self.setButtonPressedDefaultValues()
            appendLog(text: "\(Date()): Esc_Button_Pressed")
            self.serialScreenSharedObject.createPrtobufRequest(reqType: .analyzerMessage_escape)
            self.controllerViewBackgroundImage.image = UIImage(named: JLGStringConstants.kBTAControlButtonEscPress)
        } else if sender.state == .ended {
            self.controllerViewBackgroundImage.image = UIImage(named: JLGStringConstants.kBTAControlButtonDefault)
        }
    }
    
    @objc func tapPressGestureRecognizer_upArrowButton(_ sender: UIGestureRecognizer) {
        if sender.state == .began {
            self.setButtonPressedDefaultValues()
            appendLog(text: "\(Date()): Up_Arrow_Button_Pressed")
            self.serialScreenSharedObject.createPrtobufRequest(reqType: .analyzerMessage_up)
            self.controllerViewBackgroundImage.image = UIImage(named: JLGStringConstants.kBTAControlButtonUpArrowPress)
        } else if sender.state == .ended {
            self.controllerViewBackgroundImage.image = UIImage(named: JLGStringConstants.kBTAControlButtonDefault)
        }
    }

    @objc func tapPressGestureRecognizer_EnterButton(_ sender: UIGestureRecognizer) {
        if sender.state == .began {
            self.setButtonPressedDefaultValues()
            appendLog(text: "\(Date()): Enter_Button_Pressed")
            self.serialScreenSharedObject.createPrtobufRequest(reqType: .analyzerMessage_enter)
            self.controllerViewBackgroundImage.image = UIImage(named: JLGStringConstants.kBTAControlButtonEnterPress)
        } else if sender.state == .ended {
            self.controllerViewBackgroundImage.image = UIImage(named: JLGStringConstants.kBTAControlButtonDefault)
        }
    }

    @objc func tapPressGestureRecognizer_LeftArrowButton(_ sender: UIGestureRecognizer) {
        if sender.state == .began {
            self.setButtonPressedDefaultValues()
            appendLog(text: "\(Date()): Left_Arrow_Button_Pressed")
            self.serialScreenSharedObject.createPrtobufRequest(reqType: .analyzerMessage_left)
            self.controllerViewBackgroundImage.image = UIImage(named: JLGStringConstants.kBTAControlButtonLeftArrowPress)
        } else if sender.state == .ended {
            self.controllerViewBackgroundImage.image = UIImage(named: JLGStringConstants.kBTAControlButtonDefault)
        }
    }

    @objc func tapPressGestureRecognizer_RightArrowButton(_ sender: UIGestureRecognizer) {
        if sender.state == .began {
            self.setButtonPressedDefaultValues()
            appendLog(text: "\(Date()): Right_Arrow_Button_Pressed")
            self.serialScreenSharedObject.createPrtobufRequest(reqType: .analyzerMessage_right)
            self.controllerViewBackgroundImage.image = UIImage(named: JLGStringConstants.kBTAControlButtonRightArrowPress)
        } else if sender.state == .ended {
            self.controllerViewBackgroundImage.image = UIImage(named: JLGStringConstants.kBTAControlButtonDefault)
        }
    }

    @objc func tapPressGestureRecognizer_DownArrowButton(_ sender: UIGestureRecognizer) {
        if sender.state == .began {
            self.setButtonPressedDefaultValues()
            appendLog(text: "\(Date()): Down_Arrow_Button_Pressed")
            self.serialScreenSharedObject.createPrtobufRequest(reqType: .analyzerMessage_down)
            self.controllerViewBackgroundImage.image = UIImage(named: JLGStringConstants.kBTAControlButtonDownArrowPress)
        } else if sender.state == .ended {
            self.controllerViewBackgroundImage.image = UIImage(named: JLGStringConstants.kBTAControlButtonDefault)
        }
    }
    
    func setButtonPressedDefaultValues() {
        self.isCharFlashing = false
    }
}

// MARK: - JLGBLEManager delegates
extension JLGBTAAnalyzerViewController {
    /// Get Called When all the peripheral discovered
    func didDiscoverPeripherals(peripherals: [[String: Any]]) {
        self.peripheralsArray = peripherals
        if (self.peripheralsArray?.count)! > 0 {
            JLGBLEManager.sharedInstance.centralManager.stopScan()
            connectToJLGBLEModule()
        }
    }

    /// Get called when connection established
    func didConnectToPeripheral(peripheral: CBPeripheral) {
        isDisconnectedBLE = false
        JLGCommunicationManager.sharedInstance.foregroundTimerCounter = 0
        isConnectedToJLGBLE = true
        updateUIForConnection()
    }

    /// Get called when device disconnected
    func didDisconnectFromPeripheral(peripheral: CBPeripheral) {
        isDisconnectedBLE = true
        hideLoadingIndicator()
        isConnectedToJLGBLE = false
        updateUIForDisconnection()
        self.stopProtobufRequest()
        if !isDisconnectByBTANotification {
            self.showAlertForBLEConnectionLost(title: JLGStringConstants.kAlertTitleBLEDisconnected, message: JLGStringConstants.kAlertMessageBLEDisconnected)
        }
    }

    /// Perform action when device bluetooth state changed (ON/OFF)
    func centralManagerDidUpdateBLEState(centralManager: CBCentralManager) {
        if centralManager.state == .poweredOff {
            hideLoadingIndicator()
            isDeviceBluetoothOff = true
            flagForDisconnectPeripheral = 1
            self.disconnectBluetooth()
        } else if centralManager.state == .poweredOn && (JLGBLEManager.sharedInstance.activePeripheral == nil || JLGBLEManager.sharedInstance.activePeripheral?.state != .connected) {
            isDeviceBluetoothOff = false
            flagForDisconnectPeripheral = 0
            tryToConnectToBLE()
        }
    }
    
    func tryToConnectToBLE() {
        hideLoadingIndicator()
        if isDeviceBluetoothOff {
            self.showBluetoothTurnOffAlert()
        } else {
            if tabBarController != nil {
                showLoadingIndicator(self.tabBarController!.view)
                self.startScanning()
                NotificationCenter.default.addObserver(self, selector: #selector(checkForAuthentication), name: .notificationIdentifierForAuthentication, object: nil)
                self.perform(#selector(connectToJLGBLEModule), with: nil, afterDelay: scanningTimeout)
            }
        }
    }

    /// Update UI for connection
    func updateUIForConnection() {
        shouldRetryToConnect = false
        self.updateNavigationRightBarItem(withImage: "BluetoothConnected")
        isDisconnectedBLE = false
    }

    // MARK: - Start Bluetooth scanning to connect
    @objc func startScanning() {
        hideLoadingIndicator()
        if isDeviceBluetoothOff {
            self.showBluetoothTurnOffAlert()
        } else {
            showLoadingIndicator(self.tabBarController!.view)
            JLGBLEManager.sharedInstance.startScanning()
        }
    }

    // MARK: - BLE connection methods
    /// ConnectToJLGBLEModule call when BLE need to connect
    @objc func connectToJLGBLEModule() {
        let peripheralDictionaryKey = JLGBLEManager.sharedInstance.qrCodeSerialOrMachineDecalNumber.count == 8 ? JLGStringConstants.kVehiclePin : JLGStringConstants.kSerialNumber
        if self.peripheralsArray != nil && (self.peripheralsArray?.count)! > 0 {
            for (index, peripheralDictionary) in peripheralsArray!.enumerated() where peripheralDictionary[peripheralDictionaryKey] as! Substring == JLGBLEManager.sharedInstance.qrCodeSerialOrMachineDecalNumber {
                let peripheral = self.peripheralsArray![index][JLGStringConstants.kPeripheralInstance] as! CBPeripheral
                JLGBLEManager.sharedInstance.connectToPeripheral(peripheral)
                self.perform(#selector(showAlertForNoDeviceFound), with: nil, afterDelay: scanningTimeout)
                return
            }
        }
        showAlertForNoDeviceFound()
    }

    /// Show alert when no device found
    @objc func showAlertForNoDeviceFound() {
        hideLoadingIndicator()
        if isDisconnectedBLE || !isConnectedToJLGBLE {
            let alertForNoDeviceFound = UIAlertController(title: JLGStringConstants.kAlertTitleJLGLiftNotFound, message: JLGStringConstants.kAlertMessageNoDeviceFound, preferredStyle: UIAlertControllerStyle.alert)
            alertForNoDeviceFound.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionOK, style: .default, handler: nil))
            alertForNoDeviceFound.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionRetry, style: .default) { _ in
                if self.shouldRetryToConnect {
                    self.tryToConnectToBLE()
                }
            })
            self.present(alertForNoDeviceFound, animated: true, completion: nil)
        }
    }

    // MARK: - Check for authentication
    @objc func checkForAuthentication() {
        NotificationCenter.default.removeObserver(self, name: .notificationIdentifierForAuthentication, object: nil)

        if JLGCommunicationManager.sharedInstance.authenticationValue == kAuthenticationInvalid {
            self.showAlertWithTitleAndMessageWithAction(title: JLGStringConstants.kAlertTitle, message: JLGStringConstants.kAlertMessageAuthenticationInvalid)
        } else if JLGCommunicationManager.sharedInstance.authenticationValue == kAuthenticationExpire {
            self.showAlertWithTitleAndMessageWithAction(title: JLGStringConstants.kAlertTitle, message: JLGStringConstants.kAlertMessageAuthenticationExpire)
        } else {
            self.sendProtobufRequest()
            print("*******BTA Screen Connect Successfully*******")
        }
    }

    func showAlertWithTitleAndMessageWithAction(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionOK, style: .default) { _ in
            self.tryToConnectToBLE()
        })
        self.present(alert, animated: true, completion: nil)
    }

}

// MARK: - JLGAlertMessageBluetoothTurnOff Delegate
extension JLGBTAAnalyzerViewController {
    /// showBluetoothTurnOffAlert get called when BLE power off
    func showBluetoothTurnOffAlert() {
        let bleOnOrOffAlert = JLGAlertMessageBluetoothTurnOff()
        bleOnOrOffAlert.showAlertIfBLEIsOff(viewController: self)
    }
}
