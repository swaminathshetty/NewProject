//
//  JLGRCSTabViewController.swift
//  JLG Control
//
//  Created by L&T on 10/04/18.
//  Copyright © 2018 JLG. All rights reserved.
//

import UIKit
import CoreBluetooth
//import Firebase

class JLGRCSTabViewController: GoogleAnalyticsViewController, JLGBLEDelegate, UIGestureRecognizerDelegate {

    // MARK: - Variables and Constants
    @IBOutlet var driveButton: UIButton!
    @IBOutlet weak var hornButton: UIButton!
    @IBOutlet weak var parkedStatusButton: UIButton!
    @IBOutlet weak var batteryStatusButton: UIButton!
    @IBOutlet weak var rightBarCustomButton: UIButton!
    @IBOutlet weak var dtcImageView: UIImageView!

    var peripheralsArray: [[String: Any]]?
    let homeToVehicleVCSeageIdentifier = "HomeToVehicleControlScreenSegue"
    var isConnectedToJLGBLE = false
    var timerForBatteryAnimation: Timer?
    var alertControllerForDisconnection: UIAlertController?
    var authenticatedIndex = 0
    var alertForNoDeviceFound: UIAlertController?
    var shouldRetryToConnect = true
    var isBLEDisconnectedFromHomeVC = false
    // MARK: - View life cycle events
    override func viewDidLoad() {
        super.viewDidLoad()
        /// For Unit and UI Testing
        if CommandLine.arguments.contains(JLGTestingConstant.kEnableTesting) {
            assigningAccessibilityIdentifier()
        }

        /// Update initial view
        self.navigationItem.titleView = UIImageView(image: #imageLiteral(resourceName: "JLGLogo"))
        JLGBLEManager.sharedInstance.delegate = self
        flagForDisconnectPeripheral = 0

        /// Adding the long press gesture to the horn button
        let longGesture = UILongPressGestureRecognizer(target: self, action: #selector(hornButtonAction(_:)))
        self.hornButton.addGestureRecognizer(longGesture)

        /// Start timer to check 5 minutes inactivity
        JLGCommunicationManager.sharedInstance.startForegroundTimer()

        /// Set BtCanRemEStopEnum to 0 before moving to Main Control Screen
        JLGCommunicationManager.sharedInstance.btRemEStopCommand(remEStopValue: BtCanRemEStopEnum.Start)

        /// Add notification for Battery, Remote and Warning status
        NotificationCenter.default.addObserver(self, selector: #selector(receivedNotificationForBatteryStatus(notification:)), name: .notificationIdentifierForBatteryStatus, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(receivedNotificationForWarning), name: .notificationIdentifierForWarningStatus, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(disconnectBLEAndGoBackMainHomeVC), name: .notificationIdentifierForDisconnectBLEInRCSApp, object: nil)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        JLGBLEManager.sharedInstance.delegate = self
        /// Set Previous Tab Index
        getRCSTabBarControllerPreviousIndex = 1
        isBLEDisconnectedFromHomeVC = false
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        /// Listen for warning notification
        receivedNotificationForWarning()

        /// Set BtCanRemEStopEnum to 0 before moving to Main Control Screen
        JLGCommunicationManager.sharedInstance.btRemEStopCommand(remEStopValue: BtCanRemEStopEnum.Start)

        /// Reset all commands (Drive, Steer, Lift) before perform any action on Home Screen
        JLGCommunicationManager.sharedInstance.resetAllCommands()
        JLGBLEManager.sharedInstance.delegate = self

        /// Session timeout due to 5 minute inactivity
        if isTimeExceed5Minutes {
            if isDisconnectedBLE || isDeviceBluetoothOff {
                NotificationCenter.default.post(name: .notificationIdentifierForAppRouteToScanVC, object: nil)
            } else {
                JLGBLEManager.sharedInstance.stopScanning()
                JLGBLEManager.sharedInstance.disconnectFromPeripheral()
            }
        /// If bluetooth is OFF or disconnected active device show connection lost alert
        } else if flagForDisconnectPeripheral == 1 || isDeviceBluetoothOff || isDisconnectedBLE {
            flagForDisconnectPeripheral = 0
            showAlertForBLEConnectionLost(title: JLGStringConstants.kAlertTitleBLEDisconnected, mesage: JLGStringConstants.kAlertMessageBLEDisconnected)
            updateUIForDisconnection()
        /// Show timeout alert if notification received from CAN2BLE
        } else if JLGCommunicationManager.sharedInstance.showTimeOutAlert == true && !isTimeExceed5Minutes {
            JLGCommunicationManager.sharedInstance.showTimeOutAlert = false
            showAlertForTimeout()
        /// Check drivable status received from CAN2BLE (stowed, ground, charging, safe mode)
        } else {
            enableOrDisableDrive()
        }

        /// Check battery status and change battery image accordingly
        checkBatteryStatus()

        NotificationCenter.default.addObserver(self, selector: #selector(receivedNotificationForRemoteStatus(notification:)), name: .notificationIdentifierForRemoteStatus, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(checkForAuthentication), name: .notificationIdentifierForAuthentication, object: nil)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        JLGBLEManager.sharedInstance.delegate = nil
        alertControllerForDisconnection?.dismiss(animated: false, completion: nil)
        NotificationCenter.default.removeObserver(self, name: .notificationIdentifierForRemoteStatus, object: nil)
        NotificationCenter.default.removeObserver(self, name: .notificationIdentifierForAuthentication, object: nil)
    }

    // MARK: - Authentication
    @objc func checkForAuthentication() {
        hideLoadingIndicator()
        if JLGCommunicationManager.sharedInstance.authenticationValue == kAuthenticationInvalid {
            showAlertForFailedAuthentication(message: JLGStringConstants.kAlertMessageAuthenticationInvalid)
            self.disconnectBluetooth()
        } else if JLGCommunicationManager.sharedInstance.authenticationValue == kAuthenticationExpire {
            showAlertForFailedAuthentication(message: JLGStringConstants.kAlertMessageAuthenticationExpire)
            self.disconnectBluetooth()
        } else {
            print("***** Sucessfully Authenticated *****")
        }
    }

    // MARK: - UI Updation methods
    /// Update UI for disconnection
    func updateUIForDisconnection() {
        shouldRetryToConnect = true
        updateNavigationRightBarItem(withImage: "BluetoothDisconnected")
        self.parkedStatusButton.setBackgroundImage(#imageLiteral(resourceName: "ParkedIconDisabled"), for: .normal)
        self.driveButton.isEnabled = false
        self.hornButton.isEnabled = false
        dtcImageView.image = #imageLiteral(resourceName: "DTCWarningDisabled")
        stopBatteryImagesAnimation()
        batteryStatusButton.setImage(#imageLiteral(resourceName: "BatteryIndication1"), for: .normal)
        isDisconnectedBLE = true
    }

    /// Update UI for connection
    func upadteUIForConnection() {
        shouldRetryToConnect = false
        self.updateNavigationRightBarItem(withImage: "BluetoothConnected")
        self.checkBatteryStatus()
        isDisconnectedBLE = false
    }

    /// Check for drive button should enable or disable
    func enableOrDisableDrive() {
        /// Uncomment below line for enable the driv
          //self.setEnableDriveValue()
        if CommandLine.arguments.contains(JLGTestingConstant.kEnableTesting) {
            self.setEnableDriveValue()
        }

        /// Check vehical stowed, ground, charging and safe mode status
        if JLGCommunicationManager.sharedInstance.btRemStatus.btGroundMode == 1 && JLGCommunicationManager.sharedInstance.btRemStatus.btStowed == 1 && JLGCommunicationManager.sharedInstance.btRemStatus.btVehicleCharging == 0 && JLGCommunicationManager.sharedInstance.btRemStatus.btVehicleSafeMode == 0 {
            if !isDisconnectedBLE {
                self.driveButton.isEnabled = true
                self.hornButton.isEnabled = true
            }
        } else {
            self.driveButton.isEnabled = false
            self.hornButton.isEnabled = false

            var remStatusMessage = JLGStringConstants.kAlertMessageDrive
             if JLGCommunicationManager.sharedInstance.btRemStatus.btStowed == 0 {
                remStatusMessage += JLGStringConstants.kAlertMessageNotStowed
             }
             if JLGCommunicationManager.sharedInstance.btRemStatus.btGroundMode == 0 {
                remStatusMessage += JLGStringConstants.kAlertMessageNotGround
             }
             if JLGCommunicationManager.sharedInstance.btRemStatus.btVehicleCharging == 1 {
                remStatusMessage += JLGStringConstants.kAlertMessageCharging
             }
             if JLGCommunicationManager.sharedInstance.btRemStatus.btVehicleSafeMode == 1 {
                remStatusMessage += JLGStringConstants.kAlertMessageSafeMode
             }

            if !isDisconnectedBLE {
                showAlertWithTitleAndMessage(title: JLGStringConstants.kAlertTitle, message: remStatusMessage, actionTitle: JLGStringConstants.kAlertActionOK)
            }
        }

    }

    @objc func setupUI() {
        if !isDisconnectedBLE || !isDeviceBluetoothOff {
            self.upadteUIForConnection()
        }
    }

    /// Update navigation right custom button image
    func updateNavigationRightBarItem(withImage imageName: String) {
        rightBarCustomButton.setImage(UIImage(named: imageName), for: .normal)
    }

    // MARK: - Received warning notification
    @objc func receivedNotificationForWarning() {
        if JLGCommunicationManager.sharedInstance.warningIndicatorValue == 1 {
            dtcImageView.image = #imageLiteral(resourceName: "DTCWarningEnable")
        } else {
            dtcImageView.image = #imageLiteral(resourceName: "DTCWarningDisabled")
        }
    }

    // MARK: - Received Remote Status notification
    @objc func receivedNotificationForRemoteStatus(notification: NSNotification) {
        enableOrDisableDrive()
    }

    // MARK: - Received battery notification
    @objc func receivedNotificationForBatteryStatus(notification: NSNotification) {
        checkBatteryStatus()
    }

    /// Check for battery status and based on percentage change battery image
    func checkBatteryStatus() {
        /// Stop blink animation if battery if more than 10% or equal to 0
        if JLGCommunicationManager.sharedInstance.batteryPercentageValue > 10 || JLGCommunicationManager.sharedInstance.batteryPercentageValue == 0 {
            stopBatteryImagesAnimation()
        }

        /// Change battery image
        switch JLGCommunicationManager.sharedInstance.batteryPercentageValue {
        case 76...100: batteryStatusButton.setImage(#imageLiteral(resourceName: "BatteryIndication5"), for: .normal)
        case 51...75: batteryStatusButton.setImage(#imageLiteral(resourceName: "BatteryIndication4"), for: .normal)
        case 26...50: batteryStatusButton.setImage(#imageLiteral(resourceName: "BatteryIndication3"), for: .normal)
        case 11...25: batteryStatusButton.setImage(#imageLiteral(resourceName: "BatteryIndication2"), for: .normal)
        case 1...10: animateBatteryImages()
        case 0: batteryStatusButton.setImage(#imageLiteral(resourceName: "BatteryIndication1"), for: .normal)
        case 255: batteryStatusButton.setImage(#imageLiteral(resourceName: "BatteryIndication1"), for: .normal)
        default: batteryStatusButton.setImage(#imageLiteral(resourceName: "BatteryIndication1"), for: .normal)
        }

        if JLGBLEManager.sharedInstance.activePeripheral?.state != .connected {
            batteryStatusButton.setImage(#imageLiteral(resourceName: "BatteryIndication1"), for: .normal)
        }
    }

    /// Start timer to blink battery in every 0.5 seconds
    func animateBatteryImages() {
        stopBatteryImagesAnimation()
        timerForBatteryAnimation = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(startBatteryImagesAnimation), userInfo: nil, repeats: true)
    }

    /// Start battery blink animation
    @objc func startBatteryImagesAnimation() {
        if batteryStatusButton.isSelected {
            batteryStatusButton.isSelected = false
            batteryStatusButton.setImage(#imageLiteral(resourceName: "BatteryIndication2"), for: .normal)
        } else {
            batteryStatusButton.isSelected = true
            batteryStatusButton.setImage(#imageLiteral(resourceName: "BatteryIndication1"), for: .normal)
        }
    }

    /// Stop battery blink animation
    func stopBatteryImagesAnimation() {
        if timerForBatteryAnimation != nil {
            timerForBatteryAnimation?.invalidate()
            timerForBatteryAnimation = nil
        }
    }

    // MARK: - Start Bluetooth scanning to connect
    @objc func startScanning() {
        hideLoadingIndicator()
        if isDeviceBluetoothOff {
            self.showBluetoothTurnOffAlert()
        } else {
            showLoadingIndicator(self.tabBarController!.view)
            JLGBLEManager.sharedInstance.startScanning()
        }
    }

    // MARK: - Disconnect bluetooth connection
    func disconnectBluetooth() {
        if flagForDisconnectPeripheral == 1 {
            flagForDisconnectPeripheral = 0
            showAlertForBLEConnectionLost(title: JLGStringConstants.kAlertTitleBLEDisconnected, mesage: JLGStringConstants.kAlertMessageBLEDisconnected)
            updateUIForDisconnection()
        } else {
            hideLoadingIndicator()
            showLoadingIndicator(self.tabBarController!.view)
            JLGBLEManager.sharedInstance.disconnectFromPeripheral()
        }
    }

    // MARK: - Alerts
    func showAlertForFailedAuthentication(message: String) {
        let alert = UIAlertController(title: JLGStringConstants.kAlertTitle, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionOK, style: .default) { _ in
            //self.disconnectBluetooth()
        })
        self.present(alert, animated: true, completion: nil)
    }

    /// Show alert if bluetooth connection is lost
    func showAlertForBLEConnectionLost(title: String, mesage: String) {
        hideLoadingIndicator()
        JLGBLEManager.sharedInstance.delegate = self
        let alert = UIAlertController(title: title, message: mesage, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionOK, style: .default, handler: nil))
        alert.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionRetry, style: .default) { _ in
            self.tryToConnectToBLE()
        })
        self.present(alert, animated: true, completion: nil)
    }

    /// Show alert to ask disconnect permission
    func showAlertForDisconnectPermission() {
        alertControllerForDisconnection = UIAlertController(title: JLGStringConstants.kAlertTitleDisconnectJLGLift, message: JLGStringConstants.kAlertMessageDisconnection, preferredStyle: UIAlertControllerStyle.alert)
        alertControllerForDisconnection!.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionCancel, style: .default, handler: nil))
        alertControllerForDisconnection!.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionDisconnect, style: .default) { _ in
            self.disconnectBluetooth()
        })
        self.present(alertControllerForDisconnection!, animated: true, completion: nil)
    }

    /// Show alert when no device found
    @objc func showAlertForNoDeviceFound() {
        hideLoadingIndicator()
        if isDisconnectedBLE || !isConnectedToJLGBLE {
            alertForNoDeviceFound = UIAlertController(title: JLGStringConstants.kAlertTitleJLGLiftNotFound, message: JLGStringConstants.kAlertMessageNoDeviceFound, preferredStyle: UIAlertControllerStyle.alert)
            alertForNoDeviceFound!.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionOK, style: .default, handler: nil))
            alertForNoDeviceFound!.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionRetry, style: .default) { _ in
                if self.shouldRetryToConnect {
                    self.tryToConnectToBLE()
                }
            })
            self.present(alertForNoDeviceFound!, animated: true, completion: nil)
        }
    }

    /// Show time out alert when received from CAN2BLE
    func showAlertForTimeout() {
        //Analytics.logEvent("rcs_timeout", parameters: [kUserID: userID, kTimeStamp: Date().PR2DateFormatterUTC()])
        let alert = UIAlertController(title: JLGStringConstants.kAlertTitleTimeOut, message: JLGStringConstants.kAlertMessageTimeOut, preferredStyle: .alert)
        let okAction = UIAlertAction(title: JLGStringConstants.kAlertActionOK, style: .cancel, handler: nil)
        alert.addAction(okAction)
        self.present(alert, animated: true, completion: nil)
    }

    // MARK: - Action to perform BLE connection / disconnection
    @IBAction func rightBarCustomButtonAction(_ sender: UIButton) {
        //Analytics.logEvent("rcs_home_ble_icon_action", parameters: [kUserID: userID, kTimeStamp: Date().PR2DateFormatterUTC()])
        if JLGBLEManager.sharedInstance.activePeripheral == nil || JLGBLEManager.sharedInstance.activePeripheral?.state != .connected {
            self.tryToConnectToBLE()
        } else {
            showAlertForDisconnectPermission()
        }
    }

    // MARK: - Action to perform horn functionality
    /// Long gesture horn action
    @objc func hornButtonAction(_ sender: UIGestureRecognizer) {
        if sender.state == .ended {
            hornButton.setImage(#imageLiteral(resourceName: "HornButtonNormal"), for: .normal)
            JLGCommunicationManager.sharedInstance.btHornEnableCommand(hornEnableValue: .Low)
        } else if sender.state == .began {
            //Analytics.logEvent("rcs_home_horn_action", parameters: [kUserID: userID, kTimeStamp: Date().PR2DateFormatterUTC()])
            hornButton.setImage(#imageLiteral(resourceName: "HornButtonSelected"), for: .normal)
            JLGCommunicationManager.sharedInstance.btHornEnableCommand(hornEnableValue: .High)
        }
    }

    /// Single tap horn action
    @IBAction func hornButtonSingleClickAction(_ sender: UIButton) {
        hornButton.isEnabled = false
        JLGCommunicationManager.sharedInstance.btHornEnableCommand(hornEnableValue: .High)
        self.perform(#selector(disableHorn), with: nil, afterDelay: 0.5)
    }

    /// Send horn OFF command
    @objc func disableHorn() {
        hornButton.isEnabled = true
        JLGCommunicationManager.sharedInstance.btHornEnableCommand(hornEnableValue: .Low)
    }

    // MARK: - Navigation
    /// In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == homeToVehicleVCSeageIdentifier {
            //Analytics.logEvent("rcs_drive_action", parameters: [kUserID: userID, kTimeStamp: Date().PR2DateFormatterUTC()])
            segue.destination.hidesBottomBarWhenPushed = true
        }
    }

    // MARK: - BLE connection methods
    /// ConnectToJLGBLEModule call when BLE need to connect
    @objc func connectToJLGBLEModule() {
        let peripheralDictionaryKey = JLGBLEManager.sharedInstance.qrCodeSerialOrMachineDecalNumber.count == 8 ? JLGStringConstants.kVehiclePin : JLGStringConstants.kSerialNumber
        if self.peripheralsArray != nil && (self.peripheralsArray?.count)! > 0 {
            for (index, peripheralDictionary) in peripheralsArray!.enumerated() where peripheralDictionary[peripheralDictionaryKey] as! Substring == JLGBLEManager.sharedInstance.qrCodeSerialOrMachineDecalNumber {
                let peripheral = self.peripheralsArray![index][JLGStringConstants.kPeripheralInstance] as! CBPeripheral
                JLGBLEManager.sharedInstance.connectToPeripheral(peripheral)
                self.perform(#selector(showAlertForNoDeviceFound), with: nil, afterDelay: scanningTimeout)
                return
            }
        }
        showAlertForNoDeviceFound()
    }

    func tryToConnectToBLE() {
        hideLoadingIndicator()
        if isDeviceBluetoothOff {
            self.showBluetoothTurnOffAlert()
        } else {
            if tabBarController != nil {
                showLoadingIndicator(self.tabBarController!.view)
                self.startScanning()
                self.perform(#selector(connectToJLGBLEModule), with: nil, afterDelay: scanningTimeout)
            }
        }
    }

    // MARK: - JLGBLEManager delegates
    /// Get Called When all the peripheral discovered
    func didDiscoverPeripherals(peripherals: [[String: Any]]) {
        self.peripheralsArray = peripherals
        if (self.peripheralsArray?.count)! > 0 {
            JLGBLEManager.sharedInstance.centralManager.stopScan()
            connectToJLGBLEModule()
        }
    }

    /// Get called when connection established
    func didConnectToPeripheral(peripheral: CBPeripheral) {
        isDisconnectedBLE = false
        JLGCommunicationManager.sharedInstance.foregroundTimerCounter = 0
        isConnectedToJLGBLE = true
        Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(getModuleInformation), userInfo: nil, repeats: false)
        upadteUIForConnection()
    }

    /// Get called when device disconnected
    func didDisconnectFromPeripheral(peripheral: CBPeripheral) {
        isDisconnectedBLE = true
        JLGCommunicationManager.sharedInstance.foregroundTimerCounter = 0
        hideLoadingIndicator()
        isConnectedToJLGBLE = false
        JLGCommunicationManager.sharedInstance.restAllRemServiceValues()
        updateUIForDisconnection()
        if !isBLEDisconnectedFromHomeVC {
            if !isTimeExceed5Minutes {
                showAlertForBLEConnectionLost(title: JLGStringConstants.kAlertTitleBLEDisconnected, mesage: JLGStringConstants.kAlertMessageBLEDisconnected)
            } else {
                self.navigationController?.popToRootViewController(animated: true)
            }
        }
    }

    /// Perform action when device bluetooth state changed (ON/OFF)
    func centralManagerDidUpdateBLEState(centralManager: CBCentralManager) {
        if centralManager.state == .poweredOff {
            hideLoadingIndicator()
            isDeviceBluetoothOff = true
            flagForDisconnectPeripheral = 1
            self.disconnectBluetooth()
        } else if centralManager.state == .poweredOn && (JLGBLEManager.sharedInstance.activePeripheral == nil || JLGBLEManager.sharedInstance.activePeripheral?.state != .connected) {
            isDeviceBluetoothOff = false
            flagForDisconnectPeripheral = 0
            tryToConnectToBLE()
        }
    }

    // MARK: - Check Reading the characteristics
    @objc func getModuleInformation() {
        JLGCommunicationManager.sharedInstance.getModuleInformationValue()
    }

    @objc func disconnectBLEAndGoBackMainHomeVC() {
        isBLEDisconnectedFromHomeVC = true
        JLGBLEManager.sharedInstance.delegate = self
        JLGCommunicationManager.sharedInstance.stopForegroundTimer()
        JLGBLEManager.sharedInstance.stopScanning()
        JLGBLEManager.sharedInstance.disconnectFromPeripheral()
        NotificationCenter.default.removeObserver(self, name: .notificationIdentifierForDisconnectBLEInRCSApp, object: nil)
        NotificationCenter.default.post(name: .notificationIdentifierForAppRouteToMainHomeVC, object: nil)
    }

}

// MARK: - JLGAlertMessageBluetoothTurnOff Delegate
extension JLGRCSTabViewController {
    /// showBluetoothTurnOffAlert get called when BLE power off
    func showBluetoothTurnOffAlert() {
        let bleOnOrOffAlert = JLGAlertMessageBluetoothTurnOff()
        bleOnOrOffAlert.showAlertIfBLEIsOff(viewController: self)
    }
}

extension JLGRCSTabViewController {
        /// Assigning Accessibility Identifier For UI Testing
    func assigningAccessibilityIdentifier() {
        if #available(iOS 11.0, *) {
            view.accessibilityIdentifier = JLGTestingConstant.kJLGHomeVC
            self.driveButton.accessibilityIdentifier = JLGTestingConstant.kDriveButton
            self.hornButton.accessibilityIdentifier = JLGTestingConstant.kHornButton
            self.parkedStatusButton.accessibilityIdentifier = JLGTestingConstant.kParkedStatusButton
            self.batteryStatusButton.accessibilityIdentifier = JLGTestingConstant.kBatteryStatusButton
            self.rightBarCustomButton.accessibilityIdentifier = JLGTestingConstant.kRightBarCustomButton
        }
    }

    func setEnableDriveValue() {
        JLGCommunicationManager.sharedInstance.btRemStatus.btGroundMode = 1
        JLGCommunicationManager.sharedInstance.btRemStatus.btStowed = 1
        JLGCommunicationManager.sharedInstance.btRemStatus.btVehicleCharging = 0
        JLGCommunicationManager.sharedInstance.btRemStatus.btVehicleSafeMode = 0
        isDisconnectedBLE = false
    }
}
