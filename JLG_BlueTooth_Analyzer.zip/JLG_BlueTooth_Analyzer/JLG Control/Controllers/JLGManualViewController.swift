//
//  JLGManualViewController.swift
//  JLG Control
//
//  Created by L&T on 12/12/18.
//  Copyright © 2018 L&T. All rights reserved.
//

import UIKit

class JLGManualViewController: GoogleAnalyticsViewController, UIWebViewDelegate {

    @IBOutlet weak var webView: UIWebView!
    var titleText = ""
    var webURLString = ""
    var createNavigationBarBackButton = false

    override func viewDidLoad() {
        super.viewDidLoad()
        /// For Unit and UI Testing
        if CommandLine.arguments.contains(JLGTestingConstant.kEnableTesting) {
            assigningAccessibilityIdentifier()
        }

        hideLoadingIndicator()
        showLoadingIndicator(self.view)
        title = titleText
        showWebLinkContent(webURLString)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = false

        if createNavigationBarBackButton {
            let buttonLeftMenu: UIButton = UIButton()
            buttonLeftMenu.setImage(UIImage(named: JLGStringConstants.kBackwardArrow), for: UIControlState())
            buttonLeftMenu.addTarget(self, action: #selector(self.onClickBack), for: UIControlEvents.touchUpInside)
            buttonLeftMenu.frame = CGRect(x: 0, y: 0, width: 33/2, height: 27/2)
            let barButton = UIBarButtonItem(customView: buttonLeftMenu)
            self.navigationItem.leftBarButtonItem = barButton
        }
    }

    @objc func onClickBack() {
        _ = self.navigationController?.popViewController(animated: true)
    }

    func showWebLinkContent(_ urlString: String) {
        let url: URL! = URL(string: urlString)
        webView.loadRequest(URLRequest(url: url))
    }

    func webViewDidStartLoad(_ webView: UIWebView) {
        hideLoadingIndicator()
        if Reachability.isConnectedToNetwork() {
            showLoadingIndicator(self.view)
        } else {
            showNetworkError()
        }
    }

    func webViewDidFinishLoad(_ webView: UIWebView) {
        hideLoadingIndicator()
    }

    func webView(_ webView: UIWebView, didFailLoadWithError error: Error) {
        hideLoadingIndicator()
        showAlertWithTitleAndMessage(title: JLGStringConstants.kAlertTitle, message: error.localizedDescription, actionTitle: JLGStringConstants.kAlertActionOK)
    }

}

extension JLGManualViewController {
    /// Assigning Accessibility Identifier For UI Testing
    func assigningAccessibilityIdentifier() {
        if #available(iOS 11.0, *) {
            view.accessibilityIdentifier = JLGTestingConstant.kJLGManualVC
            self.webView.accessibilityIdentifier = JLGTestingConstant.kJLGManualWebView
        }
    }
}
