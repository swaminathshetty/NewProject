//
//  JLGBTATabBarController.swift
//  JLG Control
//
//  Created by Apple on 21/07/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class JLGBTATabBarController: UITabBarController, UITabBarControllerDelegate {
    // MARK: - View life cycle events
    override func viewDidLoad() {
        super.viewDidLoad()
        self.delegate = self
        self.selectedIndex = 1
        /// Setup appearance of tab bar
        let appearance = UITabBarItem.appearance(whenContainedInInstancesOf: [JLGBMSTabBarController.self])
        appearance.setTitleTextAttributes([NSAttributedStringKey.foregroundColor: UIColor.gray], for: .normal)
        appearance.setTitleTextAttributes([NSAttributedStringKey.foregroundColor: themeColor], for: .selected)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = true
    }
}
