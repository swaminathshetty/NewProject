//
//  JLGBMSProperChargingPracticesViewController.swift
//  JLG Control
//
//  Created by Admin on 5/7/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class JLGBMSProperChargingPracticesViewController: GoogleAnalyticsViewController {
    @IBOutlet weak var properChargingPracticesTextView: UITextView!
    @IBOutlet weak var cancelButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        /// For Unit and UI Testing
        if CommandLine.arguments.contains(JLGTestingConstant.kEnableTesting) {
            assigningAccessibilityIdentifier()
        }

        self.title = JLGStringConstants.kTitleChargingPractices

        /// Show proper charging practices details inside textview with html format
        properChargingPracticesTextView.attributedText = JLGStringConstants.kProperChargingPracticesHtmlText.htmlToAttributedString
        properChargingPracticesTextView.setContentOffset(CGPoint.zero, animated: false)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = false
        properChargingPracticesTextView.setContentOffset(CGPoint.zero, animated: false)
        NotificationCenter.default.addObserver(self, selector: #selector(cancelButtonAction), name: .notificationIdentifierForDismissPresentViewController, object: nil)
    }

    override func viewDidLayoutSubviews() {
        properChargingPracticesTextView.setContentOffset(.zero, animated: false)
    }

    override func viewWillDisappear(_ animated: Bool) {
        NotificationCenter.default.removeObserver(self, name: .notificationIdentifierForDismissPresentViewController, object: nil)
    }

    @IBAction func cancelButtonAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }

}

extension JLGBMSProperChargingPracticesViewController {
    /// Assigning Accessibility Identifier For UI Testing
    func assigningAccessibilityIdentifier() {
        if #available(iOS 11.0, *) {
            view.accessibilityIdentifier = JLGTestingConstant.kJLGProperChargingPracticesVC
            cancelButton.accessibilityAttributedLabel = NSAttributedString(string: JLGTestingConstant.kJLGProperChargingPracticesCancelButton)
        }
    }
}
