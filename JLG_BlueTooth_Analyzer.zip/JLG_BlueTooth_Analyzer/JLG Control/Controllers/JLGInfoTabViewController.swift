//
//  JLGInfoTabViewController.swift
//  JLG Control
//
//  Created by L&T on 20/04/18.
//  Copyright © 2018 L&T. All rights reserved.
//

import UIKit
import MessageUI
import SystemConfiguration.CaptiveNetwork

class JLGInfoTabViewController: GoogleAnalyticsViewController, UITableViewDataSource, UITableViewDelegate, MFMailComposeViewControllerDelegate {

    // MARK: - Variables and Constants
    @IBOutlet weak var settingsTableView: UITableView!

    var version = ""
    var build = ""
    var items = [[String: Any]]()

    // MARK: - View life cycle events
    override func viewDidLoad() {
        super.viewDidLoad()
        /// For Unit and UI Testing
        if CommandLine.arguments.contains(JLGTestingConstant.kEnableTesting) {
            assigningAccessibilityIdentifier()
        }

        self.setupDataSource()
        self.initialSetup()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        /// Set Previous Tab Index
        getRCSTabBarControllerPreviousIndex = 2
        getBMSTabBarControllerPreviousIndex = 3
        getBTATabBarControllerPreviousIndex = 4
        /// Set vehicle software version
        if !isJLGBTAAnalyzerFlowStart {
            if JLGCommunicationManager.sharedInstance.vehicleBLEVersion == "" {
                items[3][JLGStringConstants.kVersion] = JLGStringConstants.kThreeDash
            } else {
                items[3][JLGStringConstants.kVersion] = JLGCommunicationManager.sharedInstance.vehicleBLEVersion
            }
        }

        self.settingsTableView.reloadData()
    }

    // MARK: - Initial setup
    func initialSetup() {

        /// Get version number of ios app
        if let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String {
            self.version = version + kBetaVersion
        }

        /// Get build number of ios app
        if let build = Bundle.main.infoDictionary?["CFBundleVersion"] as? String {
            self.build = build
        }

        appendLog(text: "\(Date()): Application version --> \(self.version) and build no. \(self.build)")

        /// Set app version number
        if !isJLGBTAAnalyzerFlowStart {
            items[4][JLGStringConstants.kVersion] = version
        }

        /// Check appstore version (Future Use)
        //items[4]["IsImageRequired"] = needsUpdate()

        settingsTableView.reloadData()
    }

    // MARK: - Check current version with app store version
    func needsUpdate() -> Bool {
        let infoDictionary = Bundle.main.infoDictionary
        let appID = infoDictionary!["CFBundleIdentifier"] as! String
        let url = URL(string: "http://itunes.apple.com/lookup?bundleId=\(appID)")
        let data = try? Data(contentsOf: url!)
        let lookup = (try? JSONSerialization.jsonObject(with: data!, options: [])) as? [String: Any]
        if let resultCount = lookup!["resultCount"] as? Int, resultCount == 1 {
            if let results = lookup!["results"] as? [[String: Any]] {
                if let appStoreVersion = results[0]["version"] as? String {
                    let currentVersion = infoDictionary!["CFBundleShortVersionString"] as? String
                    if !(appStoreVersion == currentVersion) {
                        return true
                    }
                }
            }
        }
        return false
    }

    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "JLGManualViewController" {
            var webLink: [Int: String]
            var webTitle: [Int: String]
            
            if isJLGBTAAnalyzerFlowStart {
                webLink = [0: JLGStringConstants.kManualWebLink, 1: JLGStringConstants.kLegalWebLink]
                webTitle = [0: JLGStringConstants.kJLGOnlineExpress, 1: JLGStringConstants.kJLGLibrary]
            } else {
                webLink = [0: JLGStringConstants.kManualWebLink, 1: JLGStringConstants.kLegalWebLink, 2: JLGStringConstants.kRegulatoryWebLink]
                webTitle = [0: JLGStringConstants.kManual, 1: JLGStringConstants.kLegal, 2: JLGStringConstants.kRegulatory]
            }
            
            let indexRow = sender as! Int
            let vc = segue.destination as! JLGManualViewController
            vc.webURLString = webLink[indexRow]!
            vc.titleText = webTitle[indexRow]!
        }
    }

    // MARK: - Table View Data Source and Delegates
    /// Set number of rows in table view
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }

    /// Creation of table view cell
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "JLGSettingsTableViewCell", for: indexPath) as! JLGSettingsTableViewCell
        cell.fillCellData(items[indexPath.row])
        cell.accessibilityIdentifier = "\(JLGTestingConstant.kJLGSettingsTableViewCell)\(indexPath.row)"
        return cell
    }

    /// Selection of any table view cell
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if indexPath.row == 0 || indexPath.row == 1 || indexPath.row == 2 {
            if Reachability.isConnectedToNetwork() {
                self.performSegue(withIdentifier: "JLGManualViewController", sender: indexPath.row)
            } else {
                showNetworkError()
            }
        } else if indexPath.row == 5 {
            //self.sendEmail()
            shareFileToAnyPlatform(viewController: self)
        }
    }

}

extension JLGInfoTabViewController {
    /// Data source to show in setting screen
    func setupDataSource() {
        if isJLGBTAAnalyzerFlowStart {
            self.navigationItem.titleView = UIImageView(image: UIImage(named: JLGStringConstants.kJLGMobileControlLogo))
            let item1: [String: Any] = [JLGStringConstants.kTitle: JLGStringConstants.kJLGOnlineExpress, JLGStringConstants.kVersion: "", JLGStringConstants.kImage: JLGStringConstants.kForwardArrow, JLGStringConstants.kIsImageRequired: true, JLGStringConstants.kImageTitle: ""]

            let item2: [String: Any] = [JLGStringConstants.kTitle: JLGStringConstants.kJLGLibrary, JLGStringConstants.kVersion: "", JLGStringConstants.kImage: JLGStringConstants.kForwardArrow, JLGStringConstants.kIsImageRequired: true, JLGStringConstants.kImageTitle: ""]
            items.append(item1)
            items.append(item2)

            return
        }
        
        let item1: [String: Any] = [JLGStringConstants.kTitle: JLGStringConstants.kManual, JLGStringConstants.kVersion: "", JLGStringConstants.kImage: JLGStringConstants.kForwardArrow, JLGStringConstants.kIsImageRequired: true, JLGStringConstants.kImageTitle: ""]

        let item2: [String: Any] = [JLGStringConstants.kTitle: JLGStringConstants.kLegal, JLGStringConstants.kVersion: "", JLGStringConstants.kImage: JLGStringConstants.kForwardArrow, JLGStringConstants.kIsImageRequired: true, JLGStringConstants.kImageTitle: ""]

        let item3: [String: Any] = [JLGStringConstants.kTitle: JLGStringConstants.kRegulatory, JLGStringConstants.kVersion: "", JLGStringConstants.kImage: JLGStringConstants.kForwardArrow, JLGStringConstants.kIsImageRequired: true, JLGStringConstants.kImageTitle: ""]

        let item4_a: [String: Any] = [JLGStringConstants.kTitle: JLGStringConstants.kMachineBLEVersion, JLGStringConstants.kVersion: "", JLGStringConstants.kImage: "", JLGStringConstants.kIsImageRequired: false, JLGStringConstants.kImageTitle: ""]

//        let item4_b: [String: Any] = [JLGStringConstants.kTitle: JLGStringConstants.kMachineBLEVersion, JLGStringConstants.kVersion: "", JLGStringConstants.kImage: "", JLGStringConstants.kIsImageRequired: false, JLGStringConstants.kImageTitle: ""]

        let item5: [String: Any] = [JLGStringConstants.kTitle: JLGStringConstants.kAppVersion, JLGStringConstants.kVersion: "", JLGStringConstants.kImage: JLGStringConstants.kUpdateAvailable, JLGStringConstants.kIsImageRequired: false, JLGStringConstants.kImageTitle: "1"]

        items.append(item1)
        items.append(item2)
        items.append(item3)

        if let _ = self.tabBarController as? JLGBMSTabBarController {
            //items.append(item4_b)
            self.navigationItem.titleView = UIImageView(image: UIImage(named: JLGStringConstants.kJLGMobileControlLogo))
        } else {
            //items.append(item4_a)
            self.navigationItem.title = JLGStringConstants.kSettings
        }

        items.append(item4_a)
        items.append(item5)

//        let item6: [String: Any] = [JLGStringConstants.kTitle: "Log (Beta Version Only)", JLGStringConstants.kVersion: "", JLGStringConstants.kImage: "", JLGStringConstants.kIsImageRequired: false, JLGStringConstants.kImageTitle: ""]
//        items.append(item6)

    }
}

extension JLGInfoTabViewController {
    /// Open mail with attached log file with prefilled subject, body and recipient
    func sendEmail() {
        if MFMailComposeViewController.canSendMail() {
            let mailComposer = MFMailComposeViewController()
            mailComposer.setSubject("JLG Mobile Control Log File")
            mailComposer.setMessageBody("Please don't modify any content.", isHTML: false)
            mailComposer.setToRecipients(["nileshkumar.pandey@ltts.com"])
            if let documentDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
                let fileURL = documentDirectory.appendingPathComponent(JLGStringConstants.kLogFileName)
                //let fileURL = documentDirectory.appendingPathComponent("Logfile.txt")
                do {
                    let attachmentData = try Data(contentsOf: fileURL)
                    mailComposer.addAttachmentData(attachmentData, mimeType: "application/pdf", fileName: JLGStringConstants.kLogFileName)
                    //mailComposer.addAttachmentData(attachmentData, mimeType: "application/pdf", fileName: "Logfile.txt")
                    mailComposer.mailComposeDelegate = self
                    self.present(mailComposer, animated: true, completion: nil)
                } catch let error {
                    print("We have encountered error to attach log file: \(error.localizedDescription)")
                }
            }
        }
    }

    // MARK: - MailcomposerDelegate
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        switch result {
        case .cancelled:
            print("User cancelled")
        case .saved:
            print("Mail is saved by user")
        case .sent:
            print("Mail is sent successfully")
        case .failed:
            print("Sending mail is failed")
        default:
            break
        }
        controller.dismiss(animated: true)
    }
}

extension JLGInfoTabViewController {
    /// Assigning Accessibility Identifier For UI Testing
    func assigningAccessibilityIdentifier() {
        if #available(iOS 11.0, *) {
            view.accessibilityIdentifier = JLGTestingConstant.kJLGSettingsVC
            self.settingsTableView.accessibilityIdentifier = JLGTestingConstant.kJLGSettingsTableView
        }
    }
}
