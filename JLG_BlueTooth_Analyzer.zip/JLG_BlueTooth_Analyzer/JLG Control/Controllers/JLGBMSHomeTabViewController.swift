//
//  JLGBMSHomeTabViewController.swift
//  JLG Control
//
//  Created by Apple on 07/02/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class JLGBMSHomeTabViewController: GoogleAnalyticsViewController, JLGAlertBackToHomeViewControllerDelegate {
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.titleView = UIImageView(image: UIImage(named: JLGStringConstants.kJLGMobileControlLogo))
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        if isJLGBMSSerialScreenViewControllerOpen {
            self.showAlertBackToHome()
        } else {
            self.backToMainHomeViewController()
        }
    }

    func backToMainHomeViewController() {
        isJLGBMSSerialScreenViewControllerOpen = false
        stopFleetScreenScanning()
        NotificationCenter.default.post(name: .notificationIdentifierForAppRouteToMainHomeVC, object: nil)
    }
}

// MARK: - JLGBMSHomeTabViewController Delegate
extension JLGBMSHomeTabViewController {
    func showAlertBackToHome() {
        let backToHomeVC = JLGAlertBackToHomeViewController()
        backToHomeVC.showAlertForBackToHomeViewController(viewController: self)
        backToHomeVC.delegate = self
    }

    func didSelectBackToHomeConfirmButton() {
        NotificationCenter.default.post(name: .notificationIdentifierForSerialScreenDisconnectBLE, object: nil)
        self.backToMainHomeViewController()
    }

    func didSelectBackToHomeCancelButton() {
        if let tabBar = self.tabBarController as? JLGBMSTabBarController {
            tabBar.selectedIndex = getBMSTabBarControllerPreviousIndex
        }
    }
}
