//
//  JLGBMSTabBarController.swift
//  JLG Control
//
//  Created by Apple on 30/01/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class JLGBMSTabBarController: UITabBarController, UITabBarControllerDelegate {
    // MARK: - View life cycle events
    override func viewDidLoad() {
        super.viewDidLoad()
        self.delegate = self
        self.selectedIndex = 1
        /// Setup appearance of tab bar
        let appearance = UITabBarItem.appearance(whenContainedInInstancesOf: [JLGBMSTabBarController.self])
        appearance.setTitleTextAttributes([NSAttributedStringKey.foregroundColor: UIColor.gray], for: .normal)
        appearance.setTitleTextAttributes([NSAttributedStringKey.foregroundColor: themeColor], for: .selected)
        NotificationCenter.default.addObserver(self, selector: #selector(tapBMSHomeTabBar), name: .notificationIdentifierForBMSHomeTabBar, object: nil)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = true
    }

    @objc func tapBMSHomeTabBar() {
        self.selectedIndex = 0
    }

    // MARK: - UITabbar Delegate
    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {
        let selectedIndex = tabBarController.viewControllers?.firstIndex(of: viewController)!
        if selectedIndex == 1 && getBMSTabBarControllerPreviousIndex == 1 {
            return false
        }
        return true
    }

}
