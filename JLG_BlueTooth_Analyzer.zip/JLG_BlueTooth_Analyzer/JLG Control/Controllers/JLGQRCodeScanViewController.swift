//
//  QRCodeScanViewController.swift
//  JLG Control
//
//  Created by L&T on 17/04/18.
//  Copyright © 2018 L&T. All rights reserved.
//

import UIKit
import AVFoundation
import CoreBluetooth
//import Firebase

class JLGQRCodeScanViewController: GoogleAnalyticsViewController, AVCaptureMetadataOutputObjectsDelegate, JLGBLEDelegate, JLGAlertMessageBluetoothTurnOffDelegate {

    // MARK: - Variables and Constants
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var messageLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var qrCodeView: UIView!
    @IBOutlet weak var scanIndicatorImageView: UIImageView!

    var captureSession: AVCaptureSession?
    var videoPreviewLayer: AVCaptureVideoPreviewLayer?
    var qrCodeFrameView: UIView?
    var peripheralsArray: [[String: Any]]?
    var qrCodeAuthenticationString = ""
    var authenticated = false
    var timerToGoBack: Timer?
    var authenticatedIndex = 0
    var binaryFileChunkArray = [Data]()
    var binaryFileChunkIndex = 0
    var maxMTUWithoutResponse = 182 //Default
    var maxMTUWithResponse = 512 //Default
    var timerToCheckOTANotification: Timer?

    /// Added to support different barcodes
    let supportedBarCodes = [AVMetadataObject.ObjectType.dataMatrix]

    let jlgBluetoothAnalyzerTabViewController = "JLGBluetoothAnalyzerTabViewController"
    let tabBarSegueIdentifier = "TabBarSegueIdentifier"

    // MARK: - View life cycle events
    override func viewDidLoad() {
        super.viewDidLoad()

        JLGBLEManager.sharedInstance.delegate = self
        setupScanningImage(isScanning: true)
        setupQRCodeScanner()

        /// Wait for 10 seconds, if QR code didn't find show alert and come back to previous screen
        timerToGoBack = Timer.scheduledTimer(timeInterval: responseTimeout, target: self, selector: #selector(gotoPreviousScreen), userInfo: nil, repeats: false)

        /// Add observer for authentication
        NotificationCenter.default.addObserver(self, selector: #selector(checkForAuthentication), name: .notificationIdentifierForAuthentication, object: nil)

        /// Add observer for OTA Reprogramming
        NotificationCenter.default.addObserver(self, selector: #selector(receiveNotificationForOTAReprogramming), name: .notificationIdentifierForOTAReprogramming, object: nil)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        /// Start scanning to search for JLG lift
        if JLGBLEManager.sharedInstance.centralManager.state == .poweredOn && (JLGBLEManager.sharedInstance.activePeripheral == nil || JLGBLEManager.sharedInstance.activePeripheral?.state != .connected) {
            JLGBLEManager.sharedInstance.startScanning()
        }

        /// Disable ideal timer of iOS devices (auto-lock)
        UIApplication.shared.isIdleTimerDisabled = true
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(true)
        invalidateTimer()
        NotificationCenter.default.removeObserver(self, name: .notificationIdentifierForAuthentication, object: nil)
        NotificationCenter.default.removeObserver(self, name: .notificationIdentifierForOTAReprogramming, object: nil)

        /// Enable ideal timer of ios devices (auto-lock)
        UIApplication.shared.isIdleTimerDisabled = false
    }

    deinit {
        hideLoadingIndicator()
        invalidateTimer()
    }

    // MARK: - Custom methods
    /// Show alert if JLG Lift not found and go back to previous screen
    @objc func gotoPreviousScreen() {
        setupScanningImage(isScanning: true)
        captureSession?.stopRunning()
        toggleTorch(on: false)
        invalidateTimer()
        hideLoadingIndicator()
        showAlertForNoDeviceFound()
    }

    /// Invalidate timer if it is assined
    func invalidateTimer() {
        if timerToGoBack != nil {
            timerToGoBack?.invalidate()
            timerToGoBack = nil
        }
    }

    /// Set scanning outer image orange / green
    func setupScanningImage(isScanning: Bool) {
        scanIndicatorImageView.image = UIImage(named: (isScanning ? "ScanningInProgress" : "ScanningCompleted"))
    }

    /// Toggle phone torch On / OFF
    func toggleTorch(on: Bool) {
        guard let device = AVCaptureDevice.default(for: AVMediaType.video)
            else { return }
        if device.hasTorch {
            do {
                try device.lockForConfiguration()
                if on == true {
                    device.torchMode = .on
                } else {
                    device.torchMode = .off
                }
                device.unlockForConfiguration()
            } catch {
                print("Torch could not be used")
            }
        } else {
            print("Torch is not available")
        }
    }

    // MARK: - QR Code scanning methods
    /// Initial setup for QR Code
    func setupQRCodeScanner() {
        /// Get an instance of the AVCaptureDevice class to initialize a device object and provide the video as the media type parameter.
        let captureDevice = AVCaptureDevice.default(for: AVMediaType.video)
        do {
            /// Get an instance of the AVCaptureDeviceInput class using the previous device object.
            let input = try AVCaptureDeviceInput(device: captureDevice!)

            /// Initialize the captureSession object.
            captureSession = AVCaptureSession()

            /// Set the input device on the capture session.
            captureSession?.addInput(input)

            /// Initialize a AVCaptureMetadataOutput object and set it as the output device to the capture session.
            let captureMetadataOutput = AVCaptureMetadataOutput()
            captureSession?.addOutput(captureMetadataOutput)

            /// Set delegate and use the default dispatch queue to execute the call back
            captureMetadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)

            /// Detect all the supported bar code
            captureMetadataOutput.metadataObjectTypes = supportedBarCodes

            /// Initialize the video preview layer and add it as a sublayer to the viewPreview view's layer.
            videoPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession!)
            videoPreviewLayer?.videoGravity = AVLayerVideoGravity.resizeAspectFill
            videoPreviewLayer?.frame = qrCodeView.bounds
            qrCodeView.layer.addSublayer(videoPreviewLayer!)

            /// Start video capture
            captureSession?.startRunning()

            /// Move the message label to the top view
            view.bringSubview(toFront: messageLabel)

            /// Initialize QR Code Frame to highlight the QR code
            qrCodeFrameView = UIView()

            if let qrCodeFrameView = qrCodeFrameView {
                qrCodeFrameView.layer.borderColor = UIColor.green.cgColor
                qrCodeFrameView.layer.borderWidth = 2
                qrCodeView.addSubview(qrCodeFrameView)
                qrCodeView.bringSubview(toFront: qrCodeFrameView)
            }

            /// On torch
            toggleTorch(on: true)
        } catch {
            /// If any error occurs, simply print it out and don't continue any more.
            print("[ERROR] setupQRCodeScanner Error: \(error)")
            return
        }
    }

    /// If QR Code read by camera this method will get called
    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        /// Check if the metadataObjects array is not nil and it contains at least one object.
        if  metadataObjects.count == 0 {
            qrCodeFrameView?.frame = CGRect.zero
            messageLabel.text = JLGStringConstants.kQRCodeDetected
            return
        }

        /// Get the metadata object.
        let metadataObj = metadataObjects[0] as? AVMetadataMachineReadableCodeObject
        if metadataObj == nil {
            return
        }

        /// Here we use filter method to check if the type of metadataObj is supported, instead of hardcoding the AVMetadataObjectTypeQRCode, we check if the type can be found in the array of supported bar codes.
        if supportedBarCodes.contains((metadataObj?.type)!) {
            if metadataObj?.type == AVMetadataObject.ObjectType.dataMatrix {
                /// If the found metadata is equal to the QR code metadata then update the status label's text and set the bounds
                let barCodeObject = videoPreviewLayer?.transformedMetadataObject(for: metadataObj!)
                qrCodeFrameView?.frame = barCodeObject!.bounds

                /// BOTH OLD & NEW DATA MATRIX CODE SUPPPORT
                if metadataObj?.stringValue != nil {
                    var index = 1
                    messageLabel.text = JLGStringConstants.kQRCodeAuthenticating
                    print("Data matrix string: \(metadataObj?.stringValue ?? "No string found")")
                    let metadataObjString = metadataObj?.stringValue
                    var metadataStringArray = [String]()

                    /// New data matrix string
                    if metadataObjString?.prefix(3) == "[)>" {
                        index = 2
                        metadataStringArray = metadataObjString!.components(separatedBy: "\u{1D}")
                    /// Old data matrix string
                    } else {
                        index = 1
                        metadataStringArray = metadataObjString!.components(separatedBy: .whitespaces)
                    }

                    let dataMatrixString = metadataStringArray.filter { !$0.isEmpty }.joined(separator: spaceString)
                    let dataMatrixStringArray = dataMatrixString.components(separatedBy: .whitespaces)

                    if dataMatrixStringArray.count > 1 {
                        if dataMatrixStringArray[index].count > 5 {
                            let serialOrVehiclePinSectionString = dataMatrixStringArray[index]
                            let serialOrVehiclePinSectionArray = serialOrVehiclePinSectionString.components(separatedBy: "\u{1E}")
                            if serialOrVehiclePinSectionArray.count > 1 {
                                if serialOrVehiclePinSectionArray[0].count > 7 {
                                    JLGBLEManager.sharedInstance.qrCodeSerialOrMachineDecalNumber = serialOrVehiclePinSectionArray[0].suffix(8)
                                }
                            } else {
                                if JLGCommunicationManager.sharedInstance.shouldConfigureMachineDecal {
                                    invalidMachineDecal()
                                    return
                                } else {
                                    if serialOrVehiclePinSectionArray[0].count > 5 {
                                        JLGBLEManager.sharedInstance.qrCodeSerialOrMachineDecalNumber = serialOrVehiclePinSectionArray[0].suffix(6)
                                    }
                                }
                            }
                            print("QR Code / Machine Decal number: \(JLGBLEManager.sharedInstance.qrCodeSerialOrMachineDecalNumber)")
                            //Analytics.logEvent("rcs_found_qr_code", parameters: [kUserID: userID, kTimeStamp: Date().PR2DateFormatterUTC()])
                            invalidateTimer()
                            timerToGoBack = Timer.scheduledTimer(timeInterval: responseTimeout, target: self, selector: #selector(gotoPreviousScreen), userInfo: nil, repeats: false)
                            resetUIForQRCode()
                            hideLoadingIndicator()
                            showLoadingIndicator(self.navigationController!.view)
                            tryToConnectWithBLE()
                            return
                        }
                    }
                    if JLGCommunicationManager.sharedInstance.shouldConfigureMachineDecal {
                        invalidMachineDecal()
                    } else {
                        liftNotFound()
                    }
                }
            }
        }
    }

    /// Invalid machine decal
    func invalidMachineDecal() {
        invalidateTimer()
        resetUIForQRCode()
        let ac = UIAlertController(title: JLGStringConstants.kAlertTitle, message: JLGStringConstants.kAlertMessageMachineDecalNotSupported, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionOK, style: .default) { _ in
            self.navigationController?.popViewController(animated: true)
        })
        present(ac, animated: true)
    }

    /// Reset app UI after capture data matrix manufacturing string
    func resetUIForQRCode() {
        setupScanningImage(isScanning: false)
        captureSession?.stopRunning()
        toggleTorch(on: false)
    }

    /// Wait till discover near by BLE module (Max 5 seconds)
    @objc func tryToConnectWithBLE() {
        if peripheralsArray != nil {
            invalidateTimer()
            matchSerialNumberOrMachineDecal()
        } else {
            if timerToGoBack != nil {
                self.perform(#selector(tryToConnectWithBLE), with: nil, afterDelay: 1)
            }
        }
    }

    /// Match and pair with BLE module
    @objc func matchSerialNumberOrMachineDecal() {
        /*
        /// for connect the BLE device and update the machine
        authenticatedIndex = 0
        connectToBLE()
        */
        if JLGCommunicationManager.sharedInstance.shouldConfigureMachineDecal {
            authenticatedIndex = 0
            connectToBLE()
        } else {
            let peripheralDictionaryKey = JLGBLEManager.sharedInstance.qrCodeSerialOrMachineDecalNumber.count == 8 ? JLGStringConstants.kVehiclePin : JLGStringConstants.kSerialNumber
            for (index, peripheralDictionary) in JLGBLEManager.sharedInstance.peripheralsInfo.enumerated() where peripheralDictionary[peripheralDictionaryKey] as! Substring == JLGBLEManager.sharedInstance.qrCodeSerialOrMachineDecalNumber {
                authenticatedIndex = index
                connectToBLE()
                return
            }
            hideLoadingIndicator()
            showAlertForNoDeviceFound()
        }
    }

    // MARK: - Lift not found
    func liftNotFound() {
        invalidateTimer()
        resetUIForQRCode()
        showAlertForNoDeviceFound()
    }

    // MARK: - BLE connection methods
    /// Connect to specific BLE device
    func connectToBLE() {
        JLGBLEManager.sharedInstance.centralManager.stopScan()
        if (self.peripheralsArray != nil && (self.peripheralsArray?.count)! > 0) && !isDeviceBluetoothOff {
            let peripheral = self.peripheralsArray![authenticatedIndex][JLGStringConstants.kPeripheralInstance] as! CBPeripheral
            JLGBLEManager.sharedInstance.connectToPeripheral(peripheral)
            invalidateTimer()
            timerToGoBack = Timer.scheduledTimer(timeInterval: responseTimeout, target: self, selector: #selector(gotoPreviousScreen), userInfo: nil, repeats: false)
        } else {
            authenticated = true
            hideLoadingIndicator()
            showAlertForNoDeviceFound()
        }
    }

    // MARK: - Machine decal configuration
    /// Popup to show machine decal configuration
    func showPopupToConfigureMachineDecal() {
        let ac = UIAlertController(title: JLGStringConstants.kAlertTitleMachineDecal, message: JLGStringConstants.kAlertMessageMachineDecal, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionNo, style: .default, handler: gotoNextPeripheral))
        ac.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionYes, style: .default, handler: startAuthenticationAndWriteVehiclePin))
        present(ac, animated: true)
    }

    /// Disconnect with current BLE module and start pairing with next BLE module
    func gotoNextPeripheral(action: UIAlertAction) {
        if !isDeviceBluetoothOff {
            authenticatedIndex += 1
            if authenticatedIndex < peripheralsArray!.count {
                hideLoadingIndicator()
                showLoadingIndicator(self.navigationController!.view)
                JLGBLEManager.sharedInstance.disconnectFromPeripheral()
            } else {
                showAlertAndDisconnectBluetooth(message: JLGStringConstants.kAlertMessageMachineDecalScanAllPeripheral)
            }
        } else {
            showAlertForNoDeviceFound()
        }
    }

    /// Start authentication process before writing vehicle pin
    func startAuthenticationAndWriteVehiclePin(action: UIAlertAction) {
        if !isDeviceBluetoothOff {
            checkForAuthFreshnessValue()
        } else {
            showAlertForNoDeviceFound()
        }
    }

    @objc func checkForAuthFreshnessValue() {
        if JLGCommunicationManager.sharedInstance.authFressnessValue != 0 {
            JLGCommunicationManager.sharedInstance.authenticationCommand(btAuthFreshness: JLGCommunicationManager.sharedInstance.authFressnessValue)
        } else {
            self.perform(#selector(checkForAuthFreshnessValue), with: nil, afterDelay: 1)
        }
    }

    // MARK: - JLGBLEManager delegates

    func didWriteValueForCharacteristic(_ characteristic: CBCharacteristic) {
        /// Check for btVehiclePinUpdate response
        if characteristic.uuid.uuidString == kBtVehiclePinUpdateCharacteristicsUUID {
            JLGCommunicationManager.sharedInstance.shouldConfigureMachineDecal = false
            showAlertAndDisconnectBluetooth(message: JLGStringConstants.kAlertMessageMachineDecalSuccess, title: JLGStringConstants.kAlertTitleMachineDecalSuccess)
        }
    }

    func didDiscoverPeripherals(peripherals: [[String: Any]]) {
        self.peripheralsArray = peripherals
    }

    func didConnectToPeripheral(peripheral: CBPeripheral) {
        //Analytics.logEvent("rcs_connected_to_jlg_lift", parameters: [kUserID: userID, kTimeStamp: Date().PR2DateFormatterUTC()])
        invalidateTimer()
        titleLabel.text = JLGStringConstants.kConnected
        messageLabel.text = JLGStringConstants.kScanSuccessful
        imageView.image = #imageLiteral(resourceName: "VehicleConnected")
        JLGBLEManager.sharedInstance.authPinForAuthentication = self.peripheralsArray![authenticatedIndex][JLGStringConstants.kSerialNumber] as! Substring/*"100084"*/

        if JLGCommunicationManager.sharedInstance.shouldConfigureMachineDecal {
            showPopupToConfigureMachineDecal()
        }
    }

    func didDisconnectFromPeripheral(peripheral: CBPeripheral) {
        JLGCommunicationManager.sharedInstance.authFressnessValue = 0
        if JLGCommunicationManager.sharedInstance.shouldConfigureMachineDecal {
            hideLoadingIndicator()
            showLoadingIndicator(self.navigationController!.view)
            if authenticatedIndex < peripheralsArray!.count {
                connectToBLE()
                return
            }
        }
        hideLoadingIndicator()
        resetQRScanning()
        self.navigationController?.popViewController(animated: true)
    }

    func centralManagerDidUpdateBLEState(centralManager: CBCentralManager) {
        if centralManager.state == .poweredOff {
            isDeviceBluetoothOff = true
            gotoPreviousScreen()
        } else if centralManager.state == .poweredOn && (JLGBLEManager.sharedInstance.activePeripheral == nil || JLGBLEManager.sharedInstance.activePeripheral?.state != .connected) {
            isDeviceBluetoothOff = false
            JLGBLEManager.sharedInstance.startScanning()
        }
    }

    // MARK: - Check for authentication
    @objc func checkForAuthentication() {
        hideLoadingIndicator()
        if JLGCommunicationManager.sharedInstance.authenticationValue == kAuthenticationInvalid {
            showAlertAndDisconnectBluetooth(message: JLGStringConstants.kAlertMessageAuthenticationInvalid)
        } else if JLGCommunicationManager.sharedInstance.authenticationValue == kAuthenticationExpire {
            showAlertAndDisconnectBluetooth(message: JLGStringConstants.kAlertMessageAuthenticationExpire)
        } else {
            checkBLEVersion()
        }
    }

    // MARK: - Check BLE Version for OTA Firmware Upgrade
    func checkBLEVersion() {
        let bleVersionNumber = Double(JLGCommunicationManager.sharedInstance.vehicleBLEVersion)!
        let goldenImageVersionNumber = Double(JLGCommunicationManager.sharedInstance.vehicleGIVersion)!
        if bleVersionNumber >= minimumVersionToSupportOTAFirmwareUpgrade {
            if bleVersionNumber == currentVersionOfBinaryFile && goldenImageVersionNumber == currentVersionOfGIBinaryFile {
                if JLGCommunicationManager.sharedInstance.shouldConfigureMachineDecal {
                    JLGCommunicationManager.sharedInstance.btVehiclePinUpdateCommand(string: JLGBLEManager.sharedInstance.qrCodeSerialOrMachineDecalNumber as NSString)
                } else {
                    self.gotoTabBarController()
                }
            } else if goldenImageVersionNumber < currentVersionOfGIBinaryFile {
                JLGCommunicationManager.sharedInstance.shouldConfigureMachineDecal = false
                showAlertForOTAFirmwareUpgrade(firmwareName: JLGStringConstants.kGIBinaryFileName)
            } else if bleVersionNumber < currentVersionOfBinaryFile {
                JLGCommunicationManager.sharedInstance.shouldConfigureMachineDecal = false
                showAlertForOTAFirmwareUpgrade(firmwareName: JLGStringConstants.kBinaryFileName)
            } else {
                JLGCommunicationManager.sharedInstance.shouldConfigureMachineDecal = false
                showAlertForAppUpdateThroughAppStore()
            }
        } else {
            showAlertAndDisconnectBluetooth(message: JLGStringConstants.kAlertMessageVersionNotSupported)
        }
    }

    // MARK: - Go to next screen i.e. Home screen
    @objc func gotoTabBarController() {
        hideLoadingIndicator()
        if isJLGBTAAnalyzerFlowStart {
            self.performSegue(withIdentifier: jlgBluetoothAnalyzerTabViewController, sender: nil)
        } else {
            self.performSegue(withIdentifier: tabBarSegueIdentifier, sender: nil)
        }
    }

    // MARK: - Reset QR Code scanning process
    func resetQRScanning() {
        authenticated = false
        setupScanningImage(isScanning: true)
        captureSession?.stopRunning()
        toggleTorch(on: false)
    }

    // MARK: - Disconnect bluetooth connection
    func disconnectBluetooth() {
        hideLoadingIndicator()
        if isDisconnectedBLE {
            self.navigationController?.popViewController(animated: true)
        } else {
            showLoadingIndicator(self.navigationController!.view)
            JLGBLEManager.sharedInstance.disconnectFromPeripheral()
        }
    }

    // MARK: - OTA Firmware Upgrade methods
    /// Start OTA Reprogramming
    func startOTAReprogramming(firmwareName: String) {
        JLGCommunicationManager.sharedInstance.shouldConfigureMachineDecal = false
        hideLoadingIndicator()
        showLoadingIndicator(self.view)
        updateUIForBLEFirmwareUpgrade(heading: JLGStringConstants.kPleaseWait, description: JLGStringConstants.kInProgress)
        readBinaryFileContent(firmwareName: firmwareName)
    }

    /// Update UI for firmware upgrade
    func updateUIForBLEFirmwareUpgrade(heading: String, description: String = "") {
        titleLabel.text = heading
        messageLabel.text = description
    }

    /// Read binary file for OTA Reprogramming
    func readBinaryFileContent(firmwareName: String) {
        if let filepath = Bundle.main.path(forResource: firmwareName, ofType: JLGStringConstants.kBinaryFileType) {
            do {
                let contents = try Data(contentsOf: URL(fileURLWithPath: filepath))
                divideBinaryDataIntoChunks(completeData: Data(contents))
            } catch {
                hideLoadingIndicator()
                updateUIForBLEFirmwareUpgrade(heading: JLGStringConstants.kAlertTitleError)
                showAlertAndDisconnectBluetooth(message: JLGStringConstants.kAlertMessageReadingBinaryFile)
            }
        } else {
            hideLoadingIndicator()
            updateUIForBLEFirmwareUpgrade(heading: JLGStringConstants.kAlertTitleError)
            showAlertAndDisconnectBluetooth(message: JLGStringConstants.kAlertMessageBinaryFileNotFound)
        }
    }

    /// Divide binary file data into chunks(1024 bytes)
    func divideBinaryDataIntoChunks(completeData: Data) {
        let length = completeData.count
        let chunkSize = 1024
        var offset = 0
        repeat {
            let thisChunkSize = ((length - offset) > chunkSize) ? chunkSize : (length - offset)
            let chunk = completeData.subdata(in: offset..<offset + thisChunkSize )
            binaryFileChunkArray.append(chunk)
            offset += thisChunkSize
        } while (offset < length)
        requestForProgrammingFirmware(completeData: completeData)
    }

    /// Request For Programming (Firmware)
    func requestForProgrammingFirmware(completeData: Data) {
        let rfpString = "RFP," + String(completeData.count)
        print("RPF String: \(rfpString)")
        JLGBLEManager.sharedInstance.writeString(string: rfpString as NSString, charUUIDToWrite: kOTAReprogrammingDataStreamCharacteristicUUID)
        timerToCheckOTANotification = Timer.scheduledTimer(timeInterval: responseTimeout, target: self, selector: #selector(restartCAN2BLE), userInfo: nil, repeats: false)
    }

    /// Invalidate timer for OTA firmware upgrade
    @objc func invalidateOTATimer() {
        if timerToCheckOTANotification != nil {
            timerToCheckOTANotification?.invalidate()
            timerToCheckOTANotification = nil
        }
    }

    /// Ask user to restart CAN2BLE
    @objc func restartCAN2BLE() {
        hideLoadingIndicator()
        showAlertAndDisconnectBluetooth(message: JLGStringConstants.kAlertMessageBLERestart)
    }

    /// After receive CTS (Clear To Send) notification write data into BLE
    @objc func receiveNotificationForOTAReprogramming() {
        invalidateOTATimer()
        let receivedString = JLGCommunicationManager.sharedInstance.otaReprogrammingStatus

        if receivedString.contains("CTS") {
            writeDataIntoBLEWithChunks()
            binaryFileChunkIndex += 1
        } else if receivedString.contains("ProgramSuccess") {
            updateUIForBLEFirmwareUpgrade(heading: JLGStringConstants.kAlertTitleSuccess, description: JLGStringConstants.kAlertMessageOTAReprogrammingSuccess)
            isOTAFirmwareUpgradeSuccessful = true
        } else if receivedString.contains("NAK") {
            hideLoadingIndicator()
            updateUIForBLEFirmwareUpgrade(heading: JLGStringConstants.kAlertTitleError)
            showAlertAndDisconnectBluetooth(message: String(format: JLGStringConstants.kAlertMessageOTAReprogrammingError, receivedString))
        } else {
            hideLoadingIndicator()
            updateUIForBLEFirmwareUpgrade(heading: JLGStringConstants.kAlertTitleError)
            showAlertAndDisconnectBluetooth(message: String(format: JLGStringConstants.kAlertMessageOTAReprogrammingUnknownResponse, receivedString))
        }
    }

    @objc func popToPreviousScreen() {
        self.navigationController?.popViewController(animated: true)
    }

    /// Divide data into chunks based on MTU and write into BLE
    func writeDataIntoBLEWithChunks() {
        let completeData = binaryFileChunkArray[binaryFileChunkIndex]
        let length = completeData.count
        let chunkSize = maxMTUWithoutResponse - 3 ///MTU Size
        var offset = 0
        repeat {
            let thisChunkSize = ((length - offset) > chunkSize) ? chunkSize : (length - offset)
            let chunk = completeData.subdata(in: offset..<offset + thisChunkSize)
            JLGCommunicationManager.sharedInstance.otaReprogrammingDataStreamCommand(data: chunk)
            offset += thisChunkSize
        } while (offset < length)
    }

    // MARK: - Redirect app to App store
    func openAppStore() {
        if let url = URL(string: JLGStringConstants.kAppStoreURL),
            UIApplication.shared.canOpenURL(url) {
            UIApplication.shared.open(url, options: [:]) { (opened) in
                if opened {
                    print("App Store Opened")
                }
            }
        }
    }

    // MARK: - Show Alert
    @objc func showAlertForNoDeviceFound() {
        /// Bluetooth OFF alert
        if isDeviceBluetoothOff {
            self.showBluetoothTurnOffAlert()
        /// JLG Lift Not Found alert
        } else {
            if self.navigationController?.viewControllers.count == 4 {
                //Analytics.logEvent("rcs_jlg_lift_not_found", parameters: [kUserID: userID, kTimeStamp: Date().PR2DateFormatterUTC()])
                let alert = UIAlertController(title: JLGStringConstants.kAlertTitleJLGLiftNotFound, message: JLGStringConstants.kAlertMessageNoDeviceFound, preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionOK, style: .default) { _ in
                    self.navigationController?.popViewController(animated: true)
                })
                self.present(alert, animated: true, completion: nil)
            }
        }
    }

    func showAlertAndDisconnectBluetooth(message: String, title: String = JLGStringConstants.kAlertTitle) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionOK, style: .default) { _ in
            self.disconnectBluetooth()
        })
        self.present(alert, animated: true, completion: nil)
    }

    func showAlertForOTAFirmwareUpgrade(firmwareName: String) {
        maxMTUWithoutResponse = (JLGBLEManager.sharedInstance.activePeripheral?.maximumWriteValueLength(for: .withoutResponse)) ?? 182
        print("Max MTU Without Response: \(String(describing: maxMTUWithoutResponse))")

        maxMTUWithResponse = (JLGBLEManager.sharedInstance.activePeripheral?.maximumWriteValueLength(for: .withResponse)) ?? 512
        print("Max MTU With Response: \(String(describing: maxMTUWithResponse))")

        let alert = UIAlertController(title: JLGStringConstants.kAlertTitle, message: JLGStringConstants.kAlertMessageOTAFirmwareUpgrade, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionCancel, style: .cancel) { _ in
            self.disconnectBluetooth()
        })
        alert.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionUpgrade, style: .default) { _ in
            self.startOTAReprogramming(firmwareName: firmwareName)
        })
        self.present(alert, animated: true, completion: nil)
    }

    func showAlertForAppUpdateThroughAppStore() {
        let alert = UIAlertController(title: JLGStringConstants.kAlertTitle, message: JLGStringConstants.kAlertMessageExpired, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionCancel, style: .cancel) { _ in
            self.disconnectBluetooth()
        })
        alert.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionUpdate, style: .default) { _ in
            self.disconnectBluetooth()
            self.openAppStore()
        })
        self.present(alert, animated: true, completion: nil)
    }

}

// MARK: - JLGAlertMessageBluetoothTurnOff Delegate
extension JLGQRCodeScanViewController {
    /// showBluetoothTurnOffAlert get called when BLE power off
    func showBluetoothTurnOffAlert() {
        let bleOnOrOffAlert = JLGAlertMessageBluetoothTurnOff()
        bleOnOrOffAlert.delegate = self
        bleOnOrOffAlert.showAlertIfBLEIsOff(viewController: self)
    }

    func commonActionForBluetoothTurnOff() {
        self.navigationController?.popViewController(animated: true)
    }
}
