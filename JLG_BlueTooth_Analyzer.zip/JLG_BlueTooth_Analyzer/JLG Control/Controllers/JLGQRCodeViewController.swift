//
//  JLGQRCodeViewController.swift
//  JLG Control
//
//  Created by L&T on 17/04/18.
//  Copyright © 2018 L&T. All rights reserved.
//

import UIKit
import CoreBluetooth
import AVFoundation
//import Firebase

class JLGQRCodeViewController: GoogleAnalyticsViewController, JLGBLEDelegate {

    // MARK: - Variables and Constants
    var isCameraAccessDenied = false
    @IBOutlet weak var scanQRcodeButton: UIButton!
    @IBOutlet weak var menuButton: UIButton!

    // MARK: - View life cycle events
    override func viewDidLoad() {
        super.viewDidLoad()
        /// For Unit and UI Testing
        if CommandLine.arguments.contains(JLGTestingConstant.kEnableTesting) {
            assigningAccessibilityIdentifier()
        }

        JLGBLEManager.sharedInstance.delegate = self
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = true
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        JLGCommunicationManager.sharedInstance.shouldConfigureMachineDecal = false
        checkForCameraPermission()

        /// Reset all variable values to default
        if isTimeExceed5Minutes {
            isTimeExceed5Minutes = false
            JLGBLEManager.sharedInstance.qrCodeSerialOrMachineDecalNumber = "SKIP"
            JLGCommunicationManager.sharedInstance.showTimeOutAlert = false
            JLGCommunicationManager.sharedInstance.shouldStartForegroungTimer = false
            JLGCommunicationManager.sharedInstance.stopForegroundTimer()
            showAlertWithTitleAndMessage(title: JLGStringConstants.kAlertTitleSessionTimeout, message: JLGStringConstants.kAlertMessageSessionTimeout, actionTitle: JLGStringConstants.kAlertActionOK)
        } else if isOTAFirmwareUpgradeSuccessful {
            isOTAFirmwareUpgradeSuccessful = false
            showBLEFirmwareVerificationAlert()
        }
    }

    // MARK: - Check camera permission
    func checkForCameraPermission() {
        if AVCaptureDevice.authorizationStatus(for: .video) ==  .authorized {
            /// Already authorized
        } else {
            AVCaptureDevice.requestAccess(for: .video, completionHandler: { (granted: Bool) in
                if granted {
                    /// Access allowed
                    self.isCameraAccessDenied = false
                } else {
                    /// Access denied
                    self.isCameraAccessDenied = true
                }
            })
        }
    }

    // MARK: - Alerts
    /// Show alert when camera access denied by user
    func showAlertToOpenCamera() {
        let alert = UIAlertController(title: JLGStringConstants.kAlertTitleCameraAccessDenied, message: JLGStringConstants.kAlertMessageCameraAccessDenied, preferredStyle: UIAlertControllerStyle.alert)
        let actionSettings = UIAlertAction(title: JLGStringConstants.kAlertActionSettings, style: .default) { _ in
            guard let settingsUrl = URL(string: UIApplicationOpenSettingsURLString) else {
                return
            }
            if UIApplication.shared.canOpenURL(settingsUrl) {
                if #available(iOS 10.0, *) {
                    UIApplication.shared.open(settingsUrl, options: [:], completionHandler: nil)
                } else {
                    /// Fallback on earlier versions
                    UIApplication.shared.openURL(NSURL(string: UIApplicationOpenSettingsURLString)! as URL)
                }
            }
        }
        alert.addAction(actionSettings)
        alert.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionOK, style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }

    /// Show BLE firmawre upgrade verification alert
    func showBLEFirmwareVerificationAlert() {
        let alert = UIAlertController(title: JLGStringConstants.kPleaseWait, message: JLGStringConstants.kInProgress, preferredStyle: .alert)
        self.present(alert, animated: true, completion: nil)

        /// Change to desired number of seconds (in this case 15 seconds)
        let when = DispatchTime.now() + 15
        DispatchQueue.main.asyncAfter(deadline: when) {
            alert.dismiss(animated: false, completion: nil)
            self.showAlertWithTitleAndMessage(title: JLGStringConstants.kAlertTitleSuccess, message: JLGStringConstants.kAlertMessageOTAReprogrammingSuccess, actionTitle: JLGStringConstants.kAlertActionOK)
        }
    }

    // MARK: - Scan button action
    @IBAction func scanQRCodeButtonAction(_ sender: UIButton) {
        //Analytics.logEvent("rcs_scan_qr_code_action", parameters: [kUserID: userID, kTimeStamp: Date().PR2DateFormatterUTC()])
        gotoQRCodeScanViewController(cofigureMachineDecal: false)
    }

    // MARK: - Menu button action
    @IBAction func menuButtonAction(_ sender: UIButton) {
        let actionSheet = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        actionSheet.addAction(UIAlertAction(title: JLGStringConstants.kHome, style: .default) { _ in
            // Its working fine when coming form BMS RCS tab or Home view controller RCS button
            NotificationCenter.default.post(name: .notificationIdentifierForAppRouteToMainHomeVC, object: nil)
        })
        actionSheet.addAction(UIAlertAction(title: JLGStringConstants.kUserManual, style: .default) { _ in
            self.showUserManual()
        })
        actionSheet.addAction(UIAlertAction(title: JLGStringConstants.kTermsAndConditions, style: .default) { _ in
            self.navigationController?.popToRootViewController(animated: true)
        })
        actionSheet.addAction(UIAlertAction(title: JLGStringConstants.kConfigureDecal, style: .default) { _ in
            self.gotoQRCodeScanViewController(cofigureMachineDecal: true)
        })
        actionSheet.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionCancel, style: .cancel))
        present(actionSheet, animated: true)
    }

    // MARK: - Show user manual
    func showUserManual() {
        if Reachability.isConnectedToNetwork() {
            self.performSegue(withIdentifier: "JLGManualViewController", sender: nil)
        } else {
            showNetworkError()
        }
    }

    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "JLGManualViewController" {
            let vc = segue.destination as! JLGManualViewController
            vc.webURLString = JLGStringConstants.kManualWebLink
            vc.titleText = JLGStringConstants.kUserManual
        }
    }

    // MARK: - Move to data matrix scan screen
    func gotoQRCodeScanViewController(cofigureMachineDecal: Bool) {
        if isDeviceBluetoothOff {
            self.showBluetoothTurnOffAlert()
        } else if isCameraAccessDenied {
            showAlertToOpenCamera()
        } else {
            JLGCommunicationManager.sharedInstance.shouldConfigureMachineDecal = cofigureMachineDecal
            performSegue(withIdentifier: "JLGQRCodeScanViewController", sender: nil)
        }
    }

    // MARK: - JLGBLEManager delegates

    func centralManagerDidUpdateBLEState(centralManager: CBCentralManager) {
        if centralManager.state == .poweredOff {
            isDeviceBluetoothOff = true
        } else if centralManager.state == .poweredOn && (JLGBLEManager.sharedInstance.activePeripheral == nil || JLGBLEManager.sharedInstance.activePeripheral?.state != .connected) {
            isDeviceBluetoothOff = false
        }
    }
}

// MARK: - JLGAlertMessageBluetoothTurnOff Delegate
extension JLGQRCodeViewController {
    /// showBluetoothTurnOffAlert get called when BLE power off
    func showBluetoothTurnOffAlert() {
        let bleOnOrOffAlert = JLGAlertMessageBluetoothTurnOff()
        bleOnOrOffAlert.showAlertIfBLEIsOff(viewController: self)
    }
}

extension JLGQRCodeViewController {
    /// Assigning Accessibility Identifier For UI Testing
    func assigningAccessibilityIdentifier() {
        if #available(iOS 11.0, *) {
            view.accessibilityIdentifier = JLGTestingConstant.kJLGQRCodeVC
            scanQRcodeButton.accessibilityIdentifier = JLGTestingConstant.kScanQRcodeButton
            menuButton.accessibilityIdentifier = JLGTestingConstant.kMenuButton
        }
    }
}
