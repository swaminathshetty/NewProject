//
//  JLGBMSSelectMachineModelViewController.swift
//  JLG Control
//
//  Created by Apple on 31/01/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

protocol JLGSelectMachineModelDelegate: class {
    func didSelectMachineModel(machineModel: [String])
    func didNotSelectAnyMachineModel()
}

class JLGBMSSelectMachineModelViewController: GoogleAnalyticsViewController, UITableViewDelegate, UITableViewDataSource {

    weak var delegateJLGSelectMachineModelDelegate: JLGSelectMachineModelDelegate?
    @IBOutlet weak var selectModelTableView: UITableView!
    @IBOutlet weak var doneBarButton: UIButton!
    var selectModelData = [[String: [String]]]()
    var selectedIndexPaths = [IndexPath]()
    let peripheralsDevice = JLGBLEManager.sharedInstance.peripheralsInfo
    var machineModel: [String]?

    var searchModelWithThisSeriesType = [JLGStringConstants.kNoModelSeriesText, JLGStringConstants.kUnknownSeriesText, JLGStringConstants.kAESeriesText, JLGStringConstants.kERTSeriesText, JLGStringConstants.kESSeriesText, JLGStringConstants.kRTSeriesText, JLGStringConstants.kRSeriesText]

    // MARK: - View life cycle events
    override func viewDidLoad() {
        super.viewDidLoad()
        /// For Unit and UI Testing
        if CommandLine.arguments.contains(JLGTestingConstant.kEnableTesting) {
            assigningAccessibilityIdentifier()
        }

        /// Enable or disable done button
        self.doneBarButtonEnableStatus()
        /// Get machine model using machine machine series name
        self.addValuesInSelectModelData()
        /// Add delegate methods of table view
        self.selectModelTableView.delegate = self
        self.selectModelTableView.dataSource = self
        self.selectModelTableView.tableHeaderView?.backgroundColor = .lightGray
    }

    // MARK: - Other methods
    /// Add values in selectModelData array
    func addValuesInSelectModelData() {
        for modelSeries in searchModelWithThisSeriesType {
            if let dic = self.createArrayOfDic(searchString: modelSeries) {
                selectModelData.append(dic)
            }
        }
    }

    /// Get machine model by passing particular machine series
    func createArrayOfDic(searchString: String) -> [String: [String]]? {
        if let mModel = machineModel {
            let filterArray = mModel.filter({ $0.range(of: searchString, options: .caseInsensitive) != nil})
            machineModel?.removeAll(where: { filterArray.contains($0) })
            if !filterArray.isEmpty {
                return [searchString: filterArray.removingDuplicates()]
            }
        }

        return nil
    }

    /// Enable or disable done button
    func doneBarButtonEnableStatus() {
        if selectedIndexPaths.isEmpty {
            self.doneBarButton.isEnabled = false
            self.doneBarButton.setTitleColor(UIColor.white.withAlphaComponent(0.5), for: .normal)
        } else {
            self.doneBarButton.isEnabled = true
            self.doneBarButton.setTitleColor(UIColor.white, for: .normal)
        }
    }

    func getArrayOfMachineModel() -> [String] {
        var arrayOfMachineModel = [String]()
        for indexPath in selectedIndexPaths {
            for (_, value) in selectModelData [indexPath.section] {
                arrayOfMachineModel.append(value[indexPath.row])
            }
        }

        return arrayOfMachineModel
    }

}

// MARK: - IBAction
extension JLGBMSSelectMachineModelViewController {
    /// Navigation Bar button action
    @IBAction func cancelButtonAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
        self.delegateJLGSelectMachineModelDelegate?.didNotSelectAnyMachineModel()
    }

    @IBAction func doneButtonAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
        self.delegateJLGSelectMachineModelDelegate?.didSelectMachineModel(machineModel: self.getArrayOfMachineModel())
    }
}

// MARK: - TableView Delegate and Datasource
extension JLGBMSSelectMachineModelViewController {

    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let frame = tableView.frame
        let label = UILabel(frame: CGRect(x: 15, y: 6, width: frame.size.width - 30, height: 20))
        label.textColor = .black
        label.tag = section
        for (key, _) in selectModelData[section] {
            label.text = "\(key) \(JLGStringConstants.kSeriesText)"
        }

        let headerView = UIView(frame: CGRect(x: 0, y: 0, width: frame.size.width, height: frame.size.height))
        headerView.backgroundColor = UIColor.init(red: 247/255, green: 247/255, blue: 247/255, alpha: 1.0)
        headerView.addSubview(label)

        return headerView
    }

    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 32.0
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return selectModelData.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        for (_, value) in selectModelData[section] {
            return value.count
        }

        return 0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.selectModelTableView.dequeueReusableCell(withIdentifier: "JLGSelectModelCell", for: indexPath) as! JLGSelectModelCell
        for (_, value) in selectModelData [indexPath.section] {
            cell.modelLabel?.text = value[indexPath.row]
        }
        cell.accessibilityIdentifier = "\(JLGTestingConstant.kJLGSelectModelCell)\(indexPath.row)"

        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedIndexPaths.append(indexPath)
        self.doneBarButtonEnableStatus()
    }

    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        selectedIndexPaths.removeObject(object: indexPath)
        self.doneBarButtonEnableStatus()
    }
}

extension JLGBMSSelectMachineModelViewController {
    /// Assigning Accessibility Identifier For UI Testing
    func assigningAccessibilityIdentifier() {
        if #available(iOS 11.0, *) {
            view.accessibilityIdentifier = JLGTestingConstant.kJLGSelectMachineModelVC
            doneBarButton.accessibilityAttributedLabel = NSAttributedString(string: JLGTestingConstant.kJLGSelectMachineModelDoneButton)
            selectModelTableView.accessibilityIdentifier = JLGTestingConstant.kJLGSelectMachineModelTableView
        }
    }
}
