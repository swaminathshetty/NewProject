//
//  JLGRCSVehicleControlViewController.swift
//  JLG Control
//
//  Created by L&T on 09/04/18.
//  Copyright © 2018 L&T. All rights reserved.
//

import UIKit
import CoreBluetooth
import AudioToolbox
//import Firebase

class JLGRCSVehicleControlViewController: GoogleAnalyticsViewController, JLGJoystickViewDelegate, JLGBLEDelegate, UIGestureRecognizerDelegate {

    // MARK: Variables and Constants
    @IBOutlet weak var torqueHiLoButton: UIButton!
    @IBOutlet weak var joystickContainerView: UIView!
    @IBOutlet var joystickView: JLGJoystickView!
    @IBOutlet weak var joystickDismissView: UIView!
    @IBOutlet var vehiclePathView: JLGVehiclePathView!
    @IBOutlet weak var eStopButton: UIButton!
    @IBOutlet weak var hornButton: UIButton!
    @IBOutlet weak var driveIndicationImageView: UIImageView!
    @IBOutlet weak var rssaiLabel: UILabel!
    @IBOutlet weak var driveLabel: UILabel!
    @IBOutlet weak var steerLabel: UILabel!
    @IBOutlet weak var wdLabel: UILabel!
    @IBOutlet weak var dtcImageView: UIImageView!
    @IBOutlet weak var joystickLeftOuterView: UIView!
    @IBOutlet weak var joystickRightOuterView: UIView!
    @IBOutlet weak var joystickTopOuterView: UIView!
    @IBOutlet weak var joystickBottomOuterView: UIView!
    @IBOutlet weak var joystickTopConstraints: NSLayoutConstraint!
    @IBOutlet weak var joystickBottomConstraints: NSLayoutConstraint!

    var alertControllerForDisconnection: UIAlertController?
    var repeatCommandSendingTimer: Timer?
    var driveValueCurrent: Int8 = 0
    var steerValueCurrent: Int8 = 0
    var timerToShowRSSIValue: Timer?
    var counterForRemoteStop = 0
    var isEstopPressed = false
    var isSteerAlreadyVibrated = false

    // MARK: - View life cycle events
    override func viewDidLoad() {
        // #lizard forgives the complexity
        super.viewDidLoad()
        /// For Unit and UI Testing
        if CommandLine.arguments.contains(JLGTestingConstant.kEnableTesting) {
            assigningAccessibilityIdentifier()
        }

        /// Restrict to default swipe left navigation effect
        self.navigationController?.interactivePopGestureRecognizer?.delegate = self
        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = false

        /// Setup initial UI
        setupUI()
        JLGCommunicationManager.sharedInstance.resetAllCommands()
        self.eStopButton.isEnabled = true
        self.joystickView.delegate = self
        self.navigationItem.titleView = UIImageView(image: #imageLiteral(resourceName: "JLGLogo"))
        JLGCommunicationManager.sharedInstance.isWatchdogResponseReceived = true

        /// Start timer to send command in every 100 ms
        startRepeatCommandSendingTimer()

        JLGBLEManager.sharedInstance.delegate = self
        JLGCommunicationManager.sharedInstance.btRemoteInitCommand(remoteInitValue: BtCanRemoreInitEnum.Start)
        JLGCommunicationManager.sharedInstance.btRemStopCommand(remStopValue: BtCanRemStopEnum.Stop)

        /// Add notification for resign active state
        NotificationCenter.default.addObserver(self, selector: #selector(willResignActive), name: NSNotification.Name.UIApplicationWillResignActive, object: nil)

        /// Add notification for any warning alert
        NotificationCenter.default.addObserver(self, selector: #selector(receivedNotificationForWarning), name: .notificationIdentifierForWarningStatus, object: nil)

        /// Start timer to show RSSI value (Future Use)
        //timerToShowRSSIValue = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(readRSSIValue), userInfo: nil, repeats: true)

        receivedNotificationForWarning()

        joystickTopConstraints.constant = self.view.frame.height * 0.102
        joystickBottomConstraints.constant = self.view.frame.height * 0.058
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        JLGBLEManager.sharedInstance.delegate = self
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        /// Add notification for timeout alert
        NotificationCenter.default.addObserver(self, selector: #selector(methodOfReceivedNotification(notification:)), name: .notificationIdentifierForExitRemoteMode, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(willResignActive), name: .notificationIdentifierForSessionTimeout, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(receivedNotificationForRemoteStatus(notification:)), name: .notificationIdentifierForRemoteStatus, object: nil)
    }

    override func viewWillDisappear(_ animated: Bool) {
        // #lizard forgives the complexity
        super.viewWillDisappear(animated)
        hideLoadingIndicator()
        //Analytics.logEvent("rcs_drive_exit", parameters: [kUserID: userID, kTimeStamp: Date().PR2DateFormatterUTC()])

        /// Reset all commands and invalidate timer
        invalidateRSSITimer()
        alertControllerForDisconnection?.dismiss(animated: false, completion: nil)
        JLGCommunicationManager.sharedInstance.resetAllCommands()
        JLGCommunicationManager.sharedInstance.btRemoteInitCommand(remoteInitValue: BtCanRemoreInitEnum.Stop)
        JLGCommunicationManager.sharedInstance.btRemStopCommand(remStopValue: BtCanRemStopEnum.Start)
        stopRepeatCommandSendingTimer()

        /// Remove notification observer
        NotificationCenter.default.removeObserver(self, name: .notificationIdentifierForExitRemoteMode, object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIApplicationWillResignActive, object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.notificationIdentifierForSessionTimeout, object: nil)
        NotificationCenter.default.removeObserver(self, name: .notificationIdentifierForWarningStatus, object: nil)
        NotificationCenter.default.removeObserver(self, name: .notificationIdentifierForRemoteStatus, object: nil)
    }

    deinit {
        /// Remove all notification observer
        NotificationCenter.default.removeObserver(self)
    }

    // MARK: - Initial setup
    func setupUI() {
        self.torqueHiLoButton.isSelected = (JLGCommunicationManager.sharedInstance.btHiLoTorqueValue == .Low) ? false : true

        /// Adding the long press gesture to the horn button
        let longGesture = UILongPressGestureRecognizer(target: self, action: #selector(hornButtonAction(_:)))
        self.hornButton.addGestureRecognizer(longGesture)
    }

    /// Long gesture horn action
    @objc func hornButtonAction(_ sender: UIGestureRecognizer) {
        if sender.state == .ended {
            hornButton.setImage(#imageLiteral(resourceName: "HornButtonNormal"), for: .normal)
            JLGCommunicationManager.sharedInstance.btHornEnableCommand(hornEnableValue: .Low)
        } else if sender.state == .began {
            //Analytics.logEvent("rcs_main_control_horn_action", parameters: [kUserID: userID, kTimeStamp: Date().PR2DateFormatterUTC()])
            hornButton.setImage(#imageLiteral(resourceName: "HornButtonSelected"), for: .normal)
            JLGCommunicationManager.sharedInstance.btHornEnableCommand(hornEnableValue: .High)
        }
    }

    /// Single tap horn action
    @IBAction func hornButtonTapAction(_ sender: UIButton) {
        hornButton.isEnabled = false
        JLGCommunicationManager.sharedInstance.btHornEnableCommand(hornEnableValue: .High)
        self.perform(#selector(disableHorn), with: nil, afterDelay: 0.5)
    }

    /// Set horn value to 0 after 0.5 sec when single tap perform
    @objc func disableHorn() {
        hornButton.isEnabled = true
        JLGCommunicationManager.sharedInstance.btHornEnableCommand(hornEnableValue: .Low)
    }

    // MARK: - Received Remote Status notification
    @objc func receivedNotificationForRemoteStatus(notification: NSNotification) {
        if JLGCommunicationManager.sharedInstance.btRemStatus.btStowed == 0 ||
            JLGCommunicationManager.sharedInstance.btRemStatus.btGroundMode == 0 ||
            JLGCommunicationManager.sharedInstance.btRemStatus.btVehicleCharging == 1 ||
            JLGCommunicationManager.sharedInstance.btRemStatus.btVehicleSafeMode == 1 {
            self.navigationController?.popViewController(animated: true)
        }
    }

    // MARK: - Resign active notification method
    @objc private func willResignActive(notification: Notification) {
        self.navigationController?.popViewController(animated: false)
    }

    // MARK: - Timeout alert notification method
    @objc func methodOfReceivedNotification(notification: NSNotification) {
        if !isEstopPressed {
            JLGCommunicationManager.sharedInstance.showTimeOutAlert = true
            self.navigationController?.popViewController(animated: true)
        }
    }

    // MARK: - RSSI value notification method
    @objc func readRSSIValue() {
        rssaiLabel.text = String(Int(truncating: JLGBLEManager.sharedInstance.rssiValue))
    }

    func invalidateRSSITimer() {
        if timerToShowRSSIValue != nil {
            timerToShowRSSIValue?.invalidate()
            timerToShowRSSIValue = nil
        }
    }

    // MARK: - Warning notification method
    @objc func receivedNotificationForWarning() {
        if JLGCommunicationManager.sharedInstance.warningIndicatorValue == 1 {
            dtcImageView.image = #imageLiteral(resourceName: "DTCWarningEnable")
        } else {
            dtcImageView.image = #imageLiteral(resourceName: "DTCWarningDisabled")
        }
    }

    // MARK: - E Stop button action
    @IBAction func eStopButtonAction(_ sender: UIButton) {
        //Analytics.logEvent("rcs_estop_action", parameters: [kUserID: userID, kTimeStamp: Date().PR2DateFormatterUTC()])
        hideLoadingIndicator()
        showLoadingIndicator(self.navigationController!.view)
        self.eStopButton.isEnabled = false
        isEstopPressed = true
        JLGCommunicationManager.sharedInstance.btRemEStopCommand(remEStopValue: BtCanRemEStopEnum.Stop)
    }

    // MARK: - Torque button action
    @IBAction func torqueSpeedModeToggleButtonAction(_ sender: UIButton) {
        //Analytics.logEvent("rcs_torque_action", parameters: [kUserID: userID, kTimeStamp: Date().PR2DateFormatterUTC()])
        self.torqueHiLoButton.isSelected = !self.torqueHiLoButton.isSelected
        if self.torqueHiLoButton.isSelected {
            JLGCommunicationManager.sharedInstance.btHiLoTorqueCommand(hiLoTorqueValue: .High)
        } else {
            JLGCommunicationManager.sharedInstance.btHiLoTorqueCommand(hiLoTorqueValue: .Low)
        }
    }

    // MARK: - Right bar button action method
    @IBAction func rightBarCustomButtonAction(_ sender: UIButton) {
        //Analytics.logEvent("rcs_main_control_ble_icon_action", parameters: [kUserID: userID, kTimeStamp: Date().PR2DateFormatterUTC()])
        showAlertForDisconnectPermission()
    }

    // MARK: - Show alert for BLE disconnection permission
    func showAlertForDisconnectPermission() {
        alertControllerForDisconnection = UIAlertController(title: JLGStringConstants.kAlertTitleDisconnectJLGLift, message: JLGStringConstants.kAlertMessageDisconnection, preferredStyle: UIAlertControllerStyle.alert)
        alertControllerForDisconnection!.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionCancel, style: .default, handler: nil))
        alertControllerForDisconnection!.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionDisconnect, style: .default) { _ in
            hideLoadingIndicator()
            showLoadingIndicator((self.navigationController!.view))
            JLGBLEManager.sharedInstance.disconnectFromPeripheral()
        })
        self.present(alertControllerForDisconnection!, animated: true, completion: nil)
    }

    // MARK: - JoystickView Delegate methods
    /// Change drive value
    func didChangeDriveValue(_ value: Int8, driveDirection: DriveDirection) {
        driveValueCurrent = value
        changeDriveIndicationImage()
        self.vehiclePathView.calculateFrameAndAnimateVehicleView(value)
        JLGCommunicationManager.sharedInstance.updateDriveValue(driveUpdatedValue: value)
        JLGCommunicationManager.sharedInstance.stopForegroundTimer()

        /// Show forward and backward vehicle path indication
        if driveValueCurrent != 0 {
            vehiclePathView.indicationImageView.isHidden = false
            if driveDirection == .Forward {
                vehiclePathView.indicationImageView.image = #imageLiteral(resourceName: "DriveIndicationForward")
            } else {
                vehiclePathView.indicationImageView.image = #imageLiteral(resourceName: "DriveIndicationReverse")
            }
        }
    }

    /// Change steer value
    func didChangeSteerValue(_ value: Int8, steerDirection: SteerDirection) {
        steerValueCurrent = value
        changeDriveIndicationImage()
        self.vehiclePathView.changeVehicleDirection(steerDirection)
        JLGCommunicationManager.sharedInstance.updateSteerValue(steerUpdatedValue: value)
        JLGCommunicationManager.sharedInstance.stopForegroundTimer()

        /// Vibrate only once when steer start
        if value == 100 || value == -100 {
            if !isSteerAlreadyVibrated {
                isSteerAlreadyVibrated = true
                switch UIDevice.current.value(forKey: "_feedbackSupportLevel") as? Int ?? 0 {
                case 0: AudioServicesPlayAlertSound(SystemSoundID(kSystemSoundID_Vibrate))
                default: AudioServicesPlaySystemSound(1521)
                }
            }
        } else {
            isSteerAlreadyVibrated = false
        }
    }

    /// Make joystick centered
    func didRecenterJoystick(_ driveValue: Int8, steerValue: Int8) {
        driveValueCurrent = 0
        steerValueCurrent = 0
        changeDriveIndicationImage()
        self.vehiclePathView.calculateFrameAndAnimateVehicleView(0)
        JLGCommunicationManager.sharedInstance.fingerOffStopSendingCommands()
        JLGCommunicationManager.sharedInstance.startForegroundTimer()

        /// Hide vehicle indication imageview
        vehiclePathView.indicationImageView.isHidden = true
    }

    /// Dismiss joystick when it goes beyond red line (out of joystick container view)
    func goingOutOfJoystickArea() {
        // #lizard forgives the complexity
        AudioServicesPlayAlertSound(SystemSoundID(kSystemSoundID_Vibrate))
        self.joystickView.shouldChangeXY = false

        if self.joystickLeftOuterView.bounds.contains(self.joystickView.dragButtonPanGesture.location(in: self.joystickLeftOuterView)) {
            let newFrame = CGRect(x: 0.25, y: joystickView.joyStickButton.frame.origin.y, width: joystickView.joyStickButton.frame.size.width, height: joystickView.joyStickButton.frame.size.height)
            self.joystickView.joyStickButton.frame = newFrame
            self.joystickView.changeDriveAndSteerValue(isInsideRegion: false, isReachedLeftOrRightBorder: true, isReachedTopOrBottomBorder: false)
        } else if self.joystickRightOuterView.bounds.contains(self.joystickView.dragButtonPanGesture.location(in: self.joystickRightOuterView)) {
            let newFrame = CGRect(x: (joystickView.frame.size.width - joystickView.joyStickButton.frame.size.width - 0.25), y: joystickView.joyStickButton.frame.origin.y, width: joystickView.joyStickButton.frame.size.width, height: joystickView.joyStickButton.frame.size.height)
            self.joystickView.joyStickButton.frame = newFrame
            self.joystickView.changeDriveAndSteerValue(isInsideRegion: false, isReachedLeftOrRightBorder: true, isReachedTopOrBottomBorder: false)
        } else if (driveValueCurrent < 100 && driveValueCurrent > 50) && (self.joystickTopOuterView.bounds.contains(self.joystickView.dragButtonPanGesture.location(in: self.joystickTopOuterView))) {
            let newFrame = CGRect(x: joystickView.joyStickButton.frame.origin.x, y: 0.25, width: joystickView.joyStickButton.frame.size.width, height: joystickView.joyStickButton.frame.size.height)
            self.joystickView.joyStickButton.frame = newFrame
            didChangeDriveValue(100, driveDirection: .Forward)
        } else if (driveValueCurrent < -50 && driveValueCurrent > -100) && (self.joystickBottomOuterView.bounds.contains(self.joystickView.dragButtonPanGesture.location(in: self.joystickBottomOuterView))) {
            let newFrame = CGRect(x: joystickView.joyStickButton.frame.origin.x, y: (joystickView.frame.size.height - joystickView.joyStickButton.frame.size.height - 0.25), width: joystickView.joyStickButton.frame.size.width, height: joystickView.joyStickButton.frame.size.height)
            self.joystickView.joyStickButton.frame = newFrame
            didChangeDriveValue(-100, driveDirection: .Reverse)
        } else if self.joystickTopOuterView.bounds.contains(self.joystickView.dragButtonPanGesture.location(in: self.joystickTopOuterView)) || self.joystickBottomOuterView.bounds.contains(self.joystickView.dragButtonPanGesture.location(in: self.joystickBottomOuterView)) {
            self.joystickView.changeDriveAndSteerValue(isInsideRegion: false, isReachedLeftOrRightBorder: false, isReachedTopOrBottomBorder: true)
        } else {
            self.joystickView.changeDriveAndSteerValue(isInsideRegion: false, isReachedLeftOrRightBorder: false, isReachedTopOrBottomBorder: false)
        }

        if self.joystickDismissView.bounds.contains(self.joystickView.dragButtonPanGesture.location(in: self.joystickDismissView)) {
            self.joystickView.cancelPanGesture()
        }
    }

    // MARK: - Change joystick indication image based on vehicle movement
    func changeDriveIndicationImage() {
        // #lizard forgives the complexity
        if driveValueCurrent == 0 && steerValueCurrent == 0 {
            driveIndicationImageView.image = #imageLiteral(resourceName: "DrivingStop")
        } else if driveValueCurrent > 0 && steerValueCurrent == 0 {
            driveIndicationImageView.image = #imageLiteral(resourceName: "DrivingForward")
        } else if driveValueCurrent > 0 && steerValueCurrent == 100 {
            driveIndicationImageView.image = #imageLiteral(resourceName: "DrivingForwardAndRight")
        } else if driveValueCurrent > 0 && steerValueCurrent == -100 {
            driveIndicationImageView.image = #imageLiteral(resourceName: "DrivingForwardAndLeft")
        } else if driveValueCurrent < 0 && steerValueCurrent == 0 {
            driveIndicationImageView.image = #imageLiteral(resourceName: "DrivingReverse")
        } else if driveValueCurrent < 0 && steerValueCurrent == 100 {
            driveIndicationImageView.image = #imageLiteral(resourceName: "DrivingReverseAndRight")
        } else if driveValueCurrent < 0 && steerValueCurrent == -100 {
            driveIndicationImageView.image = #imageLiteral(resourceName: "DrivingReverseAndLeft")
        } else if driveValueCurrent == 0 && steerValueCurrent == 100 {
            driveIndicationImageView.image = #imageLiteral(resourceName: "DrivingRight")
        } else if driveValueCurrent == 0 && steerValueCurrent == -100 {
            driveIndicationImageView.image = #imageLiteral(resourceName: "DrivingLeft")
        }
    }

    /// Disconnect BLE
    @objc func disconnectBLE() {
        if counterForRemoteStop <= 1 {
            JLGBLEManager.sharedInstance.disconnectFromPeripheral()
        }
    }

    // MARK: - JLGBLEManager Delegate methods

    /// Perform action when write any characteristics with response
    func didWriteValueForCharacteristic(_ characteristic: CBCharacteristic) {

        /// Check for watchdog response
        if characteristic.uuid.uuidString == kBtWatchdogCharacteristicsUUID {
            JLGCommunicationManager.sharedInstance.isWatchdogResponseReceived = true
        }

        /// Check for E-Stop response
        else if characteristic.uuid.uuidString == kBtRemEStopCharacteristicsUUID {
            /// After getting first response reset all commands
            JLGCommunicationManager.sharedInstance.btRemStopCommand(remStopValue: BtCanRemStopEnum.Start)
            JLGCommunicationManager.sharedInstance.btRemEStopCommand(remEStopValue: BtCanRemEStopEnum.Start)
            JLGCommunicationManager.sharedInstance.resetAllCommands()

            /// Wait for second response to reset then disconnect active peripheral
            counterForRemoteStop += 1
            if counterForRemoteStop == 3 {
                JLGBLEManager.sharedInstance.disconnectFromPeripheral()
            }
        }
    }

    /// Perform action when connect to a peripheral
    func didConnectToPeripheral(peripheral: CBPeripheral) {
        isDisconnectedBLE = false
    }

    /// Perform action when disconnect to a peripheral
    func didDisconnectFromPeripheral(peripheral: CBPeripheral) {
        isDisconnectedBLE = true
        JLGCommunicationManager.sharedInstance.foregroundTimerCounter = 0
        dtcImageView.image = #imageLiteral(resourceName: "DTCWarningDisabled")

        hideLoadingIndicator()
        flagForDisconnectPeripheral = 1
        self.navigationController?.popViewController(animated: true)
    }

    /// Perform action when device bluetooth state changed (ON/OFF)
    func centralManagerDidUpdateBLEState(centralManager: CBCentralManager) {
        if centralManager.state == .poweredOff {
            self.navigationController?.popViewController(animated: true)
        } else if centralManager.state == .poweredOn && (JLGBLEManager.sharedInstance.activePeripheral == nil || JLGBLEManager.sharedInstance.activePeripheral?.state != .connected) {
        }
    }

    // MARK: - Timer to send values in every 100 miliseconds
    /// StartRepeatCommandSendingTimer to routine call sending the steer, drive, lift command
    func startRepeatCommandSendingTimer() {
        stopRepeatCommandSendingTimer()
        self.repeatCommandSendingTimer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(repeatSendCommandIn100MiliSecondsDuration), userInfo: nil, repeats: true)
    }

    /// Reset 100 milisecond timer when finger off from joystick
    func stopRepeatCommandSendingTimer() {
        if self.repeatCommandSendingTimer != nil {
            self.repeatCommandSendingTimer?.invalidate()
            self.repeatCommandSendingTimer = nil
        }
    }

    /// RepeatSendCommandIn100MiliSecondsDuration Any value greater than
    @objc func repeatSendCommandIn100MiliSecondsDuration() {
        JLGCommunicationManager.sharedInstance.repeatSendCommandIn100MiliSecondsDuration()
        driveLabel.text = String(Int(JLGCommunicationManager.sharedInstance.driveValue))
        steerLabel.text = String(Int(JLGCommunicationManager.sharedInstance.steerValue))
        wdLabel.text = String(Int(JLGCommunicationManager.sharedInstance.btWatchdogValue))
    }

}

extension JLGRCSVehicleControlViewController {
    /// Assigning Accessibility Identifier For UI Testing
    func assigningAccessibilityIdentifier() {
        if #available(iOS 11.0, *) {
            view.accessibilityIdentifier = JLGTestingConstant.kJLGVehicleControlVC
            self.torqueHiLoButton.accessibilityIdentifier = JLGTestingConstant.kTorqueHiLoButton
            self.eStopButton.accessibilityIdentifier = JLGTestingConstant.kEStopButton
            self.hornButton.accessibilityIdentifier = JLGTestingConstant.kVCHornButton
            self.joystickLeftOuterView.accessibilityIdentifier = JLGTestingConstant.kJoystickLeftOuterView
            self.joystickRightOuterView.accessibilityIdentifier = JLGTestingConstant.kJoystickRightOuterView
            self.joystickTopOuterView.accessibilityIdentifier = JLGTestingConstant.kJoystickTopOuterView
            self.joystickBottomOuterView.accessibilityIdentifier = JLGTestingConstant.kJoystickBottomOuterView

            self.joystickView.joyStickButton.accessibilityIdentifier = JLGTestingConstant.kJoyStickButton
        }
    }
}
