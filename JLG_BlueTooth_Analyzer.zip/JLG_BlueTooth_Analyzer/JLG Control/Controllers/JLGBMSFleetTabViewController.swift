//
//  JLGBMSFleetTabViewController.swift
//  JLG Control
//
//  Created by Apple on 11/11/19.
//  Copyright © 2019 L&T. All rights reserved.
//

import UIKit
import CoreBluetooth

class JLGBMSFleetTabViewController: GoogleAnalyticsViewController, UITableViewDelegate, UITableViewDataSource, JLGBLEDelegate, UIScrollViewDelegate, JLGSelectMachineModelDelegate, JLGAlertMessageBluetoothTurnOffDelegate {

    @IBOutlet weak var segmentControl: UISegmentedControl!
    @IBOutlet weak var bmsFeetTableView: UITableView!
    fileprivate var isRequiredAttention = false
    fileprivate var isModelSearch = false
    fileprivate var isStartScanningAgain = true
    fileprivate var timerToGoBack: Timer?
    fileprivate var isPresentViewControllerOpen = false

    var refreshControl = UIRefreshControl()
    var sortByMachineModel = [String]()
    var previousSegmentIndex: Int = 0
    let jlgBMSSerialScreenViewController = "JLGBMSSerialScreenViewController"
    let jlgSelectModelNavigationController = "JLGSelectModelNavigationController"
    var timerToConnectMachine: Timer?
    var selectedIndexRow: Int = 0
    fileprivate let blank = ""
    var startScanAfterConnectingDevice = false

    // MARK: - View life cycle events
    override func viewDidLoad() {
        super.viewDidLoad()
        /// For Unit and UI Testing
        if CommandLine.arguments.contains(JLGTestingConstant.kEnableTesting) {
            assigningAccessibilityIdentifier()
        }

        /// Setup Delegate
        bmsFeetTableView.delegate = self
        bmsFeetTableView.dataSource = self
//        JLGBLEManager.sharedInstance.delegate = self
        /// Setting Navigation bar
        self.navigationItem.titleView = UIImageView(image: UIImage(named: JLGStringConstants.kJLGMobileControlLogo))
        self.setupTableUI()
        /// Setup Refresher control
        self.setupRefreshControlUI()

        //Set tint color for segment control
        setSegmentControlTintColorForIos13(segmentControl: segmentControl)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        JLGBLEManager.sharedInstance.delegate = self
        JLGBLEManager.sharedInstance.disconnectFromPeripheral()
        isJLGBMSSerialScreenViewControllerOpen = false
        JLGCommunicationManager.sharedInstance.vehicleBLEVersion = ""

        if isStartScanningAgain {
            self.segmentControlAction(segmentControl.selectedSegmentIndex = 0)
        }
        isStartScanningAgain = true

        if startScanAfterConnectingDevice {
            hideLoadingIndicator()
            self.setupTableUI()
            startScanAfterConnectingDevice = false
        }
    }

//    override func viewDidDisappear(_ animated: Bool) {
//        super.viewDidDisappear(animated)
//        self.refreshControl.endRefreshing()
//    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(self, name: .notificationIdentifierForAuthentication, object: nil)
    }

    // MARK: - Other methods
    func setupTableUI() {
        /// Clean tableview
        JLGBLEManager.sharedInstance.peripheralsInfo = []
        self.bmsFeetTableView.reloadData()
        /// Start Loading Indicator
        self.startScan()

        /// For creating dummy data comment above lines and uncomment below line
//        if JLGBLEManager.sharedInstance.peripheralsInfo.count == 0 {
//            self.createDummyData()
//        }
    }

    func startScan() {
        /// Show loading view
        showLoadingIndicator(self.tabBarController!.view)
        /// Wait for 20 seconds, if no device getting at the time of scanning
        timerToGoBack = Timer.scheduledTimer(timeInterval: bmsScanningTimeout, target: self, selector: #selector(showAlertNoDeviceFound), userInfo: nil, repeats: false)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            JLGBLEManager.sharedInstance.startScanningForFleetScreen()
        }
    }

    func stopScan() {
        hideLoadingIndicator()
        //self.refreshControl.endRefreshing()
        self.invalidateTimer()
        JLGBLEManager.sharedInstance.stopScanning()
    }

    /// Invalidate timer
    func invalidateTimer() {
        /// Hide loading indicator
        hideLoadingIndicator()
        /// Invalid timer
        if timerToGoBack != nil {
            timerToGoBack?.invalidate()
            timerToGoBack = nil
        }
    }

    @objc func showAlertNoDeviceFound() {
        self.stopScan()
        let alert = UIAlertController(title: JLGStringConstants.kAlertTitle, message: JLGStringConstants.kAlertActiveDeviceFound, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionOK, style: .default) { _ in
            NotificationCenter.default.post(name: .notificationIdentifierForBMSHomeTabBar, object: nil)
            //self.navigationController?.popViewController(animated: true)
        })

        alert.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionRetry, style: .default) { _ in
            self.startScan()
        })

        self.present(alert, animated: true, completion: nil)
    }

    func setupRefreshControlUI() {
        refreshControl.tintColor = tintColor
        refreshControl.addTarget(self, action: #selector(startRefreshing), for: .valueChanged)
        bmsFeetTableView.addSubview(refreshControl)
    }

    @objc func startRefreshing(_ sender: Any) {
        self.refreshControl.endRefreshing()
        self.invalidateTimer()
        self.startScan()
    }

    func getMachineModel() -> [String] {
        var machineModel = [String]()
        for device in JLGBLEManager.sharedInstance.peripheralsInfo {
            for (key, value) in device where key == JLGStringConstants.kJLGFleetScreenModelInstance {
                let fleetSM = value as! JLGFleetScreenModel
                if !fleetSM.machineModel.isEmpty {
                    machineModel.append(fleetSM.machineModel)
                }
            }
        }
        return machineModel
    }

    func noMachineModelFoundAlert() {
        self.segmentControlAction(segmentControl.selectedSegmentIndex = previousSegmentIndex)
        self.showAlertWithTitleAndMessage(title: JLGStringConstants.kAlertTitle, message: JLGStringConstants.kAlertNoModelFound, actionTitle: JLGStringConstants.kAlertActionOK)
    }

    func presentSelectModelVC() {
        let navController = jlgBMSFlowStoryBoard.instantiateViewController(withIdentifier: jlgSelectModelNavigationController) as! UINavigationController
        let controller = navController.viewControllers[0] as! JLGBMSSelectMachineModelViewController
        controller.machineModel = self.getMachineModel()
        controller.delegateJLGSelectMachineModelDelegate = self
        if #available(iOS 13.0, *) {
            controller.isModalInPresentation = true
        }
        self.isPresentViewControllerOpen = true
        self.present(navController, animated: true, completion: nil)
    }

    func stopScanningViaOtherVC() {
        JLGBLEManager.sharedInstance.scanTimeout()
    }

    // MARK: - Navigation
    /// In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == jlgBMSSerialScreenViewController {
            let serialScreenObj = segue.destination as! JLGBMSSerialScreenViewController
            let peripheralObj: NSDictionary = JLGBLEManager.sharedInstance.peripheralsInfo[selectedIndexRow] as NSDictionary
            serialScreenObj.fleetScreenModelDictionary = peripheralObj
            //serialScreenObj.selectedIndexRow = self.selectedIndexRow
        }
    }
}

// MARK: - IBActions
extension JLGBMSFleetTabViewController {
    @IBAction func segmentControlAction(_ sender: Any) {
        //self.refreshControl.endRefreshing()
        isRequiredAttention = false
        isModelSearch = false

        switch segmentControl.selectedSegmentIndex {
        case 1: previousSegmentIndex = segmentControl.selectedSegmentIndex
        isRequiredAttention = true
        self.bmsFeetTableView.reloadData()

        case 2: if !self.getMachineModel().isEmpty {
            self.sortByMachineModel.removeAll()
            self.presentSelectModelVC()
        } else {
            self.noMachineModelFoundAlert()
            }

        default: previousSegmentIndex = segmentControl.selectedSegmentIndex
        self.bmsFeetTableView.reloadData()
        }
    }
}

// MARK: - Table View Data Source and Delegates
extension JLGBMSFleetTabViewController {
    /// Set number of rows in table view
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return JLGBLEManager.sharedInstance.peripheralsInfo.count
    }

    /// Creation of table view cell
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "JLGFleetTableViewCell", for: indexPath) as! JLGFleetTableViewCell
        let peripheralObj: NSDictionary = JLGBLEManager.sharedInstance.peripheralsInfo[indexPath.row] as NSDictionary
        cell.accessibilityIdentifier = "\(JLGTestingConstant.kJLGFleetTableViewCell)\(indexPath.row)"
        cell.fillCellData(dir: peripheralObj)
        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let peripheralObj: NSDictionary = JLGBLEManager.sharedInstance.peripheralsInfo[indexPath.row] as NSDictionary
        let jlgFleetScreenModelObj = peripheralObj.value(forKey: JLGStringConstants.kJLGFleetScreenModelInstance) as! JLGFleetScreenModel

        if  isRequiredAttention {
            if !jlgFleetScreenModelObj.isAlertAlarmActive {
                return 0
            }
        } else if isModelSearch {
            let containesValue = self.sortByMachineModel.contains(jlgFleetScreenModelObj.machineModel)
            if !containesValue {
                return 0
            }
        }

        return UITableViewAutomaticDimension
    }

    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        showLoadingIndicator(self.tabBarController!.view)
        JLGBLEManager.sharedInstance.centralManager.stopScan()
        NotificationCenter.default.addObserver(self, selector: #selector(checkForAuthentication), name: .notificationIdentifierForAuthentication, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(stopConnectingAndShowAlert), name: .notificationIdentifierForProtobufMissMatchArray, object: nil)

        self.selectedIndexRow = indexPath.row
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            self.connectToBLE(atIndex: self.selectedIndexRow)
        }
    }
}
// MARK: - JLGSelectMachineModelDelegate
extension JLGBMSFleetTabViewController {
    func didSelectMachineModel(machineModel: [String]) {
        isModelSearch = true
        self.isPresentViewControllerOpen = false
        self.checkDeviceBluetoothIsTurnOffOn()
        self.setIsStartScanningAgainBoolValue()
        self.sortByMachineModel = machineModel
        self.bmsFeetTableView.reloadData()
    }

    func didNotSelectAnyMachineModel() {
        self.isPresentViewControllerOpen = false
        self.checkDeviceBluetoothIsTurnOffOn()
        self.setIsStartScanningAgainBoolValue()
        self.segmentControlAction(segmentControl.selectedSegmentIndex = previousSegmentIndex)
    }

    func setIsStartScanningAgainBoolValue() {
        if #available(iOS 13.0, *) {
            isStartScanningAgain = true
        } else {
            isStartScanningAgain = false
        }
    }
}

// MARK: - JLGBLEManager delegates
extension JLGBMSFleetTabViewController {
    func didDiscoverPeripherals(peripherals: [[String: Any]]) {
        if startScanAfterConnectingDevice == false {
            self.bmsFeetTableView.reloadData()
        }
    }

    func didAddNewPeripheral(peripherals: [[String: Any]]) {
//        self.refreshControl.endRefreshing()
        self.invalidateTimer()
//        if !self.refreshControl.isRefreshing {
//            //JLGBLEManager.sharedInstance.sortPeripherals()
//            self.invalidateTimer()
//        }
        if startScanAfterConnectingDevice == false {
            self.bmsFeetTableView.reloadData()
        }
    }

    func didConnectToPeripheral(peripheral: CBPeripheral) {
        JLGBLEManager.sharedInstance.authPinForAuthentication = JLGBLEManager.sharedInstance.peripheralsInfo[selectedIndexRow][JLGStringConstants.kSerialNumber] as! Substring
        startScanAfterConnectingDevice = true
    }

    func centralManagerDidUpdateBLEState(centralManager: CBCentralManager) {
        hideLoadingIndicator()
        if centralManager.state == .poweredOff {
            isDeviceBluetoothOff = true
            self.checkDeviceBluetoothIsTurnOffOn()
        } else if centralManager.state == .poweredOn && (JLGBLEManager.sharedInstance.activePeripheral == nil || JLGBLEManager.sharedInstance.activePeripheral?.state != .connected) {
            isDeviceBluetoothOff = false
            if !self.isPresentViewControllerOpen {
                self.dismiss(animated: true, completion: nil)
            }
            JLGBLEManager.sharedInstance.centralManager.scanForPeripherals(withServices: nil, options: nil)
        }
    }

    func checkDeviceBluetoothIsTurnOffOn() {
        if isDeviceBluetoothOff {
            self.showBluetoothTurnOffAlert()
        }
    }
}

extension JLGBMSFleetTabViewController {
    // MARK: - BLE connection methods
    /// Connect to specific BLE device
    func connectToBLE(atIndex: Int) {
        JLGBLEManager.sharedInstance.centralManager.stopScan()
        timerToConnectMachine = Timer.scheduledTimer(timeInterval: responseTimeout, target: self, selector: #selector(stopConnectingAndShowAlert), userInfo: nil, repeats: false)
        let peripheral = JLGBLEManager.sharedInstance.peripheralsInfo[atIndex][JLGStringConstants.kPeripheralInstance] as! CBPeripheral
        JLGBLEManager.sharedInstance.connectToPeripheral(peripheral)
    }

    // MARK: - Check for authentication
    @objc func checkForAuthentication() {
        self.invalidateTimerToConnectMachine()
        NotificationCenter.default.removeObserver(self, name: .notificationIdentifierForAuthentication, object: nil)
        if JLGCommunicationManager.sharedInstance.authenticationValue == kAuthenticationInvalid {
            self.showAlertWithTitleAndMessage(title: JLGStringConstants.kAlertTitle, message: JLGStringConstants.kAlertMessageAuthenticationInvalid, actionTitle: JLGStringConstants.kAlertActionOK)
        } else if JLGCommunicationManager.sharedInstance.authenticationValue == kAuthenticationExpire {
            self.showAlertWithTitleAndMessage(title: JLGStringConstants.kAlertTitle, message: JLGStringConstants.kAlertMessageAuthenticationExpire, actionTitle: JLGStringConstants.kAlertActionOK)
        } else {
            self.performSegue(withIdentifier: jlgBMSSerialScreenViewController, sender: nil)
        }
    }

    /// Invalidate timer
    func invalidateTimerToConnectMachine() {
        hideLoadingIndicator()
        if timerToConnectMachine != nil {
            timerToConnectMachine?.invalidate()
            timerToConnectMachine = nil
        }
    }

    @objc func stopConnectingAndShowAlert() {
        self.invalidateTimerToConnectMachine()
        JLGBLEManager.sharedInstance.disconnectFromPeripheral()
        self.showMachineNotInRangeAlert()
    }

    @objc func showMachineNotInRangeAlert() {
        NotificationCenter.default.removeObserver(self, name: .notificationIdentifierForAuthentication, object: nil)
        NotificationCenter.default.removeObserver(self, name: .notificationIdentifierForProtobufMissMatchArray, object: nil)
        self.showAlertWithTitleAndMessage(title: JLGStringConstants.kAlertTitle, message: JLGStringConstants.kAlertNotInRange, actionTitle: JLGStringConstants.kAlertActionOK)
    }
}

// MARK: - JLGAlertMessageBluetoothTurnOff Delegate
extension JLGBMSFleetTabViewController {
    /// showBluetoothTurnOffAlert get called when BLE power off
    func showBluetoothTurnOffAlert() {
        let bleOnOrOffAlert = JLGAlertMessageBluetoothTurnOff()
        bleOnOrOffAlert.delegate = self
        bleOnOrOffAlert.showAlertIfBLEIsOff(viewController: self)
    }

    func commonActionForBluetoothTurnOff() {
        NotificationCenter.default.post(name: .notificationIdentifierForBMSHomeTabBar, object: nil)
    }
}

extension JLGBMSFleetTabViewController {
    /// Assigning Accessibility Identifier For UI Testing
    func assigningAccessibilityIdentifier() {
        if #available(iOS 11.0, *) {
            view.accessibilityIdentifier = JLGTestingConstant.kJLGFleetVC
            bmsFeetTableView.accessibilityIdentifier = JLGTestingConstant.kJLGFleetTableView
            segmentControl.accessibilityIdentifier = JLGTestingConstant.kFleetScreenSegmentControl
        }
    }
}
