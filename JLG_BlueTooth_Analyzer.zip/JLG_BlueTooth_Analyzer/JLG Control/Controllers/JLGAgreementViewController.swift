//
//  JLGAgreementViewController.swift
//  JLG Control
//
//  Created by L&T on 16/04/18.
//  Copyright © 2018 L&T. All rights reserved.
//

import UIKit
//import Firebase
import RealmSwift

class JLGAgreementViewController: GoogleAnalyticsViewController {

    // MARK: - Variables and Constants
    @IBOutlet weak var agreementTextView: UITextView!
    @IBOutlet weak var agreeButton: UIButton!

    // MARK: - View life cycle events
    override func viewDidLoad() {
        super.viewDidLoad()
        if CommandLine.arguments.contains(JLGTestingConstant.kEnableTesting) {
            assigningAccessibilityIdentifier()
        }

        self.navigationItem.titleView = UIImageView(image: UIImage(named: JLGStringConstants.kJLGMobileControlLogo))
        /// Show agreement details inside textview with html format
        agreementTextView.attributedText = JLGStringConstants.kAgreementHtmlText.htmlToAttributedString
        agreementTextView.setContentOffset(CGPoint.zero, animated: false)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = false
        agreementTextView.setContentOffset(CGPoint.zero, animated: false)
    }

    override func viewDidLayoutSubviews() {
        agreementTextView.setContentOffset(.zero, animated: false)
    }

    // MARK: - Agree button action
    @IBAction func agreeButtonAction(_ sender: UIButton) {
        self.checkRealmDBExistsOrNot()
        //Analytics.logEvent("rcs_i_agree_action", parameters: [kUserID: userID, kTimeStamp: Date().PR2DateFormatterUTC()])
        //performSegue(withIdentifier: "JLGQRCodeViewController", sender: nil)
    }
}

extension JLGAgreementViewController {
    func checkRealmDBExistsOrNot() {
        let fileManager = FileManager.default
        let defaultPath = Realm.Configuration.defaultConfiguration.fileURL!.path

        /// Delete realm file form document folder
        let realmDBName = UserDefaults.standard.value(forKey: JLGStringConstants.kRelamJSONUserDefaults) as? String ?? ""
        if realmDBName != JLGStringConstants.kRelamJSONFileName {
            do {
                try fileManager.removeItem(atPath: defaultPath)
                print("File Deleted")
            } catch {
                print(error)
            }

            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                self.createDBUsingJSONFile()
            }
        }
    }

    func createDBUsingJSONFile() {
        if let path = Bundle.main.path(forResource: JLGStringConstants.kRelamJSONFileName, ofType: JLGStringConstants.kJSONFileType) {
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                let jsonResult = try JSONSerialization.jsonObject(with: data, options: .mutableLeaves)
                if let jsonResult = jsonResult as? Dictionary <String, AnyObject>, let jlgDTCAlertArray = jsonResult["JLGDTCAlert"] as? [[String: Any]] {
                    // do stuff
                    //print("jlgDTCAlert \(jlgDTCAlertArray)")

                    let configuration = Realm.Configuration(encryptionKey: JLGStringConstants.kRelamDBKey.sha512())
                    let realm = try! Realm(configuration: configuration)
                    //let realm = try! Realm()
                    let defaultURL = Realm.Configuration.defaultConfiguration.fileURL!
                    print("defaultURL--> \(defaultURL)")

                    for jlgDTCAlert in jlgDTCAlertArray {
                        let newJLGDTCAlert = JLGDTCAlert()

                        if let spn = jlgDTCAlert["spn"] as? Int {
                            newJLGDTCAlert.spn.value = spn
                        }

                        if let fmi = jlgDTCAlert["fmi"] as? Int {
                            newJLGDTCAlert.fmi.value = fmi
                        }

                        if let chargerErrorFault = jlgDTCAlert["chargerErrorFault"] as? String {
                            newJLGDTCAlert.chargerErrorFault = chargerErrorFault
                        }

                        if let chargerErrorFaultDescription = jlgDTCAlert["chargerErrorFaultDescription"] as? String {
                            newJLGDTCAlert.chargerErrorFaultDescription = chargerErrorFaultDescription
                        }

                        if let jlgDTC = jlgDTCAlert["jlgDTC"] as? Int {
                            newJLGDTCAlert.jlgDTC.value = jlgDTC
                        }

                        if let jlgDTCDescription = jlgDTCAlert["jlgDTCDescription"] as? String {
                            newJLGDTCAlert.jlgDTCDescription = jlgDTCDescription
                        }

                        try! realm.write {
                            realm.add(newJLGDTCAlert)
                        }
                    }

                    UserDefaults.standard.set(JLGStringConstants.kRelamJSONFileName, forKey: JLGStringConstants.kRelamJSONUserDefaults)
                }
            } catch {
                // handle error
                print("RealmDB not created using JSON file")
            }
        }

    }
}

// MARK: - Unit Testing and UI Testing
extension JLGAgreementViewController {
    /// Assigning Accessibility Identifier For UI Testing
    func assigningAccessibilityIdentifier() {
        if #available(iOS 11.0, *) {
            view.accessibilityIdentifier = JLGTestingConstant.kJLGAgreementVC
            agreementTextView.accessibilityAttributedLabel = NSAttributedString(string: JLGTestingConstant.kAgreementTextView)
            agreeButton.accessibilityAttributedLabel = NSAttributedString(string: JLGTestingConstant.kIAgreeButton)
        }
    }
}
