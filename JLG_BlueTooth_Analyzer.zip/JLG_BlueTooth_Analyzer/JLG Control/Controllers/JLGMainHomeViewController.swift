//
//  JLGMainHomeViewController.swift
//  JLG Control
//
//  Created by Apple on 08/11/19.
//  Copyright © 2019 L&T. All rights reserved.
//

import UIKit
import CoreBluetooth
import RealmSwift

class JLGMainHomeViewController: GoogleAnalyticsViewController, JLGBLEDelegate {

    @IBOutlet weak var batteryMgmtView: UIView!
    @IBOutlet weak var remoteControlView: UIView!
    @IBOutlet weak var bluetoothAnalzerView: UIView!
    
    // MARK: - View life cycle events
    override func viewDidLoad() {
        super.viewDidLoad()
        /// For Unit and UI Testing
        if CommandLine.arguments.contains(JLGTestingConstant.kEnableTesting) {
            assigningAccessibilityIdentifier()
        }

        JLGBLEManager.sharedInstance.delegate = self
        NotificationCenter.default.addObserver(self, selector: #selector(receiveNotificationFromRCSTabBarButton), name: .notificationIdentifierForAppRouteToRCS, object: nil)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        isJLGBMSSerialScreenViewControllerOpen = false
        self.navigationItem.backBarButtonItem?.tintColor = .clear
        self.navigationItem.titleView = UIImageView(image: UIImage(named: JLGStringConstants.kJLGMobileControlLogo))
        self.navigationItem.hidesBackButton = true
        self.navigationController?.navigationBar.isHidden = false
    }

    /// Notification observer function
    @objc func receiveNotificationFromRCSTabBarButton() {
        self.pushToJLGQRCodeViewController(isPushVCAnimation: false)
    }

    /// Push to QR code View Controller method
    func pushToJLGQRCodeViewController(isPushVCAnimation: Bool) {
        let qrCodeVC = mainStoryboard.instantiateViewController(withIdentifier: "JLGQRCodeViewController") as! JLGQRCodeViewController
        self.navigationController?.pushViewController(qrCodeVC, animated: isPushVCAnimation)
    }

    /// showBluetoothTurnOffAlert get called when BLE power off
    func showBluetoothTurnOffAlert() {
        let bleOnOrOffAlert = JLGAlertMessageBluetoothTurnOff()
        bleOnOrOffAlert.showAlertIfBLEIsOff(viewController: self)
    }
}

// MARK: - Buttons Action
extension JLGMainHomeViewController {
    @IBAction func bmsButtonAction(_ sender: Any) {
        if isDeviceBluetoothOff {
            showBluetoothTurnOffAlert()
        } else {
            isJLGBTAAnalyzerFlowStart = false
            performSegue(withIdentifier: "JLGBMSFleetTabViewController", sender: nil)
        }
    }

    @IBAction func remoteControlButtonAction(_ sender: Any) {
        if isDeviceBluetoothOff {
            showBluetoothTurnOffAlert()
        } else {
            isJLGBTAAnalyzerFlowStart = false
            self.pushToJLGQRCodeViewController(isPushVCAnimation: true)
        }
    }
    
    @IBAction func bluetoothAnalyzerAction(_ sender: Any) {
        //performSegue(withIdentifier: "JLGBluetoothAnalyzerTabViewController", sender: nil)
        if isDeviceBluetoothOff {
            showBluetoothTurnOffAlert()
        } else {
            isJLGBTAAnalyzerFlowStart = true
            self.pushToJLGQRCodeViewController(isPushVCAnimation: true)
        }
    }

    @IBAction func shareButtonAction(_ sender: Any) {
        shareFileToAnyPlatform(viewController: self)
    }
}

// MARK: - JLGBLEManager delegates
extension JLGMainHomeViewController {
    func centralManagerDidUpdateBLEState(centralManager: CBCentralManager) {
        if centralManager.state == .poweredOff {
            isDeviceBluetoothOff = true
        } else if centralManager.state == .poweredOn && (JLGBLEManager.sharedInstance.activePeripheral == nil || JLGBLEManager.sharedInstance.activePeripheral?.state != .connected) {
            isDeviceBluetoothOff = false
        }
    }
}

extension JLGMainHomeViewController {
    /// Assigning Accessibility Identifier For UI Testing
    func assigningAccessibilityIdentifier() {
        if #available(iOS 11.0, *) {
            view.accessibilityIdentifier = JLGTestingConstant.kJLGMainHomeVC
            batteryMgmtView.accessibilityIdentifier = JLGTestingConstant.kBatteryMgmtView
            remoteControlView.accessibilityIdentifier = JLGTestingConstant.kRemoteControlView
            bluetoothAnalzerView.accessibilityIdentifier = JLGTestingConstant.kBluetoothAnalzerView
        }
    }
}
