//
//  JLGBTAConnectViewController.swift
//  JLG Control
//
//  Created by LTTS_iMac_Conti on 26/08/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class JLGBTAConnectViewController: GoogleAnalyticsViewController, JLGAlertBackToHomeViewControllerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.titleView = UIImageView(image: UIImage(named: JLGStringConstants.kJLGMobileControlLogo))
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.showAlertBackToHome()
    }
}

    // MARK: - JLGBMSHomeTabViewController Delegate
    extension JLGBTAConnectViewController {
        func showAlertBackToHome() {
            let backToHomeVC = JLGAlertBackToHomeViewController()
            backToHomeVC.showAlertForBackToHomeViewController(viewController: self)
            backToHomeVC.delegate = self
        }

        func didSelectBackToHomeConfirmButton() {
            NotificationCenter.default.post(name: .notificationIdentifierForJLGBTADisconnectBLE, object: nil)
            NotificationCenter.default.post(name: .notificationIdentifierForAppRouteToScanVC, object: nil)
        }

        func didSelectBackToHomeCancelButton() {
            if let tabBar = self.tabBarController as? JLGBTATabBarController {
                tabBar.selectedIndex = getBTATabBarControllerPreviousIndex
            }
        }
    }
