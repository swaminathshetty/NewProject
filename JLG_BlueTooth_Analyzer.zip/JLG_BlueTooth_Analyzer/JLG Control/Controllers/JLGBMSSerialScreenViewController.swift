//
//  JLGBMSSerialScreenViewController.swift
//  JLG Control
//
//  Created by Apple on 19/11/19.
//  Copyright © 2019 L&T. All rights reserved.
//

import UIKit
import CoreBluetooth

class JLGBMSSerialScreenViewController: GoogleAnalyticsViewController, UITableViewDelegate, UITableViewDataSource, JLGBatteryDetailsTableViewCellDelegate, JLGGraphCellDelegate, UIGestureRecognizerDelegate, JLGBLEDelegate, JLGPreviousChargeDelegate, JLGSerialScreenModelDelegate, JLGWaterLevelTableViewCellDelegate, JLGAlertMessageBluetoothTurnOffDelegate {

    @IBOutlet weak var tableView: UITableView!
    fileprivate var isBatteryDetailViewCellExpand = false
    fileprivate var isSelectBatteryWeekWiseReport = false
    fileprivate var isSelectDropLevel = false
    fileprivate var isBatteryInstallationDate = false
    fileprivate var isTryToDisconnectFormAlertMsg = false
    fileprivate var isConnectedToJLGBLE = false
    fileprivate var isCloseKeyBoard = false
    fileprivate var serialScreenSharedObject = JLGSerialScreenModel.sharedInstance
    fileprivate var assetIDString: String?
    fileprivate let jlgBMSAlarmAlertStatusNC = "JLGBMSAlarmAlertStatusNavigationController"
    fileprivate let jlgProperChargingPracticesNC = "JLGProperChargingPracticesNavigationController"
    fileprivate var isPresentViewControllerOpen = false

    var toolBarView: UIView! = nil
    var datePicker: UIDatePicker! = nil
    var fleetScreenModelDictionary: NSDictionary?
    var timerToGetDataFromProtobuf: Timer?
    var timerToConnectMachine: Timer?
    var refreshControl = UIRefreshControl()

    // MARK: - View life cycle events
    override func viewDidLoad() {
        super.viewDidLoad()
        /// For Unit and UI Testing
        if CommandLine.arguments.contains(JLGTestingConstant.kEnableTesting) {
            assigningAccessibilityIdentifier()
        }
        // Clear all previous data
        self.serialScreenSharedObject.resetAllValue()

        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(self.dismissKeyboardByPressingOutSide))
        view.addGestureRecognizer(tap)

        JLGBLEManager.sharedInstance.delegate = self
        showLoadingIndicator(self.tabBarController!.view)
        self.callAllProtobufRequest()
        NotificationCenter.default.addObserver(self, selector: #selector(disconnectBLEOnSerialScreen), name: .notificationIdentifierForSerialScreenDisconnectBLE, object: nil)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        isJLGBMSSerialScreenViewControllerOpen = true
        getBMSTabBarControllerPreviousIndex = 1
        self.isPresentViewControllerOpen = false
        self.setupNavigationController()
        JLGBLEManager.sharedInstance.delegate = self
        if JLGBLEManager.sharedInstance.activePeripheral?.state == .disconnected {
            self.disconnectedFromPeripheral()
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if !self.isPresentViewControllerOpen {
            JLGBLEManager.sharedInstance.delegate = nil
        }
    }

    @objc func disconnectBLEOnSerialScreen() {
        isJLGBMSSerialScreenViewControllerOpen = false
        self.isPresentViewControllerOpen = true
        self.isTryToDisconnectFormAlertMsg = true
        NotificationCenter.default.removeObserver(self, name: .notificationIdentifierForSerialScreenDisconnectBLE, object: nil)
        if JLGBLEManager.sharedInstance.activePeripheral?.state == .connected {
            JLGBLEManager.sharedInstance.disconnectFromPeripheral()
        } else {
            self.disconnectedFromPeripheral()
        }
        JLGBLEManager.sharedInstance.activePeripheral = nil
        // Clear all previous data
        self.serialScreenSharedObject.resetAllValue()
    }

    // Setup Navigation Controller
    func setupNavigationController() {
        self.navigationController?.interactivePopGestureRecognizer?.delegate = self
        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = false
        self.navigationItem.titleView = UIImageView(image: UIImage(named: JLGStringConstants.kJLGMobileControlLogo))
        let buttonLeftMenu: UIButton = UIButton()
        buttonLeftMenu.setImage(UIImage(named: JLGStringConstants.kBackwardArrow), for: UIControlState())
        buttonLeftMenu.addTarget(self, action: #selector(self.onClickBack), for: UIControlEvents.touchUpInside)
        buttonLeftMenu.frame = CGRect(x: 0, y: 0, width: 33/2, height: 27/2)
        let barButton = UIBarButtonItem(customView: buttonLeftMenu)
        self.navigationItem.leftBarButtonItem = barButton
    }

    // Back button action
    @objc func onClickBack() {
        showAlertForDisconnectFromBLEDevice(title: JLGStringConstants.kAlertBackToFleetView, message: JLGStringConstants.kAlertBackToFleetViewMessage)
    }

    // Calls this function when the tap is recognized.
    @objc func dismissKeyboardByPressingOutSide() {
        _ = self.writeAssetIdUsingProtobuf()
    }

    // All protobuf request
    func callAllProtobufRequest() {
        timerToGetDataFromProtobuf = Timer.scheduledTimer(timeInterval: responseTimeout, target: self, selector: #selector(doNotUpdatedSerialScreen), userInfo: nil, repeats: false)
        self.serialScreenSharedObject.delegateJLGSerialScreenModel = self
        self.serialScreenSharedObject.createPrtobufRequest(reqType: .infoSerialNumber)
        self.serialScreenSharedObject.createPrtobufRequest(reqType: .infoAssetID)
        self.serialScreenSharedObject.createPrtobufRequest(reqType: .bmsHistory)
        self.serialScreenSharedObject.createPrtobufRequest(reqType: .diagChargerFaultList)
        self.serialScreenSharedObject.createPrtobufRequest(reqType: .diagDtcList)
        self.serialScreenSharedObject.createPrtobufRequest(reqType: .bmsAlerts)
        self.serialScreenSharedObject.createPrtobufRequest(reqType: .serviceConnect)
        self.serialScreenSharedObject.createPrtobufRequest(reqType: .alarmAlertStatus)
        self.serialScreenSharedObject.createPrtobufRequest(reqType: .bmsBatteryInfo)
    }

    // Set up tableview
    func setupTableView() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.rowHeight = UITableViewAutomaticDimension
    }

    // Set up Refresh Controller
    func setupRefreshControlUI() {
        refreshControl.tintColor = tintColor
        refreshControl.addTarget(self, action: #selector(startRefreshing), for: .valueChanged)
        tableView.addSubview(refreshControl)
    }

    // Refresher controller action
    @objc func startRefreshing(_ sender: Any) {
        showLoadingIndicator(self.tabBarController!.view)
        serialScreenSharedObject.clearAllDataArray()
        self.callAllProtobufRequest()
    }

    /// Invalidate timer
    func invalidateProtobufTimer() {
        if timerToGetDataFromProtobuf != nil {
            timerToGetDataFromProtobuf?.invalidate()
            timerToGetDataFromProtobuf = nil
        }
    }

    /// Write Asset ID into BLE Device using Protobuf request
    func writeAssetIdUsingProtobuf() -> Bool {
        self.isCloseKeyBoard = true
        view.endEditing(true)

        if let assetID = assetIDString {
            if assetID == zeroString {
                self.showAlertWithTitleAndMessage(title: JLGStringConstants.kAlertTitleError, message: JLGStringConstants.kAlertAssetIDNotZero, actionTitle: JLGStringConstants.kAlertActionOK)
                return false
            }

            if serialScreenSharedObject.assetIdModel.assetID != assetID {
                if assetID.count == 0 {
                    self.showAlertWithTitleAndMessage(title: JLGStringConstants.kAlertTitleError, message: JLGStringConstants.kAlertAssetIDNotEmpty, actionTitle: JLGStringConstants.kAlertActionOK)
                    return false
                }

                showLoadingIndicator(self.tabBarController!.view)
                serialScreenSharedObject.writeAssetIdInProtobuf(value: assetID)
            }
        }

        return true
    }

    func reloadJLGBatteryDetailsTableViewCell() {
        let topIndex = IndexPath(row: 0, section: 0)
        self.tableView.reloadRows(at: [topIndex], with: .fade)
        self.tableView.scrollToRow(at: topIndex, at: .top, animated: true)
    }

}

// MARK: - Table View Delegates and DataSource
extension JLGBMSSerialScreenViewController {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 6
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.row {
        case 0: let cell = tableView.dequeueReusableCell(withIdentifier: "JLGBatteryDetailsTableViewCell", for: indexPath) as! JLGBatteryDetailsTableViewCell
        if self.serialScreenSharedObject.batteryInfoModel != nil {
            cell.batteryDetailsCellDelegate = self
            cell.serialScreenModelObject = serialScreenSharedObject
            cell.isExpand = isBatteryDetailViewCellExpand
            cell.fillCellData(dic: fleetScreenModelDictionary!)
            cell.assetIdTextField.delegate = self
            assetIDString = cell.assetIdTextField.text
            cell.assetIdTextField.layer.masksToBounds = true
            cell.assetIdTextField.layer.borderColor = UIColor.lightGray.cgColor
            cell.assetIdTextField.layer.borderWidth = 1.0
            cell.assetIdTextField.layer.cornerRadius = 5.0
            cell.setNeedsDisplay()
        }
        return cell

        case 1: let cell = tableView.dequeueReusableCell(withIdentifier: "JLGBatteryStatusTableViewCell", for: indexPath) as! JLGBatteryStatusTableViewCell
        if self.serialScreenSharedObject.batteryInfoModel != nil {
            cell.fillCellData(serialScreenModelObj: serialScreenSharedObject)
            cell.setNeedsDisplay()
        }
        return cell

        case 2: let cell = tableView.dequeueReusableCell(withIdentifier: "JLGPreviousChargeTableViewCell", for: indexPath) as! JLGPreviousChargeTableViewCell
        if self.serialScreenSharedObject.batteryInfoModel != nil {
            cell.chargeDelegate = self
            cell.fillCellData(isDropDataShow: isSelectDropLevel, serialScreenModelObj: serialScreenSharedObject)
            cell.setNeedsDisplay()
        }
        return cell

        case 3: let cell = tableView.dequeueReusableCell(withIdentifier: "JLGGraphTableViewCell", for: indexPath) as! JLGGraphTableViewCell
        if self.serialScreenSharedObject.batteryInfoModel != nil {
            cell.graphDelegate = self
            cell.fillCellData(isWeekBatteryReport: isSelectBatteryWeekWiseReport)
            cell.setNeedsDisplay()
        }
        return cell

        case 4: let cell = tableView.dequeueReusableCell(withIdentifier: "JLGWaterLevelTableViewCell", for: indexPath) as! JLGWaterLevelTableViewCell
        if self.serialScreenSharedObject.batteryInfoModel != nil {
            cell.waterLevelCellDelegate = self
            cell.fillCellData(serialScreenModelObj: serialScreenSharedObject)
            cell.setNeedsDisplay()
        }
        return cell

        default:
            return UITableViewCell()
        }
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch indexPath.row {
        case 3: if isSelectDropLevel {
            return 0
            }
        case 4: if !isSelectDropLevel {
            return 0
            }
        default:
            return UITableViewAutomaticDimension
        }

        return UITableViewAutomaticDimension
    }

}

// MARK: - JLGBLEDelegate
extension JLGBMSSerialScreenViewController {
    func disconnectedFromPeripheral() {
        if self.isTryToDisconnectFormAlertMsg {
            self.navigationController?.popViewController(animated: true)
        } else {
            self.showAlertForBLEConnectionLost()
            self.isTryToDisconnectFormAlertMsg = false
        }
    }

    /// Get called when connection established
    func didConnectToPeripheral(peripheral: CBPeripheral) {
        JLGBLEManager.sharedInstance.authPinForAuthentication = self.fleetScreenModelDictionary!.value(forKey: JLGStringConstants.kSerialNumber) as! Substring
        isDisconnectedBLE = false
        isConnectedToJLGBLE = true
        self.dismiss(animated: true, completion: nil)
        self.invalidateTimerToConnectMachine()
    }

    func didDisconnectFromPeripheral(peripheral: CBPeripheral) {
        self.refreshControl.endRefreshing()
        self.disconnectedFromPeripheral()
    }

    func centralManagerDidUpdateBLEState(centralManager: CBCentralManager) {
        if centralManager.state == .poweredOff {
            hideLoadingIndicator()
            isDeviceBluetoothOff = true
            flagForDisconnectPeripheral = 1
            isConnectedToJLGBLE = false
            self.showBluetoothTurnOffAlert()
        } else if centralManager.state == .poweredOn && (JLGBLEManager.sharedInstance.activePeripheral == nil || JLGBLEManager.sharedInstance.activePeripheral?.state != .connected) {
            isDeviceBluetoothOff = false
            flagForDisconnectPeripheral = 0
            self.dismiss(animated: true, completion: nil)
            tryToConnectToBLE()
        }
    }

    func tryToConnectToBLE() {
        hideLoadingIndicator()
        if isDeviceBluetoothOff {
            self.showBluetoothTurnOffAlert()
        } else {
            if tabBarController != nil {
                showLoadingIndicator(self.tabBarController!.view)
                self.perform(#selector(connectToBLE), with: nil, afterDelay: scanningTimeout)
            }
        }
    }

    // MARK: - BLE connection methods
    /// ConnectToJLGBLEModule call when BLE need to connect
    @objc func connectToBLE() {
        NotificationCenter.default.addObserver(self, selector: #selector(checkForAuthentication), name: .notificationIdentifierForAuthentication, object: nil)
        timerToConnectMachine = Timer.scheduledTimer(timeInterval: responseTimeout, target: self, selector: #selector(showAlertForBLEConnectionLost), userInfo: nil, repeats: false)

        let peripheral: CBPeripheral = self.fleetScreenModelDictionary!.value(forKey: JLGStringConstants.kPeripheralInstance) as! CBPeripheral
        JLGBLEManager.sharedInstance.connectToPeripheral(peripheral)
    }

    // MARK: - Check for authentication
    @objc func checkForAuthentication() {
        self.invalidateTimerToConnectMachine()
        NotificationCenter.default.removeObserver(self, name: .notificationIdentifierForAuthentication, object: nil)

        if JLGCommunicationManager.sharedInstance.authenticationValue == kAuthenticationInvalid {
            self.showAlertWithTitleAndMessageWithAction(title: JLGStringConstants.kAlertTitle, message: JLGStringConstants.kAlertMessageAuthenticationInvalid)
        } else if JLGCommunicationManager.sharedInstance.authenticationValue == kAuthenticationExpire {
            self.showAlertWithTitleAndMessageWithAction(title: JLGStringConstants.kAlertTitle, message: JLGStringConstants.kAlertMessageAuthenticationExpire)
        } else {
            print("*******Serial Screen Connect Successfully*******")
        }
    }

    /// Invalidate timer
    func invalidateTimerToConnectMachine() {
        hideLoadingIndicator()
        if timerToConnectMachine != nil {
            timerToConnectMachine?.invalidate()
            timerToConnectMachine = nil
        }
    }

    func showAlertWithTitleAndMessageWithAction(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionOK, style: .default) { _ in
            self.tryToConnectToBLE()
        })
        self.present(alert, animated: true, completion: nil)
    }

    /// Show alert if bluetooth connection is lost
    @objc func showAlertForBLEConnectionLost() {
        if self.tableView.delegate != nil {
            NotificationCenter.default.post(name: .notificationIdentifierForDismissPresentViewController, object: nil)
            self.invalidateTimerToConnectMachine()
            JLGBLEManager.sharedInstance.delegate = self
            let alert = UIAlertController(title: JLGStringConstants.kAlertTitleBLEDisconnected, message: JLGStringConstants.kAlertMessageBLEDisconnected, preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionOK, style: .default) { _ in
                if isDeviceBluetoothOff {
                    alert.dismiss(animated: true, completion: nil)
                    self.self.showBluetoothTurnOffAlert()
                } else {
                    self.disconnectBLEOnSerialScreen()
                }
            })
            alert.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionRetry, style: .default) { _ in
                self.reloadJLGBatteryDetailsTableViewCell()
                self.tryToConnectToBLE()
            })
            self.present(alert, animated: true, completion: nil)
        }
    }

    /// Show alert for Disconnect From BLE Device
    func showAlertForDisconnectFromBLEDevice(title: String, message: String) {
        NotificationCenter.default.post(name: .notificationIdentifierForDismissPresentViewController, object: nil)
        hideLoadingIndicator()
        JLGBLEManager.sharedInstance.delegate = self
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionConfirm, style: .default) { _ in
            self.disconnectBLEOnSerialScreen()
        })
        alert.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionCancel, style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }

    func presentViewControllerByPassingNavigationController(navVC: UINavigationController) {

        if self.writeAssetIdUsingProtobuf() {
            var controller = navVC.viewControllers[0]

            if controller.isKind(of: JLGBMSAlarmAlertStatusViewController.self) {
                controller = controller as! JLGBMSAlarmAlertStatusViewController
            } else if controller.isKind(of: JLGBMSProperChargingPracticesViewController.self) {
                controller = controller as! JLGBMSProperChargingPracticesViewController
            } else {
                return
            }

            if #available(iOS 13.0, *) {
                controller.isModalInPresentation = true
            } else {
                self.isPresentViewControllerOpen = true
            }
            self.present(navVC, animated: true, completion: nil)
        }
    }
}

// MARK: - Textfield Delegates
extension JLGBMSSerialScreenViewController: UITextFieldDelegate {

    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        self.datePickerCancelButtonPressed()
        return true
    }

    func textFieldDidEndEditing(_ textField: UITextField) {
        self.assetIDString = textField.text!
        if isCloseKeyBoard {
            if textField.text?.count == 0 || textField.text == zeroString {
                textField.becomeFirstResponder()
                isCloseKeyBoard = false
            }
        }
    }

    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if string.isEmpty {
            return true
        }

        if textField.text!.count > 15 {
            return false
        }

        let alphaNumericRegEx = "[a-zA-Z0-9]"
        let predicate = NSPredicate(format: "SELF MATCHES %@", alphaNumericRegEx)
        return predicate.evaluate(with: string)
    }

    @objc func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField.text!.count == 0 {
            return false
        }
        _ = self.writeAssetIdUsingProtobuf()
        return true
    }
}

// MARK: - Create Date Picker and Toolbar delegate
extension JLGBMSSerialScreenViewController {
    func createDatePicker() {
        if datePicker == nil && self.writeAssetIdUsingProtobuf() {
            let screenWidth = self.view.frame.width
            let screenHeight = self.view.frame.height

            //Add DatePicker as inputView
            datePicker = UIDatePicker(frame: CGRect(x: 0, y: screenHeight - 216 - 44, width: screenWidth, height: 216))
            datePicker.datePickerMode = .date
            datePicker.minimumDate = getTwoWeekOldDateFormCurrentDate()
            datePicker.backgroundColor = UIColor.white
            datePicker.setValue(UIColor.black, forKeyPath: "textColor")
            self.view.addSubview(datePicker)

            toolBarView = UIView.init(frame: CGRect(x: 0, y: screenHeight - 256 - 44, width: screenWidth, height: 50))
            toolBarView.backgroundColor = UIColor.init(red: 234/255, green: 234/255, blue: 234/255, alpha: 1.0)

            let cancelButton = UIButton.init(frame: CGRect(x: 15, y: 5, width: 100, height: 40))
            cancelButton.setTitle(JLGStringConstants.kAlertActionCancel, for: .normal)
            cancelButton.setTitleColor(themeColor, for: .normal)
            cancelButton.contentHorizontalAlignment = .left
            cancelButton.addTarget(self, action: #selector(self.datePickerCancelButtonPressed), for: .touchUpInside)

            let doneButton = UIButton.init(frame: CGRect(x: screenWidth - 115, y: 5, width: 100, height: 40))
            doneButton.setTitle(JLGStringConstants.kAlertActionDone, for: .normal)
            doneButton.setTitleColor(themeColor, for: .normal)
            doneButton.contentHorizontalAlignment = .right
            doneButton.addTarget(self, action: #selector(self.datepickerDoneButtonPressed), for: .touchUpInside)

            toolBarView.addSubview(cancelButton)
            toolBarView.addSubview(doneButton)
            self.view.addSubview(toolBarView)
        }
    }

    @objc func datepickerDoneButtonPressed() {
        var alertTitle = JLGStringConstants.kAlertTitleBatteryInstallationDate
        var alertMsg = JLGStringConstants.kAlertBatteryInstallDate

        if !isBatteryInstallationDate {
            alertTitle = JLGStringConstants.kAlertTitleLastRefillDate
            alertMsg = JLGStringConstants.kAlertWaterLevelInstallDate
        }

        let alert = UIAlertController(title: alertTitle, message: alertMsg, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionConfirm, style: .default) { _ in
            self.dateChanged(self.datePicker)
            self.datePickerCancelButtonPressed()
        })
        alert.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionCancel, style: .default) { _ in
            self.datePickerCancelButtonPressed()
        })
        self.present(alert, animated: true, completion: nil)

    }

    @objc func datePickerCancelButtonPressed() {
        if datePicker != nil && toolBarView != nil {
            toolBarView.removeFromSuperview()
            datePicker.removeFromSuperview()
            datePicker = nil
            toolBarView = nil
        }
    }

    @objc func dateChanged(_ sender: UIDatePicker?) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .long
        dateFormatter.timeStyle = .none

        if var date = sender?.date {
            if date < sender?.minimumDate ?? Date() {
                date = sender?.minimumDate ?? Date()
            }
            let unixDate = date.timeIntervalSince1970
            serialScreenSharedObject.writeDateInBLEUsingProtobuf(dateInt: Int(unixDate), isInstallationDate: isBatteryInstallationDate)
        }
    }
}

// MARK: - JLGSerialScreenModelDelegate Methods
extension JLGBMSSerialScreenViewController {
    func updateSerialScreen() {
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.2) {
            self.invalidateProtobufTimer()
            self.setupTableView()
            self.setupRefreshControlUI()
            self.refreshControl.endRefreshing()
            hideLoadingIndicator()
            self.tableView.reloadData()
        }
    }

    @objc func doNotUpdatedSerialScreen() {
        self.invalidateProtobufTimer()
        hideLoadingIndicator()
        self.refreshControl.endRefreshing()

        let alertView = UIAlertController(title: JLGStringConstants.kAlertTitle, message: JLGStringConstants.kAlertDataNotReceiveFormProtobuf, preferredStyle: UIAlertControllerStyle.alert)
        alertView.addAction(UIAlertAction(title: JLGStringConstants.kAlertActionOK, style: .default) { _ in
            self.view.endEditing(true)
            self.disconnectBLEOnSerialScreen()
        })
        self.present(alertView, animated: true, completion: nil)
    }

    func protobufResponseData(requestType: String) {
        self.protoufResponseParser(requestType: requestType)
    }

    func protobufFailResponseData(requestType: String) {
        self.protoufResponseParser(requestType: requestType)
    }

    func protoufResponseParser(requestType: String) {
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()) {
            hideLoadingIndicator()

            var titleString = ""
            var messageString = ""

            if requestType == JLGStringConstants.kAssetIdUpdated {
                if self.serialScreenSharedObject.responseModel.responseType == JLGStringConstants.kACK {
                    titleString = JLGStringConstants.kAlertTitleSuccess
                    messageString = JLGStringConstants.kAlertAssetIDUpdateSuccessfully
                    self.serialScreenSharedObject.createPrtobufRequest(reqType: .infoAssetID)
                } else {
                    titleString = JLGStringConstants.kAlertTitleError
                    messageString = JLGStringConstants.kAlertAssetIDUpdateFailed
                }
            } else if requestType == JLGStringConstants.kBatteryInstallationDateUpdated {
                if self.serialScreenSharedObject.responseModel.responseType == JLGStringConstants.kACK {
                    titleString = JLGStringConstants.kAlertTitleSuccess
                    messageString = JLGStringConstants.kAlertBatteryInstallationDateSuccessfully
                    self.serialScreenSharedObject.createPrtobufRequest(reqType: .bmsBatteryInfo)
                } else {
                    titleString = JLGStringConstants.kAlertTitleError
                    messageString = JLGStringConstants.kAlertBatteryInstallationDateUpdateFailed
                }
            } else if requestType == JLGStringConstants.kBatteryMaintenanceDateUpdated {
                if self.serialScreenSharedObject.responseModel.responseType == JLGStringConstants.kACK {
                    titleString = JLGStringConstants.kAlertTitleSuccess
                    messageString = JLGStringConstants.kAlertBatteryMaintenanceDateUpdateSuccessfully
                    self.serialScreenSharedObject.createPrtobufRequest(reqType: .bmsBatteryInfo)
                } else {
                    titleString = JLGStringConstants.kAlertTitleError
                    messageString = JLGStringConstants.kAlertBatteryMaintenanceDateUpdateFailed
                }
            }

            if titleString != "" && messageString != "" {
                self.showAlertWithTitleAndMessage(title: titleString, message: messageString, actionTitle: JLGStringConstants.kAlertActionOK)
            }
        }
    }
}

// MARK: - JLGGraphCellDelegate Methods
extension JLGBMSSerialScreenViewController {
    func isDisplayWeekWiseGraph(isWeekWiseGraph: Bool) {
        isSelectBatteryWeekWiseReport = isWeekWiseGraph
    }

    func infoButtonActionDelegate() {
        let navController = jlgBMSFlowStoryBoard.instantiateViewController(withIdentifier: jlgProperChargingPracticesNC) as! UINavigationController
        self.presentViewControllerByPassingNavigationController(navVC: navController)
    }

}

// MARK: - JLGPreviousChargeDelegate Method
extension JLGBMSSerialScreenViewController {
    func isDisplayDropLevelData(isDropData: Bool) {
        isSelectDropLevel = isDropData
        self.tableView.reloadData()
        let topIndex = IndexPath(row: 0, section: 0)
        self.tableView.scrollToRow(at: topIndex, at: .top, animated: true)
    }
}

// MARK: - JLGWaterLevelTableViewCellDelegate Methods
extension JLGBMSSerialScreenViewController {
    func openDatePickerForWaterLevelMaintenanceDate() {
        isBatteryInstallationDate = false
        self.createDatePicker()
    }
}

// MARK: - JLGBatteryDetailsTableViewCellDelegate Methods
extension JLGBMSSerialScreenViewController {
    func isCellExpand(isExpand: Bool) {
        isBatteryDetailViewCellExpand = isExpand
        if self.writeAssetIdUsingProtobuf() {
            self.reloadJLGBatteryDetailsTableViewCell()
        }
    }

    func openDatePickerForBatteryInstallation() {
        isBatteryInstallationDate = true
        self.createDatePicker()
    }

    func warningDetailInformationView() {
        self.openJLGBMSAlarmAlertStatusViewControllerVC(isWarningActive: true)
    }

    /// Open Warning screen
    func openJLGBMSAlarmAlertStatusViewControllerVC(isWarningActive: Bool) {
        let navController = jlgBMSFlowStoryBoard.instantiateViewController(withIdentifier: jlgBMSAlarmAlertStatusNC) as! UINavigationController
        self.presentViewControllerByPassingNavigationController(navVC: navController)
    }
}

// MARK: - JLGAlertMessageBluetoothTurnOff Delegate
extension JLGBMSSerialScreenViewController {
    /// showBluetoothTurnOffAlert get called when BLE power off
    func showBluetoothTurnOffAlert() {
        NotificationCenter.default.post(name: .notificationIdentifierForDismissPresentViewController, object: nil)
        let bleOnOrOffAlert = JLGAlertMessageBluetoothTurnOff()
        bleOnOrOffAlert.delegate = self
        bleOnOrOffAlert.showAlertIfBLEIsOff(viewController: self)
    }

    func commonActionForBluetoothTurnOff() {
        NotificationCenter.default.post(name: .notificationIdentifierForAppRouteToMainHomeVC, object: nil)
    }
}

extension JLGBMSSerialScreenViewController {
    /// Assigning Accessibility Identifier For UI Testing
    func assigningAccessibilityIdentifier() {
        if #available(iOS 11.0, *) {
            view.accessibilityIdentifier = JLGTestingConstant.kJLGSerialScreenVC
            tableView.accessibilityIdentifier = JLGTestingConstant.kJLGSerialScreenTableView
        }
    }
}
