//
//  JLGMainNavigationController.swift
//  JLG Control
//
//  Created by L&T on 04/05/18.
//  Copyright © 2018 L&T. All rights reserved.
//

import UIKit

class JLGMainNavigationController: UINavigationController {

    // MARK: - View life cycle events
    override func viewDidLoad() {
        super.viewDidLoad()

        /// Add notification to redirect to QR code screen (5 minute inactivity)
        NotificationCenter.default.addObserver(self, selector: #selector(popToRootScanViewController), name: .notificationIdentifierForAppRouteToScanVC, object: nil)
        self.interactivePopGestureRecognizer?.isEnabled = false

        NotificationCenter.default.addObserver(self, selector: #selector(popToMainHomeViewController), name: .notificationIdentifierForAppRouteToMainHomeVC, object: nil)
    }

    // MARK: - Notification received to redirect to QR Code screen (5 minute inactivity)
    @objc func popToRootScanViewController() {
        if self.viewControllers.count > 2 && (isTimeExceed5Minutes || isJLGBTAAnalyzerFlowStart) {
            let scanController = self.viewControllers[2]
            self.popToViewController(scanController, animated: true)
        }
    }

    // MARK: - Notification received to redirect to MainHomeViewController
    @objc func popToMainHomeViewController() {
        if self.viewControllers.count > 2 {
            let mainHomeController = self.viewControllers[1]
            self.popToViewController(mainHomeController, animated: true)
        }
    }

}
