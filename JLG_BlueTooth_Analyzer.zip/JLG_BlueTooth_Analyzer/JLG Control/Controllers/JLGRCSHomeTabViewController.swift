//
//  JLGRCSHomeTabViewController.swift
//  JLG Control
//
//  Created by L&T on 20/04/18.
//  Copyright © 2018 L&T. All rights reserved.
//

import UIKit
//import Firebase

class JLGRCSHomeTabViewController: GoogleAnalyticsViewController, JLGAlertBackToHomeViewControllerDelegate {

    let backToHomeVC = JLGAlertBackToHomeViewController()

    // MARK: - View life cycle events
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.titleView = UIImageView(image: #imageLiteral(resourceName: "JLGLogo"))
        NotificationCenter.default.addObserver(self, selector: #selector(dismissAlertView), name: .notificationIdentifierForDismissDisconnectBLEAlert, object: nil)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.showAlertBackToHome()
    }

    @objc func dismissAlertView() {
        self.backToHomeVC.removeAlertForBackToHomeViewController()
        NotificationCenter.default.removeObserver(self, name: .notificationIdentifierForDismissDisconnectBLEAlert, object: nil)
    }
}

// MARK: - JLGBMSHomeTabViewController Delegate
extension JLGRCSHomeTabViewController {
    func showAlertBackToHome() {
        backToHomeVC.showAlertForBackToHomeViewController(viewController: self)
        backToHomeVC.delegate = self
    }

    func didSelectBackToHomeConfirmButton() {
        NotificationCenter.default.post(name: .notificationIdentifierForDisconnectBLEInRCSApp, object: nil)
    }

    func didSelectBackToHomeCancelButton() {
        if let tabbar = self.tabBarController as? JLGRCSTabBarController {
            tabbar.selectedIndex = getRCSTabBarControllerPreviousIndex
        }
    }
}
