//
//  JLGBMSAlarmAlertStatusViewController.swift
//  JLG Control
//
//  Created by Apple on 03/02/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit
import RealmSwift

class JLGBMSAlarmAlertStatusViewController: GoogleAnalyticsViewController, UITableViewDataSource, UITableViewDelegate {

    fileprivate var serialScreenSharedObj = JLGSerialScreenModel.sharedInstance
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var cancelButton: UIButton!
    var arrayOfBMSAlert = [String]()
    let queue = DispatchQueue(label: "com.lntts.JLGControl.queue")

    override func viewDidLoad() {
        super.viewDidLoad()
        /// For Unit and UI Testing
        if CommandLine.arguments.contains(JLGTestingConstant.kEnableTesting) {
            assigningAccessibilityIdentifier()
        }

        showLoadingIndicator(self.view)
        self.title = JLGStringConstants.kWarnings
        self.tableView.dataSource = self
        self.tableView.delegate = self
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        NotificationCenter.default.addObserver(self, selector: #selector(cancelButtonAction), name: .notificationIdentifierForDismissPresentViewController, object: nil)
        self.getDataFromDB()
    }

    @objc func getDataFromDB() {
        self.queue.sync {
            self.bmsAlertListArray()
            self.dtcAlertArray()
            self.faultCodesModelDataArray()

            if arrayOfBMSAlert.count == 0 {
                arrayOfBMSAlert.append(JLGStringConstants.kNoWarnings)
            }
            hideLoadingIndicator()
            self.arrayOfBMSAlert.removeDuplicates()
            self.tableView.reloadData()
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        NotificationCenter.default.removeObserver(self, name: .notificationIdentifierForDismissPresentViewController, object: nil)
    }

    func bmsAlertListArray() {
        for bmsAlert in serialScreenSharedObj.bmsAlertListModelData where bmsAlert.alertActive {
            switch bmsAlert.alertId {
            case JLGStringConstants.kBA_FREEZE_WARNING:                 arrayOfBMSAlert.append(JLGStringConstants.kText_BA_FREEZE_WARNING)

            case JLGStringConstants.kBA_LOW_WATER_WARNING:                 arrayOfBMSAlert.append(JLGStringConstants.kText_BA_LOW_WATER_WARNING)

            case JLGStringConstants.kBA_DISCHARGED_BATTERY:                 arrayOfBMSAlert.append(JLGStringConstants.kText_BA_DISCHARGED_BATTERY)

            case JLGStringConstants.kBA_DEEP_DISCHARGED_BATTERY:                 arrayOfBMSAlert.append(JLGStringConstants.kText_BA_DEEP_DISCHARGED_BATTERY)

            case JLGStringConstants.kBA_LOW_SOC_CHARGING:                 arrayOfBMSAlert.append(JLGStringConstants.kText_BA_LOW_SOC_CHARGING)

            default:
                break
            }
        }
    }

    func dtcAlertArray() {
        for dtcAlert in serialScreenSharedObj.dtcAlertListModelData {
            let realmObject = try! Realm(configuration: realmConfiguration)
            let otherResults = realmObject.objects(JLGDTCAlert.self).filter(NSPredicate(format: "jlgDTC == \(dtcAlert)"))

            for value in otherResults {
                arrayOfBMSAlert.append("\(dtcAlert) - \(value.jlgDTCDescription ?? "")")
                var index = 0
                for faultCode in serialScreenSharedObj.faultCodesModelData {
                    if let fmi = value.fmi.value, faultCode.fmi == fmi, let spn = value.spn.value, faultCode.spn == spn {
                        serialScreenSharedObj.faultCodesModelData.remove(at: index)
                    }
                    index = +1
                }
            }

            if otherResults.count == 0 {
                let unknownText = "\(dtcAlert) - \(JLGStringConstants.kUnknownText)"
                arrayOfBMSAlert.append(unknownText)
            }
        }

    }

    func faultCodesModelDataArray() {
        for faultCode in serialScreenSharedObj.faultCodesModelData {
            let realmObject = try! Realm(configuration: realmConfiguration)
            let otherResults = realmObject.objects(JLGDTCAlert.self).filter(NSPredicate(format: "spn == \(faultCode.spn) && fmi == \(faultCode.fmi)"))
            for value in otherResults {
                let chargerError = { () -> String in
                    var chargerErrorText = ""
                    if let chargerErrorFault = value.chargerErrorFault {
                        chargerErrorText = chargerErrorFault
                    }

                    if let chargerErrorFaultDescription = value.chargerErrorFaultDescription {
                        chargerErrorText = "\(chargerErrorText) - \(chargerErrorFaultDescription)"
                    }
                    return chargerErrorText
                }

                var holeDescription = ""

                if let jlgDTC = value.jlgDTC.value {
                    holeDescription = "\(jlgDTC)"

                    if jlgDTC == 44136 {
                        if var jlgDescription = value.jlgDTCDescription {
                            jlgDescription = jlgDescription.replacingOccurrences(of: "(SPN:FMI)", with: "(\(faultCode.spn):\(faultCode.fmi))")
                            holeDescription = "\(holeDescription) - \(jlgDescription), \(chargerError())"
                        }
                    } else if jlgDTC == 99365 {
                        holeDescription = chargerError()
                    } else {
                        if let jlgDescription = value.jlgDTCDescription {
                            holeDescription = "\(holeDescription) - \(jlgDescription)"
                        }
                    }
                } else {
                    holeDescription = chargerError()
                }
                arrayOfBMSAlert.append(holeDescription)
            }

            if otherResults.count == 0 {
                let unknownText = "\(faultCode.spn):\(faultCode.fmi) - \(JLGStringConstants.kUnknownText)"
                arrayOfBMSAlert.append(unknownText)
            }
        }
    }

    @IBAction func cancelButtonAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }

    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let frame = tableView.frame
        let warningImageView = UIImageView.init(frame: CGRect(x: 35, y: 5, width: 25, height: 22))
        warningImageView.image = UIImage(named: "DetailsPageWarning")
        let headerView = UIView(frame: CGRect(x: 0, y: 0, width: frame.size.width, height: frame.size.height))
        headerView.backgroundColor = UIColor.init(red: 247/255, green: 247/255, blue: 247/255, alpha: 1.0)
        headerView.addSubview(warningImageView)
        return headerView
    }

    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 35.0
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayOfBMSAlert.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "JLGSerialScreenAlarmAlertStatusCell", for: indexPath) as! JLGSerialScreenAlarmAlertStatusCell
        let alertText = arrayOfBMSAlert[indexPath.row]
        if alertText == JLGStringConstants.kNoWarnings {
            cell.alarmAlertLabel?.textAlignment = .center
        }

        cell.alarmAlertLabel?.text = alertText
        return cell
    }

}

extension JLGBMSAlarmAlertStatusViewController {
    /// Assigning Accessibility Identifier For UI Testing
    func assigningAccessibilityIdentifier() {
        if #available(iOS 11.0, *) {
            view.accessibilityIdentifier = JLGTestingConstant.kJLGBMSAlarmAlertStatusViewControllerVC
            cancelButton.accessibilityAttributedLabel = NSAttributedString(string: JLGTestingConstant.kJLGBMSAlarmAlertStatusViewControllerCancelButton)
        }
    }
}
