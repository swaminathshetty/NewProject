//
//  XCUIApplication+CheckVC.swift
//  JLG ControlUITests
//
//  Created by Apple on 26/12/19.
//  Copyright © 2019 L&T. All rights reserved.
//

import XCTest

extension XCUIApplication {
    var isDisplayJLGAgreementVC: Bool {
        return otherElements[JLGTestingConstant.kJLGAgreementVC].exists
    }
    
    var isDisplayJLGMainHomeVC: Bool {
        return otherElements[JLGTestingConstant.kJLGMainHomeVC].exists
    }

    var isDisplayJLGFleetVC: Bool {
        return otherElements[JLGTestingConstant.kJLGFleetVC].exists
    }

    var isDisplayJLGQRCodeVC: Bool {
        return otherElements[JLGTestingConstant.kJLGQRCodeVC].exists
    }
    
    var isDisplayJLGHomeVC: Bool {
        return otherElements[JLGTestingConstant.kJLGHomeVC].exists
    }

    var isDisplayJLGBMSAlarmAlertStatusViewControllerVC: Bool {
        return otherElements[JLGTestingConstant.kJLGBMSAlarmAlertStatusViewControllerVC].exists
    }
    
    var isDisplayJLGProperChargingPracticesVC: Bool {
        return otherElements[JLGTestingConstant.kJLGProperChargingPracticesVC].exists
    }

    var isDisplayJLGSelectMachineModelVC: Bool {
        return otherElements[JLGTestingConstant.kJLGSelectMachineModelVC].exists
    }

}
