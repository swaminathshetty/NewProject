//
//  JLGAgreementVCUITest.swift
//  JLG ControlTests
//
//  Created by Apple on 26/12/19.
//  Copyright © 2019 L&T. All rights reserved.
//

import XCTest

class JLGUITesting: XCTestCase {
    var app: XCUIApplication!
    
    // MARK: - Defaults Methods
    override func setUp() {
        super.setUp()
        continueAfterFailure = false
        app = XCUIApplication()
        app.launchArguments = [JLGTestingConstant.kEnableTesting]
        app.launch()
        self.allowSystemDialog()
    }
    
    override func tearDown() {
        super.tearDown()
        app = nil
    }
    /// UI Testing for BMS Flow
    func testBMSUITesting() {
        /// System alerts
        self.allowSystemDialog()
        sleep(5)
        XCTAssertTrue(app.isDisplayJLGAgreementVC)
        sleep(5)
        self.allowSystemDialog()

        let agreementTextView = app.textViews[JLGTestingConstant.kAgreementTextView]
        XCTAssertTrue(agreementTextView.exists)
        
        let agreeButton = app.buttons[JLGTestingConstant.kIAgreeButton]
        if agreeButton.exists {
            XCTAssertTrue(agreeButton.exists)
            agreeButton.tap()
        }
        
        sleep(5)
        XCTAssertTrue(app.isDisplayJLGMainHomeVC)
        
        let batteryMgmtView = app.otherElements[JLGTestingConstant.kBatteryMgmtView]
        batteryMgmtView.tap()
        
        XCTAssertTrue(app.isDisplayJLGFleetVC)
        sleep(15)
        
        let controlsView = app.segmentedControls.matching(identifier: JLGTestingConstant.kFleetScreenSegmentControl).element
        let requiresAttention = controlsView.buttons.matching(identifier: "Requires Attention").element
        requiresAttention.tap()
        let modelSegementControl = controlsView.buttons.matching(identifier: "Model").element
        modelSegementControl.tap()
        
        if app.isDisplayJLGSelectMachineModelVC {
            let modelTable = app.tables[JLGTestingConstant.kJLGSelectMachineModelTableView]
            let cell = modelTable.cells.element(matching: .cell, identifier: "\(JLGTestingConstant.kJLGSelectModelCellZero)")
            cell.tap()
            
            let modelDoneButton = app.buttons[JLGTestingConstant.kJLGSelectMachineModelDoneButton]
            if modelDoneButton.exists {
                modelDoneButton.tap()
            }

        }

        
        let all = controlsView.buttons.matching(identifier: "All").element
        all.tap()

        let myTable = app.tables[JLGTestingConstant.kJLGFleetTableView]
        let cell = myTable.cells.element(matching: .cell, identifier: "\(JLGTestingConstant.kJLGFleetTableViewCellZero)")
        cell.tap()
        sleep(20)
        let warningButton = app.buttons[JLGTestingConstant.kJLGSerialScreenWarningButton]
        if warningButton.exists {
            warningButton.tap()
        }
        sleep(10)
        if app.isDisplayJLGBMSAlarmAlertStatusViewControllerVC {
            let alertAndAlramCancelButton = app.buttons[JLGTestingConstant.kJLGBMSAlarmAlertStatusViewControllerCancelButton]
            if alertAndAlramCancelButton.exists {
                alertAndAlramCancelButton.tap()
            }
        }

        let infoButton = app.buttons[JLGTestingConstant.kJLGSerialScreenBatteryInfoButton]
        if infoButton.exists {
            infoButton.tap()
        }
        sleep(10)
        if app.isDisplayJLGProperChargingPracticesVC {
            let properChargingPracticesCancelButton = app.buttons[JLGTestingConstant.kJLGProperChargingPracticesCancelButton]
            if properChargingPracticesCancelButton.exists {
                properChargingPracticesCancelButton.tap()
            }
        }
        
        let graphSegment = app.segmentedControls[JLGTestingConstant.kJLGSerialScreenSegmentController]
        graphSegment.buttons["Last 5 Cycles"].tap()
        sleep(2)
        let dropButton = app.buttons[JLGTestingConstant.kJLGSerialScreenDropButton]
        dropButton.tap()
        sleep(2)
        let moreInfoButton = app.buttons[JLGTestingConstant.kJLGSerialScreenMoreInfoButton]
        moreInfoButton.tap()
        sleep(2)
        let batteryInstallDate = app.buttons[JLGTestingConstant.kJLGSerialScreenBatteryInstallationDateButton]
        batteryInstallDate.tap()
        app.buttons["Cancel"].tap()
        /*
        sleep(5)
        addUIInterruptionMonitor(withDescription: JLGStringConstants.kAlertBatteryInstallDate) {(alert) -> Bool in
            alert.buttons[JLGStringConstants.kAlertActionConfirm].tap()
            return true
        }
        sleep(10)

        addUIInterruptionMonitor(withDescription: JLGStringConstants.kAlertBatteryInstallationDateSuccessfully) {(alert) -> Bool in
            alert.buttons[JLGStringConstants.kAlertActionOK].tap()
            return true
        }

        sleep(10)*/

        let tabBarButtons = XCUIApplication().tabBars.buttons
        let infoTabBarButton = tabBarButtons["Info"]
        infoTabBarButton.tap()
        
        let rcsButton = tabBarButtons["RCS"]
        rcsButton.tap()
        sleep(10)
        addUIInterruptionMonitor(withDescription: JLGStringConstants.kAlertBackToHomeViewController) {(alert) -> Bool in
            alert.buttons[JLGStringConstants.kAlertActionCancel].tap()
            return true
        }

        let homeTabBarButton = tabBarButtons["Home"]
        homeTabBarButton.tap()

        // Background the app
        XCUIDevice.shared.press(.home)
        // Reactivate the app
        XCUIApplication().activate()
        
    }
    /// UI Testing for RCS flow
    func testRCSUITesting() {
       self.allowSystemDialog()
       sleep(5)
       XCTAssertTrue(app.isDisplayJLGAgreementVC)
       sleep(5)
       self.allowSystemDialog()

        let agreementTextView = app.textViews[JLGTestingConstant.kAgreementTextView]
        XCTAssertTrue(agreementTextView.exists)
        
        let agreeButton = app.buttons[JLGTestingConstant.kIAgreeButton]
        if agreeButton.exists {
            XCTAssertTrue(agreeButton.exists)
            agreeButton.tap()
        }

        XCTAssertTrue(app.isDisplayJLGMainHomeVC)
        sleep(5)
        self.allowSystemDialog()
        
        let remoteControlBtn = app.otherElements[JLGTestingConstant.kRemoteControlView]
        XCTAssertTrue(remoteControlBtn.exists)
        remoteControlBtn.tap()
        
        XCTAssertTrue(app.isDisplayJLGQRCodeVC)
        let scanButton = app.buttons[JLGTestingConstant.kScanQRcodeButton]
        XCTAssertTrue(scanButton.exists)
        scanButton.tap()
        
        addUIInterruptionMonitor(withDescription: JLGStringConstants.kAlertTitleCameraAccessDenied) {(alert) -> Bool in
            alert.buttons[JLGStringConstants.kAlertActionOK].tap()
            return true
        }
        app.tap()
        
        sleep(20)
        /// Here it comes that upgrade msg
        addUIInterruptionMonitor(withDescription: JLGStringConstants.kAlertTitle) { alert in
            alert.buttons[JLGStringConstants.kAlertActionOK].tap()
            return true
        }
        app.tap()
        XCTAssertTrue(app.isDisplayJLGHomeVC)

        let hornButton = app.buttons[JLGTestingConstant.kHornButton]
        hornButton.tap()
        hornButton.press(forDuration: 0.5)

        let driveButton = app.buttons[JLGTestingConstant.kDriveButton]
        driveButton.tap()
        
        let vcHornButton = app.buttons[JLGTestingConstant.kVCHornButton]
        vcHornButton.tap()
        vcHornButton.press(forDuration: 0.5)

        let torqueHiLoButton = app.buttons[JLGTestingConstant.kTorqueHiLoButton]
        //torqueHiLoButton.tap()
        torqueHiLoButton.tap()

        let joyStickButton = app.buttons[JLGTestingConstant.kJoyStickButton]
        let joystickLeftOuterView = app.otherElements[JLGTestingConstant.kJoystickLeftOuterView]
        joyStickButton.dragAndDropUsingCenterPos(forDuration: 0.5, thenDragTo: joystickLeftOuterView)
        
        let joystickRightOuterView = app.otherElements[JLGTestingConstant.kJoystickRightOuterView]
        joyStickButton.dragAndDropUsingCenterPos(forDuration: 0.5, thenDragTo: joystickRightOuterView)

        let joystickTopOuterView = app.otherElements[JLGTestingConstant.kJoystickTopOuterView]
        joyStickButton.dragAndDropUsingCenterPos(forDuration: 0.5, thenDragTo: joystickTopOuterView)

        let joystickBottomOuterView = app.otherElements[JLGTestingConstant.kJoystickBottomOuterView]
        joyStickButton.dragAndDropUsingCenterPos(forDuration: 0.5, thenDragTo: joystickBottomOuterView)

//        let eStopButton = app.buttons[JLGTestingConstant.kEStopButton]
//        eStopButton.tap()
        
        app.navigationBars.buttons.element(boundBy: 0).tap()
        
        let rightBarButton = app.buttons[JLGTestingConstant.kRightBarCustomButton]
        XCTAssertTrue(rightBarButton.exists)
        rightBarButton.tap()
        XCTAssertTrue(app.alerts [JLGStringConstants.kAlertTitleDisconnectJLGLift].waitForExistence(timeout: 1.0))

        addUIInterruptionMonitor(withDescription: JLGStringConstants.kAlertTitleDisconnectJLGLift) {(alert) -> Bool in
            if alert.staticTexts[JLGStringConstants.kAlertMessageDisconnection].exists {
                alert.buttons[JLGStringConstants.kAlertActionDisconnect].tap()
            }

            if alert.staticTexts[JLGStringConstants.kAlertMessageBLEDisconnected].exists {
                alert.buttons[JLGStringConstants.kAlertActionRetry].tap()
            }
            return true
        }
        app.tap()

        sleep(15)

        addUIInterruptionMonitor(withDescription: JLGStringConstants.kAlertTitleCameraAccessDenied) {(alert) -> Bool in
            alert.buttons[JLGStringConstants.kAlertActionOK].tap()
            return true
        }
        app.tap()

        let tabBarButtons = XCUIApplication().tabBars.buttons
        let infoButton = tabBarButtons["Info"]
        infoButton.tap()

        let myTable = app.tables[JLGTestingConstant.kJLGSettingsTableView]
        let cell = myTable.cells.element(matching: .cell, identifier: "\(JLGTestingConstant.kJLGSettingsTableViewCellZero)")
        cell.tap()
        
        sleep(100)

        addUIInterruptionMonitor(withDescription: JLGStringConstants.kAlertTitle) {(alert) -> Bool in
            alert.buttons[JLGStringConstants.kAlertActionOK].tap()
            return true
        }
        app.tap()
        
        app.navigationBars.buttons.element(boundBy: 0).tap()

        let homeButton = tabBarButtons["Home"]
        homeButton.tap()
        sleep(10)
        addUIInterruptionMonitor(withDescription: JLGStringConstants.kAlertBackToHomeViewController) {(alert) -> Bool in
            alert.buttons[JLGStringConstants.kAlertActionConfirm].tap()
            return true
        }
        app.tap()

        XCUIApplication().launch()
    }
    
    func testBTAUITesting() {
        self.allowSystemDialog()
        sleep(5)
        XCTAssertTrue(app.isDisplayJLGAgreementVC)
        sleep(5)
        self.allowSystemDialog()

         let agreementTextView = app.textViews[JLGTestingConstant.kAgreementTextView]
         XCTAssertTrue(agreementTextView.exists)
         
         let agreeButton = app.buttons[JLGTestingConstant.kIAgreeButton]
         if agreeButton.exists {
             XCTAssertTrue(agreeButton.exists)
             agreeButton.tap()
         }

         XCTAssertTrue(app.isDisplayJLGMainHomeVC)
         sleep(5)
         self.allowSystemDialog()
         
         let remoteControlBtn = app.otherElements[JLGTestingConstant.kBluetoothAnalzerView]
         XCTAssertTrue(remoteControlBtn.exists)
         remoteControlBtn.tap()
         
         XCTAssertTrue(app.isDisplayJLGQRCodeVC)
         let scanButton = app.buttons[JLGTestingConstant.kScanQRcodeButton]
         XCTAssertTrue(scanButton.exists)
         scanButton.tap()
         
         addUIInterruptionMonitor(withDescription: JLGStringConstants.kAlertTitleCameraAccessDenied) {(alert) -> Bool in
             alert.buttons[JLGStringConstants.kAlertActionOK].tap()
             return true
         }
         app.tap()
         
         sleep(20)
         /// Here it comes that upgrade msg
         addUIInterruptionMonitor(withDescription: JLGStringConstants.kAlertTitle) { alert in
             alert.buttons[JLGStringConstants.kAlertActionOK].tap()
             return true
         }
         app.tap()
    }
/*
    func testDriveButton() {
        self.allowSystemDialog()
        sleep(5)
        XCTAssertTrue(app.isDisplayJLGAgreementVC)
        sleep(5)
        self.allowSystemDialog()

         let agreementTextView = app.textViews[JLGTestingConstant.kAgreementTextView]
         XCTAssertTrue(agreementTextView.exists)
         
         let agreeButton = app.buttons[JLGTestingConstant.kIAgreeButton]
         if agreeButton.exists {
             XCTAssertTrue(agreeButton.exists)
             agreeButton.tap()
         }

         XCTAssertTrue(app.isDisplayJLGMainHomeVC)
         sleep(5)
         self.allowSystemDialog()

         let remoteControlBtn = app.otherElements[JLGTestingConstant.kRemoteControlView]
         XCTAssertTrue(remoteControlBtn.exists)
         remoteControlBtn.tap()
         
         XCTAssertTrue(app.isDisplayJLGQRCodeVC)
         let scanButton = app.buttons[JLGTestingConstant.kScanQRcodeButton]
         XCTAssertTrue(scanButton.exists)
         scanButton.tap()
         
         addUIInterruptionMonitor(withDescription: JLGStringConstants.kAlertTitleCameraAccessDenied) {(alert) -> Bool in
             alert.buttons[JLGStringConstants.kAlertActionOK].tap()
             return true
         }
         app.tap()
         
         sleep(20)
         /// Here it comes that upgrade msg
         XCTAssertTrue(app.isDisplayJLGHomeVC)
         addUIInterruptionMonitor(withDescription: JLGStringConstants.kAlertTitle) { alert in
             alert.buttons[JLGStringConstants.kAlertActionOK].tap()
             return true
         }
         app.tap()
         
         let driveButton = app.buttons[JLGTestingConstant.kDriveButton]
         driveButton.tap()

    }
    */
    func allowSystemDialog () {
        addUIInterruptionMonitor(withDescription: "System Dialog") {(alert) -> Bool in
            let okButton = alert.buttons[JLGStringConstants.kAlertActionOK]
            if okButton.exists {
                okButton.tap()
            }
            
            let allowButton = alert.buttons["Allow"]
            if allowButton.exists {
                allowButton.tap()
            }
            return true
        }
    }
}

/*
 func testFleetVC() {
 self.testBMSButtonAction()
 
 //        let loadingView = app.otherElements[JLGTestingConstant.kLoadingIndicatorView]
 //        XCTAssertTrue(loadingView.exists)
 //        let exp = self.expectation(description: "myExpectation")
 //        if loadingView.exists {
 //            exp.fulfill()
 //         }
 //        waitForExpectations(timeout: 15.0, handler: { (error) in
 //        XCTAssertNil(error, "Test timed out.")
 //        })
 //
 //        let tableView = app.tables[JLGTestingConstant.kJLGFleetTableView]
 //        XCTAssertTrue(tableView.exists)
 //wait(for: [exp], timeout: 10.0)
 }
 */
/*
 
 //    func testRemoteControlMenuButtonPress() {
 //        self.testRemoteContolButtonAction()
 //        XCTAssertTrue(app.isDisplayJLGQRCodeVC)
 //        self.allowSystemDialog()
 //
 //        let menuButton = app.buttons[JLGTestingConstant.kMenuButton]
 //        XCTAssertTrue(menuButton.exists)
 //        menuButton.tap()
 //    }
 func testRemoteControlScanQRCodeButtonPress() {
 self.testRemoteContolButtonAction()
 XCTAssertTrue(app.isDisplayJLGQRCodeVC)
 let scanButton = app.buttons[JLGTestingConstant.kScanQRcodeButton]
 XCTAssertTrue(scanButton.exists)
 scanButton.tap()
 
 addUIInterruptionMonitor(withDescription: JLGStringConstants.kAlertTitleCameraAccessDenied) {(alert) -> Bool in
 alert.buttons["OK"].tap()
 return true
 }
 app.tap()
 
 sleep(20)
 
 addUIInterruptionMonitor(withDescription: "Alert") {(alert) -> Bool in
 let okButton = alert.buttons["OK"]
 if okButton.exists {
 okButton.tap()
 }
 return true
 }
 }
 */

extension XCUIElement {

func dragAndDropUsingCenterPos(forDuration duration: TimeInterval,
                               thenDragTo destElement: XCUIElement) {

    let sourceCoordinate: XCUICoordinate = self.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5))

    let destCorodinate: XCUICoordinate = destElement.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5))

    sourceCoordinate.press(forDuration: duration, thenDragTo: destCorodinate)
  }

}
