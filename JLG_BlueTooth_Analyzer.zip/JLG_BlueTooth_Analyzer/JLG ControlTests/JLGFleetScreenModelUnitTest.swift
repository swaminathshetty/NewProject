//
//  JLGFleetScreenModelUnitTest.swift
//  JLG ControlTests
//
//  Created by Apple on 27/12/19.
//  Copyright © 2019 L&T. All rights reserved.
//

import XCTest
@testable import JLG_Control

class JLGFleetScreenModelUnitTest: XCTestCase {

    func testForWarningIcon_Success() {
        /// Given
        let dataValue = JLGIntByteConverter.uInt8arrayToDataConverter(valueArray: arrayOfFleetScreen[0])
        /// When
        let jlgFleetScreenModelObj = JLGFleetScreenModel.init(manufacturerData: dataValue)
        /// Then
        XCTAssertTrue(jlgFleetScreenModelObj.isAlertAlarmActive)
    }
    
    func testForWarningIcon_Fail() {
        /// Given
        let dataValue = JLGIntByteConverter.uInt8arrayToDataConverter(valueArray: arrayOfFleetScreen[1])
        /// When
        let jlgFleetScreenModelObj = JLGFleetScreenModel.init(manufacturerData: dataValue)
        /// Then
        XCTAssertFalse(jlgFleetScreenModelObj.isAlertAlarmActive)
    }

    
    func testMachineSerialNumber_Success() {
        /// Given
        let dataValue = JLGIntByteConverter.uInt8arrayToDataConverter(valueArray: arrayOfFleetScreen[2])
        /// When
        let jlgFleetScreenModelObj = JLGFleetScreenModel.init(manufacturerData: dataValue)
        /// Then
        XCTAssertEqual(jlgFleetScreenModelObj.machineSn, "\u{07}\u{02}0\0\0\0\0\0\0\0\0\0\0")
    }
    
    func testMachineSerialNumber_Fail() {
        /// Given
        let dataValue = JLGIntByteConverter.uInt8arrayToDataConverter(valueArray: arrayOfFleetScreen[0])
        /// When
        let jlgFleetScreenModelObj = JLGFleetScreenModel.init(manufacturerData: dataValue)
        /// Then
        XCTAssertNotEqual(jlgFleetScreenModelObj.machineSn, "\u{07}\u{02}0\0\0\0\0\0\0\0\0\0\0")
    }

    func testMachineType_Success() {
        /// Given
        let dataValue = JLGIntByteConverter.uInt8arrayToDataConverter(valueArray: arrayOfFleetScreen[1])
        /// When
        let jlgFleetScreenModelObj = JLGFleetScreenModel.init(manufacturerData: dataValue)
        /// Then
        XCTAssertEqual(jlgFleetScreenModelObj.machineModel, "ES1530L")
    }

    func testMachineType_Fail() {
        /// Given
        let dataValue = JLGIntByteConverter.uInt8arrayToDataConverter(valueArray: arrayOfFleetScreen[3])
        /// When
        let jlgFleetScreenModelObj = JLGFleetScreenModel.init(manufacturerData: dataValue)
        /// Then
        XCTAssertNotEqual(jlgFleetScreenModelObj.machineModel, "ES1530L")
    }
    
    func testAssetId1_Success() {
        /// Given
        let dataValue = JLGIntByteConverter.uInt8arrayToDataConverter(valueArray: arrayOfAssetId1[0])
        /// When
        let jlgFleetScreenModelObj = JLGFleetScreenModel.init(manufacturerData: dataValue)
        /// Then
        XCTAssertEqual(jlgFleetScreenModelObj.assetId1, "\u{07}\u{03}UR201911031")
    }

    func testAssetId1_Fail() {
        /// Given
        let dataValue = JLGIntByteConverter.uInt8arrayToDataConverter(valueArray: arrayOfAssetId1[0])
        /// When
        let jlgFleetScreenModelObj = JLGFleetScreenModel.init(manufacturerData: dataValue)
        /// Then
        XCTAssertNotEqual(jlgFleetScreenModelObj.assetId1, "\u{07}\u{03}UR201911032")
    }

    func testAssetId2_Success() {
        /// Given
        let dataValue = JLGIntByteConverter.uInt8arrayToDataConverter(valueArray: arrayOfAssetId2[0])
        /// When
        let jlgFleetScreenModelObj = JLGFleetScreenModel.init(manufacturerData: dataValue)
        /// Then
        XCTAssertEqual(jlgFleetScreenModelObj.assetId2, "\u{07}\u{04}7452396\0\0\0\0")
    }

    func testAssetId2_Fail() {
        /// Given
        let dataValue = JLGIntByteConverter.uInt8arrayToDataConverter(valueArray: arrayOfAssetId2[0])
        /// When
        let jlgFleetScreenModelObj = JLGFleetScreenModel.init(manufacturerData: dataValue)
        /// Then
        XCTAssertNotEqual(jlgFleetScreenModelObj.assetId2, "\u{07}\u{04}745237\0\0\0\0")
    }

    func testBatteryInPercentage_Success() {
        /// Given
        let dataValue = JLGIntByteConverter.uInt8arrayToDataConverter(valueArray: arrayOfFleetScreen[5])
        /// When
        let jlgFleetScreenModelObj = JLGFleetScreenModel.init(manufacturerData: dataValue)
        /// Then
        XCTAssertNotEqual(jlgFleetScreenModelObj.batteryPercentage, "80%")
    }
    
    func testBatteryInPercentage_Fail() {
        /// Given
        let dataValue = JLGIntByteConverter.uInt8arrayToDataConverter(valueArray: arrayOfBatteryAndStatus[5])
        /// When
        let jlgFleetScreenModelObj = JLGFleetScreenModel.init(manufacturerData: dataValue)
        /// Then
        XCTAssertNotEqual(jlgFleetScreenModelObj.batteryPercentage, "90%")
    }

    func testBatteryInVolt() {
        /// Given
        let dataValue = JLGIntByteConverter.uInt8arrayToDataConverter(valueArray: arrayOfBatteryAndStatus[6])
        /// When
        let jlgFleetScreenModelObj = JLGFleetScreenModel.init(manufacturerData: dataValue)
        /// Then
        XCTAssertNotEqual(jlgFleetScreenModelObj.batteryPercentage, "24.2V")
    }
    
    func testForPluggedInIcon_Success() {
        /// Given
        let dataValue = JLGIntByteConverter.uInt8arrayToDataConverter(valueArray: arrayOfFleetScreen[5])
        /// When
        let jlgFleetScreenModelObj = JLGFleetScreenModel.init(manufacturerData: dataValue)
        /// Then
        XCTAssertEqual(jlgFleetScreenModelObj.isConnectedWithACPower, JLGStringConstants.kPlugConnectedWarning)
    }
    
    func testForPluggedInIcon_Fail() {
        /// Given
        let dataValue = JLGIntByteConverter.uInt8arrayToDataConverter(valueArray: arrayOfFleetScreen[1])
        /// When
        let jlgFleetScreenModelObj = JLGFleetScreenModel.init(manufacturerData: dataValue)
        /// Then
        XCTAssertNotEqual(jlgFleetScreenModelObj.isConnectedWithACPower, JLGStringConstants.kPlugConnectedWarning)
    }

}
