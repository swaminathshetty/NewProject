//
//  JLGAgreementVCUnitTest.swift
//  JLG ControlTests
//
//  Created by Apple on 25/12/19.
//  Copyright © 2019 L&T. All rights reserved.
//

import XCTest
import RealmSwift

@testable import JLG_Control

class JLGAgreementVCUnitTest: XCTestCase {
    
    var jlgAgreementVC: JLGAgreementViewController!
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
        jlgAgreementVC = mainStoryboard.instantiateViewController(withIdentifier: "JLGAgreementViewController") as? JLGAgreementViewController
        _ = jlgAgreementVC.view
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
        jlgAgreementVC = nil
    }
    
    func testAgreeButtonAction() {
        jlgAgreementVC.agreeButtonAction(jlgAgreementVC.agreeButton)
        XCTAssertTrue((jlgAgreementVC!.agreeButton != nil))
    }
    
    func testCheckRealmDB() {
        /// Given
        var realmDBName: String? = nil
        
        /// When
        jlgAgreementVC.checkRealmDBExistsOrNot()
        realmDBName = UserDefaults.standard.value(forKey: JLGStringConstants.kRelamJSONUserDefaults) as? String
        
        /// Then
        if realmDBName == nil {
            XCTAssertNil(realmDBName, "Realm File not Exists")
        } else {
            XCTAssertNotNil(realmDBName, "Realm File Exists")
        }
    }
    
    func testCreateRealmDB() {
        /// Given
        var realmDBName: String? = nil
        
        /// When
        jlgAgreementVC.createDBUsingJSONFile()
        realmDBName = UserDefaults.standard.value(forKey: JLGStringConstants.kRelamJSONUserDefaults) as? String
        
        /// Then
        if realmDBName == nil {
            XCTAssertNil(realmDBName, "Realm File not Exists")
        } else {
            XCTAssertNotNil(realmDBName, "Realm File Exists")
        }
    }
    
}
