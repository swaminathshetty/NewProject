//
//  JLGQRCodeVCUnitTest.swift
//  JLG ControlTests
//
//  Created by Apple on 03/01/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import XCTest
@testable import JLG_Control

class JLGQRCodeVCUnitTest: XCTestCase {
    var jlgQRCodeVC: JLGQRCodeViewController!
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
        
        jlgQRCodeVC = mainStoryboard.instantiateViewController(withIdentifier: "JLGQRCodeViewController") as? JLGQRCodeViewController
        _ = jlgQRCodeVC.view
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
        jlgQRCodeVC = nil
    }
    
    func testShowUserManual() {
        jlgQRCodeVC.menuButtonAction(jlgQRCodeVC.menuButton)
        jlgQRCodeVC.showUserManual()
    }
    
    func testCofigureMachineDecal() {
        jlgQRCodeVC.gotoQRCodeScanViewController(cofigureMachineDecal: true)
        jlgQRCodeVC.gotoQRCodeScanViewController(cofigureMachineDecal: false)
    }
    
//    func testAllAlert() {
//        jlgQRCodeVC.showAlertToOpenCamera()
//        jlgQRCodeVC.showBLEFirmwareVerificationAlert()
//        JLGAlertUtilities.sharedInstance.showAlertIfBLEIsOff(viewController: jlgQRCodeVC)
//    }
}
