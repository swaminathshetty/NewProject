//
//  JLGQRCodeScanVCUnitTest.swift
//  JLG ControlTests
//
//  Created by Apple on 03/01/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import XCTest
@testable import JLG_Control

class JLGQRCodeScanVCUnitTest: XCTestCase {

    var jlgQRCodeScanVC: JLGQRCodeScanViewController!

    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
        
        jlgQRCodeScanVC = mainStoryboard.instantiateViewController(withIdentifier: "JLGQRCodeScanViewController") as? JLGQRCodeScanViewController
        _ = jlgQRCodeScanVC.view
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
        jlgQRCodeScanVC = nil
    }

    func testMethods() {
        jlgQRCodeScanVC.gotoPreviousScreen()
        
        jlgQRCodeScanVC.toggleTorch(on: true)
        jlgQRCodeScanVC.toggleTorch(on: false)
        
        jlgQRCodeScanVC.setupQRCodeScanner()
        
        jlgQRCodeScanVC.invalidMachineDecal()
        
        jlgQRCodeScanVC.resetUIForQRCode()
        
        jlgQRCodeScanVC.tryToConnectWithBLE()
        
        jlgQRCodeScanVC.matchSerialNumberOrMachineDecal()
        
        jlgQRCodeScanVC.liftNotFound()
        
        jlgQRCodeScanVC.connectToBLE()
        
        jlgQRCodeScanVC.showPopupToConfigureMachineDecal()
        
        jlgQRCodeScanVC.checkForAuthFreshnessValue()
        
        jlgQRCodeScanVC.checkForAuthentication()
        
        //jlgQRCodeScanVC.checkBLEVersion()
        
        jlgQRCodeScanVC.checkForAuthFreshnessValue()
        
        jlgQRCodeScanVC.resetQRScanning()
        
        //jlgQRCodeScanVC.disconnectBluetooth()
        
        jlgQRCodeScanVC.startOTAReprogramming(firmwareName: JLGStringConstants.kBinaryFileName)
        
        jlgQRCodeScanVC.readBinaryFileContent(firmwareName: JLGStringConstants.kBinaryFileName)
        
        jlgQRCodeScanVC.invalidateOTATimer()
        
        jlgQRCodeScanVC.restartCAN2BLE()
        
        jlgQRCodeScanVC.receiveNotificationForOTAReprogramming()
        
        jlgQRCodeScanVC.writeDataIntoBLEWithChunks()
        
        jlgQRCodeScanVC.openAppStore()
        
        jlgQRCodeScanVC.showAlertForNoDeviceFound()
        
        jlgQRCodeScanVC.showAlertForOTAFirmwareUpgrade(firmwareName: JLGStringConstants.kBinaryFileName)
        
        jlgQRCodeScanVC.showAlertForAppUpdateThroughAppStore()
    }

}
