//
//  JLGSettingsVCUnitTest.swift
//  JLG ControlTests
//
//  Created by Apple on 06/01/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import XCTest
@testable import JLG_Control

class JLGSettingsVCUnitTest: XCTestCase {
    var jlgSettingsVC: JLGInfoTabViewController!

    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
        
        jlgSettingsVC = mainStoryboard.instantiateViewController(withIdentifier: "JLGInfoTabViewController") as? JLGInfoTabViewController
        _ = jlgSettingsVC.view
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
        jlgSettingsVC = nil
    }
    
    func testMethods() {
        jlgSettingsVC.initialSetup()
        //_ = jlgSettingsVC.needsUpdate()
        jlgSettingsVC.performSegue(withIdentifier: "JLGManualViewController", sender: 0)
        jlgSettingsVC.performSegue(withIdentifier: "JLGManualViewController", sender: 1)
        jlgSettingsVC.performSegue(withIdentifier: "JLGManualViewController", sender: 2)
    }

}
