//
//  JLGMainHomeVCUnitTest.swift
//  JLG ControlTests
//
//  Created by Apple on 25/12/19.
//  Copyright © 2019 L&T. All rights reserved.
//

import XCTest
@testable import JLG_Control

class JLGMainHomeVCUnitTest: XCTestCase {
    
    var jlgMainHomeVC: JLGMainHomeViewController!
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
        
        jlgMainHomeVC = mainStoryboard.instantiateViewController(withIdentifier: "JLGMainHomeViewController") as? JLGMainHomeViewController
        _ = jlgMainHomeVC.view
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
        jlgMainHomeVC = nil
    }
    
    
    func testBMSButtonActionIfBluetoothIsOff() {
        isDeviceBluetoothOff = true
        jlgMainHomeVC.bmsButtonAction((Any).self)
    }

    func testRemoteControlButtonAction() {
        jlgMainHomeVC.remoteControlButtonAction((Any).self)
    }

}
