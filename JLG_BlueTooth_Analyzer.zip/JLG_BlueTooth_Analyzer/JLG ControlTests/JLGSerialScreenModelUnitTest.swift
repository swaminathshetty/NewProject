//
//  JLGSerialScreenModelUnitTest.swift
//  JLG ControlTests
//
//  Created by Apple on 27/07/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import XCTest
@testable import JLG_Control

class JLGSerialScreenModelUnitTest: XCTestCase {
    var jlgCommunicationManager: JLGCommunicationManager!
    var jlgSerialScreenModelObject: JLGSerialScreenModel!
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
        
        jlgCommunicationManager = JLGCommunicationManager.sharedInstance
        jlgSerialScreenModelObject = JLGSerialScreenModel.sharedInstance
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
        jlgCommunicationManager = nil
        jlgSerialScreenModelObject = nil
    }

    
    func testBatteryInfoModel() {
        /// Given
        let arrayOfDummyData = jlgCommunicationManager.createSerialScreenDummyData()
        let stringData = arrayOfDummyData[0]
        /// When
        jlgCommunicationManager.createSerialScreenDummyDataForTesting(stringData: stringData)
        /// Then
        XCTAssertEqual(jlgSerialScreenModelObject.batteryInfoModel.batterySoc, 80)
    }
    
    func testBatteryInfoModel_Default() {
        /// Given
        let stringData = "battery_info {}"
        /// When
        jlgCommunicationManager.createSerialScreenDummyDataForTesting(stringData: stringData)
        /// Then
        XCTAssertEqual(jlgSerialScreenModelObject.batteryInfoModel.batterySoc, 0)
    }

    func testAssetIdModel() {
        /// Given
        let arrayOfDummyData = jlgCommunicationManager.createSerialScreenDummyData()
        let stringData = arrayOfDummyData[1]
        /// When
        jlgCommunicationManager.createSerialScreenDummyDataForTesting(stringData: stringData)
        /// Then
        XCTAssertEqual(jlgSerialScreenModelObject.assetIdModel.assetID, "9876432")
    }

    func testSerialNumberModel() {
        /// Given
        let arrayOfDummyData = jlgCommunicationManager.createSerialScreenDummyData()
        let stringData = arrayOfDummyData[9]
        /// When
        jlgCommunicationManager.createSerialScreenDummyDataForTesting(stringData: stringData)
        /// Then
        XCTAssertEqual(jlgSerialScreenModelObject.serialNumberModel?.serialNumber, "Serial123")
    }
    
    func testBatteryHistory_LastChargeCycleModel() {
        /// Given
        let arrayOfDummyData = jlgCommunicationManager.createSerialScreenDummyData()
        let stringData = arrayOfDummyData[2]
        /// When
        jlgCommunicationManager.createSerialScreenDummyDataForTesting(stringData: stringData)
        /// Then
        XCTAssertTrue(jlgSerialScreenModelObject.batteryHistoryModel.lastChargeCycleModel.count != 0)
    }

    func testBatteryHistory_LastFiveCyclesModel() {
        /// Given
        let arrayOfDummyData = jlgCommunicationManager.createSerialScreenDummyData()
        let stringData = arrayOfDummyData[3]
        /// When
        jlgCommunicationManager.createSerialScreenDummyDataForTesting(stringData: stringData)
        /// Then
        XCTAssertTrue(jlgSerialScreenModelObject.batteryHistoryModel.lastFiveCyclesModel.count != 0)
    }

    func testChargerFaultListModel() {
        /// Given
        let arrayOfDummyData = jlgCommunicationManager.createSerialScreenDummyData()
        let stringData = arrayOfDummyData[5]
        /// When
        jlgCommunicationManager.createSerialScreenDummyDataForTesting(stringData: stringData)
        /// Then
        XCTAssertTrue(jlgSerialScreenModelObject.chargerFaultListModel.faultCodesModel.count != 0)
    }

    func testAlarmAlertStatusModel() {
        /// Given
        let arrayOfDummyData = jlgCommunicationManager.createSerialScreenDummyData()
        let stringData = arrayOfDummyData[7]
        /// When
        jlgCommunicationManager.createSerialScreenDummyDataForTesting(stringData: stringData)
        /// Then
        //XCTAssertTrue(jlgSerialScreenModelObject.alarmAlertStatusModel.chargerAlertActive)
    }
    
    func testAlarmAlertStatusModel_Default() {
        /// Given
        let stringData = "alarm_alert_status {}"
        /// When
        jlgCommunicationManager.createSerialScreenDummyDataForTesting(stringData: stringData)
        /// Then
        //XCTAssertFalse(jlgSerialScreenModelObject.alarmAlertStatusModel.chargerAlertActive)
    }

    func testBMSAlertModel() {
        /// Given
        let arrayOfDummyData = jlgCommunicationManager.createSerialScreenDummyData()
        let stringData = arrayOfDummyData[8]
        /// When
        jlgCommunicationManager.createSerialScreenDummyDataForTesting(stringData: stringData)
        /// Then
        XCTAssertTrue(jlgSerialScreenModelObject.bmsAlertListModel.bmsAlertsModel.count != 0)
    }
    
    func testDTCAlertListModel() {
        /// Given
        let arrayOfDummyData = jlgCommunicationManager.createSerialScreenDummyData()
        let stringData = arrayOfDummyData[6]
        /// When
        jlgCommunicationManager.createSerialScreenDummyDataForTesting(stringData: stringData)
        /// Then
        XCTAssertTrue(jlgSerialScreenModelObject.dtcAlertListModel.dtcAlertNumber.count != 0)
    }

    func testServiceConnectModel() {
        /// Given
        let arrayOfDummyData = jlgCommunicationManager.createSerialScreenDummyData()
        let stringData = arrayOfDummyData[10]
        /// When
        jlgCommunicationManager.createSerialScreenDummyDataForTesting(stringData: stringData)
        /// Then
        XCTAssertEqual(jlgSerialScreenModelObject.serviceConnectModel?.vehicleModel, 20)
    }

}
