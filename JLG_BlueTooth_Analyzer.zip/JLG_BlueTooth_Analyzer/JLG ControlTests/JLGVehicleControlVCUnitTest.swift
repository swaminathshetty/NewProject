//
//  JLGVehicleControlVCUnitTest.swift
//  JLG ControlTests
//
//  Created by Apple on 08/01/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import XCTest
@testable import JLG_Control

class JLGVehicleControlVCUnitTest: XCTestCase {

    var jlgVehicleControlVC: JLGRCSVehicleControlViewController!

    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
        
        jlgVehicleControlVC = mainStoryboard.instantiateViewController(withIdentifier: "JLGRCSVehicleControlViewController") as? JLGRCSVehicleControlViewController
        _ = jlgVehicleControlVC.view
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
        jlgVehicleControlVC = nil
    }
    
    func testMethods() {
        jlgVehicleControlVC.loadViewIfNeeded()
        
        jlgVehicleControlVC.viewDidAppear(true)
        
        jlgVehicleControlVC.viewWillDisappear(true)
        
        jlgVehicleControlVC.setupUI()
        
        jlgVehicleControlVC.hornButtonTapAction(jlgVehicleControlVC.hornButton)
        
        jlgVehicleControlVC.disableHorn()
        
        jlgVehicleControlVC.readRSSIValue()
        
        jlgVehicleControlVC.invalidateRSSITimer()
        
        jlgVehicleControlVC.receivedNotificationForWarning()
        
        //jlgVehicleControlVC.eStopButtonAction(jlgVehicleControlVC.eStopButton)
        
        jlgVehicleControlVC.torqueSpeedModeToggleButtonAction(jlgVehicleControlVC.torqueHiLoButton)
        
        //jlgVehicleControlVC.rightBarCustomButtonAction((Any).self)

        jlgVehicleControlVC.showAlertForDisconnectPermission()
        
        //jlgVehicleControlVC.goingOutOfJoystickArea()
        
        jlgVehicleControlVC.changeDriveIndicationImage()
        
        jlgVehicleControlVC.disconnectBLE()
        
        jlgVehicleControlVC.startRepeatCommandSendingTimer()
        
        jlgVehicleControlVC.stopRepeatCommandSendingTimer()
        
        jlgVehicleControlVC.repeatSendCommandIn100MiliSecondsDuration()
    }
    
    func testJoystickView() {
        jlgVehicleControlVC.joystickView.startJoystickRippling()
        jlgVehicleControlVC.joystickView.stopJoystickRippling()
        
        jlgVehicleControlVC.joystickView.layoutSubviews()
    }
    
    func testVehicalPathView() {
        jlgVehicleControlVC.vehiclePathView.layoutSubviews()
    }
}
