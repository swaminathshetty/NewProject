//
//  JLGHomeVCUnitTest.swift
//  JLG ControlTests
//
//  Created by Apple on 03/01/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import XCTest
@testable import JLG_Control

class JLGHomeVCUnitTest: XCTestCase {
    var jlgHomeVC: JLGRCSTabViewController!

    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
        
        jlgHomeVC = mainStoryboard.instantiateViewController(withIdentifier: "JLGRCSTabViewController") as? JLGRCSTabViewController
        _ = jlgHomeVC.view
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
        jlgHomeVC = nil
    }
    
    func testMethods() {
        jlgHomeVC.viewDidAppear(true)
        
        //jlgHomeVC.checkForAuthentication()
        
        jlgHomeVC.enableOrDisableDrive()
        
        jlgHomeVC.setupUI()
        
        jlgHomeVC.animateBatteryImages()
        
        jlgHomeVC.startBatteryImagesAnimation()
        
        jlgHomeVC.showAlertForFailedAuthentication(message: JLGStringConstants.kAlertMessageAuthenticationInvalid)
        
        jlgHomeVC.showAlertForBLEConnectionLost(title: JLGStringConstants.kAlertTitleBLEDisconnected, mesage: JLGStringConstants.kAlertMessageBLEDisconnected)
                
        jlgHomeVC.showAlertForDisconnectPermission()
        
        jlgHomeVC.showAlertForTimeout()
        
        jlgHomeVC.hornButtonSingleClickAction(jlgHomeVC.hornButton)
        
        jlgHomeVC.disableHorn()
        
        isDeviceBluetoothOff = true
        jlgHomeVC.showAlertForNoDeviceFound()
        isDeviceBluetoothOff = false
    }

}
