//
//  JLGFleetVCUnitTest.swift
//  JLG ControlTests
//
//  Created by Apple on 26/12/19.
//  Copyright © 2019 L&T. All rights reserved.
//

import XCTest
@testable import JLG_Control

class JLGFleetVCUnitTest: XCTestCase {
    var jlgFleetVC: JLGBMSFleetTabViewController!
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
        
        jlgFleetVC = mainStoryboard.instantiateViewController(withIdentifier: "JLGBMSFleetTabViewController") as? JLGBMSFleetTabViewController
        _ = jlgFleetVC.view
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
        jlgFleetVC = nil
    }

    func testFleetViewControllerHasTableView() {

        jlgFleetVC.loadViewIfNeeded()
        jlgFleetVC.viewDidDisappear(true)
        jlgFleetVC.segmentControlAction(jlgFleetVC.segmentControl.contentOffsetForSegment(at: 2))
    }

}
