//
//  WIFISettingsVMTests.swift
//  KobelcoServiceTests
//
//  Created by Swaminath on 10/4/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit
import XCTest
@testable import KobelcoService

class WIFISettingsVMTests: XCTestCase {
    var getSSIDInstance: KSWiFiSettingsVM!
    
    override func setUp() {
        super.setUp()
        // Initializing modeltype viewmodel before the invocation of each test method in the class.
        getSSIDInstance = KSWiFiSettingsVM()
    }
    
    // This method is called after the invocation of each test method in the class.
    override func tearDown() {
        getSSIDInstance = nil // Deallocating or clear object from memory
        super.tearDown()
    }

    // Checking for empty SSID-Name.
    func testIsSSIDEmpty() {
        let ssidName = getSSIDInstance.getSSID()
        XCTAssertNil(ssidName)
    }

}
