//
//  KSViewController+Design.swift
//  KobelcoService
//
//  Created by Guest L&T on 14/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation
import UIKit
import EFAutoScrollLabel

extension UIViewController {
    
    // ReusableAlert without button action
    func presentAlert(withTitle title: String, message: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default) { _ in
        }
        alertController.addAction(OKAction)
        self.present(alertController, animated: true, completion: nil)
    }
    // ReusableAlert without button action
    func presentAlertOKAction(withTitle title: String, message: String, completionHandler: @escaping (Bool) -> Void) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default) { _ in
            completionHandler(true)
        }
        alertController.addAction(OKAction)
        self.present(alertController, animated: true, completion: nil)
    }

    // Reuable 2 titles alert with return action
    func presentAlertWithAction(title: String, message: String, action1Title: String, action2Title: String, completionHandler: @escaping (Bool) -> Void) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: action1Title, style: .default) { _ in
            completionHandler(false)
        }
        let OKAction = UIAlertAction(title: action2Title, style: .destructive) { _ in
            completionHandler(true)
        }
        alertController.addAction(cancelAction)
        alertController.addAction(OKAction)
        self.present(alertController, animated: true, completion: nil)
    }
    // AlertView with 2 titles.
    func presentAttributedStringAlert(message1: String, message2: String, completionHandler: @escaping (Bool) -> Void) {
        let textAttributeForTitle = [NSAttributedString.Key.foregroundColor: UIColor.black, NSAttributedString.Key.font: UIFont.bold(ofSize: 16)]
        let textAttributeForMessage = [NSAttributedString.Key.foregroundColor: UIColor.darkGray, NSAttributedString.Key.font: UIFont.regular(ofSize: 15)]

        let title1 = NSMutableAttributedString(string: "Explanation", attributes: textAttributeForTitle)
        let description1 = NSMutableAttributedString(string: "\n\n\(message1)\n\n", attributes: textAttributeForMessage)
        let title2 = NSMutableAttributedString(string: "Attention", attributes: textAttributeForTitle)
        let description2 = NSMutableAttributedString(string: "\n\n\(message2)", attributes: textAttributeForMessage)

        let attributedText = NSMutableAttributedString()
        attributedText.append(title1)
        attributedText.append(description1)
        attributedText.append(title2)
        attributedText.append(description2)

        let alertController = UIAlertController(title: title, message: "", preferredStyle: .alert)
        alertController.setValue(attributedText, forKey: "attributedMessage")
        let OKAction = UIAlertAction(title: "OK", style: .default) { _ in
            completionHandler(true)
        }
        alertController.addAction(OKAction)
        self.present(alertController, animated: true, completion: nil)
    }

    // Navigation based on dynamic identifier name.
    func navigation(to screenIdentifier: Identifier, navigationTitle: String = "") {
        if screenIdentifier.rawValue == "KSMemoryReset" {
            let memoryResetSubScreen = MAINSTORYBOARD.instantiateViewController(withIdentifier: "KSMemoryReset") as? KSMemoryReset
            memoryResetSubScreen?.navigationTitle = navigationTitle
            self.navigationController?.pushViewController(memoryResetSubScreen!, animated: true)
        } else {
            let viewController = MAINSTORYBOARD.instantiateViewController(withIdentifier: screenIdentifier.rawValue)
            self.navigationController?.pushViewController(viewController, animated: true)
        }
    }
    
    // MARK: - configure navigationbar
    
    func commonNavigationBarCode() {
        self.navigationController?.setNavigationBarHidden(false, animated: true)
        self.navigationController?.navigationBar.barTintColor = NAVIGATIONBARCOLOR
    }
    // Dashboard navigationItems.
    func setNavigationBarColorAndItems() {
        commonNavigationBarCode()
        self.navigationController?.navigationBar.backItem?.title = "  "
        self.navigationItem.setHidesBackButton(true, animated: true)
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(image: NAVIGATIONLEFTBARLOGO, style: .plain, target: self, action: nil)
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: NAVIGATIONDASHBOARDRIGHTBAR, style: .plain, target: self, action: #selector(navigateToWiFiSettingsScreen))
    }
    // Subscreen navigation bar.
    func setNavigationBarColorWithButtonTitle(buttonTitle: String) {
        commonNavigationBarCode()
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: NAVIGATIONRIGHTBARLOGO, style: .plain, target: self, action: #selector(navigateToDashboard))
        self.navigationItem.setHidesBackButton(false, animated: true)
        self.navigationController?.navigationBar.backItem?.title = "  "
        // Adding scrollable label as navigation title.
        SCROLLLABEL.backgroundColor = .clear
        SCROLLLABEL.textColor = .white
        SCROLLLABEL.font = UIFont.medium(ofSize: 16)
        SCROLLLABEL.labelSpacing = 30                       // Distance between start and end labels
        SCROLLLABEL.pauseInterval = 1.5                     // Seconds of pause before scrolling starts again
        SCROLLLABEL.scrollSpeed = 0                        // Pixels per second
        SCROLLLABEL.textAlignment = NSTextAlignment.center    // Centers text when no auto-scrolling is applied
        SCROLLLABEL.fadeLength = 1                         // Length of the left and right edge fade, 0 to disable
        SCROLLLABEL.scrollDirection = EFAutoScrollDirection.left
        SCROLLLABEL.text = buttonTitle
        SCROLLLABEL.isUserInteractionEnabled = true
        self.navigationItem.titleView = SCROLLLABEL
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.tapToScrollNavigationTitle(_:)))
        SCROLLLABEL.addGestureRecognizer(tap)
    }
    // Tap geture action for errorcodedisplay view.
    @objc func tapToScrollNavigationTitle(_ : UITapGestureRecognizer?) {
        KSSingletonManager.shared.toastController = UIAlertController(title: "Title", message: "\(SCROLLLABEL.text ?? "")", preferredStyle: .alert)
        KSSingletonManager.shared.toastController?.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { _ in
            // OK Action
        }))
        self.present(KSSingletonManager.shared.toastController!, animated: true, completion: {
            KSSingletonManager.shared.toastController?.view.superview?.isUserInteractionEnabled = true
            KSSingletonManager.shared.toastController?.view.superview?.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(self.alertClose(_:))))
        })
    }
    // Touch outside on view anywhere to hide alertview.
     @objc func alertClose(_ : UITapGestureRecognizer) {
        KSSingletonManager.shared.toastController?.dismiss(animated: true, completion: nil)
    }
    // ConfirmationAlert for Dashboard RightBarItem.
    @objc func navigateToWiFiSettingsScreen() {
        let alert = UIAlertController(title: "Confirmation", message: "Are you sure you want to disconnect from machine?", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: { _ in
            // Cancel Action
        }))
        alert.addAction(UIAlertAction(title: "Yes", style: UIAlertAction.Style.destructive, handler: {(_: UIAlertAction!) in
            self.navigateToWiFiSettings()
        }))
        self.present(alert, animated: true, completion: nil)
    }
    // Navigation for Dashboard.
    @objc func navigateToDashboard() {
        self.navigationController?.popOverToDashboard(index: KSSingletonManager.shared.dashboardNavigationID)
    }
    // Navigation for WiFiSettings Screen.
    func navigateToWiFiSettings() {
        self.navigationController?.popOverToWiFiSettings(index: KSSingletonManager.shared.wifiSettingsNavigationID)
    }
    // Convert data format to JSON dictionary format
    func convertDataToDictionary(data: Data) -> [String: Any]? {
        do {
            return try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
        } catch {
            print(error.localizedDescription)
        }
        return nil
    }
    // MARK: - SHOW LOADER
    func showLoader() {
        DispatchQueue.main.async {
        self.view.addSubview((appDelegate?.indicatorView)!)
        appDelegate?.indicatorView?.activityIndicator.startAnimating()
        appDelegate?.indicatorView?.setIndicatorFrame()
      }
    }
    
    // MARK: - HIDE LOADER
    func hideLoader() {
        DispatchQueue.main.async {
            appDelegate?.indicatorView?.activityIndicator.stopAnimating()
            appDelegate?.indicatorView?.removeFromSuperview()
            self.view.willRemoveSubview((appDelegate?.indicatorView)!)
        }
    }
    
    // MARK: - Show Copyright Label
    func showCopyrightLabel() {
        DispatchQueue.main.async {
        appDelegate?.copyrightView?.setViewFrame()
        self.view.addSubview((appDelegate?.copyrightView)!)
      }
    }
    
    // MARK: - Hide Copyright Label
    func hideCopyrightLabel() {
        DispatchQueue.main.async {
        appDelegate?.copyrightView?.removeFromSuperview()
        self.view.willRemoveSubview((appDelegate?.copyrightView)!)
      }
    }
    
    // MARK: - Connect websocket reuable function
    func initiateWebSocketConnection() {
        self.showLoader()
        KSSingletonManager.shared.connectWebSocket()
    }
}
