//
//  KSLoginVM.swift
//  KobelcoService
//
//  Created by Guest L&T on 11/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation

class KSLoginVM {
    
    private let model: LoginModel?

    init(model: LoginModel) {
        self.model = model
    }
    func validateUserName(_ username: String?) throws -> String {
        guard let userName = username else { throw ValidationError.inValidValue }
        guard userName.count != 0  else { throw ValidationError.inValidUserName }
        return userName
    }
    
    func validatePassword(_ password: String?) throws -> String {
        guard let password = password else { throw ValidationError.inValidValue }
        guard password.count != 0 else { throw ValidationError.inValidPassword }
        return password
    }
    func validateUserNameAndPassword(_ username: String?, _ password: String?) throws -> String {
        if self.model?.username == username && self.model?.password == password {
            return username!
        } else {
            throw ValidationError.invalidCredentails
        }
    }
}

enum ValidationError: LocalizedError {
    case inValidValue
    case invalidCredentails
    case inValidUserName
    case inValidPassword
    
    var errorDescription: String? {
        switch self {
        case .inValidValue:
            return "Please enter a valid credentials."
        case .invalidCredentails:
            return "Please enter the correct User ID and Password."
        case .inValidUserName:
            return "Please enter User ID."
        case .inValidPassword:
            return "Please enter Passowrd."
        }
    }
}
