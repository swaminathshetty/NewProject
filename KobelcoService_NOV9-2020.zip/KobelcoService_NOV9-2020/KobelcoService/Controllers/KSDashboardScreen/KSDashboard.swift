//
//  KSDashboard.swift
//  KobelcoService
//
//  Created by Guest L&T on 14/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSDashboard: UIViewController {

    @IBOutlet weak var labelNoConnection: UILabel!
    @IBOutlet weak var viewErrorCodeDisplay: UIView!
    @IBOutlet weak var labelErrorCodeDisplay: UILabel!
    @IBOutlet weak var labelECUErrorCount: UILabel!
    @IBOutlet weak var labelDCUErrorCount: UILabel!
    @IBOutlet weak var buttonMemoryReset: UIButton!
    @IBOutlet weak var buttonDiagnostic: UIButton!
    @IBOutlet weak var buttonSetValueFunction: UIButton!
    @IBOutlet weak var buttonDataMonitor: UIButton!
    @IBOutlet weak var buttonDataComparision: UIButton!
    @IBOutlet weak var buttonConfiguration: UIButton!
    fileprivate var dashboardViewCanSwipe: Bool = false
    fileprivate var isViewPresented: Bool = true
    fileprivate var dashboardModel: DashboardResponseDict?

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.navigationController?.navigationBar.isHidden = false
        self.navigationController?.getDashboardNavigationID()
        KSSingletonManager.shared.delegate = self
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarColorAndItems()
        self.viewErrorCodeDisplay.layer.cornerRadius = 6
        isViewPresented = true
        configureGestureRecognizers()
    }
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        if isViewPresented {
            self.hideCopyrightLabel()
            if UIDevice.current.orientation.isLandscape {
                self.showCopyrightLabel()
            } else {
                self.showCopyrightLabel()
            }
        }
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.showCopyrightLabel()
        if KSSingletonManager.shared.isOfflineConnection == true {
            //self.disableFewMainMenuItems()
        } else {
            KSSingletonManager.shared.delegate = self
            dashboardViewCanSwipe = false
            self.showLoader()
            KSSingletonManager.shared.networkHandler()
            KSSingletonManager.shared.connectWebSocket()
            self.perform(#selector(sendDashboardCommand), with: self, afterDelay: 3)
        }
    }
    @objc func sendDashboardCommand() {
        self.showLoader()
        let dashboardCommand = SocketRequestDict(screenName: "DashboardScreen", frameType: "ActiveErrorCountRequest", device: "All", periodicity: 10000)
        guard let dashboardRequestData = try? JSONEncoder().encode(dashboardCommand) else { return }
        KSSingletonManager.shared.sendCommand(format: dashboardRequestData)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.hideCopyrightLabel()
        self.hideLoader()
        dashboardViewCanSwipe = false
        isViewPresented = false
        KSSingletonManager.shared.disconnectWebSocket()
    }
    
    // Configure gesture recognizer for errorcode screen navigation.
    fileprivate func configureGestureRecognizers() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(respondToTapGesture))
        viewErrorCodeDisplay.addGestureRecognizer(tap)
        
        let swipeGesture = UISwipeGestureRecognizer(target: self, action: #selector(respondToSwipeGesture))
        swipeGesture.direction = .left
        self.view.addGestureRecognizer(swipeGesture)
    }
    // Called when user tap on the error code display view.
    @objc func respondToTapGesture(gesture: UIGestureRecognizer) {
        self.navigation(to: Identifier.errorCodeScreen)
    }
    // Called when user swipe right for error code navigation.
    @objc func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if dashboardViewCanSwipe {
            self.navigation(to: Identifier.errorCodeScreen)
        }
    }
    // Tag based navigation for dashboard menu items
    @IBAction func buttonTapAction(_ sender: UIButton) {
        switch sender.tag {
        case 0:
            self.navigation(to: Identifier.memoryResetScreen)
        case 1:
            self.navigation(to: Identifier.setValueWritingFunction)
        case 2:
            self.navigation(to: Identifier.diagnosticTest)
        case 3:
            self.navigation(to: Identifier.dataMonitor)
        case 4:
            self.navigation(to: Identifier.dataComparision)
        case 5:
            self.navigation(to: Identifier.configuration)
        default:
            break
        }
    }
}
// MARK: WebSocket Response Delegate
extension KSDashboard: KSWebSocketDelegates {
    func webSocketStringResponse(response: String) {
        print("Dashboard Response")
        guard let jsonDictionary = convertToDictionary(text: response) else { return }
        guard let screenTitle = jsonDictionary["screenName"] as? String else { return }
        if screenTitle == "DashboardScreen" {
            self.hideLoader()
            dashboardViewCanSwipe = true
            if let data = response.data(using: String.Encoding.utf8) {
                do {
                    self.dashboardModel = try JSONDecoder().decode(DashboardResponseDict.self, from: data)
                    DispatchQueue.main.async {
                        self.labelECUErrorCount.text = "Active ECU Errors- \(self.dashboardModel?.ecuErrorCount ?? "")"
                        self.labelDCUErrorCount.text = "Active DCU Errors- \(self.dashboardModel?.dcuErrorCount ?? "")"
                    }
                } catch let error as NSError {
                    self.presentAlert(withTitle: "ERROR", message: error.localizedDescription)
                }
            }
        }
    }
    func webSocketErrorConnection(message: String) {
        self.hideLoader()
        presentAlert(withTitle: "ERROR", message: message)
    }
    func internetConnectionNotAvailable() {
        self.hideLoader()
        if KSSingletonManager.shared.isOfflineConnection == false {
            presentAlertOKAction(withTitle: "ERROR", message: WIFIDISCONNECTEDMESSAGE) { (isOkTapped) in
                if isOkTapped {
                    self.navigateToWiFiSettings()
                }
            }
        }
    }
    // Deactivate few menu items in offline mode.
    func disableFewMainMenuItems() {
        self.hideLoader()
        dashboardViewCanSwipe = true
        labelNoConnection.isHidden = false
        viewErrorCodeDisplay.isUserInteractionEnabled = false
        labelErrorCodeDisplay.textColor = .lightGray
        viewErrorCodeDisplay.alpha = 0.8
        buttonMemoryReset.isEnabled = false
        buttonMemoryReset.alpha = 0.8
        buttonSetValueFunction.isEnabled = false
        buttonSetValueFunction.alpha = 0.8
        buttonDiagnostic.isEnabled = false
        buttonDiagnostic.alpha = 0.8
        buttonDataMonitor.isEnabled = false
        buttonDataMonitor.alpha = 0.8
    }
}
