//
//  KSInjectorPartEntry.swift
//  KobelcoService
//
//  Created by Swaminath on 9/26/20.
//  Copyright © 2020 L&T. All rights reserved.
//
// swiftlint:disable force_cast

import UIKit

// Protocals for to add scan QR as a child and 
@objc protocol KSInjectorPartDelegate {
    func showConfirmationAlertIfRequired(UIType: String, injectorHandler: @escaping (Bool) -> Void)
    func addScanQRChildController()
    func removeScanQRChildContoller(QRCode: String)
}

class KSInjectorPartEntry: UIViewController {

    @IBOutlet weak var tableViewInjectorNumbers: UITableView!
    @IBOutlet weak var doneButton: UIButton!
    fileprivate var injectorsList = ["Inj. #1", "Inj. #2", "Inj. #3", "Inj. #4", "Inj. #5", "Inj. #6"]
    fileprivate var injectorNumbers = ["", "", "", "", "", ""]
    var scanQRViewController: KSScanInjectorQRCode?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Injector Part Number Entry")
        self.tableViewInjectorNumbers.rowHeight = 94
        self.tableViewInjectorNumbers.estimatedRowHeight = UITableView.automaticDimension
    }
    // Hide iPhoneX/Pro Footer-Line.
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
    
    // Click on this to submit updated injector values in websocket request.
    @IBAction func doneButtonAction(_ sender: Any) {
        self.doneButton.isEnabled = false
    }
}
// MARK: TableView Delegate
extension KSInjectorPartEntry: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return injectorsList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "KSInjectorNumberCell"
        let injectorCell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as! KSInjectorNumberCell
        injectorCell.buttonQRCode.tag = indexPath.row
        injectorCell.injectorDelegate = self
        injectorCell.configureInjectorCellDetails(injectorName: injectorsList[indexPath.row], injectorNumber: injectorNumbers[indexPath.row])
        injectorCell.buttonQRCode.addTarget(self, action: #selector(scanInjectorQRCode(_ :)), for: .touchUpInside)
        return injectorCell
    }
    
    // Click on this to change the default QR value with updated scan value.
    @objc fileprivate func scanInjectorQRCode(_ sender: UIButton) {
        self.showConfirmationAlertIfRequired(UIType: "BUTTON") { (isAlertShown) in
        }
    }
}

// MARK: Extension for add/remove child controllers.
extension KSInjectorPartEntry: KSInjectorPartDelegate {
    
    // Condition check for to show confirmation alert.
    func showConfirmationAlertIfRequired(UIType: String, injectorHandler: @escaping (Bool) -> Void) {
        if self.doneButton.isEnabled == false {
            self.presentAlertWithAction(title: "Confirmation", message: "Are you sure you want to change value?", action1Title: "No", action2Title: "Yes") { (isSuccess) in
                if isSuccess {
                    DispatchQueue.main.async {
                        injectorHandler(true)
                        self.doneButton.isEnabled = true
                        self.addScanQRChildController()
                    }
                }
            }
        } else {
            if UIType == "BUTTON" { // Navigate to QRScan controller when tap on scan button.
                self.addScanQRChildController()
            }
        }
    }
    // Used to add QR child controller on top of the current controller
    func addScanQRChildController() {
        let scanQRViewController = MAINSTORYBOARD.instantiateViewController(withIdentifier: Identifier.scanInjectorQRCode.rawValue) as! KSScanInjectorQRCode
        scanQRViewController.delegate = self
        scanQRViewController.modalPresentationStyle = .fullScreen
        self.present(scanQRViewController, animated: true, completion: nil)
    }

    // Called from scan QR code screen to remove the child controller
    func removeScanQRChildContoller(QRCode: String) {
    }
}
