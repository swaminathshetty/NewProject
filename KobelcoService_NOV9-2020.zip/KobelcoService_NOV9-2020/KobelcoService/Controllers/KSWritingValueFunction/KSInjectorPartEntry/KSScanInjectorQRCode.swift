//
//  KSScanInjectorQRCode.swift
//  KobelcoService
//
//  Created by Guest L&T on 09/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit
import AVFoundation

class KSScanInjectorQRCode: UIViewController, AVCaptureMetadataOutputObjectsDelegate {

    @IBOutlet weak var scanHeaderTitle: UILabel!
    @IBOutlet weak var scanSubTitle: UILabel!
    @IBOutlet weak var scanQRView: UIView!
    //Scan related properties
    fileprivate var captureSession: AVCaptureSession!
    fileprivate var previewLayer: AVCaptureVideoPreviewLayer!

    weak var delegate: KSInjectorPartDelegate!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        DispatchQueue.main.async {
            self.cameraPermissionRequest()
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if captureSession?.isRunning == false {
            captureSession.startRunning()
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if captureSession?.isRunning == true {
            captureSession.stopRunning()
        }
    }
    // Tap to dismiss the current controller
    @IBAction func scanQRCodeBackTap(_ sender: Any) {
        if AVCaptureDevice.authorizationStatus(for: .video) == .authorized {
            self.removePreviewLayers()
        }
    }
    // Clear session and preview layers fom mainview.
    func removePreviewLayers() {
        captureSession.stopRunning()
        //previewLayer.removeFromSuperlayer()
        //previewLayer.removeAllAnimations()
        self.dismiss(animated: true, completion: nil)
    }
    // Requesting for camera access to scan QRCode.
    func cameraPermissionRequest() {
        if AVCaptureDevice.authorizationStatus(for: .video) ==  .authorized {
            // already authorized
            print("already authorized")
            DispatchQueue.main.async {
                self.configureVideoCapture()
            }
        } else {
            AVCaptureDevice.requestAccess(for: .video, completionHandler: { (granted: Bool) in
                if granted {
                    // access allowed
                    print("access allowed")
                    DispatchQueue.main.async {
                        self.configureVideoCapture()
                    }
                } else {
                    // access denied
                    print("access denied")
                    DispatchQueue.main.async {
                        self.presentAlertWithAction(title: "Important", message: QRCODEMESSAGE, action1Title: "Cancel", action2Title: "Allow camera") { (isAllowCamera) in
                            if isAllowCamera {
                                KSSingletonManager.openWifiSettings() // It will open iPhone general settings screen
                            }
                        }
                    }
                }
            })
        }
    }
    
    // configure QRCode session
    func configureVideoCapture() {
        captureSession = AVCaptureSession()
        guard let videoCaptureDevice = AVCaptureDevice.default(for: .video) else {
            self.presentAlertOKAction(withTitle: QRCODEERRORTITLE, message: QRCODEERRORMESSAGE) { (isOkClicked) in
                if isOkClicked {
                    self.removePreviewLayers()
                }
            }
            return
        }
        let videoInput: AVCaptureDeviceInput
        do {
            videoInput = try AVCaptureDeviceInput(device: videoCaptureDevice)
        } catch {
            return
        }
        if captureSession.canAddInput(videoInput) {
            captureSession.addInput(videoInput)
        } else {
            self.presentAlert(withTitle: QRCODEERRORTITLE, message: QRCODEERRORMESSAGE)
            return
        }
        let metadataOutput = AVCaptureMetadataOutput()
        if captureSession.canAddOutput(metadataOutput) {
            captureSession.addOutput(metadataOutput)
            metadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
            metadataOutput.metadataObjectTypes = [.qr]

        } else {
            self.presentAlert(withTitle: QRCODEERRORTITLE, message: QRCODEERRORMESSAGE)
            return
        }
        self.addVideoPreviewLayer()
    }
    
    // Set video preview layer for scanning.
    func addVideoPreviewLayer() {
        previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        //setFramesForPreviewLayer()
        previewLayer.frame =  CGRect(x: 5, y: 5, width: scanQRView.frame.width - 10, height: scanQRView.frame.height - 10)
        previewLayer.videoGravity = .resizeAspectFill
        scanQRView?.layer.borderColor = UIColor.green.cgColor
        scanQRView?.layer.borderWidth = 5
        scanQRView.layer.addSublayer(previewLayer)
        
        captureSession.startRunning()
    }
    // Callback method to recieve qr scan output.
    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        captureSession.stopRunning()
        print("metadataObjects: \(metadataObjects)")

        if let metadataObject = metadataObjects.first {
            guard let readableObject = metadataObject as? AVMetadataMachineReadableCodeObject else { return }
            guard let stringValue = readableObject.stringValue else { return }
            AudioServicesPlaySystemSound(SystemSoundID(kSystemSoundID_Vibrate))
            found(code: stringValue)
        }

        dismiss(animated: true)
    }
    // Read QRCode string.
    func found(code: String) {
        print("code: \(code)")
        print(code)
    }

}
