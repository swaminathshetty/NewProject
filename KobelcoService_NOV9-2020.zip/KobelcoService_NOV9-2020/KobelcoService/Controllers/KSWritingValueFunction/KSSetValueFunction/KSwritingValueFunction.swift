//
//  KSwritingValueFunction.swift
//  KobelcoService
//
//  Created by Swaminath on 9/26/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSwritingValueFunction: UIViewController {
    
    @IBOutlet weak var tableViewWritingFunction: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEWBACKGROUNDCOLOR
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Set Value Writing Function")
        self.navigationItem.hidesBackButton = true
        loadWritingValueUIElements()
    }
    // Adding corner radius and row height of tableview.
    fileprivate func loadWritingValueUIElements() {
        tableViewWritingFunction.layer.cornerRadius = 8
        tableViewWritingFunction.rowHeight = 55
    }
}

// MARK: Tableview delegate
extension KSwritingValueFunction: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return SETVALUELIST.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: "Cell")
        cell.accessoryType = .disclosureIndicator
        cell.textLabel?.text = SETVALUELIST[indexPath.row]
        cell.textLabel?.font = UIFont.regular(ofSize: 15)
        cell.selectionStyle = .none
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.navigation(to: (indexPath.row == 0) ? Identifier.injectorPartEntry : Identifier.machineLearningStatus) //Used nil collision operator for navigation
    }
}
