//
//  KSDashboardModel.swift
//  KobelcoService
//
//  Created by Guest L&T on 15/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import Foundation

struct DashboardResponseDict: Codable {
    let screenName: String
    let frameType: String
    let device: String
    let ecuErrorCount: String
    let dcuErrorCount: String
}
