//
//  KSErrorCodeCell.swift
//  KobelcoService
//
//  Created by Swaminath on 9/16/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSErrorCodeCell: UITableViewCell {
    @IBOutlet weak var errorCodeBGView: UIView!
    @IBOutlet weak var label_ErrorCode: UILabel!
    @IBOutlet weak var label_Description: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
