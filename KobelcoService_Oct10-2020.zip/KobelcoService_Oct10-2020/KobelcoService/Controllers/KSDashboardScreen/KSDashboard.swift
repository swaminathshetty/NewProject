//
//  KSDashboard.swift
//  KobelcoService
//
//  Created by Guest L&T on 14/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSDashboard: UIViewController {

    @IBOutlet weak var label_NoConnection: UILabel!
    @IBOutlet weak var view_ErrorCodeDisplay: UIView!
    @IBOutlet weak var button_MemoryReset: UIButton!
    @IBOutlet weak var button_Diagnostic: UIButton!
    @IBOutlet weak var button_SetValueFunction: UIButton!
    @IBOutlet weak var button_DataMonitor: UIButton!
    @IBOutlet weak var button_DataComparision: UIButton!
    @IBOutlet weak var button_Configuration: UIButton!
    fileprivate var isViewPresented: Bool = true

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        self.navigationController?.navigationBar.isHidden = false
        self.navigationController?.getDashboardNavigationID()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarColorAndItems()
        self.view_ErrorCodeDisplay.layer.cornerRadius = 6
        isViewPresented = true
        configureTapGestureToErrorCodeView()
    }
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        if isViewPresented {
            self.hideCopyrightLabel()
            if UIDevice.current.orientation.isLandscape {
                self.showCopyrightLabel()
            } else {
                self.showCopyrightLabel()
            }
        }
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.showCopyrightLabel()
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.hideCopyrightLabel()
        isViewPresented = false
    }
    
    // Added tap gesture to errocode display view for errorcode screen navigation.
    fileprivate func configureTapGestureToErrorCodeView() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:)))
        view_ErrorCodeDisplay.addGestureRecognizer(tap)
    }
    
    // Tap geture action for errorcodedisplay view.
    @objc func handleTap(_ sender: UITapGestureRecognizer? = nil) {
        self.navigation(to: Identifier.errorCodeScreen)
    }
    
    // Tag based navigation for dashboard icons
    @IBAction func buttonTapAction(_ sender: UIButton) {
        switch sender.tag {
        case 0:
            self.navigation(to: Identifier.memoryResetScreen)
            break
        case 1:
            self.navigation(to: Identifier.setValueWritingFunction)
            break
        case 2:
            self.navigation(to: Identifier.diagnosticTest)
            break
        case 3:
            self.navigation(to: Identifier.dataMonitor)
            break
        case 4:
            self.navigation(to: Identifier.dataComparision)
            break
        case 5:
            self.navigation(to: Identifier.configuration)
            break
        default:
            break
        }
    }
}

