//
//  KSScanInjectorQRCode.swift
//  KobelcoService
//
//  Created by Guest L&T on 09/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSScanInjectorQRCode: UIViewController {

    @IBOutlet weak var scanHeaderTitle: UILabel!
    @IBOutlet weak var scanSubTitle: UILabel!
    @IBOutlet weak var scanQRView: UIView!
    weak var delegate: KSInjectorPartDelegate!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    // Tap to dismiss the current controller
    @IBAction func scanQRCodeBackTap(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
}
