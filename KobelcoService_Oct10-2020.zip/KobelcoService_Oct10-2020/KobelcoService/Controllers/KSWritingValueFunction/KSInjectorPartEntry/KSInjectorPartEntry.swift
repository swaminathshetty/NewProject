//
//  KSInjectorPartEntry.swift
//  KobelcoService
//
//  Created by Swaminath on 9/26/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

// Protocals for to add scan QR as a child and 
@objc protocol KSInjectorPartDelegate {
    func addScanQRChildController()
    func removeScanQRChildContoller(QRCode:  String)
}

class KSInjectorPartEntry: UIViewController {

    @IBOutlet weak var tableView_InjectorNumbers: UITableView!
    @IBOutlet weak var doneButton: UIButton!
    fileprivate var injectorsList = ["Inj. #1", "Inj. #2", "Inj. #3", "Inj. #4", "Inj. #5", "Inj. #6"]
    fileprivate var injectorNumbers = ["6353E0050171101856421FA0CD30CFBF0E0D1D5E700000000", "6353E0050171001087421F300C9F7F8E4E0EBD2E8000000C1", "6353E0050170902563421D4FCB5E5DCD4D1D3D0E000000063", "6353E00501710010654210306D00AF1E500E7E4FE00000017", "", ""]
    var scanQRViewController: KSScanInjectorQRCode?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Injector Part Number Entry")
        self.tableView_InjectorNumbers.rowHeight = 94
        self.tableView_InjectorNumbers.estimatedRowHeight = UITableView.automaticDimension
    }
    // Hide iPhoneX/Pro Footer-Line.
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
    
    // Click on this to submit updated injector values in websocket request.
    @IBAction func doneButtonAction(_ sender: Any) {
        self.doneButton.isEnabled = false
    }
}
// MARK:- TableView Delegate
extension KSInjectorPartEntry: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return injectorsList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "KSInjectorNumberCell"
        let injectorCell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as! KSInjectorNumberCell
        injectorCell.button_QRCode.tag = indexPath.row
        injectorCell.configureCellDetails(injectorName: injectorsList[indexPath.row], injectorNumber: injectorNumbers[indexPath.row])
        injectorCell.button_QRCode.addTarget(self, action: #selector(scanInjectorQRCode(_ :)), for: .touchUpInside)
        return injectorCell
    }
    
    // Click on this to change the default QR value with updated scan value.
    @objc fileprivate func scanInjectorQRCode(_ sender: UIButton) {
        if self.doneButton.isEnabled == false {
            self.presentAlertWithAction(title: "Confirmation", message: "Are you sure you want to change value?", action1Title: "No", action2Title: "Yes") { (isSuccess) in
                if isSuccess {
                    DispatchQueue.main.async {
                        self.doneButton.isEnabled = true
                        self.addScanQRChildController()
                    }
                }
            }
        } else {
            self.addScanQRChildController()
        }
    }
}

// MARK:- Extension for add/remove child controllers.
extension KSInjectorPartEntry: KSInjectorPartDelegate {
    
    // Used to add QR child controller on top of the current controller
    func addScanQRChildController() {
        let scanQRViewController = MAIN_STORYBOARD.instantiateViewController(withIdentifier: Identifier.scanInjectorQRCode.rawValue) as! KSScanInjectorQRCode
        scanQRViewController.delegate = self
        scanQRViewController.modalPresentationStyle = .fullScreen
        self.present(scanQRViewController, animated: true, completion: nil)
    }

    // Called from scan QR code screen to remove the child controller
    func removeScanQRChildContoller(QRCode:  String){
    }
}
