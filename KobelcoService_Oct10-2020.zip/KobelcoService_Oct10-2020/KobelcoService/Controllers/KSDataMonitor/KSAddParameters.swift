//
//  KSAddParameters.swift
//  KobelcoService
//
//  Created by Swaminath on 10/4/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSAddParameters: UIViewController {

    @IBOutlet weak var headerViewSetParameter: UIView!
    @IBOutlet weak var headerSetParameterButton: UIButton!
    @IBOutlet weak var tableviewSetDataParameters: UITableView!
    @IBOutlet weak var tableviewTheDataParameters: UITableView!
    @IBOutlet weak var engineSegmentMonitor: UISegmentedControl!
    @IBOutlet weak var segmentECUMonitor: UISegmentedControl!
    @IBOutlet weak var footerConfigureButton: UIButton!
    @IBOutlet weak var footerFavoriteButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Add Parameters")
        self.loadMonitorAddParametersUIComponents()
    }
    // Set custom property values to monitor add paramters UI elements.
    fileprivate func loadMonitorAddParametersUIComponents() {
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        self.headerViewSetParameter.layer.cornerRadius = 6
        self.engineSegmentMonitor.setSegmentTintColors()
        self.segmentECUMonitor.setSegmentTintColors()
    }
    // Click on this button to plot line graphs for the selected parameters.
    @IBAction func configurePlotButtonTapped(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    // Tap on this button to make/create favorite parameters.
    @IBAction func addFavoriteButtonTapped(_ sender: Any) {
        self.navigation(to: Identifier.createParameter)
    }
    
    // Toggle action for engine and pump selection.
    @IBAction func engineSegmentMonitorToggleAction(_ sender: Any) {
    }
    
    // Toggle segment controller for ECU & DCU engine selection.
    @IBAction func segmentECUMonitorToggleAction(_ sender: Any) {
    }
}

// MARK:- Tableview delegate
extension KSAddParameters: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == tableviewSetDataParameters {
            let setMonitorCell = tableView.dequeueReusableCell(withIdentifier: "KSParameterRegistrationCell") as! KSParameterRegistrationCell
            setMonitorCell.button_SetCheckBox.tag = indexPath.row
            setMonitorCell.button_SetCheckBox.addTarget(self, action: #selector(setDataParameterSelection(_ :)), for: .touchUpInside)
            return setMonitorCell
        } else {
            let theMonitorCell = tableView.dequeueReusableCell(withIdentifier: "KSTheParameterCell") as! KSTheParameterCell
            theMonitorCell.button_TheParametercheckBox.tag = indexPath.row
            theMonitorCell.button_TheParametercheckBox.addTarget(self, action: #selector(theDataParameterSelection(_ :)), for: .touchUpInside)
            return theMonitorCell
        }
    }
    
    // Called when clicking on set parameters items checkbox.
    @objc func setDataParameterSelection(_ sender: UIButton) {
    }
    
    // Called when clicking on the parameters items checkbox.
    @objc func theDataParameterSelection(_ sender: UIButton) {
    }
}

