//
//  KSTextFieldDropDown.swift
//  KobelcoService
//
//  Created by Swaminath on 10/6/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSTextFieldDropDown: UITextField {
    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        self.setCustomTextFieldStyle(imageNameString: "dropdownIcon")
    }
    

}
