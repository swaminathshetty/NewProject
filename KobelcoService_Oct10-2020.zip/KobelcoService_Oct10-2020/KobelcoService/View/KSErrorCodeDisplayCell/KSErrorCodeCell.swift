//
//  KSErrorCodeCell.swift
//  KobelcoService
//
//  Created by Swaminath on 9/16/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSErrorCodeCell: UITableViewCell {
    @IBOutlet weak var errorCodeBGView: UIView!
    @IBOutlet weak var label_ErrorCode: UILabel!
    @IBOutlet weak var label_Description: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    // Used for binding values and colors to the error code cell components.
    func configureCell(errorCode: String, description: String) {
        errorCodeBGView.clipsToBounds = true
        errorCodeBGView.layer.cornerRadius = 6
        label_ErrorCode.backgroundColor = HEADERVIEW_COLOR
        label_ErrorCode.text = errorCode
        label_ErrorCode.textColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        label_Description.textColor = #colorLiteral(red: 0.4549019608, green: 0.4549019608, blue: 0.4549019608, alpha: 1)
        label_Description.text = description
        label_Description.numberOfLines = 3
        label_Description.lineBreakMode = .byWordWrapping
    }
}
