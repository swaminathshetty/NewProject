//
//  KSNormalDataDownload.swift
//  KobelcoService
//
//  Created by Guest L&T on 08/10/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSNormalDataDownload: UIViewController {

    @IBOutlet weak var topHeaderView: UIView!
    @IBOutlet weak var headerTextLabel: UILabel!
    @IBOutlet weak var dataDownloadTableView: UITableView!
    @IBOutlet weak var downloadNormalDataButton: KSCustomButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Normal Data Acquisition")
    }
    
    // Configure Normal data UI components.
    fileprivate func loadDataDownloadViewComponents() {
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        self.topHeaderView.layer.cornerRadius = 6
        self.headerTextLabel.text = "Normal Data List"
        self.downloadNormalDataButton.setTitle("Data Acquisition", for: .normal)
    }
    // Click on this button to download selected normal data files from tableview.
    @IBAction func dataAcquisitionDataDownloadAction(_ sender: Any) {
    }
}

// MARK:- Tableview Delegate
extension KSNormalDataDownload: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return rowCountZeroCheckDataDownload(tableViewName: tableView, rowCount: 0)
    }
    // Condition check for tableview row count and add tableview background with records label if count == 0.
     fileprivate func rowCountZeroCheckDataDownload(tableViewName: UITableView, rowCount: Int) -> Int {
         if rowCount == 0 {
             DispatchQueue.main.async {
                 tableViewName.backgroundView =  KSSingletonManager.shared.nullDataFilesLabel()
             }
         } else {
             tableViewName.backgroundView = nil
         }
         return rowCount
     }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "KSEditParameterCell"
        let setCell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as! KSEditParameterCell
        setCell.checkBoxEditParameter.tag = indexPath.row
        setCell.checkBoxEditParameter.addTarget(self, action: #selector(selectDataAcquisitionFiles), for: .touchUpInside)
        return setCell
        
    }
    // Store locally when user selects data file names from tableview list for data acquisition.
    @objc func selectDataAcquisitionFiles(_ sender: UIButton) {
    }
}
