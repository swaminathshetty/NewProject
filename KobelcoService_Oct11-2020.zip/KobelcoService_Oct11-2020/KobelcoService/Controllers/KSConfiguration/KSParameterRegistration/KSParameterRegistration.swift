//
//  KSParameterRegistration.swift
//  KobelcoService
//
//  Created by Guest L&T on 30/09/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSParameterRegistration: UIViewController {

    @IBOutlet weak var view_SetParameter: UIView!
    @IBOutlet weak var view_TheParameter: UIView!
    @IBOutlet weak var label_SetParameter: UILabel!
    @IBOutlet weak var setParameterTableView: UITableView!
    @IBOutlet weak var enginePumpSegmentRegistration: UISegmentedControl!
    @IBOutlet weak var theParameterTableView: UITableView!
    @IBOutlet weak var button_Favorite: UIButton!
    @IBOutlet weak var registartionECUDCUSegment: UISegmentedControl!
    @IBOutlet weak var button_Edit: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Parameter Registration(Favorite)")
        setUpUIParameterRegistrationComponents()
    }
    // Autohide for iPhone Footer Line.
    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }
    // Configure UI Components.
    fileprivate func setUpUIParameterRegistrationComponents() {
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        self.view_SetParameter.layer.cornerRadius = 6
        self.view_TheParameter.layer.cornerRadius = 6
        self.button_Edit.setTitle("Edit", for: .normal)
        self.enginePumpSegmentRegistration.setSegmentTintColors()
        self.registartionECUDCUSegment.setSegmentTintColors()
    }
    
    // Toggle segment for engine and pump selection.
    // By default engine and ECU will select and display respective list in the parameter tableview.
    @IBAction func enginePumpRegistrationmainSegmentAction(_ sender: Any) {
    }
    
    // Click on this to create temperory favorite parameter name.
    @IBAction func favoriteButtonTapAction(_ sender: UIButton) {
    }
    
    // Click on this to navigate to edit parameter screen for to edit parameter name and items.
    @IBAction func editButtonTapAction(_ sender: UIButton) {
        self.navigation(to: Identifier.parameterEditScreen)
    }
    
    // Toggle action for the parameters tableview list.
    // If ECU/DCU selected display only ECU/DCU related parameters in the paramter tableview.
    @IBAction func footerRegistrationECUDCUSegmentAction(_ sender: Any) {
    }
}

// MARK:- Tableview delegate
extension KSParameterRegistration: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == setParameterTableView {
            let setParameterCell = tableView.dequeueReusableCell(withIdentifier: "KSParameterRegistrationCell") as! KSParameterRegistrationCell
            setParameterCell.button_SetCheckBox.tag = indexPath.row
            setParameterCell.button_SetCheckBox.addTarget(self, action: #selector(setRegistrationParameterSelection(_ :)), for: .touchUpInside)
            return setParameterCell
        } else {
            let theParameterCell = tableView.dequeueReusableCell(withIdentifier: "KSTheParameterCell") as! KSTheParameterCell
            theParameterCell.button_TheParametercheckBox.tag = indexPath.row
            theParameterCell.button_TheParametercheckBox.addTarget(self, action: #selector(theRegistrationParameterSelection(_ :)), for: .touchUpInside)
            return theParameterCell
        }
    }
    @objc func setRegistrationParameterSelection(_ sender: UIButton) {
    }
    @objc func theRegistrationParameterSelection(_ sender: UIButton) {
    }
}
