//
//  KSDiagnosticTestFunction.swift
//  KobelcoService
//
//  Created by Swaminath on 9/27/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit
@objc protocol KSDiagnosticMainTableViewDelegate {
    func clickOnAttritubedAlertViewOkButton(returnType: Int)
}
class KSDiagnosticTestFunction: UIViewController {
    
    @IBOutlet weak var tableView_Diagnostics: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setNavigationBarColorWithButtonTitle(buttonTitle: "Diagnostic Test Function")
        self.navigationItem.hidesBackButton = true
        loadDiagnosticsUIComponets()
    }
    // Assign additional/custom property values to diagnostic UI components.
    fileprivate func loadDiagnosticsUIComponets() {
        self.view.backgroundColor = VIEW_BACKGROUND_COLOR
        tableView_Diagnostics.layer.cornerRadius = 8
        tableView_Diagnostics.estimatedRowHeight = 55
        tableView_Diagnostics.rowHeight = UITableView.automaticDimension
    }
    // Attributed alertview on button action.
    func clickOnAttritubedAlertViewOkButton(returnType: Int) {
        switch returnType {
        case 0:
            self.navigation(to: Identifier.diagnosticNormal) // Diagnostic value display screen.
            break
        case 1:
            self.navigation(to: Identifier.diagnosticSwitch) // Diagnostic switch display screen.
            break
        case 2:
            self.navigation(to: Identifier.diagnosticUpDown) // Diagnostic updown arrow functionality screen.
            break
        default:
            break
        }
    }
}
// MARK:- Tableview delegate
extension KSDiagnosticTestFunction: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return DIAGNOSTICLIST.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: "Cell")
        cell.accessoryType = .disclosureIndicator
        cell.textLabel?.text = DIAGNOSTICLIST[indexPath.row]
        cell.textLabel?.lineBreakMode = .byWordWrapping
        cell.textLabel?.textColor = .darkGray
        cell.textLabel?.font = UIFont.regular(ofSize: 15)
        cell.textLabel?.numberOfLines = 0 // label height increases based on text
        cell.selectionStyle = .none // set clear color on selection
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        KSSingletonManager.shared.diagnosticNavigationTitle = DIAGNOSTICLIST[indexPath.row]
        showAttributedTextAlert(diagnosticType: indexPath.row)
    }
    // Custom AlertView with 2 titles
    fileprivate func showAttributedTextAlert(diagnosticType: Int) {
        let description1 = "Performs a different pressure check. The engine speed will increase automatically, so pay close attention to the safety of your surroundings"
        let description2 = "In the idle state, set the gear to the neutral position"
        
        DispatchQueue.main.async {
            self.presentAttributedStringAlert(message1: description1, message2: description2) { (isClickedOnOK) in
                if isClickedOnOK {
                    self.clickOnAttritubedAlertViewOkButton(returnType: diagnosticType)
                }
            }
        }
    }
}
