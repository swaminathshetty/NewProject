//
//  KSMachineLearningCell.swift
//  KobelcoService
//
//  Created by Swaminath on 9/26/20.
//  Copyright © 2020 L&T. All rights reserved.
//

import UIKit

class KSMachineLearningCell: UITableViewCell {

    @IBOutlet weak var BGLearningView: UIView!
    @IBOutlet weak var learningItemName: UIButton!
    @IBOutlet weak var learningValue: UILabel!
    @IBOutlet weak var learningUnits: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.BGLearningView.layer.cornerRadius = 6
    }

    // Data binding cell function for machine learning itemname, value and unit.
    func configureMachineLearningStatusCellTitle(itemName: String) {
        self.learningItemName.setTitle(itemName, for: .normal)
        self.learningValue.text = "-"
        self.learningUnits.text = "-"
    }

}
